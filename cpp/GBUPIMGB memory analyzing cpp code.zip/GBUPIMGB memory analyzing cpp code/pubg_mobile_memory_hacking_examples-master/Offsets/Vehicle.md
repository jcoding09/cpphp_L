## Pubg Mobile Vehicle Entity Offsets

![Pubg Mobile Vehicle Entity Offsets](https://raw.githubusercontent.com/atiksoftware/pubg_mobile_memory_hacking_examples/master/Offsets/images/ReClassVehicle.png "Pubg Mobile Vehicle Entity Offsets")
 