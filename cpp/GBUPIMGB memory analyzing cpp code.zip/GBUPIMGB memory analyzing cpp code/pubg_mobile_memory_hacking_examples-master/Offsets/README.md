## Pubg Mobile Entity Offsets

[![Pubg Mobile Player Entity Offsets](https://raw.githubusercontent.com/atiksoftware/pubg_mobile_memory_hacking_examples/master/Offsets/images/ReClassThumbnailPlayer.png)](Player.md)
[![Pubg Mobile Vehicle Entity Offsets](https://raw.githubusercontent.com/atiksoftware/pubg_mobile_memory_hacking_examples/master/Offsets/images/ReClassThumbnailVehicle.png)](Vehicle.md)
[![Pubg Mobile Invetory Entity Offsets](https://raw.githubusercontent.com/atiksoftware/pubg_mobile_memory_hacking_examples/master/Offsets/images/ReClassThumbnailInventory.png)](Inventory.md)