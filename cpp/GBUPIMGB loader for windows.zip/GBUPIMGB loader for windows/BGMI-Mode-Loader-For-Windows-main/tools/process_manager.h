#ifndef PROCESS_MANAGER_H
#define PROCESS_MANAGER_H

#include <QtCore/QObject>
#include <QtCore/QString>
#include <QtCore/QStringList>
#include <QtCore/QTimer>
#include <memory>
#include <vector>

struct ProcessInfo
{
    quint32 processId;
    QString processName;
    QString executablePath;
    QString windowTitle;
    qint64 memoryUsage;
    double cpuUsage;
    QString status;
    bool isTarget;
};

class ProcessManager : public QObject
{
    Q_OBJECT

public:
    explicit ProcessManager(QObject *parent = nullptr);
    ~ProcessManager();

    // Process management
    bool attachToProcess(const QString &processName);
    bool attachToProcess(quint32 processId);
    void detachFromProcess();
    bool isAttached() const;
    
    // Process information
    ProcessInfo getCurrentProcessInfo() const;
    std::vector<ProcessInfo> getRunningProcesses() const;
    ProcessInfo getProcessInfo(quint32 processId) const;
    ProcessInfo getProcessInfo(const QString &processName) const;
    
    // Process monitoring
    void startMonitoring();
    void stopMonitoring();
    void setTargetProcess(const QString &processName);
    QString getTargetProcess() const;
    
    // Process utilities
    bool isProcessRunning(const QString &processName) const;
    bool isProcessRunning(quint32 processId) const;
    QStringList getProcessModules(quint32 processId) const;
    
    // Memory operations
    bool readProcessMemory(qint64 address, void *buffer, size_t size) const;
    bool writeProcessMemory(qint64 address, const void *buffer, size_t size) const;
    qint64 allocateMemory(size_t size) const;
    bool freeMemory(qint64 address) const;
    
signals:
    void processAttached(const ProcessInfo &info);
    void processDetached();
    void targetProcessFound(const ProcessInfo &info);
    void targetProcessLost();
    void processListUpdated(const std::vector<ProcessInfo> &processes);
    
private slots:
    void checkProcesses();
    void updateProcessInfo();
    
private:
    class ProcessManagerPrivate;
    std::unique_ptr<ProcessManagerPrivate> d;
};

#endif // PROCESS_MANAGER_H