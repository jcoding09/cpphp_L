#ifndef MEMORY_SCANNER_H
#define MEMORY_SCANNER_H

#include <QtCore/QObject>
#include <QtCore/QThread>
#include <QtCore/QMutex>
#include <QtCore/QWaitCondition>
#include <QtCore/QTimer>
#include <QtCore/QDateTime>
#include <QtCore/QMap>
#include <QtCore/QList>
#include <QtCore/QStringList>
#include <QtCore/QByteArray>
#include <QtCore/QVariant>
#include <QtGui/QVector3D>
#include <memory>

// Forward declarations
class MemoryManager;
class Logger;

enum class ScanType {
    ExactValue = 0,
    IncreasedValue = 1,
    DecreasedValue = 2,
    ChangedValue = 3,
    UnchangedValue = 4,
    UnknownInitialValue = 5,
    RangeValue = 6,
    PatternScan = 7,
    StringScan = 8,
    PointerScan = 9,
    StructureScan = 10,
    ArrayScan = 11
};

enum class ValueType {
    Byte = 0,
    Short = 1,
    Integer = 2,
    Long = 3,
    Float = 4,
    Double = 5,
    String = 6,
    ByteArray = 7,
    Pointer = 8,
    Vector3D = 9,
    Custom = 10
};

enum class ScanRegion {
    All = 0,
    Heap = 1,
    Stack = 2,
    Code = 3,
    Data = 4,
    Modules = 5,
    Custom = 6
};

enum class ScanSpeed {
    Slow = 0,
    Normal = 1,
    Fast = 2,
    Turbo = 3
};

enum class ScanAlignment {
    None = 0,
    Byte = 1,
    Word = 2,
    DWord = 4,
    QWord = 8,
    Custom = 16
};

enum class ScanStatus {
    Idle = 0,
    Scanning = 1,
    Paused = 2,
    Completed = 3,
    Cancelled = 4,
    Error = 5
};

struct ScanResult {
    quint64 address = 0;
    QVariant value;
    ValueType type = ValueType::Integer;
    QString description;
    QDateTime timestamp;
    bool verified = false;
    int confidence = 100;
    QByteArray originalBytes;
    QByteArray currentBytes;
    QString moduleName;
    quint64 moduleOffset = 0;
    QList<quint64> pointerChain;
    QMap<QString, QVariant> metadata;
};

struct ScanConfiguration {
    ScanType scanType = ScanType::ExactValue;
    ValueType valueType = ValueType::Integer;
    ScanRegion scanRegion = ScanRegion::All;
    ScanSpeed scanSpeed = ScanSpeed::Normal;
    ScanAlignment alignment = ScanAlignment::DWord;
    
    QVariant searchValue;
    QVariant minValue;
    QVariant maxValue;
    QString searchPattern;
    QString searchString;
    bool caseSensitive = false;
    bool unicode = false;
    
    quint64 startAddress = 0;
    quint64 endAddress = 0;
    QStringList includeModules;
    QStringList excludeModules;
    
    bool readOnly = false;
    bool writable = true;
    bool executable = false;
    bool privateMemory = true;
    bool sharedMemory = false;
    
    int maxResults = 10000;
    int threadCount = 4;
    int chunkSize = 1024 * 1024; // 1MB
    bool pauseOnResults = false;
    bool verifyResults = true;
    
    bool enableLogging = true;
    bool enableStatistics = true;
    bool enableCaching = true;
    bool enableOptimization = true;
    
    QString sessionName = "Default";
    QString description;
    QMap<QString, QVariant> customSettings;
};

struct ScanStatistics {
    QDateTime scanStartTime;
    QDateTime scanEndTime;
    int totalScans = 0;
    int successfulScans = 0;
    int failedScans = 0;
    int cancelledScans = 0;
    
    quint64 totalBytesScanned = 0;
    quint64 totalAddressesScanned = 0;
    int totalResultsFound = 0;
    int verifiedResults = 0;
    int falsePositives = 0;
    
    float averageScanTime = 0.0f;
    float fastestScanTime = 999999.0f;
    float slowestScanTime = 0.0f;
    float averageResultsPerScan = 0.0f;
    
    QMap<ScanType, int> scanTypeUsage;
    QMap<ValueType, int> valueTypeUsage;
    QMap<ScanRegion, int> regionUsage;
    QMap<QString, int> moduleUsage;
    
    int memoryErrors = 0;
    int accessViolations = 0;
    int timeouts = 0;
    QStringList recentErrors;
    
    float cpuUsage = 0.0f;
    float memoryUsage = 0.0f;
    int peakThreadCount = 0;
    quint64 peakMemoryUsage = 0;
};

struct PointerPath {
    quint64 baseAddress = 0;
    QList<quint64> offsets;
    QString moduleName;
    QString description;
    bool isStatic = false;
    bool isValid = false;
    int depth = 0;
    QDateTime lastValidated;
    int validationCount = 0;
    float reliability = 0.0f;
};

struct MemoryRegion {
    quint64 startAddress = 0;
    quint64 endAddress = 0;
    quint64 size = 0;
    QString protection;
    QString type;
    QString moduleName;
    QString description;
    bool readable = false;
    bool writable = false;
    bool executable = false;
    bool isPrivate = false;
    bool isShared = false;
    QDateTime lastAccessed;
};

class MemoryScanner : public QObject
{
    Q_OBJECT

public:
    explicit MemoryScanner(QObject *parent = nullptr);
    ~MemoryScanner();
    
    // Component integration
    void setMemoryManager(MemoryManager *memoryManager);
    void setLogger(Logger *logger);
    
    // Configuration management
    void setConfiguration(const ScanConfiguration &config);
    ScanConfiguration getConfiguration() const;
    void loadConfiguration(const QString &name);
    void saveConfiguration(const QString &name);
    void resetConfiguration();
    QStringList getAvailableConfigurations() const;
    
    // Scan control
    void startScan();
    void pauseScan();
    void resumeScan();
    void stopScan();
    void cancelScan();
    ScanStatus getStatus() const;
    float getProgress() const;
    
    // Scan methods
    void scanForExactValue(const QVariant &value, ValueType type);
    void scanForChangedValue();
    void scanForUnchangedValue();
    void scanForIncreasedValue();
    void scanForDecreasedValue();
    void scanForRangeValue(const QVariant &min, const QVariant &max, ValueType type);
    void scanForPattern(const QString &pattern);
    void scanForString(const QString &text, bool caseSensitive = false, bool unicode = false);
    void scanForPointer(quint64 targetAddress);
    void scanForStructure(const QByteArray &structure);
    void scanForArray(const QVariant &value, ValueType type, int arraySize);
    
    // Advanced scanning
    void scanWithCustomFilter(std::function<bool(quint64, const QByteArray&)> filter);
    void scanMemoryRegion(quint64 startAddress, quint64 endAddress);
    void scanModule(const QString &moduleName);
    void scanMultipleModules(const QStringList &moduleNames);
    void rescanResults();
    void refineResults(const ScanConfiguration &refinementConfig);
    
    // Pointer scanning
    void startPointerScan(quint64 targetAddress, int maxDepth = 5);
    void generatePointerMap();
    QList<PointerPath> findPointerPaths(quint64 targetAddress, int maxDepth = 5);
    bool validatePointerPath(const PointerPath &path);
    void updatePointerPaths();
    
    // Result management
    QList<ScanResult> getResults() const;
    QList<ScanResult> getFilteredResults(const QString &filter) const;
    ScanResult getResult(int index) const;
    void clearResults();
    void removeResult(int index);
    void removeResults(const QList<int> &indices);
    void exportResults(const QString &filename, const QString &format = "csv");
    void importResults(const QString &filename);
    
    // Result verification
    void verifyResults();
    void verifyResult(int index);
    bool isResultValid(int index) const;
    void updateResultValues();
    void trackResultChanges();
    
    // Memory region analysis
    QList<MemoryRegion> getMemoryRegions() const;
    QList<MemoryRegion> getModuleRegions(const QString &moduleName) const;
    MemoryRegion getRegionAt(quint64 address) const;
    void refreshMemoryMap();
    void analyzeMemoryLayout();
    
    // Value operations
    QVariant readValue(quint64 address, ValueType type) const;
    bool writeValue(quint64 address, const QVariant &value, ValueType type);
    QByteArray readBytes(quint64 address, int size) const;
    bool writeBytes(quint64 address, const QByteArray &data);
    bool freezeValue(quint64 address, const QVariant &value, ValueType type);
    void unfreezeValue(quint64 address);
    void unfreezeAllValues();
    
    // Pattern utilities
    QString bytesToPattern(const QByteArray &bytes) const;
    QByteArray patternToBytes(const QString &pattern) const;
    bool isValidPattern(const QString &pattern) const;
    QString generatePattern(quint64 address, int size, bool includeWildcards = true) const;
    
    // Statistics and monitoring
    ScanStatistics getStatistics() const;
    void resetStatistics();
    void updateStatistics();
    QString getPerformanceReport() const;
    QString getMemoryUsageReport() const;
    
    // Session management
    void saveSession(const QString &name);
    void loadSession(const QString &name);
    void deleteSession(const QString &name);
    QStringList getAvailableSessions() const;
    void exportSession(const QString &filename);
    void importSession(const QString &filename);
    
public slots:
    // Configuration slots
    void onConfigurationChanged(const ScanConfiguration &config);
    void onScanTypeChanged(int type);
    void onValueTypeChanged(int type);
    void onScanRegionChanged(int region);
    void onScanSpeedChanged(int speed);
    void onAlignmentChanged(int alignment);
    void onMaxResultsChanged(int maxResults);
    void onThreadCountChanged(int threadCount);
    void onChunkSizeChanged(int chunkSize);
    
    // Search value slots
    void onSearchValueChanged(const QVariant &value);
    void onMinValueChanged(const QVariant &value);
    void onMaxValueChanged(const QVariant &value);
    void onSearchPatternChanged(const QString &pattern);
    void onSearchStringChanged(const QString &text);
    void onCaseSensitiveChanged(bool enabled);
    void onUnicodeChanged(bool enabled);
    
    // Region slots
    void onStartAddressChanged(quint64 address);
    void onEndAddressChanged(quint64 address);
    void onIncludeModulesChanged(const QStringList &modules);
    void onExcludeModulesChanged(const QStringList &modules);
    void onReadOnlyChanged(bool enabled);
    void onWritableChanged(bool enabled);
    void onExecutableChanged(bool enabled);
    void onPrivateMemoryChanged(bool enabled);
    void onSharedMemoryChanged(bool enabled);
    
    // Control slots
    void onStartScanRequested();
    void onPauseScanRequested();
    void onResumeScanRequested();
    void onStopScanRequested();
    void onCancelScanRequested();
    void onRescanRequested();
    void onRefineRequested();
    
    // Result slots
    void onResultSelected(int index);
    void onResultDoubleClicked(int index);
    void onResultsCleared();
    void onResultRemoved(int index);
    void onResultsExported(const QString &filename, const QString &format);
    void onResultsImported(const QString &filename);
    void onVerifyResultsRequested();
    void onUpdateResultsRequested();
    
    // Value operation slots
    void onValueRead(quint64 address, int type);
    void onValueWritten(quint64 address, const QVariant &value, int type);
    void onValueFrozen(quint64 address, const QVariant &value, int type);
    void onValueUnfrozen(quint64 address);
    void onAllValuesUnfrozen();
    
    // Pointer scanning slots
    void onPointerScanRequested(quint64 targetAddress, int maxDepth);
    void onPointerMapRequested();
    void onPointerPathValidationRequested(const PointerPath &path);
    void onPointerPathsUpdateRequested();
    
    // Memory region slots
    void onMemoryMapRefreshRequested();
    void onMemoryLayoutAnalysisRequested();
    void onRegionSelected(quint64 startAddress, quint64 endAddress);
    void onModuleSelected(const QString &moduleName);
    
    // Session slots
    void onSessionSaved(const QString &name);
    void onSessionLoaded(const QString &name);
    void onSessionDeleted(const QString &name);
    void onSessionExported(const QString &filename);
    void onSessionImported(const QString &filename);
    
    // Statistics slots
    void onStatisticsRequested();
    void onStatisticsReset();
    void onPerformanceReportRequested();
    void onMemoryUsageReportRequested();
    
signals:
    void scanStarted();
    void scanPaused();
    void scanResumed();
    void scanStopped();
    void scanCancelled();
    void scanCompleted();
    void scanError(const QString &error);
    void progressChanged(float progress);
    void statusChanged(ScanStatus status);
    
    void resultFound(const ScanResult &result);
    void resultsCleared();
    void resultRemoved(int index);
    void resultUpdated(int index, const ScanResult &result);
    void resultVerified(int index, bool valid);
    void resultCountChanged(int count);
    
    void valueRead(quint64 address, const QVariant &value);
    void valueWritten(quint64 address, const QVariant &value);
    void valueFrozen(quint64 address, const QVariant &value);
    void valueUnfrozen(quint64 address);
    void valueChanged(quint64 address, const QVariant &oldValue, const QVariant &newValue);
    
    void pointerScanStarted(quint64 targetAddress);
    void pointerScanCompleted(const QList<PointerPath> &paths);
    void pointerPathFound(const PointerPath &path);
    void pointerPathValidated(const PointerPath &path, bool valid);
    void pointerMapGenerated();
    
    void memoryMapRefreshed();
    void memoryLayoutAnalyzed();
    void memoryRegionFound(const MemoryRegion &region);
    void memoryAccessViolation(quint64 address);
    
    void configurationChanged(const ScanConfiguration &config);
    void statisticsUpdated(const ScanStatistics &stats);
    void sessionSaved(const QString &name);
    void sessionLoaded(const QString &name);
    
private slots:
    void onScanThreadFinished();
    void onScanThreadError(const QString &error);
    void onProgressUpdate(float progress);
    void onResultsUpdate(const QList<ScanResult> &results);
    void onStatisticsTimer();
    void onFrozenValuesTimer();
    void onMemoryMapTimer();
    
private:
    // Core scanning functionality
    void performScan();
    void scanMemoryChunk(quint64 startAddress, quint64 endAddress);
    bool matchesSearchCriteria(quint64 address, const QByteArray &data) const;
    bool matchesExactValue(const QByteArray &data, const QVariant &value, ValueType type) const;
    bool matchesPattern(const QByteArray &data, const QString &pattern) const;
    bool matchesString(const QByteArray &data, const QString &text, bool caseSensitive, bool unicode) const;
    bool matchesRange(const QByteArray &data, const QVariant &min, const QVariant &max, ValueType type) const;
    
    // Value conversion and validation
    QVariant bytesToValue(const QByteArray &bytes, ValueType type) const;
    QByteArray valueToBytes(const QVariant &value, ValueType type) const;
    bool isValidValue(const QVariant &value, ValueType type) const;
    int getValueSize(ValueType type) const;
    QString valueToString(const QVariant &value, ValueType type) const;
    QVariant stringToValue(const QString &text, ValueType type) const;
    
    // Memory region management
    void updateMemoryRegions();
    bool isAddressInRegion(quint64 address, const MemoryRegion &region) const;
    bool isRegionScannable(const MemoryRegion &region) const;
    QList<MemoryRegion> getScannableRegions() const;
    MemoryRegion createRegionFromAddress(quint64 address, quint64 size) const;
    
    // Pattern processing
    QByteArray processPattern(const QString &pattern) const;
    QByteArray createPatternMask(const QString &pattern) const;
    bool patternMatch(const QByteArray &data, const QByteArray &pattern, const QByteArray &mask) const;
    QString normalizePattern(const QString &pattern) const;
    
    // Pointer scanning implementation
    void performPointerScan(quint64 targetAddress, int maxDepth);
    void findPointersToAddress(quint64 targetAddress, int currentDepth, int maxDepth, QList<quint64> &currentPath, QList<PointerPath> &results);
    bool isValidPointer(quint64 address) const;
    quint64 dereferencePointer(quint64 address) const;
    PointerPath createPointerPath(const QList<quint64> &addresses, const QString &moduleName) const;
    
    // Result processing
    void addResult(const ScanResult &result);
    void updateResult(int index, const ScanResult &result);
    void sortResults();
    void filterResults();
    void deduplicateResults();
    void validateResults();
    ScanResult createResult(quint64 address, const QVariant &value, ValueType type) const;
    
    // Threading and performance
    void initializeThreads();
    void cleanupThreads();
    void distributeWork();
    void optimizeScanParameters();
    void adjustThreadCount();
    void monitorPerformance();
    
    // Frozen values management
    void updateFrozenValues();
    void addFrozenValue(quint64 address, const QVariant &value, ValueType type);
    void removeFrozenValue(quint64 address);
    bool isFrozenValue(quint64 address) const;
    
    // Statistics and monitoring
    void updateScanStatistics();
    void updatePerformanceStatistics();
    void updateMemoryStatistics();
    void updateErrorStatistics(const QString &error);
    void logScanEvent(const QString &event);
    void logPerformanceMetrics();
    
    // Configuration management
    void validateConfiguration();
    void optimizeConfiguration();
    void saveConfigurationToFile(const QString &filename);
    void loadConfigurationFromFile(const QString &filename);
    
    // Session management
    void saveSessionData(const QString &filename);
    void loadSessionData(const QString &filename);
    void validateSessionData();
    void migrateSessionData();
    
    // Error handling
    void handleScanError(const QString &error);
    void handleMemoryError(quint64 address);
    void handleAccessViolation(quint64 address);
    void handleTimeout();
    void recoverFromError();
    
    // Utility functions
    QString formatAddress(quint64 address) const;
    QString formatSize(quint64 size) const;
    QString formatTime(float seconds) const;
    QString formatProgress(float progress) const;
    bool isValidAddress(quint64 address) const;
    quint64 alignAddress(quint64 address, int alignment) const;
    
    // Core components
    MemoryManager *m_memoryManager;
    Logger *m_logger;
    
    // Configuration
    ScanConfiguration m_configuration;
    QMap<QString, ScanConfiguration> m_savedConfigurations;
    
    // Scan state
    ScanStatus m_status;
    float m_progress;
    QDateTime m_scanStartTime;
    QDateTime m_scanEndTime;
    
    // Results
    QList<ScanResult> m_results;
    QList<ScanResult> m_previousResults;
    QMap<quint64, ScanResult> m_resultMap;
    int m_maxResults;
    
    // Memory regions
    QList<MemoryRegion> m_memoryRegions;
    QMap<QString, QList<MemoryRegion>> m_moduleRegions;
    QDateTime m_lastMemoryMapUpdate;
    
    // Pointer scanning
    QList<PointerPath> m_pointerPaths;
    QMap<quint64, QList<quint64>> m_pointerMap;
    bool m_pointerScanActive;
    
    // Frozen values
    QMap<quint64, QPair<QVariant, ValueType>> m_frozenValues;
    QTimer *m_frozenValuesTimer;
    
    // Statistics
    ScanStatistics m_statistics;
    QDateTime m_lastStatisticsUpdate;
    
    // Threading
    QList<QThread*> m_scanThreads;
    QMutex m_resultsMutex;
    QMutex m_statisticsMutex;
    QWaitCondition m_pauseCondition;
    bool m_pauseRequested;
    bool m_cancelRequested;
    
    // Performance monitoring
    QTimer *m_statisticsTimer;
    QTimer *m_memoryMapTimer;
    QDateTime m_lastPerformanceUpdate;
    float m_cpuUsage;
    quint64 m_memoryUsage;
    
    // Session data
    QString m_currentSession;
    QMap<QString, QString> m_savedSessions;
    
    // Constants
    static const int DEFAULT_MAX_RESULTS = 10000;
    static const int DEFAULT_THREAD_COUNT = 4;
    static const int DEFAULT_CHUNK_SIZE = 1024 * 1024; // 1MB
    static const int STATISTICS_UPDATE_INTERVAL = 1000; // 1 second
    static const int FROZEN_VALUES_UPDATE_INTERVAL = 100; // 100ms
    static const int MEMORY_MAP_UPDATE_INTERVAL = 30000; // 30 seconds
    static const int MAX_POINTER_DEPTH = 10;
    static const int MAX_SCAN_THREADS = 16;
    static const float DETECTION_RISK_THRESHOLD = 0.8f;
};

#endif // MEMORY_SCANNER_H