#include "module_manager.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>
#include <QDir>
#include <QStandardPaths>
#include <QMutexLocker>
#include <QTimer>
#include <QDebug>
#include <QLibrary>
#include <QPluginLoader>
#include <QCoreApplication>
#include <QThread>
#include <QProcess>

ModuleManager::ModuleManager(QObject *parent)
    : QObject(parent)
    , m_initialized(false)
    , m_autoLoad(true)
    , m_autoUnload(false)
    , m_dependencyResolution(true)
    , m_versionChecking(true)
    , m_signatureVerification(false)
    , m_sandboxMode(false)
    , m_hotReload(false)
    , m_debugMode(false)
    , m_maxModules(50)
    , m_loadTimeout(30000)
    , m_unloadTimeout(10000)
{
    // Initialize timers
    m_updateTimer = new QTimer(this);
    m_watchdogTimer = new QTimer(this);
    m_cleanupTimer = new QTimer(this);
    
    // Connect timer signals
    connect(m_updateTimer, &QTimer::timeout, this, &ModuleManager::onUpdateTimer);
    connect(m_watchdogTimer, &QTimer::timeout, this, &ModuleManager::onWatchdogTimer);
    connect(m_cleanupTimer, &QTimer::timeout, this, &ModuleManager::onCleanupTimer);
    
    // Initialize statistics
    initializeStatistics();
}

ModuleManager::~ModuleManager()
{
    cleanup();
}

bool ModuleManager::initialize()
{
    QMutexLocker locker(&m_mutex);
    
    if (m_initialized) {
        return true;
    }
    
    try {
        // Create modules directory
        QString modulesDir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/modules";
        QDir().mkpath(modulesDir);
        m_modulesPath = modulesDir;
        
        // Load module registry
        loadModuleRegistry();
        
        // Scan for available modules
        scanForModules();
        
        // Auto-load modules if enabled
        if (m_autoLoad) {
            loadAutoStartModules();
        }
        
        // Start timers
        m_updateTimer->start(5000); // 5 seconds
        m_watchdogTimer->start(10000); // 10 seconds
        m_cleanupTimer->start(300000); // 5 minutes
        
        m_initialized = true;
        emit statusChanged("Module manager initialized successfully");
        
        return true;
    }
    catch (const std::exception& e) {
        emit errorOccurred(QString("Failed to initialize module manager: %1").arg(e.what()));
        return false;
    }
}

void ModuleManager::cleanup()
{
    QMutexLocker locker(&m_mutex);
    
    // Stop timers
    if (m_updateTimer) m_updateTimer->stop();
    if (m_watchdogTimer) m_watchdogTimer->stop();
    if (m_cleanupTimer) m_cleanupTimer->stop();
    
    // Unload all modules
    unloadAllModules();
    
    // Clear data
    m_modules.clear();
    m_loadedModules.clear();
    m_dependencies.clear();
    
    m_initialized = false;
}

void ModuleManager::initializeStatistics()
{
    m_statistics.totalModules = 0;
    m_statistics.loadedModules = 0;
    m_statistics.failedLoads = 0;
    m_statistics.totalLoads = 0;
    m_statistics.totalUnloads = 0;
    m_statistics.averageLoadTime = 0;
    m_statistics.lastUpdate = QDateTime::currentDateTime();
    m_statistics.uptime = 0;
    m_statistics.memoryUsage = 0;
    m_statistics.cpuUsage = 0.0;
}

// Module Loading
bool ModuleManager::loadModule(const QString& name)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_initialized) {
        emit errorOccurred("Module manager not initialized");
        return false;
    }
    
    if (isModuleLoaded(name)) {
        emit statusChanged(QString("Module '%1' is already loaded").arg(name));
        return true;
    }
    
    if (!m_modules.contains(name)) {
        emit errorOccurred(QString("Module '%1' not found").arg(name));
        return false;
    }
    
    ModuleInfo& moduleInfo = m_modules[name];
    
    try {
        QDateTime startTime = QDateTime::currentDateTime();
        
        // Check dependencies
        if (m_dependencyResolution && !resolveDependencies(name)) {
            emit errorOccurred(QString("Failed to resolve dependencies for module '%1'").arg(name));
            return false;
        }
        
        // Check version compatibility
        if (m_versionChecking && !checkVersionCompatibility(moduleInfo)) {
            emit errorOccurred(QString("Version incompatibility for module '%1'").arg(name));
            return false;
        }
        
        // Verify signature if enabled
        if (m_signatureVerification && !verifyModuleSignature(moduleInfo)) {
            emit errorOccurred(QString("Signature verification failed for module '%1'").arg(name));
            return false;
        }
        
        // Load the module
        bool success = false;
        
        if (moduleInfo.type == ModuleType::DynamicLibrary) {
            success = loadDynamicLibrary(moduleInfo);
        } else if (moduleInfo.type == ModuleType::Plugin) {
            success = loadPlugin(moduleInfo);
        } else if (moduleInfo.type == ModuleType::Script) {
            success = loadScript(moduleInfo);
        } else if (moduleInfo.type == ModuleType::Executable) {
            success = loadExecutable(moduleInfo);
        }
        
        if (success) {
            moduleInfo.status = ModuleStatus::Loaded;
            moduleInfo.loadTime = QDateTime::currentDateTime();
            moduleInfo.loadDuration = startTime.msecsTo(moduleInfo.loadTime);
            
            m_loadedModules.insert(name);
            m_statistics.loadedModules++;
            m_statistics.totalLoads++;
            
            // Update average load time
            if (m_statistics.totalLoads > 0) {
                m_statistics.averageLoadTime = 
                    (m_statistics.averageLoadTime * (m_statistics.totalLoads - 1) + moduleInfo.loadDuration) / m_statistics.totalLoads;
            }
            
            emit moduleLoaded(name);
            emit statusChanged(QString("Module '%1' loaded successfully").arg(name));
            
            return true;
        } else {
            moduleInfo.status = ModuleStatus::Failed;
            m_statistics.failedLoads++;
            
            emit moduleLoadFailed(name, "Failed to load module");
            emit errorOccurred(QString("Failed to load module '%1'").arg(name));
            
            return false;
        }
    }
    catch (const std::exception& e) {
        moduleInfo.status = ModuleStatus::Failed;
        m_statistics.failedLoads++;
        
        emit moduleLoadFailed(name, e.what());
        emit errorOccurred(QString("Exception while loading module '%1': %2").arg(name, e.what()));
        
        return false;
    }
}

bool ModuleManager::unloadModule(const QString& name)
{
    QMutexLocker locker(&m_mutex);
    
    if (!isModuleLoaded(name)) {
        emit statusChanged(QString("Module '%1' is not loaded").arg(name));
        return true;
    }
    
    ModuleInfo& moduleInfo = m_modules[name];
    
    try {
        // Check for dependent modules
        QStringList dependents = findDependentModules(name);
        if (!dependents.isEmpty()) {
            emit errorOccurred(QString("Cannot unload module '%1': dependent modules exist: %2")
                              .arg(name, dependents.join(", ")));
            return false;
        }
        
        // Unload the module
        bool success = false;
        
        if (moduleInfo.type == ModuleType::DynamicLibrary) {
            success = unloadDynamicLibrary(moduleInfo);
        } else if (moduleInfo.type == ModuleType::Plugin) {
            success = unloadPlugin(moduleInfo);
        } else if (moduleInfo.type == ModuleType::Script) {
            success = unloadScript(moduleInfo);
        } else if (moduleInfo.type == ModuleType::Executable) {
            success = unloadExecutable(moduleInfo);
        }
        
        if (success) {
            moduleInfo.status = ModuleStatus::Unloaded;
            moduleInfo.unloadTime = QDateTime::currentDateTime();
            
            m_loadedModules.remove(name);
            m_statistics.loadedModules--;
            m_statistics.totalUnloads++;
            
            emit moduleUnloaded(name);
            emit statusChanged(QString("Module '%1' unloaded successfully").arg(name));
            
            return true;
        } else {
            emit moduleUnloadFailed(name, "Failed to unload module");
            emit errorOccurred(QString("Failed to unload module '%1'").arg(name));
            
            return false;
        }
    }
    catch (const std::exception& e) {
        emit moduleUnloadFailed(name, e.what());
        emit errorOccurred(QString("Exception while unloading module '%1': %2").arg(name, e.what()));
        
        return false;
    }
}

bool ModuleManager::reloadModule(const QString& name)
{
    if (isModuleLoaded(name)) {
        if (!unloadModule(name)) {
            return false;
        }
    }
    
    return loadModule(name);
}

void ModuleManager::unloadAllModules()
{
    QMutexLocker locker(&m_mutex);
    
    QStringList loadedModules = m_loadedModules.values();
    
    // Unload in reverse dependency order
    for (auto it = loadedModules.rbegin(); it != loadedModules.rend(); ++it) {
        unloadModule(*it);
    }
}

// Module Discovery
void ModuleManager::scanForModules()
{
    QDir modulesDir(m_modulesPath);
    if (!modulesDir.exists()) {
        return;
    }
    
    // Scan for different module types
    scanForDynamicLibraries(modulesDir);
    scanForPlugins(modulesDir);
    scanForScripts(modulesDir);
    scanForExecutables(modulesDir);
    
    m_statistics.totalModules = m_modules.size();
    emit modulesScanned(m_modules.size());
}

void ModuleManager::scanForDynamicLibraries(const QDir& dir)
{
    QStringList filters;
#ifdef Q_OS_WIN
    filters << "*.dll";
#elif defined(Q_OS_LINUX)
    filters << "*.so";
#elif defined(Q_OS_MAC)
    filters << "*.dylib";
#endif
    
    QFileInfoList files = dir.entryInfoList(filters, QDir::Files);
    
    for (const QFileInfo& fileInfo : files) {
        ModuleInfo moduleInfo;
        moduleInfo.name = fileInfo.baseName();
        moduleInfo.path = fileInfo.absoluteFilePath();
        moduleInfo.type = ModuleType::DynamicLibrary;
        moduleInfo.status = ModuleStatus::Available;
        moduleInfo.version = "1.0.0"; // Default version
        moduleInfo.description = "Dynamic library module";
        moduleInfo.author = "Unknown";
        moduleInfo.autoStart = false;
        
        m_modules[moduleInfo.name] = moduleInfo;
    }
}

void ModuleManager::scanForPlugins(const QDir& dir)
{
    QDir pluginsDir(dir.absolutePath() + "/plugins");
    if (!pluginsDir.exists()) {
        return;
    }
    
    QStringList filters;
#ifdef Q_OS_WIN
    filters << "*.dll";
#elif defined(Q_OS_LINUX)
    filters << "*.so";
#elif defined(Q_OS_MAC)
    filters << "*.dylib";
#endif
    
    QFileInfoList files = pluginsDir.entryInfoList(filters, QDir::Files);
    
    for (const QFileInfo& fileInfo : files) {
        ModuleInfo moduleInfo;
        moduleInfo.name = fileInfo.baseName();
        moduleInfo.path = fileInfo.absoluteFilePath();
        moduleInfo.type = ModuleType::Plugin;
        moduleInfo.status = ModuleStatus::Available;
        moduleInfo.version = "1.0.0";
        moduleInfo.description = "Plugin module";
        moduleInfo.author = "Unknown";
        moduleInfo.autoStart = false;
        
        m_modules[moduleInfo.name] = moduleInfo;
    }
}

void ModuleManager::scanForScripts(const QDir& dir)
{
    QDir scriptsDir(dir.absolutePath() + "/scripts");
    if (!scriptsDir.exists()) {
        return;
    }
    
    QStringList filters;
    filters << "*.js" << "*.py" << "*.lua";
    
    QFileInfoList files = scriptsDir.entryInfoList(filters, QDir::Files);
    
    for (const QFileInfo& fileInfo : files) {
        ModuleInfo moduleInfo;
        moduleInfo.name = fileInfo.baseName();
        moduleInfo.path = fileInfo.absoluteFilePath();
        moduleInfo.type = ModuleType::Script;
        moduleInfo.status = ModuleStatus::Available;
        moduleInfo.version = "1.0.0";
        moduleInfo.description = "Script module";
        moduleInfo.author = "Unknown";
        moduleInfo.autoStart = false;
        
        m_modules[moduleInfo.name] = moduleInfo;
    }
}

void ModuleManager::scanForExecutables(const QDir& dir)
{
    QDir execDir(dir.absolutePath() + "/executables");
    if (!execDir.exists()) {
        return;
    }
    
    QStringList filters;
#ifdef Q_OS_WIN
    filters << "*.exe";
#else
    filters << "*";
#endif
    
    QFileInfoList files = execDir.entryInfoList(filters, QDir::Files | QDir::Executable);
    
    for (const QFileInfo& fileInfo : files) {
        ModuleInfo moduleInfo;
        moduleInfo.name = fileInfo.baseName();
        moduleInfo.path = fileInfo.absoluteFilePath();
        moduleInfo.type = ModuleType::Executable;
        moduleInfo.status = ModuleStatus::Available;
        moduleInfo.version = "1.0.0";
        moduleInfo.description = "Executable module";
        moduleInfo.author = "Unknown";
        moduleInfo.autoStart = false;
        
        m_modules[moduleInfo.name] = moduleInfo;
    }
}

// Module Type Loaders
bool ModuleManager::loadDynamicLibrary(ModuleInfo& moduleInfo)
{
    QLibrary* library = new QLibrary(moduleInfo.path);
    
    if (library->load()) {
        moduleInfo.handle = library;
        return true;
    } else {
        delete library;
        return false;
    }
}

bool ModuleManager::unloadDynamicLibrary(ModuleInfo& moduleInfo)
{
    if (moduleInfo.handle) {
        QLibrary* library = static_cast<QLibrary*>(moduleInfo.handle);
        bool success = library->unload();
        delete library;
        moduleInfo.handle = nullptr;
        return success;
    }
    return true;
}

bool ModuleManager::loadPlugin(ModuleInfo& moduleInfo)
{
    QPluginLoader* loader = new QPluginLoader(moduleInfo.path);
    
    if (loader->load()) {
        moduleInfo.handle = loader;
        return true;
    } else {
        delete loader;
        return false;
    }
}

bool ModuleManager::unloadPlugin(ModuleInfo& moduleInfo)
{
    if (moduleInfo.handle) {
        QPluginLoader* loader = static_cast<QPluginLoader*>(moduleInfo.handle);
        bool success = loader->unload();
        delete loader;
        moduleInfo.handle = nullptr;
        return success;
    }
    return true;
}

bool ModuleManager::loadScript(ModuleInfo& moduleInfo)
{
    // Placeholder for script loading
    Q_UNUSED(moduleInfo)
    return true;
}

bool ModuleManager::unloadScript(ModuleInfo& moduleInfo)
{
    // Placeholder for script unloading
    Q_UNUSED(moduleInfo)
    return true;
}

bool ModuleManager::loadExecutable(ModuleInfo& moduleInfo)
{
    QProcess* process = new QProcess();
    process->start(moduleInfo.path);
    
    if (process->waitForStarted()) {
        moduleInfo.handle = process;
        return true;
    } else {
        delete process;
        return false;
    }
}

bool ModuleManager::unloadExecutable(ModuleInfo& moduleInfo)
{
    if (moduleInfo.handle) {
        QProcess* process = static_cast<QProcess*>(moduleInfo.handle);
        process->terminate();
        if (!process->waitForFinished(5000)) {
            process->kill();
        }
        delete process;
        moduleInfo.handle = nullptr;
        return true;
    }
    return true;
}

// Dependency Management
bool ModuleManager::resolveDependencies(const QString& moduleName)
{
    if (!m_dependencies.contains(moduleName)) {
        return true; // No dependencies
    }
    
    const QStringList& deps = m_dependencies[moduleName];
    
    for (const QString& dep : deps) {
        if (!isModuleLoaded(dep)) {
            if (!loadModule(dep)) {
                return false;
            }
        }
    }
    
    return true;
}

QStringList ModuleManager::findDependentModules(const QString& moduleName)
{
    QStringList dependents;
    
    for (auto it = m_dependencies.begin(); it != m_dependencies.end(); ++it) {
        if (it.value().contains(moduleName)) {
            dependents.append(it.key());
        }
    }
    
    return dependents;
}

void ModuleManager::addDependency(const QString& moduleName, const QString& dependency)
{
    m_dependencies[moduleName].append(dependency);
}

void ModuleManager::removeDependency(const QString& moduleName, const QString& dependency)
{
    if (m_dependencies.contains(moduleName)) {
        m_dependencies[moduleName].removeAll(dependency);
    }
}

// Utility Functions
bool ModuleManager::isModuleLoaded(const QString& name) const
{
    return m_loadedModules.contains(name);
}

bool ModuleManager::isModuleAvailable(const QString& name) const
{
    return m_modules.contains(name);
}

QStringList ModuleManager::getAvailableModules() const
{
    return m_modules.keys();
}

QStringList ModuleManager::getLoadedModules() const
{
    return m_loadedModules.values();
}

ModuleInfo ModuleManager::getModuleInfo(const QString& name) const
{
    return m_modules.value(name);
}

ModuleStatistics ModuleManager::getStatistics() const
{
    return m_statistics;
}

bool ModuleManager::checkVersionCompatibility(const ModuleInfo& moduleInfo)
{
    // Placeholder for version checking
    Q_UNUSED(moduleInfo)
    return true;
}

bool ModuleManager::verifyModuleSignature(const ModuleInfo& moduleInfo)
{
    // Placeholder for signature verification
    Q_UNUSED(moduleInfo)
    return true;
}

void ModuleManager::loadAutoStartModules()
{
    for (auto it = m_modules.begin(); it != m_modules.end(); ++it) {
        if (it.value().autoStart) {
            loadModule(it.key());
        }
    }
}

bool ModuleManager::loadModuleRegistry()
{
    QString registryPath = m_modulesPath + "/registry.json";
    QFile file(registryPath);
    
    if (!file.open(QIODevice::ReadOnly)) {
        return false;
    }
    
    QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
    QJsonObject root = doc.object();
    
    // Load module information from registry
    QJsonArray modules = root["modules"].toArray();
    for (const QJsonValue& value : modules) {
        QJsonObject moduleObj = value.toObject();
        
        ModuleInfo moduleInfo;
        moduleInfo.name = moduleObj["name"].toString();
        moduleInfo.path = moduleObj["path"].toString();
        moduleInfo.version = moduleObj["version"].toString();
        moduleInfo.description = moduleObj["description"].toString();
        moduleInfo.author = moduleObj["author"].toString();
        moduleInfo.autoStart = moduleObj["autoStart"].toBool();
        
        QString typeStr = moduleObj["type"].toString();
        if (typeStr == "DynamicLibrary") {
            moduleInfo.type = ModuleType::DynamicLibrary;
        } else if (typeStr == "Plugin") {
            moduleInfo.type = ModuleType::Plugin;
        } else if (typeStr == "Script") {
            moduleInfo.type = ModuleType::Script;
        } else if (typeStr == "Executable") {
            moduleInfo.type = ModuleType::Executable;
        }
        
        moduleInfo.status = ModuleStatus::Available;
        
        m_modules[moduleInfo.name] = moduleInfo;
        
        // Load dependencies
        QJsonArray deps = moduleObj["dependencies"].toArray();
        for (const QJsonValue& dep : deps) {
            addDependency(moduleInfo.name, dep.toString());
        }
    }
    
    return true;
}

bool ModuleManager::saveModuleRegistry()
{
    QString registryPath = m_modulesPath + "/registry.json";
    QFile file(registryPath);
    
    if (!file.open(QIODevice::WriteOnly)) {
        return false;
    }
    
    QJsonObject root;
    QJsonArray modules;
    
    for (auto it = m_modules.begin(); it != m_modules.end(); ++it) {
        const ModuleInfo& moduleInfo = it.value();
        
        QJsonObject moduleObj;
        moduleObj["name"] = moduleInfo.name;
        moduleObj["path"] = moduleInfo.path;
        moduleObj["version"] = moduleInfo.version;
        moduleObj["description"] = moduleInfo.description;
        moduleObj["author"] = moduleInfo.author;
        moduleObj["autoStart"] = moduleInfo.autoStart;
        
        QString typeStr;
        switch (moduleInfo.type) {
            case ModuleType::DynamicLibrary: typeStr = "DynamicLibrary"; break;
            case ModuleType::Plugin: typeStr = "Plugin"; break;
            case ModuleType::Script: typeStr = "Script"; break;
            case ModuleType::Executable: typeStr = "Executable"; break;
        }
        moduleObj["type"] = typeStr;
        
        // Save dependencies
        if (m_dependencies.contains(moduleInfo.name)) {
            QJsonArray deps;
            for (const QString& dep : m_dependencies[moduleInfo.name]) {
                deps.append(dep);
            }
            moduleObj["dependencies"] = deps;
        }
        
        modules.append(moduleObj);
    }
    
    root["modules"] = modules;
    
    QJsonDocument doc(root);
    file.write(doc.toJson());
    
    return true;
}

// Slot implementations
void ModuleManager::onUpdateTimer()
{
    m_statistics.uptime++;
    m_statistics.lastUpdate = QDateTime::currentDateTime();
    
    // Update module statistics
    m_statistics.loadedModules = m_loadedModules.size();
    m_statistics.totalModules = m_modules.size();
}

void ModuleManager::onWatchdogTimer()
{
    // Check module health
    for (const QString& moduleName : m_loadedModules) {
        if (m_modules.contains(moduleName)) {
            ModuleInfo& moduleInfo = m_modules[moduleName];
            
            // Check if module is still responsive
            if (!checkModuleHealth(moduleInfo)) {
                emit moduleHealthChanged(moduleName, false);
                emit statusChanged(QString("Module '%1' health check failed").arg(moduleName));
            }
        }
    }
}

void ModuleManager::onCleanupTimer()
{
    // Cleanup unused resources
    // This is a placeholder for cleanup logic
}

bool ModuleManager::checkModuleHealth(const ModuleInfo& moduleInfo)
{
    // Placeholder for module health checking
    Q_UNUSED(moduleInfo)
    return true;
}

void ModuleManager::onAutoLoadToggled(bool enabled)
{
    m_autoLoad = enabled;
    emit statusChanged(enabled ? "Auto-load enabled" : "Auto-load disabled");
}

void ModuleManager::onAutoUnloadToggled(bool enabled)
{
    m_autoUnload = enabled;
    emit statusChanged(enabled ? "Auto-unload enabled" : "Auto-unload disabled");
}

void ModuleManager::onDependencyResolutionToggled(bool enabled)
{
    m_dependencyResolution = enabled;
    emit statusChanged(enabled ? "Dependency resolution enabled" : "Dependency resolution disabled");
}

void ModuleManager::onVersionCheckingToggled(bool enabled)
{
    m_versionChecking = enabled;
    emit statusChanged(enabled ? "Version checking enabled" : "Version checking disabled");
}

void ModuleManager::onSignatureVerificationToggled(bool enabled)
{
    m_signatureVerification = enabled;
    emit statusChanged(enabled ? "Signature verification enabled" : "Signature verification disabled");
}

void ModuleManager::onSandboxModeToggled(bool enabled)
{
    m_sandboxMode = enabled;
    emit statusChanged(enabled ? "Sandbox mode enabled" : "Sandbox mode disabled");
}

void ModuleManager::onHotReloadToggled(bool enabled)
{
    m_hotReload = enabled;
    emit statusChanged(enabled ? "Hot reload enabled" : "Hot reload disabled");
}

void ModuleManager::onDebugModeToggled(bool enabled)
{
    m_debugMode = enabled;
    emit statusChanged(enabled ? "Debug mode enabled" : "Debug mode disabled");
}

void ModuleManager::onModulesPathChanged(const QString& path)
{
    m_modulesPath = path;
    scanForModules();
    emit statusChanged(QString("Modules path changed to: %1").arg(path));
}

void ModuleManager::onMaxModulesChanged(int max)
{
    m_maxModules = max;
    emit statusChanged(QString("Maximum modules limit set to: %1").arg(max));
}

void ModuleManager::onLoadTimeoutChanged(int timeout)
{
    m_loadTimeout = timeout;
    emit statusChanged(QString("Load timeout set to: %1 ms").arg(timeout));
}

void ModuleManager::onUnloadTimeoutChanged(int timeout)
{
    m_unloadTimeout = timeout;
    emit statusChanged(QString("Unload timeout set to: %1 ms").arg(timeout));
}

void ModuleManager::onRefreshModules()
{
    scanForModules();
    emit statusChanged("Module list refreshed");
}

void ModuleManager::onClearStatistics()
{
    initializeStatistics();
    emit statusChanged("Statistics cleared");
}

void ModuleManager::onSaveRegistry()
{
    if (saveModuleRegistry()) {
        emit statusChanged("Module registry saved");
    } else {
        emit errorOccurred("Failed to save module registry");
    }
}

void ModuleManager::onLoadRegistry()
{
    if (loadModuleRegistry()) {
        emit statusChanged("Module registry loaded");
    } else {
        emit errorOccurred("Failed to load module registry");
    }
}