#include "update_manager.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>
#include <QDir>
#include <QStandardPaths>
#include <QMutexLocker>
#include <QTimer>
#include <QDebug>
#include <QThread>
#include <QCoreApplication>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrl>
#include <QUrlQuery>
#include <QDateTime>
#include <QUuid>
#include <QByteArray>
#include <QDataStream>
#include <QBuffer>
#include <QCryptographicHash>
#include <QProcess>
#include <QFileInfo>
#include <QDirIterator>
#include <QTemporaryDir>
#include <QTemporaryFile>
#include <QProgressDialog>
#include <QMessageBox>
#include <QApplication>
#include <QDesktopServices>
#include <QSysInfo>
#include <QVersionNumber>

#ifdef Q_OS_WIN
#include <windows.h>
#include <wininet.h>
#pragma comment(lib, "wininet.lib")
#endif

UpdateManager::UpdateManager(QObject *parent)
    : QObject(parent)
    , m_initialized(false)
    , m_enableAutoUpdate(true)
    , m_enableBetaUpdates(false)
    , m_enablePreReleaseUpdates(false)
    , m_enableBackgroundCheck(true)
    , m_enableNotifications(true)
    , m_enableAutoDownload(false)
    , m_enableAutoInstall(false)
    , m_enableRollback(true)
    , m_enableDeltaUpdates(true)
    , m_enableCompression(true)
    , m_enableEncryption(false)
    , m_enableSignatureVerification(true)
    , m_enableMetrics(true)
    , m_enableLogging(true)
    , m_checkInterval(3600000) // 1 hour
    , m_downloadTimeout(300000) // 5 minutes
    , m_retryAttempts(3)
    , m_retryDelay(5000) // 5 seconds
    , m_maxDownloadSize(104857600) // 100MB
    , m_maxCacheSize(524288000) // 500MB
    , m_compressionLevel(6)
    , m_currentVersion("3.9.0")
    , m_updateChannel(UpdateChannel::Stable)
    , m_downloadMethod(DownloadMethod::HTTP)
    , m_installMethod(InstallMethod::Automatic)
    , m_verificationMethod(VerificationMethod::SHA256)
    , m_compressionMethod(CompressionMethod::ZIP)
    , m_encryptionMethod(EncryptionMethod::AES256)
    , m_networkManager(nullptr)
    , m_updateTimer(nullptr)
    , m_downloadTimer(nullptr)
    , m_retryTimer(nullptr)
    , m_cleanupTimer(nullptr)
    , m_metricsTimer(nullptr)
    , m_currentDownload(nullptr)
    , m_downloadProgress(0)
    , m_downloadSpeed(0)
    , m_estimatedTimeRemaining(0)
    , m_totalBytesReceived(0)
    , m_totalBytesToReceive(0)
    , m_isDownloading(false)
    , m_isInstalling(false)
    , m_isChecking(false)
    , m_hasUpdate(false)
    , m_updateRequired(false)
    , m_rollbackAvailable(false)
{
    // Initialize network manager
    m_networkManager = new QNetworkAccessManager(this);
    
    // Initialize timers
    m_updateTimer = new QTimer(this);
    m_downloadTimer = new QTimer(this);
    m_retryTimer = new QTimer(this);
    m_cleanupTimer = new QTimer(this);
    m_metricsTimer = new QTimer(this);
    
    // Connect signals
    connect(m_updateTimer, &QTimer::timeout, this, &UpdateManager::onUpdateTimer);
    connect(m_downloadTimer, &QTimer::timeout, this, &UpdateManager::onDownloadTimer);
    connect(m_retryTimer, &QTimer::timeout, this, &UpdateManager::onRetryTimer);
    connect(m_cleanupTimer, &QTimer::timeout, this, &UpdateManager::onCleanupTimer);
    connect(m_metricsTimer, &QTimer::timeout, this, &UpdateManager::onMetricsTimer);
    
    // Initialize statistics
    initializeStatistics();
    
    // Initialize update information
    initializeUpdateInfo();
    
    // Setup update servers
    setupUpdateServers();
}

UpdateManager::~UpdateManager()
{
    cleanup();
}

bool UpdateManager::initialize()
{
    QMutexLocker locker(&m_mutex);
    
    if (m_initialized) {
        return true;
    }
    
    try {
        // Create update directories
        if (!createUpdateDirectories()) {
            emit errorOccurred("Failed to create update directories");
            return false;
        }
        
        // Load configuration
        if (!loadConfiguration()) {
            emit statusChanged("Using default configuration");
        }
        
        // Load update history
        loadUpdateHistory();
        
        // Start timers
        if (m_enableBackgroundCheck) {
            m_updateTimer->start(m_checkInterval);
        }
        
        m_cleanupTimer->start(3600000); // 1 hour
        
        if (m_enableMetrics) {
            m_metricsTimer->start(60000); // 1 minute
        }
        
        m_initialized = true;
        emit statusChanged("Update manager initialized successfully");
        
        // Perform initial update check
        if (m_enableAutoUpdate) {
            QTimer::singleShot(5000, this, &UpdateManager::checkForUpdates);
        }
        
        return true;
    }
    catch (const std::exception& e) {
        emit errorOccurred(QString("Failed to initialize update manager: %1").arg(e.what()));
        return false;
    }
}

void UpdateManager::cleanup()
{
    QMutexLocker locker(&m_mutex);
    
    // Stop timers
    if (m_updateTimer) m_updateTimer->stop();
    if (m_downloadTimer) m_downloadTimer->stop();
    if (m_retryTimer) m_retryTimer->stop();
    if (m_cleanupTimer) m_cleanupTimer->stop();
    if (m_metricsTimer) m_metricsTimer->stop();
    
    // Cancel current download
    if (m_currentDownload) {
        m_currentDownload->abort();
        m_currentDownload = nullptr;
    }
    
    // Save configuration
    saveConfiguration();
    
    // Save update history
    saveUpdateHistory();
    
    // Clear data
    m_availableUpdates.clear();
    m_downloadQueue.clear();
    m_updateHistory.clear();
    m_updateServers.clear();
    m_downloadCache.clear();
    
    m_initialized = false;
}

void UpdateManager::initializeStatistics()
{
    m_statistics.totalChecks = 0;
    m_statistics.totalDownloads = 0;
    m_statistics.totalInstalls = 0;
    m_statistics.totalRollbacks = 0;
    m_statistics.successfulChecks = 0;
    m_statistics.successfulDownloads = 0;
    m_statistics.successfulInstalls = 0;
    m_statistics.failedChecks = 0;
    m_statistics.failedDownloads = 0;
    m_statistics.failedInstalls = 0;
    m_statistics.totalBytesDownloaded = 0;
    m_statistics.averageDownloadSpeed = 0;
    m_statistics.averageCheckTime = 0;
    m_statistics.averageDownloadTime = 0;
    m_statistics.averageInstallTime = 0;
    m_statistics.lastCheck = QDateTime();
    m_statistics.lastDownload = QDateTime();
    m_statistics.lastInstall = QDateTime();
    m_statistics.uptime = 0;
}

void UpdateManager::initializeUpdateInfo()
{
    m_updateInfo.version = "";
    m_updateInfo.buildNumber = "";
    m_updateInfo.releaseDate = QDateTime();
    m_updateInfo.downloadUrl = "";
    m_updateInfo.changelogUrl = "";
    m_updateInfo.size = 0;
    m_updateInfo.checksum = "";
    m_updateInfo.signature = "";
    m_updateInfo.isRequired = false;
    m_updateInfo.isBeta = false;
    m_updateInfo.isPreRelease = false;
    m_updateInfo.minimumVersion = "";
    m_updateInfo.maximumVersion = "";
    m_updateInfo.supportedPlatforms.clear();
    m_updateInfo.dependencies.clear();
    m_updateInfo.changelog.clear();
    m_updateInfo.releaseNotes = "";
    m_updateInfo.downloadCount = 0;
    m_updateInfo.rating = 0.0;
    m_updateInfo.category = "";
    m_updateInfo.tags.clear();
}

void UpdateManager::setupUpdateServers()
{
    m_updateServers.clear();
    
    // Primary update server
    UpdateServer primary;
    primary.url = "https://api.github.com/repos/ghostpulse/bgmi-loader/releases";
    primary.priority = 1;
    primary.isActive = true;
    primary.supportsHTTPS = true;
    primary.supportsDelta = false;
    primary.supportsCompression = true;
    primary.supportsEncryption = false;
    primary.maxConnections = 4;
    primary.timeout = 30000;
    primary.retryAttempts = 3;
    primary.lastCheck = QDateTime();
    primary.responseTime = 0;
    primary.successRate = 100.0;
    primary.errorCount = 0;
    m_updateServers.append(primary);
    
    // Backup update server
    UpdateServer backup;
    backup.url = "https://releases.ghostpulse.dev/bgmi-loader";
    backup.priority = 2;
    backup.isActive = true;
    backup.supportsHTTPS = true;
    backup.supportsDelta = true;
    backup.supportsCompression = true;
    backup.supportsEncryption = true;
    backup.maxConnections = 2;
    backup.timeout = 45000;
    backup.retryAttempts = 2;
    backup.lastCheck = QDateTime();
    backup.responseTime = 0;
    backup.successRate = 100.0;
    backup.errorCount = 0;
    m_updateServers.append(backup);
}

bool UpdateManager::createUpdateDirectories()
{
    QStringList directories = {
        QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/updates",
        QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/updates/downloads",
        QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/updates/cache",
        QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/updates/backups",
        QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/updates/temp",
        QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/updates/logs"
    };
    
    for (const QString& dirPath : directories) {
        QDir dir;
        if (!dir.mkpath(dirPath)) {
            return false;
        }
    }
    
    return true;
}

// Update Checking
void UpdateManager::checkForUpdates()
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_initialized || m_isChecking) {
        return;
    }
    
    m_isChecking = true;
    m_statistics.totalChecks++;
    
    QDateTime startTime = QDateTime::currentDateTime();
    
    emit updateCheckStarted();
    emit statusChanged("Checking for updates...");
    
    // Find best update server
    UpdateServer* server = getBestUpdateServer();
    if (!server) {
        m_statistics.failedChecks++;
        m_isChecking = false;
        emit errorOccurred("No available update servers");
        return;
    }
    
    // Prepare request
    QNetworkRequest request(QUrl(server->url));
    request.setHeader(QNetworkRequest::UserAgentHeader, 
                     QString("GhostPulse-BGMI-Loader/%1").arg(m_currentVersion));
    request.setRawHeader("Accept", "application/json");
    request.setRawHeader("Cache-Control", "no-cache");
    
    // Add authentication if required
    if (!server->apiKey.isEmpty()) {
        request.setRawHeader("Authorization", QString("Bearer %1").arg(server->apiKey).toUtf8());
    }
    
    // Send request
    QNetworkReply* reply = m_networkManager->get(request);
    
    // Set timeout
    QTimer::singleShot(server->timeout, reply, &QNetworkReply::abort);
    
    // Connect signals
    connect(reply, &QNetworkReply::finished, [this, reply, server, startTime]() {
        handleUpdateCheckResponse(reply, server, startTime);
    });
    
    connect(reply, QOverload<QNetworkReply::NetworkError>::of(&QNetworkReply::error),
            [this, reply, server](QNetworkReply::NetworkError error) {
        handleUpdateCheckError(reply, server, error);
    });
}

void UpdateManager::handleUpdateCheckResponse(QNetworkReply* reply, UpdateServer* server, const QDateTime& startTime)
{
    QMutexLocker locker(&m_mutex);
    
    reply->deleteLater();
    
    qint64 elapsedTime = startTime.msecsTo(QDateTime::currentDateTime());
    server->responseTime = elapsedTime;
    server->lastCheck = QDateTime::currentDateTime();
    
    if (reply->error() != QNetworkReply::NoError) {
        server->errorCount++;
        server->successRate = qMax(0.0, server->successRate - 5.0);
        m_statistics.failedChecks++;
        m_isChecking = false;
        emit errorOccurred(QString("Update check failed: %1").arg(reply->errorString()));
        return;
    }
    
    // Parse response
    QByteArray data = reply->readAll();
    QJsonParseError parseError;
    QJsonDocument doc = QJsonDocument::fromJson(data, &parseError);
    
    if (parseError.error != QJsonParseError::NoError) {
        server->errorCount++;
        m_statistics.failedChecks++;
        m_isChecking = false;
        emit errorOccurred(QString("Failed to parse update response: %1").arg(parseError.errorString()));
        return;
    }
    
    // Process update information
    if (processUpdateResponse(doc)) {
        server->successRate = qMin(100.0, server->successRate + 1.0);
        m_statistics.successfulChecks++;
        m_statistics.lastCheck = QDateTime::currentDateTime();
        m_statistics.averageCheckTime = (m_statistics.averageCheckTime + elapsedTime) / 2;
        
        emit updateCheckCompleted(m_hasUpdate);
        
        if (m_hasUpdate) {
            emit updateAvailable(m_updateInfo);
            
            if (m_enableAutoDownload) {
                downloadUpdate();
            }
        } else {
            emit statusChanged("No updates available");
        }
    } else {
        server->errorCount++;
        m_statistics.failedChecks++;
        emit errorOccurred("Failed to process update information");
    }
    
    m_isChecking = false;
}

void UpdateManager::handleUpdateCheckError(QNetworkReply* reply, UpdateServer* server, QNetworkReply::NetworkError error)
{
    Q_UNUSED(reply)
    
    server->errorCount++;
    server->successRate = qMax(0.0, server->successRate - 10.0);
    m_statistics.failedChecks++;
    m_isChecking = false;
    
    emit errorOccurred(QString("Network error during update check: %1").arg(static_cast<int>(error)));
}

bool UpdateManager::processUpdateResponse(const QJsonDocument& doc)
{
    try {
        QJsonArray releases = doc.array();
        if (releases.isEmpty()) {
            return true; // No updates available
        }
        
        // Find the latest suitable release
        for (const QJsonValue& value : releases) {
            QJsonObject release = value.toObject();
            
            QString version = release["tag_name"].toString();
            bool isPrerelease = release["prerelease"].toBool();
            bool isDraft = release["draft"].toBool();
            
            // Skip drafts
            if (isDraft) {
                continue;
            }
            
            // Skip pre-releases if not enabled
            if (isPrerelease && !m_enablePreReleaseUpdates) {
                continue;
            }
            
            // Check if this is a newer version
            if (isNewerVersion(version, m_currentVersion)) {
                // Parse update information
                m_updateInfo.version = version;
                m_updateInfo.buildNumber = release["id"].toString();
                m_updateInfo.releaseDate = QDateTime::fromString(release["published_at"].toString(), Qt::ISODate);
                m_updateInfo.isPreRelease = isPrerelease;
                m_updateInfo.releaseNotes = release["body"].toString();
                
                // Find download asset
                QJsonArray assets = release["assets"].toArray();
                for (const QJsonValue& assetValue : assets) {
                    QJsonObject asset = assetValue.toObject();
                    QString name = asset["name"].toString();
                    
                    // Look for Windows executable
                    if (name.contains("windows", Qt::CaseInsensitive) || name.endsWith(".exe")) {
                        m_updateInfo.downloadUrl = asset["browser_download_url"].toString();
                        m_updateInfo.size = asset["size"].toInt();
                        m_updateInfo.downloadCount = asset["download_count"].toInt();
                        break;
                    }
                }
                
                m_hasUpdate = true;
                return true;
            }
        }
        
        m_hasUpdate = false;
        return true;
    }
    catch (const std::exception& e) {
        emit errorOccurred(QString("Error processing update response: %1").arg(e.what()));
        return false;
    }
}

bool UpdateManager::isNewerVersion(const QString& version1, const QString& version2)
{
    // Simple version comparison
    QVersionNumber v1 = QVersionNumber::fromString(version1.startsWith("v") ? version1.mid(1) : version1);
    QVersionNumber v2 = QVersionNumber::fromString(version2.startsWith("v") ? version2.mid(1) : version2);
    
    return QVersionNumber::compare(v1, v2) > 0;
}

UpdateServer* UpdateManager::getBestUpdateServer()
{
    UpdateServer* best = nullptr;
    double bestScore = -1.0;
    
    for (auto& server : m_updateServers) {
        if (!server.isActive) {
            continue;
        }
        
        // Calculate server score based on priority, success rate, and response time
        double score = server.successRate * (1.0 / server.priority);
        if (server.responseTime > 0) {
            score *= (10000.0 / server.responseTime); // Prefer faster servers
        }
        
        if (score > bestScore) {
            bestScore = score;
            best = &server;
        }
    }
    
    return best;
}

// Update Downloading
void UpdateManager::downloadUpdate()
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_initialized || m_isDownloading || !m_hasUpdate) {
        return;
    }
    
    if (m_updateInfo.downloadUrl.isEmpty()) {
        emit errorOccurred("No download URL available");
        return;
    }
    
    m_isDownloading = true;
    m_downloadProgress = 0;
    m_downloadSpeed = 0;
    m_estimatedTimeRemaining = 0;
    m_totalBytesReceived = 0;
    m_totalBytesToReceive = m_updateInfo.size;
    
    m_statistics.totalDownloads++;
    
    QDateTime startTime = QDateTime::currentDateTime();
    
    emit downloadStarted(m_updateInfo);
    emit statusChanged("Downloading update...");
    
    // Prepare download request
    QNetworkRequest request(QUrl(m_updateInfo.downloadUrl));
    request.setHeader(QNetworkRequest::UserAgentHeader, 
                     QString("GhostPulse-BGMI-Loader/%1").arg(m_currentVersion));
    
    // Start download
    m_currentDownload = m_networkManager->get(request);
    
    // Set timeout
    QTimer::singleShot(m_downloadTimeout, m_currentDownload, &QNetworkReply::abort);
    
    // Connect signals
    connect(m_currentDownload, &QNetworkReply::downloadProgress,
            this, &UpdateManager::onDownloadProgress);
    
    connect(m_currentDownload, &QNetworkReply::finished, [this, startTime]() {
        handleDownloadFinished(startTime);
    });
    
    connect(m_currentDownload, QOverload<QNetworkReply::NetworkError>::of(&QNetworkReply::error),
            [this](QNetworkReply::NetworkError error) {
        handleDownloadError(error);
    });
    
    // Start download timer for speed calculation
    m_downloadTimer->start(1000); // Update every second
}

void UpdateManager::onDownloadProgress(qint64 bytesReceived, qint64 bytesTotal)
{
    m_totalBytesReceived = bytesReceived;
    m_totalBytesToReceive = bytesTotal;
    
    if (bytesTotal > 0) {
        m_downloadProgress = (bytesReceived * 100) / bytesTotal;
    }
    
    emit downloadProgress(m_downloadProgress, bytesReceived, bytesTotal);
}

void UpdateManager::handleDownloadFinished(const QDateTime& startTime)
{
    QMutexLocker locker(&m_mutex);
    
    m_downloadTimer->stop();
    
    if (!m_currentDownload) {
        return;
    }
    
    qint64 elapsedTime = startTime.msecsTo(QDateTime::currentDateTime());
    
    if (m_currentDownload->error() != QNetworkReply::NoError) {
        m_statistics.failedDownloads++;
        m_isDownloading = false;
        
        QString error = m_currentDownload->errorString();
        m_currentDownload->deleteLater();
        m_currentDownload = nullptr;
        
        emit downloadFailed(error);
        emit errorOccurred(QString("Download failed: %1").arg(error));
        return;
    }
    
    // Save downloaded data
    QByteArray data = m_currentDownload->readAll();
    m_currentDownload->deleteLater();
    m_currentDownload = nullptr;
    
    // Verify download
    if (!verifyDownload(data)) {
        m_statistics.failedDownloads++;
        m_isDownloading = false;
        emit downloadFailed("Download verification failed");
        return;
    }
    
    // Save to file
    QString filename = QString("update_%1.exe").arg(m_updateInfo.version);
    QString filepath = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/updates/downloads/" + filename;
    
    QFile file(filepath);
    if (!file.open(QIODevice::WriteOnly)) {
        m_statistics.failedDownloads++;
        m_isDownloading = false;
        emit downloadFailed("Failed to save download");
        return;
    }
    
    file.write(data);
    file.close();
    
    // Update statistics
    m_statistics.successfulDownloads++;
    m_statistics.lastDownload = QDateTime::currentDateTime();
    m_statistics.totalBytesDownloaded += data.size();
    m_statistics.averageDownloadTime = (m_statistics.averageDownloadTime + elapsedTime) / 2;
    
    if (elapsedTime > 0) {
        m_downloadSpeed = (data.size() * 1000) / elapsedTime; // bytes per second
        m_statistics.averageDownloadSpeed = (m_statistics.averageDownloadSpeed + m_downloadSpeed) / 2;
    }
    
    m_isDownloading = false;
    m_downloadedFilePath = filepath;
    
    emit downloadCompleted(filepath);
    emit statusChanged("Download completed successfully");
    
    // Auto-install if enabled
    if (m_enableAutoInstall) {
        installUpdate();
    }
}

void UpdateManager::handleDownloadError(QNetworkReply::NetworkError error)
{
    m_downloadTimer->stop();
    m_statistics.failedDownloads++;
    m_isDownloading = false;
    
    if (m_currentDownload) {
        m_currentDownload->deleteLater();
        m_currentDownload = nullptr;
    }
    
    emit downloadFailed(QString("Network error: %1").arg(static_cast<int>(error)));
}

bool UpdateManager::verifyDownload(const QByteArray& data)
{
    if (m_updateInfo.checksum.isEmpty()) {
        return true; // No checksum to verify
    }
    
    QCryptographicHash hash(QCryptographicHash::Sha256);
    hash.addData(data);
    QString calculatedChecksum = hash.result().toHex();
    
    return calculatedChecksum.compare(m_updateInfo.checksum, Qt::CaseInsensitive) == 0;
}

// Update Installation
void UpdateManager::installUpdate()
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_initialized || m_isInstalling || m_downloadedFilePath.isEmpty()) {
        return;
    }
    
    if (!QFile::exists(m_downloadedFilePath)) {
        emit errorOccurred("Downloaded update file not found");
        return;
    }
    
    m_isInstalling = true;
    m_statistics.totalInstalls++;
    
    QDateTime startTime = QDateTime::currentDateTime();
    
    emit installationStarted(m_updateInfo);
    emit statusChanged("Installing update...");
    
    // Create backup if enabled
    if (m_enableRollback) {
        if (!createBackup()) {
            m_isInstalling = false;
            emit installationFailed("Failed to create backup");
            return;
        }
    }
    
    // Install update based on method
    bool success = false;
    
    switch (m_installMethod) {
        case InstallMethod::Automatic:
            success = installAutomatic();
            break;
        case InstallMethod::Manual:
            success = installManual();
            break;
        case InstallMethod::Silent:
            success = installSilent();
            break;
        case InstallMethod::Restart:
            success = installWithRestart();
            break;
        default:
            success = installAutomatic();
            break;
    }
    
    qint64 elapsedTime = startTime.msecsTo(QDateTime::currentDateTime());
    
    if (success) {
        m_statistics.successfulInstalls++;
        m_statistics.lastInstall = QDateTime::currentDateTime();
        m_statistics.averageInstallTime = (m_statistics.averageInstallTime + elapsedTime) / 2;
        
        // Update current version
        m_currentVersion = m_updateInfo.version;
        
        // Add to update history
        addToUpdateHistory(m_updateInfo);
        
        // Clean up
        QFile::remove(m_downloadedFilePath);
        m_downloadedFilePath.clear();
        m_hasUpdate = false;
        
        emit installationCompleted(m_updateInfo);
        emit statusChanged("Update installed successfully");
    } else {
        m_statistics.failedInstalls++;
        emit installationFailed("Installation failed");
    }
    
    m_isInstalling = false;
}

bool UpdateManager::installAutomatic()
{
    // Launch the installer
    QProcess installer;
    QStringList arguments;
    
    // Add silent installation arguments
    arguments << "/S" << "/D=" + QCoreApplication::applicationDirPath();
    
    installer.start(m_downloadedFilePath, arguments);
    
    if (!installer.waitForStarted(10000)) {
        return false;
    }
    
    if (!installer.waitForFinished(300000)) { // 5 minutes timeout
        installer.kill();
        return false;
    }
    
    return installer.exitCode() == 0;
}

bool UpdateManager::installManual()
{
    // Open the installer for manual installation
    return QDesktopServices::openUrl(QUrl::fromLocalFile(m_downloadedFilePath));
}

bool UpdateManager::installSilent()
{
    return installAutomatic();
}

bool UpdateManager::installWithRestart()
{
    // Schedule installation after restart
    // This would typically involve creating a batch file or using Windows Task Scheduler
    
    QString batchFile = QStandardPaths::writableLocation(QStandardPaths::TempLocation) + "/update_install.bat";
    
    QFile file(batchFile);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        return false;
    }
    
    QTextStream out(&file);
    out << "@echo off\n";
    out << "timeout /t 5 /nobreak > nul\n";
    out << "\"" << m_downloadedFilePath << "\" /S /D=\"" << QCoreApplication::applicationDirPath() << "\"\n";
    out << "del \"" << batchFile << "\"\n";
    
    file.close();
    
    // Schedule the batch file to run
    QProcess::startDetached(batchFile);
    
    // Request application restart
    emit restartRequested();
    
    return true;
}

bool UpdateManager::createBackup()
{
    QString backupDir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/updates/backups";
    QString backupName = QString("backup_%1_%2").arg(m_currentVersion, QDateTime::currentDateTime().toString("yyyyMMdd_hhmmss"));
    QString backupPath = backupDir + "/" + backupName;
    
    QDir dir;
    if (!dir.mkpath(backupPath)) {
        return false;
    }
    
    // Copy current application files
    QString appDir = QCoreApplication::applicationDirPath();
    
    QDirIterator it(appDir, QDirIterator::Subdirectories);
    while (it.hasNext()) {
        QString filePath = it.next();
        QFileInfo fileInfo(filePath);
        
        if (fileInfo.isFile()) {
            QString relativePath = QDir(appDir).relativeFilePath(filePath);
            QString destPath = backupPath + "/" + relativePath;
            
            QDir destDir = QFileInfo(destPath).dir();
            if (!destDir.exists()) {
                destDir.mkpath(".");
            }
            
            if (!QFile::copy(filePath, destPath)) {
                // Continue with other files even if one fails
            }
        }
    }
    
    return true;
}

void UpdateManager::addToUpdateHistory(const UpdateInfo& updateInfo)
{
    UpdateHistoryEntry entry;
    entry.version = updateInfo.version;
    entry.installDate = QDateTime::currentDateTime();
    entry.size = updateInfo.size;
    entry.success = true;
    entry.rollbackAvailable = m_enableRollback;
    entry.backupPath = QString("backup_%1_%2").arg(m_currentVersion, entry.installDate.toString("yyyyMMdd_hhmmss"));
    
    m_updateHistory.append(entry);
    
    // Keep only last 10 entries
    while (m_updateHistory.size() > 10) {
        m_updateHistory.removeFirst();
    }
}

// Configuration
bool UpdateManager::loadConfiguration()
{
    QString configPath = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/update_config.json";
    
    QFile file(configPath);
    if (!file.open(QIODevice::ReadOnly)) {
        return false;
    }
    
    QByteArray data = file.readAll();
    file.close();
    
    QJsonParseError parseError;
    QJsonDocument doc = QJsonDocument::fromJson(data, &parseError);
    
    if (parseError.error != QJsonParseError::NoError) {
        return false;
    }
    
    QJsonObject config = doc.object();
    
    // Load settings
    m_enableAutoUpdate = config["enableAutoUpdate"].toBool(m_enableAutoUpdate);
    m_enableBetaUpdates = config["enableBetaUpdates"].toBool(m_enableBetaUpdates);
    m_enablePreReleaseUpdates = config["enablePreReleaseUpdates"].toBool(m_enablePreReleaseUpdates);
    m_enableBackgroundCheck = config["enableBackgroundCheck"].toBool(m_enableBackgroundCheck);
    m_enableNotifications = config["enableNotifications"].toBool(m_enableNotifications);
    m_enableAutoDownload = config["enableAutoDownload"].toBool(m_enableAutoDownload);
    m_enableAutoInstall = config["enableAutoInstall"].toBool(m_enableAutoInstall);
    m_enableRollback = config["enableRollback"].toBool(m_enableRollback);
    m_checkInterval = config["checkInterval"].toInt(m_checkInterval);
    m_downloadTimeout = config["downloadTimeout"].toInt(m_downloadTimeout);
    m_retryAttempts = config["retryAttempts"].toInt(m_retryAttempts);
    m_retryDelay = config["retryDelay"].toInt(m_retryDelay);
    m_updateChannel = static_cast<UpdateChannel>(config["updateChannel"].toInt(static_cast<int>(m_updateChannel)));
    m_downloadMethod = static_cast<DownloadMethod>(config["downloadMethod"].toInt(static_cast<int>(m_downloadMethod)));
    m_installMethod = static_cast<InstallMethod>(config["installMethod"].toInt(static_cast<int>(m_installMethod)));
    
    return true;
}

void UpdateManager::saveConfiguration()
{
    QString configPath = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/update_config.json";
    
    QJsonObject config;
    config["enableAutoUpdate"] = m_enableAutoUpdate;
    config["enableBetaUpdates"] = m_enableBetaUpdates;
    config["enablePreReleaseUpdates"] = m_enablePreReleaseUpdates;
    config["enableBackgroundCheck"] = m_enableBackgroundCheck;
    config["enableNotifications"] = m_enableNotifications;
    config["enableAutoDownload"] = m_enableAutoDownload;
    config["enableAutoInstall"] = m_enableAutoInstall;
    config["enableRollback"] = m_enableRollback;
    config["checkInterval"] = m_checkInterval;
    config["downloadTimeout"] = m_downloadTimeout;
    config["retryAttempts"] = m_retryAttempts;
    config["retryDelay"] = m_retryDelay;
    config["updateChannel"] = static_cast<int>(m_updateChannel);
    config["downloadMethod"] = static_cast<int>(m_downloadMethod);
    config["installMethod"] = static_cast<int>(m_installMethod);
    
    QJsonDocument doc(config);
    
    QFile file(configPath);
    if (file.open(QIODevice::WriteOnly)) {
        file.write(doc.toJson());
        file.close();
    }
}

void UpdateManager::loadUpdateHistory()
{
    QString historyPath = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/update_history.json";
    
    QFile file(historyPath);
    if (!file.open(QIODevice::ReadOnly)) {
        return;
    }
    
    QByteArray data = file.readAll();
    file.close();
    
    QJsonParseError parseError;
    QJsonDocument doc = QJsonDocument::fromJson(data, &parseError);
    
    if (parseError.error != QJsonParseError::NoError) {
        return;
    }
    
    QJsonArray history = doc.array();
    m_updateHistory.clear();
    
    for (const QJsonValue& value : history) {
        QJsonObject obj = value.toObject();
        
        UpdateHistoryEntry entry;
        entry.version = obj["version"].toString();
        entry.installDate = QDateTime::fromString(obj["installDate"].toString(), Qt::ISODate);
        entry.size = obj["size"].toInt();
        entry.success = obj["success"].toBool();
        entry.rollbackAvailable = obj["rollbackAvailable"].toBool();
        entry.backupPath = obj["backupPath"].toString();
        
        m_updateHistory.append(entry);
    }
}

void UpdateManager::saveUpdateHistory()
{
    QString historyPath = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/update_history.json";
    
    QJsonArray history;
    
    for (const UpdateHistoryEntry& entry : m_updateHistory) {
        QJsonObject obj;
        obj["version"] = entry.version;
        obj["installDate"] = entry.installDate.toString(Qt::ISODate);
        obj["size"] = entry.size;
        obj["success"] = entry.success;
        obj["rollbackAvailable"] = entry.rollbackAvailable;
        obj["backupPath"] = entry.backupPath;
        
        history.append(obj);
    }
    
    QJsonDocument doc(history);
    
    QFile file(historyPath);
    if (file.open(QIODevice::WriteOnly)) {
        file.write(doc.toJson());
        file.close();
    }
}

// Getters
UpdateStatistics UpdateManager::getStatistics() const
{
    return m_statistics;
}

UpdateInfo UpdateManager::getUpdateInfo() const
{
    return m_updateInfo;
}

QList<UpdateHistoryEntry> UpdateManager::getUpdateHistory() const
{
    return m_updateHistory;
}

QList<UpdateServer> UpdateManager::getUpdateServers() const
{
    return m_updateServers;
}

bool UpdateManager::isInitialized() const
{
    return m_initialized;
}

bool UpdateManager::hasUpdate() const
{
    return m_hasUpdate;
}

bool UpdateManager::isDownloading() const
{
    return m_isDownloading;
}

bool UpdateManager::isInstalling() const
{
    return m_isInstalling;
}

bool UpdateManager::isChecking() const
{
    return m_isChecking;
}

int UpdateManager::getDownloadProgress() const
{
    return m_downloadProgress;
}

qint64 UpdateManager::getDownloadSpeed() const
{
    return m_downloadSpeed;
}

qint64 UpdateManager::getEstimatedTimeRemaining() const
{
    return m_estimatedTimeRemaining;
}

QString UpdateManager::getCurrentVersion() const
{
    return m_currentVersion;
}

// Slot implementations
void UpdateManager::onUpdateTimer()
{
    if (m_enableAutoUpdate && !m_isChecking) {
        checkForUpdates();
    }
}

void UpdateManager::onDownloadTimer()
{
    // Calculate download speed and estimated time remaining
    static qint64 lastBytesReceived = 0;
    static QDateTime lastUpdate = QDateTime::currentDateTime();
    
    QDateTime now = QDateTime::currentDateTime();
    qint64 elapsedMs = lastUpdate.msecsTo(now);
    
    if (elapsedMs > 0) {
        qint64 bytesPerMs = (m_totalBytesReceived - lastBytesReceived) / elapsedMs;
        m_downloadSpeed = bytesPerMs * 1000; // bytes per second
        
        if (m_downloadSpeed > 0) {
            qint64 remainingBytes = m_totalBytesToReceive - m_totalBytesReceived;
            m_estimatedTimeRemaining = remainingBytes / m_downloadSpeed;
        }
    }
    
    lastBytesReceived = m_totalBytesReceived;
    lastUpdate = now;
    
    emit downloadSpeedUpdated(m_downloadSpeed, m_estimatedTimeRemaining);
}

void UpdateManager::onRetryTimer()
{
    // Retry failed operations
    m_retryTimer->stop();
    
    if (!m_isChecking && !m_hasUpdate) {
        checkForUpdates();
    }
}

void UpdateManager::onCleanupTimer()
{
    QMutexLocker locker(&m_mutex);
    
    // Clean up old downloads
    QString downloadsDir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/updates/downloads";
    QDir dir(downloadsDir);
    
    QFileInfoList files = dir.entryInfoList(QDir::Files, QDir::Time);
    qint64 totalSize = 0;
    
    for (const QFileInfo& fileInfo : files) {
        totalSize += fileInfo.size();
    }
    
    // Remove old files if cache size exceeds limit
    if (totalSize > m_maxCacheSize) {
        for (int i = files.size() - 1; i >= 0 && totalSize > m_maxCacheSize / 2; --i) {
            const QFileInfo& fileInfo = files[i];
            totalSize -= fileInfo.size();
            QFile::remove(fileInfo.absoluteFilePath());
        }
    }
    
    // Clean up old backups (keep only last 5)
    QString backupsDir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/updates/backups";
    QDir backupDir(backupsDir);
    
    QStringList backups = backupDir.entryList(QDir::Dirs | QDir::NoDotAndDotDot, QDir::Time);
    while (backups.size() > 5) {
        QString oldestBackup = backups.takeLast();
        QDir(backupsDir + "/" + oldestBackup).removeRecursively();
    }
}

void UpdateManager::onMetricsTimer()
{
    m_statistics.uptime++;
    emit statisticsUpdated(m_statistics);
}

// Configuration slots
void UpdateManager::onAutoUpdateToggled(bool enabled)
{
    m_enableAutoUpdate = enabled;
    
    if (enabled && m_enableBackgroundCheck) {
        m_updateTimer->start(m_checkInterval);
    } else {
        m_updateTimer->stop();
    }
    
    emit statusChanged(enabled ? "Auto-update enabled" : "Auto-update disabled");
}

void UpdateManager::onBetaUpdatesToggled(bool enabled)
{
    m_enableBetaUpdates = enabled;
    emit statusChanged(enabled ? "Beta updates enabled" : "Beta updates disabled");
}

void UpdateManager::onPreReleaseUpdatesToggled(bool enabled)
{
    m_enablePreReleaseUpdates = enabled;
    emit statusChanged(enabled ? "Pre-release updates enabled" : "Pre-release updates disabled");
}

void UpdateManager::onBackgroundCheckToggled(bool enabled)
{
    m_enableBackgroundCheck = enabled;
    
    if (enabled && m_enableAutoUpdate) {
        m_updateTimer->start(m_checkInterval);
    } else {
        m_updateTimer->stop();
    }
    
    emit statusChanged(enabled ? "Background checking enabled" : "Background checking disabled");
}

void UpdateManager::onNotificationsToggled(bool enabled)
{
    m_enableNotifications = enabled;
    emit statusChanged(enabled ? "Update notifications enabled" : "Update notifications disabled");
}

void UpdateManager::onAutoDownloadToggled(bool enabled)
{
    m_enableAutoDownload = enabled;
    emit statusChanged(enabled ? "Auto-download enabled" : "Auto-download disabled");
}

void UpdateManager::onAutoInstallToggled(bool enabled)
{
    m_enableAutoInstall = enabled;
    emit statusChanged(enabled ? "Auto-install enabled" : "Auto-install disabled");
}

void UpdateManager::onRollbackToggled(bool enabled)
{
    m_enableRollback = enabled;
    emit statusChanged(enabled ? "Rollback enabled" : "Rollback disabled");
}

void UpdateManager::onCheckIntervalChanged(int interval)
{
    m_checkInterval = interval;
    
    if (m_updateTimer->isActive()) {
        m_updateTimer->start(m_checkInterval);
    }
    
    emit statusChanged(QString("Check interval set to %1 ms").arg(interval));
}

void UpdateManager::onDownloadTimeoutChanged(int timeout)
{
    m_downloadTimeout = timeout;
    emit statusChanged(QString("Download timeout set to %1 ms").arg(timeout));
}

void UpdateManager::onRetryAttemptsChanged(int attempts)
{
    m_retryAttempts = attempts;
    emit statusChanged(QString("Retry attempts set to %1").arg(attempts));
}

void UpdateManager::onRetryDelayChanged(int delay)
{
    m_retryDelay = delay;
    emit statusChanged(QString("Retry delay set to %1 ms").arg(delay));
}

void UpdateManager::onUpdateChannelChanged(int channel)
{
    m_updateChannel = static_cast<UpdateChannel>(channel);
    emit statusChanged(QString("Update channel changed to %1").arg(channel));
}

void UpdateManager::onDownloadMethodChanged(int method)
{
    m_downloadMethod = static_cast<DownloadMethod>(method);
    emit statusChanged(QString("Download method changed to %1").arg(method));
}

void UpdateManager::onInstallMethodChanged(int method)
{
    m_installMethod = static_cast<InstallMethod>(method);
    emit statusChanged(QString("Install method changed to %1").arg(method));
}

void UpdateManager::onCancelDownload()
{
    if (m_isDownloading && m_currentDownload) {
        m_currentDownload->abort();
        emit statusChanged("Download cancelled");
    }
}

void UpdateManager::onPauseDownload()
{
    // Pause functionality would require more complex implementation
    emit statusChanged("Download pause not implemented");
}

void UpdateManager::onResumeDownload()
{
    // Resume functionality would require more complex implementation
    emit statusChanged("Download resume not implemented");
}

void UpdateManager::onClearCache()
{
    QString cacheDir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/updates/cache";
    QDir dir(cacheDir);
    dir.removeRecursively();
    dir.mkpath(".");
    
    emit statusChanged("Update cache cleared");
}

void UpdateManager::onClearHistory()
{
    m_updateHistory.clear();
    saveUpdateHistory();
    
    emit statusChanged("Update history cleared");
}

void UpdateManager::onExportStatistics()
{
    QString filename = QString("update_stats_%1.json").arg(QDateTime::currentDateTime().toString("yyyyMMdd_hhmmss"));
    
    QJsonObject statsObj;
    statsObj["totalChecks"] = static_cast<qint64>(m_statistics.totalChecks);
    statsObj["totalDownloads"] = static_cast<qint64>(m_statistics.totalDownloads);
    statsObj["totalInstalls"] = static_cast<qint64>(m_statistics.totalInstalls);
    statsObj["totalRollbacks"] = static_cast<qint64>(m_statistics.totalRollbacks);
    statsObj["successfulChecks"] = static_cast<qint64>(m_statistics.successfulChecks);
    statsObj["successfulDownloads"] = static_cast<qint64>(m_statistics.successfulDownloads);
    statsObj["successfulInstalls"] = static_cast<qint64>(m_statistics.successfulInstalls);
    statsObj["failedChecks"] = static_cast<qint64>(m_statistics.failedChecks);
    statsObj["failedDownloads"] = static_cast<qint64>(m_statistics.failedDownloads);
    statsObj["failedInstalls"] = static_cast<qint64>(m_statistics.failedInstalls);
    statsObj["totalBytesDownloaded"] = static_cast<qint64>(m_statistics.totalBytesDownloaded);
    statsObj["averageDownloadSpeed"] = static_cast<qint64>(m_statistics.averageDownloadSpeed);
    statsObj["averageCheckTime"] = m_statistics.averageCheckTime;
    statsObj["averageDownloadTime"] = m_statistics.averageDownloadTime;
    statsObj["averageInstallTime"] = m_statistics.averageInstallTime;
    statsObj["lastCheck"] = m_statistics.lastCheck.toString(Qt::ISODate);
    statsObj["lastDownload"] = m_statistics.lastDownload.toString(Qt::ISODate);
    statsObj["lastInstall"] = m_statistics.lastInstall.toString(Qt::ISODate);
    statsObj["uptime"] = static_cast<qint64>(m_statistics.uptime);
    
    QJsonDocument doc(statsObj);
    
    QFile file(filename);
    if (file.open(QIODevice::WriteOnly)) {
        file.write(doc.toJson());
        file.close();
        emit statusChanged(QString("Statistics exported to %1").arg(filename));
    } else {
        emit errorOccurred(QString("Failed to export statistics to %1").arg(filename));
    }
}