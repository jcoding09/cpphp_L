#ifndef MODULE_MANAGER_H
#define MODULE_MANAGER_H

#include <QtCore/QObject>
#include <QtCore/QString>
#include <QtCore/QStringList>
#include <QtCore/QTimer>
#include <memory>
#include <vector>

struct ModuleInfo
{
    QString name;
    QString path;
    QString version;
    bool isLoaded;
    bool isEnabled;
    qint64 baseAddress;
    qint64 size;
    QString description;
};

class ModuleManager : public QObject
{
    Q_OBJECT

public:
    explicit ModuleManager(QObject *parent = nullptr);
    ~ModuleManager();

    // Module management
    bool loadModule(const QString &modulePath);
    bool unloadModule(const QString &moduleName);
    bool enableModule(const QString &moduleName);
    bool disableModule(const QString &moduleName);
    
    // Module information
    std::vector<ModuleInfo> getLoadedModules() const;
    ModuleInfo getModuleInfo(const QString &moduleName) const;
    bool isModuleLoaded(const QString &moduleName) const;
    
    // Module scanning
    void scanForModules();
    QStringList getAvailableModules() const;
    
    // Process monitoring
    void startMonitoring();
    void stopMonitoring();
    
signals:
    void moduleLoaded(const QString &moduleName);
    void moduleUnloaded(const QString &moduleName);
    void moduleEnabled(const QString &moduleName);
    void moduleDisabled(const QString &moduleName);
    void moduleDetected(const ModuleInfo &info);
    
private slots:
    void checkModules();
    
private:
    class ModuleManagerPrivate;
    std::unique_ptr<ModuleManagerPrivate> d;
};

#endif // MODULE_MANAGER_H