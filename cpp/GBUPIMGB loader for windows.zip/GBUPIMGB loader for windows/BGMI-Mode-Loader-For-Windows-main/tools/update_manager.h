#ifndef UPDATE_MANAGER_H
#define UPDATE_MANAGER_H

#include <QtCore/QObject>
#include <QtCore/QString>
#include <QtCore/QUrl>
#include <QtCore/QTimer>
#include <QtCore/QVersionNumber>
#include <memory>

struct UpdateInfo
{
    QVersionNumber version;
    QString description;
    QUrl downloadUrl;
    qint64 fileSize;
    QString checksum;
    bool isRequired;
    QString releaseDate;
};

class UpdateManager : public QObject
{
    Q_OBJECT

public:
    explicit UpdateManager(QObject *parent = nullptr);
    ~UpdateManager();

    // Update checking
    void checkForUpdates();
    void setUpdateUrl(const QUrl &url);
    void setCurrentVersion(const QVersionNumber &version);
    QVersionNumber getCurrentVersion() const;
    
    // Update management
    void downloadUpdate(const UpdateInfo &info);
    void installUpdate(const QString &filePath);
    void scheduleUpdate(const UpdateInfo &info);
    
    // Auto-update settings
    void enableAutoUpdate(bool enable = true);
    bool isAutoUpdateEnabled() const;
    void setUpdateInterval(int hours);
    int getUpdateInterval() const;
    
    // Update information
    bool isUpdateAvailable() const;
    UpdateInfo getLatestUpdate() const;
    QString getUpdateStatus() const;
    
signals:
    void updateAvailable(const UpdateInfo &info);
    void updateDownloadProgress(qint64 bytesReceived, qint64 bytesTotal);
    void updateDownloaded(const QString &filePath);
    void updateInstalled();
    void updateError(const QString &error);
    void updateCheckFinished(bool available);
    
private slots:
    void performUpdateCheck();
    void onDownloadProgress(qint64 bytesReceived, qint64 bytesTotal);
    void onDownloadFinished();
    
private:
    class UpdateManagerPrivate;
    std::unique_ptr<UpdateManagerPrivate> d;
};

#endif // UPDATE_MANAGER_H