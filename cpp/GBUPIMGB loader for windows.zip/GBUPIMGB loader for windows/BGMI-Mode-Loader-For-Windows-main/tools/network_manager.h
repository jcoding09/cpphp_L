#ifndef NETWORK_MANAGER_H
#define NETWORK_MANAGER_H

#include <QtCore/QObject>
#include <QtCore/QByteArray>
#include <QtCore/QString>
#include <QtCore/QUrl>
#include <QtCore/QTimer>
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkReply>
#include <memory>

struct NetworkStats
{
    qint64 bytesReceived;
    qint64 bytesSent;
    qint64 packetsReceived;
    qint64 packetsSent;
    double packetLoss;
    int ping;
    QString connectionStatus;
};

class NetworkManager : public QObject
{
    Q_OBJECT

public:
    explicit NetworkManager(QObject *parent = nullptr);
    ~NetworkManager();

    // Network operations
    void sendRequest(const QUrl &url, const QByteArray &data = QByteArray());
    void downloadFile(const QUrl &url, const QString &filePath);
    void uploadFile(const QUrl &url, const QString &filePath);
    
    // Network monitoring
    void startMonitoring();
    void stopMonitoring();
    NetworkStats getNetworkStats() const;
    
    // Connection management
    bool isConnected() const;
    void setProxy(const QString &host, int port, const QString &username = QString(), const QString &password = QString());
    void clearProxy();
    
    // Security
    void enableSSL(bool enable = true);
    void setUserAgent(const QString &userAgent);
    void setTimeout(int timeoutMs);
    
signals:
    void requestFinished(const QByteArray &data);
    void requestError(const QString &error);
    void downloadProgress(qint64 bytesReceived, qint64 bytesTotal);
    void uploadProgress(qint64 bytesSent, qint64 bytesTotal);
    void networkStatsUpdated(const NetworkStats &stats);
    void connectionStatusChanged(bool connected);
    
private slots:
    void onRequestFinished(QNetworkReply *reply);
    void updateNetworkStats();
    
private:
    class NetworkManagerPrivate;
    std::unique_ptr<NetworkManagerPrivate> d;
};

#endif // NETWORK_MANAGER_H