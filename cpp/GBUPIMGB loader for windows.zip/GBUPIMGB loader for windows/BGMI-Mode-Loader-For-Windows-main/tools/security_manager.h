#ifndef SECURITY_MANAGER_H
#define SECURITY_MANAGER_H

#include <QtCore/QObject>
#include <QtCore/QString>
#include <QtCore/QStringList>
#include <QtCore/QVector>
#include <QtCore/QMap>
#include <QtCore/QSet>
#include <QtCore/QDateTime>
#include <QtCore/QTimer>
#include <QtCore/QMutex>
#include <QtCore/QThread>
#include <QtCore/QCryptographicHash>
#include <QtCore/QRandomGenerator>
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkReply>
#include <memory>

// Forward declarations
class Logger;
class MemoryManager;
class GameInterface;
class InjectionManager;

enum class SecurityLevel {
    None = 0,
    Low = 1,
    Medium = 2,
    High = 3,
    Maximum = 4,
    Paranoid = 5
};

enum class ThreatType {
    Unknown = 0,
    AntiCheat = 1,
    Debugger = 2,
    VirtualMachine = 3,
    Sandbox = 4,
    Monitor = 5,
    Injection = 6,
    Memory = 7,
    Process = 8,
    Network = 9,
    File = 10,
    Registry = 11,
    Hardware = 12,
    Behavioral = 13,
    Signature = 14,
    Heuristic = 15
};

enum class ThreatLevel {
    None = 0,
    Low = 1,
    Medium = 2,
    High = 3,
    Critical = 4,
    Extreme = 5
};

enum class DetectionMethod {
    Unknown = 0,
    Static = 1,
    Dynamic = 2,
    Behavioral = 3,
    Signature = 4,
    Heuristic = 5,
    Machine_Learning = 6,
    Cloud = 7,
    Hybrid = 8
};

enum class ProtectionType {
    None = 0,
    Obfuscation = 1,
    Encryption = 2,
    Packing = 3,
    AntiDebug = 4,
    AntiVM = 5,
    AntiSandbox = 6,
    AntiDump = 7,
    AntiHook = 8,
    AntiInject = 9,
    Stealth = 10,
    Evasion = 11,
    Polymorphism = 12,
    Metamorphism = 13,
    CodeCaves = 14,
    ProcessHollowing = 15
};

enum class SecurityStatus {
    Unknown = 0,
    Safe = 1,
    Warning = 2,
    Danger = 3,
    Critical = 4,
    Compromised = 5
};

enum class AntiCheatType {
    Unknown = 0,
    BattlEye = 1,
    EasyAntiCheat = 2,
    VAC = 3,
    XIGNCODE = 4,
    nProtect = 5,
    Punkbuster = 6,
    FairFight = 7,
    Ricochet = 8,
    Vanguard = 9,
    Custom = 10,
    Kernel = 11,
    Usermode = 12,
    Hybrid_AC = 13
};

struct ThreatInfo {
    QString id;
    QString name;
    QString description;
    
    ThreatType type = ThreatType::Unknown;
    ThreatLevel level = ThreatLevel::None;
    DetectionMethod method = DetectionMethod::Unknown;
    
    QString processName;
    QString moduleName;
    QString signature;
    QString hash;
    
    QStringList indicators;
    QStringList behaviors;
    QStringList mitigation;
    
    bool isActive = false;
    bool isPersistent = false;
    bool isKnown = false;
    
    QDateTime firstDetected;
    QDateTime lastDetected;
    int detectionCount = 0;
    
    QMap<QString, QVariant> properties;
};

struct SecurityEvent {
    QString id;
    QString type;
    QString source;
    QString target;
    QString description;
    
    ThreatLevel severity = ThreatLevel::None;
    SecurityStatus status = SecurityStatus::Unknown;
    
    QDateTime timestamp;
    QString location;
    QString context;
    
    QStringList details;
    QMap<QString, QVariant> data;
    
    bool isHandled = false;
    bool isBlocked = false;
    QString response;
};

struct ProtectionConfig {
    ProtectionType type = ProtectionType::None;
    SecurityLevel level = SecurityLevel::None;
    
    bool enabled = false;
    bool automatic = true;
    bool aggressive = false;
    
    QStringList targets;
    QStringList exclusions;
    QMap<QString, QVariant> parameters;
    
    int priority = 0;
    int interval = 1000; // ms
    int timeout = 5000; // ms
    
    QString description;
    QDateTime lastUpdate;
};

struct AntiCheatInfo {
    QString name;
    QString version;
    QString description;
    
    AntiCheatType type = AntiCheatType::Unknown;
    ThreatLevel level = ThreatLevel::None;
    
    QString processName;
    QString serviceName;
    QString driverName;
    QStringList modules;
    
    bool isActive = false;
    bool isKernel = false;
    bool isUsermode = false;
    bool isHybrid = false;
    
    QStringList capabilities;
    QStringList techniques;
    QStringList signatures;
    
    QDateTime detectedAt;
    QString detectionMethod;
    
    QMap<QString, QVariant> properties;
};

struct SecurityStatistics {
    // Detection statistics
    int totalThreats = 0;
    int activeThreats = 0;
    int blockedThreats = 0;
    int mitigatedThreats = 0;
    
    // Event statistics
    int totalEvents = 0;
    int criticalEvents = 0;
    int warningEvents = 0;
    int infoEvents = 0;
    
    // Protection statistics
    int activeProtections = 0;
    int successfulBlocks = 0;
    int failedBlocks = 0;
    int bypassAttempts = 0;
    
    // Performance statistics
    float averageResponseTime = 0.0f;
    float cpuUsage = 0.0f;
    float memoryUsage = 0.0f;
    int scanCount = 0;
    
    // Time statistics
    QDateTime lastScan;
    QDateTime lastThreat;
    QDateTime lastUpdate;
    int uptime = 0; // seconds
    
    QMap<QString, int> threatsByType;
    QMap<QString, int> eventsByType;
    QMap<QString, QVariant> customStats;
};

class SecurityManager : public QObject
{
    Q_OBJECT

public:
    explicit SecurityManager(QObject *parent = nullptr);
    ~SecurityManager();
    
    // Component integration
    void setLogger(Logger *logger);
    void setMemoryManager(MemoryManager *memoryManager);
    void setGameInterface(GameInterface *gameInterface);
    void setInjectionManager(InjectionManager *injectionManager);
    
    // Initialization
    bool initialize();
    void cleanup();
    bool isInitialized() const;
    
    // Security level management
    void setSecurityLevel(SecurityLevel level);
    SecurityLevel getSecurityLevel() const;
    void setAutoAdjustLevel(bool enabled);
    bool isAutoAdjustLevelEnabled() const;
    
    // Threat detection
    bool startThreatDetection();
    void stopThreatDetection();
    bool isThreatDetectionActive() const;
    void scanForThreats();
    void scanProcess(const QString &processName);
    void scanModule(const QString &moduleName);
    void scanMemory(void *address, size_t size);
    
    // Threat management
    QList<ThreatInfo> getActiveThreats() const;
    QList<ThreatInfo> getAllThreats() const;
    ThreatInfo getThreat(const QString &id) const;
    void addThreat(const ThreatInfo &threat);
    void updateThreat(const ThreatInfo &threat);
    void removeThreat(const QString &id);
    void clearThreats();
    bool hasThreat(const QString &id) const;
    bool hasThreatType(ThreatType type) const;
    
    // Anti-cheat detection
    QList<AntiCheatInfo> getDetectedAntiCheats() const;
    AntiCheatInfo getAntiCheat(AntiCheatType type) const;
    bool hasAntiCheat(AntiCheatType type) const;
    void scanForAntiCheats();
    void addAntiCheat(const AntiCheatInfo &info);
    void updateAntiCheat(const AntiCheatInfo &info);
    
    // Protection management
    void enableProtection(ProtectionType type);
    void disableProtection(ProtectionType type);
    bool isProtectionEnabled(ProtectionType type) const;
    void setProtectionConfig(const ProtectionConfig &config);
    ProtectionConfig getProtectionConfig(ProtectionType type) const;
    QList<ProtectionConfig> getAllProtections() const;
    
    // Specific protections
    void enableAntiDebug();
    void disableAntiDebug();
    void enableAntiVM();
    void disableAntiVM();
    void enableAntiSandbox();
    void disableAntiSandbox();
    void enableStealth();
    void disableStealth();
    void enableObfuscation();
    void disableObfuscation();
    
    // Event management
    QList<SecurityEvent> getSecurityEvents() const;
    QList<SecurityEvent> getRecentEvents(int count = 100) const;
    SecurityEvent getEvent(const QString &id) const;
    void addSecurityEvent(const SecurityEvent &event);
    void clearSecurityEvents();
    
    // Security status
    SecurityStatus getSecurityStatus() const;
    QString getSecurityStatusText() const;
    bool isSafe() const;
    bool hasWarnings() const;
    bool hasCriticalThreats() const;
    
    // Evasion techniques
    void enableProcessHiding();
    void disableProcessHiding();
    void enableModuleHiding();
    void disableModuleHiding();
    void enableMemoryProtection();
    void disableMemoryProtection();
    void enableAPIHooking();
    void disableAPIHooking();
    
    // Code protection
    void obfuscateCode(void *address, size_t size);
    void deobfuscateCode(void *address, size_t size);
    void encryptCode(void *address, size_t size, const QString &key);
    void decryptCode(void *address, size_t size, const QString &key);
    void polymorphCode(void *address, size_t size);
    
    // Environment checks
    bool isDebuggerPresent() const;
    bool isVirtualMachine() const;
    bool isSandbox() const;
    bool isMonitored() const;
    bool isAnalysisEnvironment() const;
    bool hasKnownAnalysisTools() const;
    
    // Process protection
    void protectProcess();
    void unprotectProcess();
    bool isProcessProtected() const;
    void hideProcess();
    void unhideProcess();
    bool isProcessHidden() const;
    
    // Memory protection
    void protectMemoryRegion(void *address, size_t size);
    void unprotectMemoryRegion(void *address, size_t size);
    bool isMemoryRegionProtected(void *address) const;
    void hideMemoryRegion(void *address, size_t size);
    void unhideMemoryRegion(void *address, size_t size);
    
    // Network security
    void enableNetworkProtection();
    void disableNetworkProtection();
    bool isNetworkProtectionEnabled() const;
    void blockNetworkTraffic(const QString &address);
    void allowNetworkTraffic(const QString &address);
    QStringList getBlockedAddresses() const;
    
    // File system protection
    void enableFileProtection();
    void disableFileProtection();
    bool isFileProtectionEnabled() const;
    void protectFile(const QString &filename);
    void unprotectFile(const QString &filename);
    bool isFileProtected(const QString &filename) const;
    
    // Registry protection
    void enableRegistryProtection();
    void disableRegistryProtection();
    bool isRegistryProtectionEnabled() const;
    void protectRegistryKey(const QString &key);
    void unprotectRegistryKey(const QString &key);
    bool isRegistryKeyProtected(const QString &key) const;
    
    // Signature management
    void addThreatSignature(const QString &signature, ThreatType type);
    void removeThreatSignature(const QString &signature);
    QStringList getThreatSignatures(ThreatType type) const;
    bool hasThreatSignature(const QString &signature) const;
    void updateSignatureDatabase();
    
    // Whitelist/Blacklist management
    void addToWhitelist(const QString &item);
    void removeFromWhitelist(const QString &item);
    QStringList getWhitelist() const;
    bool isWhitelisted(const QString &item) const;
    void addToBlacklist(const QString &item);
    void removeFromBlacklist(const QString &item);
    QStringList getBlacklist() const;
    bool isBlacklisted(const QString &item) const;
    
    // Statistics
    SecurityStatistics getStatistics() const;
    void resetStatistics();
    void updateStatistics();
    
    // Configuration
    void loadConfiguration(const QString &filename);
    void saveConfiguration(const QString &filename) const;
    void resetConfiguration();
    void setAutoSave(bool enabled);
    bool isAutoSaveEnabled() const;
    
    // Emergency functions
    void emergencyShutdown();
    void emergencyHide();
    void emergencyCleanup();
    void panicMode();
    
    // Utility functions
    static QString securityLevelToString(SecurityLevel level);
    static SecurityLevel stringToSecurityLevel(const QString &str);
    static QString threatTypeToString(ThreatType type);
    static ThreatType stringToThreatType(const QString &str);
    static QString threatLevelToString(ThreatLevel level);
    static ThreatLevel stringToThreatLevel(const QString &str);
    static QString protectionTypeToString(ProtectionType type);
    static ProtectionType stringToProtectionType(const QString &str);
    static QString antiCheatTypeToString(AntiCheatType type);
    static AntiCheatType stringToAntiCheatType(const QString &str);
    
public slots:
    // Security level slots
    void onSecurityLevelChangeRequested(int level);
    void onAutoAdjustLevelToggled(bool enabled);
    
    // Threat detection slots
    void onThreatDetectionToggled(bool enabled);
    void onScanRequested();
    void onThreatScanRequested(const QString &target);
    void onAntiCheatScanRequested();
    
    // Protection slots
    void onProtectionToggled(int type, bool enabled);
    void onProtectionConfigChanged(const ProtectionConfig &config);
    void onAntiDebugToggled(bool enabled);
    void onAntiVMToggled(bool enabled);
    void onAntiSandboxToggled(bool enabled);
    void onStealthToggled(bool enabled);
    void onObfuscationToggled(bool enabled);
    
    // Event slots
    void onSecurityEventReceived(const SecurityEvent &event);
    void onClearEventsRequested();
    
    // Emergency slots
    void onEmergencyShutdownRequested();
    void onEmergencyHideRequested();
    void onEmergencyCleanupRequested();
    void onPanicModeRequested();
    
    // Configuration slots
    void onLoadConfigurationRequested(const QString &filename);
    void onSaveConfigurationRequested(const QString &filename);
    void onResetConfigurationRequested();
    void onAutoSaveToggled(bool enabled);
    
private slots:
    void onScanTimer();
    void onProtectionTimer();
    void onStatisticsTimer();
    void onAutoSaveTimer();
    void onThreatDetected(const ThreatInfo &threat);
    void onProtectionTriggered(ProtectionType type, const QString &details);
    
signals:
    void securityLevelChanged(SecurityLevel oldLevel, SecurityLevel newLevel);
    void autoAdjustLevelToggled(bool enabled);
    
    void threatDetectionStarted();
    void threatDetectionStopped();
    void threatDetected(const ThreatInfo &threat);
    void threatRemoved(const QString &id);
    void threatsCleared();
    
    void antiCheatDetected(const AntiCheatInfo &info);
    void antiCheatRemoved(AntiCheatType type);
    
    void protectionEnabled(ProtectionType type);
    void protectionDisabled(ProtectionType type);
    void protectionTriggered(ProtectionType type, const QString &details);
    void protectionConfigChanged(const ProtectionConfig &config);
    
    void securityEventAdded(const SecurityEvent &event);
    void securityEventsCleared();
    
    void securityStatusChanged(SecurityStatus oldStatus, SecurityStatus newStatus);
    
    void emergencyShutdownTriggered();
    void emergencyHideTriggered();
    void emergencyCleanupTriggered();
    void panicModeTriggered();
    
    void configurationLoaded(const QString &filename, bool success);
    void configurationSaved(const QString &filename, bool success);
    void configurationReset();
    void autoSaveToggled(bool enabled);
    
    void statisticsUpdated(const SecurityStatistics &stats);
    void statisticsReset();
    
    void error(const QString &message);
    void warning(const QString &message);
    void info(const QString &message);
    
private:
    // Detection methods
    void detectDebugger();
    void detectVirtualMachine();
    void detectSandbox();
    void detectMonitoring();
    void detectAntiCheat();
    void detectProcesses();
    void detectModules();
    void detectSignatures();
    void detectBehaviors();
    
    // Protection methods
    void applyAntiDebug();
    void applyAntiVM();
    void applyAntiSandbox();
    void applyStealth();
    void applyObfuscation();
    void applyProcessProtection();
    void applyMemoryProtection();
    void applyNetworkProtection();
    void applyFileProtection();
    void applyRegistryProtection();
    
    // Evasion methods
    void hideFromProcessList();
    void hideFromModuleList();
    void hideFromMemoryScans();
    void hideFromAPIHooks();
    void hideFromDebuggers();
    void hideFromAnalysis();
    
    // Code manipulation
    void obfuscateCodeInternal(void *address, size_t size);
    void encryptCodeInternal(void *address, size_t size, const QByteArray &key);
    void polymorphCodeInternal(void *address, size_t size);
    QByteArray generatePolymorphicCode(const QByteArray &original);
    QByteArray generateRandomKey(int length);
    
    // Environment analysis
    bool checkDebuggerPresence();
    bool checkVirtualMachinePresence();
    bool checkSandboxPresence();
    bool checkMonitoringPresence();
    bool checkAnalysisTools();
    QStringList getRunningProcesses();
    QStringList getLoadedModules();
    
    // Threat analysis
    ThreatLevel analyzeThreat(const ThreatInfo &threat);
    bool isThreatKnown(const ThreatInfo &threat);
    void categorizeThreat(ThreatInfo &threat);
    void updateThreatDatabase();
    
    // Response handling
    void handleThreatDetection(const ThreatInfo &threat);
    void handleProtectionTrigger(ProtectionType type, const QString &details);
    void handleSecurityEvent(const SecurityEvent &event);
    void handleEmergency(const QString &reason);
    
    // Configuration management
    void loadDefaultConfiguration();
    void validateConfiguration();
    void applyConfiguration();
    
    // Statistics management
    void updateStatisticsInternal();
    void recordThreatDetection(const ThreatInfo &threat);
    void recordProtectionTrigger(ProtectionType type);
    void recordSecurityEvent(const SecurityEvent &event);
    
    // Utility methods
    QString generateThreatId();
    QString generateEventId();
    QByteArray calculateHash(const QByteArray &data);
    QString getCurrentTimestamp();
    
    // Error handling
    void handleError(const QString &operation, const QString &error);
    void handleWarning(const QString &operation, const QString &warning);
    void logOperation(const QString &operation, bool success);
    
    // Core components
    Logger *m_logger;
    MemoryManager *m_memoryManager;
    GameInterface *m_gameInterface;
    InjectionManager *m_injectionManager;
    
    // Security configuration
    SecurityLevel m_securityLevel;
    bool m_autoAdjustLevel;
    bool m_autoSave;
    
    // Threat data
    QMap<QString, ThreatInfo> m_threats;
    QMap<AntiCheatType, AntiCheatInfo> m_antiCheats;
    QVector<SecurityEvent> m_securityEvents;
    
    // Protection data
    QMap<ProtectionType, ProtectionConfig> m_protections;
    QSet<ProtectionType> m_activeProtections;
    
    // Signature data
    QMap<ThreatType, QStringList> m_threatSignatures;
    QStringList m_whitelist;
    QStringList m_blacklist;
    
    // Statistics
    SecurityStatistics m_statistics;
    
    // Timers
    QTimer *m_scanTimer;
    QTimer *m_protectionTimer;
    QTimer *m_statisticsTimer;
    QTimer *m_autoSaveTimer;
    
    // State
    bool m_initialized;
    bool m_threatDetectionActive;
    SecurityStatus m_securityStatus;
    QMutex m_mutex;
    
    // Threading
    QThread *m_scanThread;
    QThread *m_protectionThread;
    
    // Constants
    static const int DEFAULT_SCAN_INTERVAL = 5000; // 5 seconds
    static const int DEFAULT_PROTECTION_INTERVAL = 1000; // 1 second
    static const int DEFAULT_STATISTICS_INTERVAL = 10000; // 10 seconds
    static const int DEFAULT_AUTOSAVE_INTERVAL = 60000; // 1 minute
    static const int MAX_EVENTS = 1000;
    static const int MAX_THREATS = 100;
};

#endif // SECURITY_MANAGER_H