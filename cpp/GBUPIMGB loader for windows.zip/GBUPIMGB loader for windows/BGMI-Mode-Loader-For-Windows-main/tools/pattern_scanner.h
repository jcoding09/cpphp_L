#ifndef PATTERN_SCANNER_H
#define PATTERN_SCANNER_H

#include <QtCore/QObject>
#include <QtCore/QByteArray>
#include <QtCore/QList>
#include <QtCore/QMap>
#include <QtCore/QString>
#include <QtCore/QStringList>
#include <QtCore/QDateTime>
#include <QtCore/QTimer>
#include <QtCore/QMutex>
#include <QtCore/QThread>
#include <QtCore/QFuture>
#include <QtCore/QFutureWatcher>
#include <QtCore/QJsonObject>
#include <QtCore/QVariant>
#include <memory>

// Forward declarations
class MemoryManager;
class Logger;

enum class PatternType {
    Exact = 0,
    Wildcard = 1,
    Regex = 2,
    Signature = 3,
    Bytes = 4,
    String = 5,
    Unicode = 6,
    Custom = 7
};

enum class ScanRegion {
    All = 0,
    Code = 1,
    Data = 2,
    Heap = 3,
    Stack = 4,
    Module = 5,
    Custom = 6
};

enum class ScanDirection {
    Forward = 0,
    Backward = 1,
    Bidirectional = 2
};

enum class ScanSpeed {
    Slow = 0,
    Normal = 1,
    Fast = 2,
    Turbo = 3
};

enum class ScanStatus {
    Idle = 0,
    Running = 1,
    Paused = 2,
    Completed = 3,
    Cancelled = 4,
    Error = 5
};

enum class MatchQuality {
    Poor = 0,
    Fair = 1,
    Good = 2,
    Excellent = 3,
    Perfect = 4
};

struct PatternMatch {
    quint64 address = 0;
    quint64 offset = 0;
    QByteArray data;
    QString moduleName;
    QString sectionName;
    
    PatternType type = PatternType::Exact;
    MatchQuality quality = MatchQuality::Poor;
    float confidence = 0.0f;
    int matchLength = 0;
    int wildcardCount = 0;
    
    QDateTime timestamp;
    bool verified = false;
    bool isValid = true;
    QString notes;
    
    QMap<QString, QVariant> metadata;
};

struct PatternInfo {
    QString name;
    QString description;
    QString category;
    PatternType type = PatternType::Exact;
    
    QString pattern;
    QByteArray bytes;
    QString mask;
    QString signature;
    QString regex;
    
    ScanRegion region = ScanRegion::All;
    QString moduleName;
    QString sectionName;
    quint64 startAddress = 0;
    quint64 endAddress = 0;
    
    ScanDirection direction = ScanDirection::Forward;
    ScanSpeed speed = ScanSpeed::Normal;
    int alignment = 1;
    int maxResults = 100;
    
    bool caseSensitive = true;
    bool wholeWords = false;
    bool useCache = true;
    bool verifyResults = true;
    
    QStringList tags;
    QMap<QString, QVariant> options;
    QDateTime created;
    QDateTime lastUsed;
    int usageCount = 0;
};

struct ScanConfiguration {
    ScanRegion region = ScanRegion::All;
    ScanDirection direction = ScanDirection::Forward;
    ScanSpeed speed = ScanSpeed::Normal;
    
    quint64 startAddress = 0;
    quint64 endAddress = 0;
    quint64 chunkSize = 0x10000; // 64KB
    int alignment = 1;
    int maxResults = 1000;
    int timeout = 30000; // 30 seconds
    
    bool useMultiThreading = true;
    int threadCount = 0; // Auto-detect
    bool useCache = true;
    bool verifyResults = true;
    bool optimizePatterns = true;
    
    QStringList includeModules;
    QStringList excludeModules;
    QStringList includeSections;
    QStringList excludeSections;
    
    QMap<QString, QVariant> advancedOptions;
};

struct ScanResult {
    QString patternName;
    PatternInfo pattern;
    QList<PatternMatch> matches;
    
    ScanStatus status = ScanStatus::Idle;
    QDateTime startTime;
    QDateTime endTime;
    qint64 duration = 0; // milliseconds
    
    quint64 bytesScanned = 0;
    quint64 totalBytes = 0;
    float progress = 0.0f;
    
    int totalMatches = 0;
    int validMatches = 0;
    int verifiedMatches = 0;
    
    QString errorMessage;
    QStringList warnings;
    QMap<QString, QVariant> statistics;
};

struct ScanStatistics {
    int totalScans = 0;
    int successfulScans = 0;
    int failedScans = 0;
    int cancelledScans = 0;
    
    qint64 totalDuration = 0;
    qint64 averageDuration = 0;
    qint64 fastestScan = 0;
    qint64 slowestScan = 0;
    
    quint64 totalBytesScanned = 0;
    quint64 averageBytesScanned = 0;
    float averageSpeed = 0.0f; // bytes per second
    
    int totalMatches = 0;
    int averageMatches = 0;
    float successRate = 0.0f;
    
    QMap<PatternType, int> typeUsage;
    QMap<ScanRegion, int> regionUsage;
    QMap<ScanSpeed, int> speedUsage;
    
    QStringList mostUsedPatterns;
    QStringList fastestPatterns;
    QStringList slowestPatterns;
    QStringList mostSuccessfulPatterns;
    
    QDateTime lastReset;
    QDateTime lastUpdate;
};

class PatternScanner : public QObject
{
    Q_OBJECT

public:
    explicit PatternScanner(QObject *parent = nullptr);
    ~PatternScanner();
    
    // Component integration
    void setMemoryManager(MemoryManager *memoryManager);
    void setLogger(Logger *logger);
    
    // Initialization
    bool initialize();
    void cleanup();
    bool isInitialized() const;
    
    // Pattern management
    void addPattern(const PatternInfo &pattern);
    void updatePattern(const QString &name, const PatternInfo &pattern);
    void removePattern(const QString &name);
    PatternInfo getPattern(const QString &name) const;
    QList<PatternInfo> getAllPatterns() const;
    QList<PatternInfo> getPatternsByCategory(const QString &category) const;
    QList<PatternInfo> getPatternsByType(PatternType type) const;
    QStringList getPatternNames() const;
    bool hasPattern(const QString &name) const;
    
    // Scanning operations
    QString scanPattern(const QString &name);
    QString scanPattern(const PatternInfo &pattern);
    QString scanBytes(const QByteArray &bytes, const ScanConfiguration &config = ScanConfiguration());
    QString scanString(const QString &text, const ScanConfiguration &config = ScanConfiguration());
    QString scanSignature(const QString &signature, const ScanConfiguration &config = ScanConfiguration());
    QString scanRegex(const QString &regex, const ScanConfiguration &config = ScanConfiguration());
    
    // Batch scanning
    QStringList scanMultiplePatterns(const QStringList &names);
    QStringList scanAllPatterns();
    QStringList scanCategory(const QString &category);
    
    // Scan control
    void pauseScan(const QString &scanId);
    void resumeScan(const QString &scanId);
    void cancelScan(const QString &scanId);
    void cancelAllScans();
    bool isScanRunning(const QString &scanId) const;
    ScanStatus getScanStatus(const QString &scanId) const;
    float getScanProgress(const QString &scanId) const;
    
    // Results management
    ScanResult getScanResult(const QString &scanId) const;
    QList<ScanResult> getAllResults() const;
    QList<PatternMatch> getMatches(const QString &scanId) const;
    PatternMatch getBestMatch(const QString &scanId) const;
    QList<PatternMatch> getVerifiedMatches(const QString &scanId) const;
    void clearResults(const QString &scanId);
    void clearAllResults();
    
    // Result verification
    bool verifyMatch(const PatternMatch &match);
    bool verifyAllMatches(const QString &scanId);
    void setMatchVerified(const QString &scanId, int matchIndex, bool verified);
    int getVerifiedMatchCount(const QString &scanId) const;
    
    // Configuration
    void setConfiguration(const ScanConfiguration &config);
    ScanConfiguration getConfiguration() const;
    void resetConfiguration();
    void loadConfiguration();
    void saveConfiguration() const;
    
    // Advanced scanning
    QString scanWithCustomFilter(const PatternInfo &pattern, std::function<bool(const QByteArray&, quint64)> filter);
    QString scanWithCallback(const PatternInfo &pattern, std::function<void(const PatternMatch&)> callback);
    QString scanIncrementally(const PatternInfo &pattern, quint64 chunkSize = 0x10000);
    QString scanWithPriority(const PatternInfo &pattern, int priority = 0);
    
    // Pattern optimization
    PatternInfo optimizePattern(const PatternInfo &pattern) const;
    QList<PatternInfo> optimizePatterns(const QList<PatternInfo> &patterns) const;
    bool isPatternOptimal(const PatternInfo &pattern) const;
    QString getOptimizationSuggestions(const PatternInfo &pattern) const;
    
    // Cache management
    void enableCache(bool enabled);
    bool isCacheEnabled() const;
    void clearCache();
    void clearCache(const QString &patternName);
    int getCacheSize() const;
    void setCacheLimit(int limit);
    int getCacheLimit() const;
    
    // Statistics
    ScanStatistics getStatistics() const;
    void resetStatistics();
    void updateStatistics();
    QString getPerformanceReport() const;
    QString getUsageReport() const;
    
    // Import/Export
    bool exportPatterns(const QString &filename) const;
    bool importPatterns(const QString &filename);
    bool exportResults(const QString &filename, const QString &scanId = "") const;
    bool importResults(const QString &filename);
    QString exportPatternsToString() const;
    bool importPatternsFromString(const QString &data);
    
    // Utility functions
    static QByteArray stringToBytes(const QString &str);
    static QString bytesToString(const QByteArray &bytes);
    static QByteArray patternToBytes(const QString &pattern);
    static QString bytesToPattern(const QByteArray &bytes);
    static QByteArray signatureToBytes(const QString &signature);
    static QString bytesToSignature(const QByteArray &bytes);
    static bool isValidPattern(const QString &pattern);
    static bool isValidSignature(const QString &signature);
    static QString normalizePattern(const QString &pattern);
    static QString normalizeSignature(const QString &signature);
    
public slots:
    // Pattern management slots
    void onPatternAdded(const QString &name);
    void onPatternUpdated(const QString &name);
    void onPatternRemoved(const QString &name);
    void onPatternUsed(const QString &name);
    
    // Scan control slots
    void onScanRequested(const QString &name);
    void onBatchScanRequested(const QStringList &names);
    void onCategoryScanRequested(const QString &category);
    void onAllPatternsScanRequested();
    void onScanPaused(const QString &scanId);
    void onScanResumed(const QString &scanId);
    void onScanCancelled(const QString &scanId);
    void onAllScansCancelled();
    
    // Configuration slots
    void onConfigurationChanged(const ScanConfiguration &config);
    void onConfigurationReset();
    void onConfigurationLoaded();
    void onConfigurationSaved();
    
    // Cache slots
    void onCacheToggled(bool enabled);
    void onCacheCleared();
    void onCacheLimitChanged(int limit);
    
    // Results slots
    void onResultsCleared(const QString &scanId);
    void onAllResultsCleared();
    void onMatchVerificationRequested(const QString &scanId, int matchIndex);
    void onAllMatchesVerificationRequested(const QString &scanId);
    
    // Statistics slots
    void onStatisticsRequested();
    void onStatisticsReset();
    void onPerformanceReportRequested();
    void onUsageReportRequested();
    
    // Import/Export slots
    void onPatternsExportRequested(const QString &filename);
    void onPatternsImportRequested(const QString &filename);
    void onResultsExportRequested(const QString &filename, const QString &scanId);
    void onResultsImportRequested(const QString &filename);
    
signals:
    void patternAdded(const QString &name, const PatternInfo &pattern);
    void patternUpdated(const QString &name, const PatternInfo &pattern);
    void patternRemoved(const QString &name);
    void patternUsed(const QString &name);
    
    void scanStarted(const QString &scanId, const QString &patternName);
    void scanProgress(const QString &scanId, float progress);
    void scanPaused(const QString &scanId);
    void scanResumed(const QString &scanId);
    void scanCompleted(const QString &scanId, const ScanResult &result);
    void scanCancelled(const QString &scanId);
    void scanError(const QString &scanId, const QString &error);
    
    void matchFound(const QString &scanId, const PatternMatch &match);
    void matchVerified(const QString &scanId, int matchIndex, bool verified);
    void bestMatchFound(const QString &scanId, const PatternMatch &match);
    
    void batchScanStarted(const QStringList &patterns);
    void batchScanProgress(int completed, int total);
    void batchScanCompleted(const QStringList &scanIds);
    void batchScanCancelled();
    
    void configurationChanged(const ScanConfiguration &config);
    void cacheToggled(bool enabled);
    void cacheCleared();
    void cacheLimitChanged(int limit);
    
    void statisticsUpdated(const ScanStatistics &stats);
    void performanceReportGenerated(const QString &report);
    void usageReportGenerated(const QString &report);
    
    void patternsExported(const QString &filename, bool success);
    void patternsImported(const QString &filename, bool success, int count);
    void resultsExported(const QString &filename, bool success);
    void resultsImported(const QString &filename, bool success, int count);
    
    void error(const QString &message);
    void warning(const QString &message);
    void info(const QString &message);
    
private slots:
    void onScanFinished();
    void onScanThreadFinished();
    void onCacheCleanupTimer();
    void onStatisticsUpdateTimer();
    
private:
    // Core scanning implementation
    ScanResult performScan(const PatternInfo &pattern, const ScanConfiguration &config);
    QList<PatternMatch> scanMemoryRegion(const PatternInfo &pattern, quint64 startAddr, quint64 endAddr);
    QList<PatternMatch> scanBytes(const QByteArray &data, const QByteArray &pattern, const QByteArray &mask, quint64 baseAddr);
    QList<PatternMatch> scanString(const QByteArray &data, const QString &text, quint64 baseAddr, bool caseSensitive);
    QList<PatternMatch> scanRegex(const QByteArray &data, const QString &regex, quint64 baseAddr);
    QList<PatternMatch> scanSignature(const QByteArray &data, const QString &signature, quint64 baseAddr);
    
    // Pattern processing
    QByteArray processPattern(const QString &pattern, QByteArray &mask) const;
    QByteArray processSignature(const QString &signature) const;
    bool validatePattern(const PatternInfo &pattern) const;
    PatternInfo preprocessPattern(const PatternInfo &pattern) const;
    
    // Memory region management
    QList<QPair<quint64, quint64>> getMemoryRegions(ScanRegion region, const QString &moduleName = "") const;
    QList<QPair<quint64, quint64>> getCodeRegions() const;
    QList<QPair<quint64, quint64>> getDataRegions() const;
    QList<QPair<quint64, quint64>> getHeapRegions() const;
    QList<QPair<quint64, quint64>> getStackRegions() const;
    QList<QPair<quint64, quint64>> getModuleRegions(const QString &moduleName) const;
    
    // Match processing
    PatternMatch createMatch(quint64 address, const QByteArray &data, const PatternInfo &pattern) const;
    bool verifyMatchInternal(const PatternMatch &match) const;
    MatchQuality calculateMatchQuality(const PatternMatch &match, const PatternInfo &pattern) const;
    float calculateMatchConfidence(const PatternMatch &match, const PatternInfo &pattern) const;
    void sortMatches(QList<PatternMatch> &matches) const;
    void filterMatches(QList<PatternMatch> &matches, const PatternInfo &pattern) const;
    
    // Threading
    void startScanThread(const PatternInfo &pattern, const ScanConfiguration &config);
    void stopScanThread(const QString &scanId);
    void cleanupFinishedThreads();
    
    // Cache implementation
    void addToCache(const QString &key, const QList<PatternMatch> &matches);
    QList<PatternMatch> getFromCache(const QString &key) const;
    bool isInCache(const QString &key) const;
    void removeFromCache(const QString &key);
    void cleanupCache();
    QString generateCacheKey(const PatternInfo &pattern, const ScanConfiguration &config) const;
    
    // Statistics implementation
    void updateScanStatistics(const ScanResult &result);
    void updatePatternUsage(const QString &name);
    void updatePerformanceMetrics(const ScanResult &result);
    void calculateAverages();
    
    // File operations
    bool savePatternsToFile(const QString &filename) const;
    bool loadPatternsFromFile(const QString &filename);
    bool saveResultsToFile(const QString &filename, const ScanResult &result) const;
    bool loadResultsFromFile(const QString &filename);
    
    // JSON serialization
    QJsonObject patternToJson(const PatternInfo &pattern) const;
    PatternInfo patternFromJson(const QJsonObject &json) const;
    QJsonObject matchToJson(const PatternMatch &match) const;
    PatternMatch matchFromJson(const QJsonObject &json) const;
    QJsonObject resultToJson(const ScanResult &result) const;
    ScanResult resultFromJson(const QJsonObject &json) const;
    QJsonObject configToJson(const ScanConfiguration &config) const;
    ScanConfiguration configFromJson(const QJsonObject &json) const;
    
    // Utility functions
    QString generateScanId() const;
    QString getConfigFilePath() const;
    QString getPatternsFilePath() const;
    QString getCacheDirectory() const;
    bool createDirectoryIfNotExists(const QString &path) const;
    
    // Error handling
    void handleScanError(const QString &scanId, const QString &error);
    void handlePatternError(const QString &name, const QString &error);
    void handleMemoryError(const QString &error);
    void recoverFromError();
    
    // Core components
    MemoryManager *m_memoryManager;
    Logger *m_logger;
    
    // Pattern storage
    QMap<QString, PatternInfo> m_patterns;
    QMap<QString, ScanResult> m_results;
    QMap<QString, QFutureWatcher<ScanResult>*> m_scanWatchers;
    
    // Configuration
    ScanConfiguration m_configuration;
    QString m_configFilePath;
    QString m_patternsFilePath;
    
    // Cache
    QMap<QString, QList<PatternMatch>> m_cache;
    bool m_cacheEnabled;
    int m_cacheLimit;
    QTimer *m_cacheCleanupTimer;
    
    // Statistics
    ScanStatistics m_statistics;
    QTimer *m_statisticsTimer;
    
    // Threading
    QMap<QString, QThread*> m_scanThreads;
    QMutex m_resultsMutex;
    QMutex m_cacheMutex;
    QMutex m_statisticsMutex;
    
    // State
    bool m_initialized;
    QDateTime m_lastUpdate;
    int m_nextScanId;
    
    // Constants
    static const int DEFAULT_CACHE_LIMIT = 1000;
    static const int DEFAULT_CHUNK_SIZE = 0x10000; // 64KB
    static const int DEFAULT_MAX_RESULTS = 1000;
    static const int DEFAULT_TIMEOUT = 30000; // 30 seconds
    static const int CACHE_CLEANUP_INTERVAL = 300000; // 5 minutes
    static const int STATISTICS_UPDATE_INTERVAL = 60000; // 1 minute
};

#endif // PATTERN_SCANNER_H