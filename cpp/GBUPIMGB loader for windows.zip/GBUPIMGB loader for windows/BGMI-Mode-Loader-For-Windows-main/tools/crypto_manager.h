#ifndef CRYPTO_MANAGER_H
#define CRYPTO_MANAGER_H

#include <QtCore/QObject>
#include <QtCore/QByteArray>
#include <QtCore/QString>
#include <memory>

class CryptoManager : public QObject
{
    Q_OBJECT

public:
    explicit CryptoManager(QObject *parent = nullptr);
    ~CryptoManager();

    // Encryption/Decryption
    QByteArray encrypt(const QByteArray &data, const QString &key);
    QByteArray decrypt(const QByteArray &data, const QString &key);
    
    // Hash functions
    QString generateHash(const QByteArray &data);
    bool verifyHash(const QByteArray &data, const QString &hash);
    
    // Key generation
    QString generateKey(int length = 32);
    QString generateSalt(int length = 16);
    
    // Secure random
    QByteArray generateRandomBytes(int length);
    
private:
    class CryptoManagerPrivate;
    std::unique_ptr<CryptoManagerPrivate> d;
};

#endif // CRYPTO_MANAGER_H