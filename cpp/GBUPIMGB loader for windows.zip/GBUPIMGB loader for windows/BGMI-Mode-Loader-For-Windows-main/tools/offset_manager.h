#ifndef OFFSET_MANAGER_H
#define OFFSET_MANAGER_H

#include <QtCore/QObject>
#include <QtCore/QMap>
#include <QtCore/QList>
#include <QtCore/QStringList>
#include <QtCore/QDateTime>
#include <QtCore/QTimer>
#include <QtCore/QMutex>
#include <QtCore/QJsonObject>
#include <QtCore/QJsonDocument>
#include <QtCore/QVariant>
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkReply>
#include <memory>

// Forward declarations
class MemoryManager;
class Logger;
class MemoryScanner;

enum class OffsetType {
    Static = 0,
    Dynamic = 1,
    Pointer = 2,
    Pattern = 3,
    Signature = 4,
    Module = 5,
    Function = 6,
    Class = 7,
    Variable = 8,
    Array = 9,
    Structure = 10,
    Interface = 11
};

enum class OffsetStatus {
    Unknown = 0,
    Valid = 1,
    Invalid = 2,
    Outdated = 3,
    Updating = 4,
    Failed = 5,
    Deprecated = 6
};

enum class UpdateSource {
    Manual = 0,
    Local = 1,
    Remote = 2,
    Community = 3,
    Auto = 4,
    Pattern = 5,
    Signature = 6
};

enum class GameVersion {
    Unknown = 0,
    v3_9_0 = 390,
    v3_9_1 = 391,
    v3_9_2 = 392,
    v3_9_3 = 393,
    v3_9_4 = 394,
    v3_9_5 = 395,
    Latest = 999
};

enum class Platform {
    Unknown = 0,
    Windows = 1,
    Android = 2,
    iOS = 3,
    Linux = 4
};

struct OffsetInfo {
    QString name;
    QString category;
    QString description;
    OffsetType type = OffsetType::Static;
    OffsetStatus status = OffsetStatus::Unknown;
    
    quint64 address = 0;
    quint64 baseAddress = 0;
    quint64 offset = 0;
    QList<quint64> pointerChain;
    QString moduleName;
    QString pattern;
    QString signature;
    
    GameVersion gameVersion = GameVersion::Unknown;
    Platform platform = Platform::Unknown;
    QString buildId;
    QString checksum;
    
    QDateTime lastUpdated;
    QDateTime lastValidated;
    QDateTime expiryDate;
    UpdateSource updateSource = UpdateSource::Manual;
    
    int validationCount = 0;
    int failureCount = 0;
    float reliability = 0.0f;
    float confidence = 0.0f;
    
    bool isEncrypted = false;
    bool isObfuscated = false;
    bool isProtected = false;
    bool isVolatile = false;
    bool isDeprecated = false;
    
    QMap<QString, QVariant> metadata;
    QStringList dependencies;
    QStringList tags;
    QString notes;
};

struct OffsetCategory {
    QString name;
    QString description;
    QString icon;
    QStringList offsets;
    bool enabled = true;
    int priority = 0;
    QMap<QString, QVariant> settings;
};

struct OffsetUpdate {
    QString name;
    OffsetInfo oldInfo;
    OffsetInfo newInfo;
    UpdateSource source = UpdateSource::Manual;
    QDateTime timestamp;
    QString reason;
    bool applied = false;
    bool verified = false;
};

struct OffsetStatistics {
    int totalOffsets = 0;
    int validOffsets = 0;
    int invalidOffsets = 0;
    int outdatedOffsets = 0;
    int deprecatedOffsets = 0;
    
    QDateTime lastUpdate;
    QDateTime lastValidation;
    int updateCount = 0;
    int validationCount = 0;
    int failureCount = 0;
    
    float averageReliability = 0.0f;
    float averageConfidence = 0.0f;
    float successRate = 0.0f;
    
    QMap<OffsetType, int> typeDistribution;
    QMap<OffsetStatus, int> statusDistribution;
    QMap<UpdateSource, int> sourceDistribution;
    QMap<QString, int> categoryUsage;
    
    QStringList recentUpdates;
    QStringList recentFailures;
    QStringList mostUsedOffsets;
    QStringList leastReliableOffsets;
};

struct GameInfo {
    QString name = "BGMI";
    GameVersion version = GameVersion::Unknown;
    Platform platform = Platform::Unknown;
    QString buildId;
    QString processName;
    QString moduleName;
    QString executablePath;
    
    quint64 baseAddress = 0;
    quint64 imageSize = 0;
    QString checksum;
    QString timestamp;
    
    bool isRunning = false;
    bool isSupported = false;
    bool isDetected = false;
    QDateTime lastDetected;
    
    QMap<QString, QVariant> properties;
};

class OffsetManager : public QObject
{
    Q_OBJECT

public:
    explicit OffsetManager(QObject *parent = nullptr);
    ~OffsetManager();
    
    // Component integration
    void setMemoryManager(MemoryManager *memoryManager);
    void setLogger(Logger *logger);
    void setMemoryScanner(MemoryScanner *memoryScanner);
    
    // Initialization and cleanup
    bool initialize();
    void cleanup();
    bool isInitialized() const;
    
    // Game detection and info
    bool detectGame();
    GameInfo getGameInfo() const;
    void setGameInfo(const GameInfo &info);
    bool isGameSupported() const;
    bool isGameRunning() const;
    QString getGameVersion() const;
    Platform getGamePlatform() const;
    
    // Offset management
    bool addOffset(const OffsetInfo &info);
    bool updateOffset(const QString &name, const OffsetInfo &info);
    bool removeOffset(const QString &name);
    OffsetInfo getOffset(const QString &name) const;
    QList<OffsetInfo> getAllOffsets() const;
    QList<OffsetInfo> getOffsetsByCategory(const QString &category) const;
    QList<OffsetInfo> getOffsetsByType(OffsetType type) const;
    QList<OffsetInfo> getOffsetsByStatus(OffsetStatus status) const;
    bool hasOffset(const QString &name) const;
    
    // Address resolution
    quint64 resolveAddress(const QString &name) const;
    quint64 resolveOffset(const QString &name) const;
    quint64 resolvePointer(const QString &name) const;
    quint64 resolvePattern(const QString &name) const;
    quint64 resolveSignature(const QString &name) const;
    QList<quint64> resolvePointerChain(const QString &name) const;
    
    // Pattern and signature scanning
    quint64 findPattern(const QString &pattern, const QString &moduleName = "") const;
    quint64 findSignature(const QString &signature, const QString &moduleName = "") const;
    QList<quint64> findAllPatterns(const QString &pattern, const QString &moduleName = "") const;
    QList<quint64> findAllSignatures(const QString &signature, const QString &moduleName = "") const;
    bool validatePattern(const QString &pattern, quint64 address) const;
    bool validateSignature(const QString &signature, quint64 address) const;
    
    // Offset validation
    bool validateOffset(const QString &name);
    bool validateAllOffsets();
    bool validateCategory(const QString &category);
    OffsetStatus getOffsetStatus(const QString &name) const;
    float getOffsetReliability(const QString &name) const;
    float getOffsetConfidence(const QString &name) const;
    QDateTime getLastValidation(const QString &name) const;
    
    // Automatic updates
    void enableAutoUpdate(bool enabled);
    bool isAutoUpdateEnabled() const;
    void setUpdateInterval(int seconds);
    int getUpdateInterval() const;
    void checkForUpdates();
    void updateFromSource(UpdateSource source);
    void updateOffset(const QString &name, UpdateSource source);
    void updateCategory(const QString &category, UpdateSource source);
    
    // Manual updates
    void updateOffsetManually(const QString &name, quint64 address);
    void updateOffsetFromPattern(const QString &name);
    void updateOffsetFromSignature(const QString &name);
    void updateOffsetFromPointer(const QString &name);
    void recalculateOffset(const QString &name);
    void refreshOffset(const QString &name);
    
    // Category management
    void addCategory(const OffsetCategory &category);
    void updateCategory(const QString &name, const OffsetCategory &category);
    void removeCategory(const QString &name);
    OffsetCategory getCategory(const QString &name) const;
    QList<OffsetCategory> getAllCategories() const;
    QStringList getCategoryNames() const;
    bool hasCategory(const QString &name) const;
    
    // Import/Export
    bool exportOffsets(const QString &filename, const QString &format = "json") const;
    bool importOffsets(const QString &filename, const QString &format = "json");
    bool exportCategory(const QString &category, const QString &filename) const;
    bool importCategory(const QString &filename);
    QString exportOffsetsToString(const QString &format = "json") const;
    bool importOffsetsFromString(const QString &data, const QString &format = "json");
    
    // Configuration
    void loadConfiguration();
    void saveConfiguration() const;
    void resetConfiguration();
    QJsonObject getConfiguration() const;
    void setConfiguration(const QJsonObject &config);
    
    // Remote updates
    void setRemoteUpdateUrl(const QString &url);
    QString getRemoteUpdateUrl() const;
    void downloadUpdates();
    void uploadOffsets(const QStringList &names);
    void syncWithRemote();
    bool isRemoteUpdateAvailable() const;
    
    // Statistics and monitoring
    OffsetStatistics getStatistics() const;
    void resetStatistics();
    void updateStatistics();
    QString getStatusReport() const;
    QString getValidationReport() const;
    QString getUpdateReport() const;
    
    // Backup and restore
    void createBackup(const QString &name = "");
    void restoreBackup(const QString &name);
    void deleteBackup(const QString &name);
    QStringList getAvailableBackups() const;
    void autoBackup();
    
    // Search and filtering
    QList<OffsetInfo> searchOffsets(const QString &query) const;
    QList<OffsetInfo> filterOffsets(const QMap<QString, QVariant> &filters) const;
    QStringList getOffsetNames(const QString &filter = "") const;
    QStringList getOffsetsByTag(const QString &tag) const;
    QStringList getRecentlyUpdated(int count = 10) const;
    QStringList getMostUsed(int count = 10) const;
    
    // Utility functions
    QString formatAddress(quint64 address) const;
    QString formatOffset(quint64 offset) const;
    QString formatPointerChain(const QList<quint64> &chain) const;
    bool isValidAddress(quint64 address) const;
    bool isValidOffset(quint64 offset) const;
    quint64 calculateOffset(quint64 address, quint64 baseAddress) const;
    quint64 calculateAddress(quint64 offset, quint64 baseAddress) const;
    
public slots:
    // Game detection slots
    void onGameDetected();
    void onGameLost();
    void onGameVersionChanged(const QString &version);
    void onGameProcessChanged(const QString &processName);
    
    // Offset management slots
    void onOffsetAdded(const QString &name);
    void onOffsetUpdated(const QString &name);
    void onOffsetRemoved(const QString &name);
    void onOffsetValidated(const QString &name, bool valid);
    void onOffsetStatusChanged(const QString &name, int status);
    
    // Update slots
    void onAutoUpdateToggled(bool enabled);
    void onUpdateIntervalChanged(int seconds);
    void onUpdateRequested();
    void onUpdateSourceChanged(int source);
    void onManualUpdateRequested(const QString &name, quint64 address);
    void onPatternUpdateRequested(const QString &name);
    void onSignatureUpdateRequested(const QString &name);
    void onPointerUpdateRequested(const QString &name);
    
    // Category slots
    void onCategoryAdded(const QString &name);
    void onCategoryUpdated(const QString &name);
    void onCategoryRemoved(const QString &name);
    void onCategoryEnabled(const QString &name, bool enabled);
    void onCategoryValidationRequested(const QString &name);
    
    // Import/Export slots
    void onExportRequested(const QString &filename, const QString &format);
    void onImportRequested(const QString &filename, const QString &format);
    void onCategoryExportRequested(const QString &category, const QString &filename);
    void onCategoryImportRequested(const QString &filename);
    
    // Remote update slots
    void onRemoteUrlChanged(const QString &url);
    void onDownloadRequested();
    void onUploadRequested(const QStringList &names);
    void onSyncRequested();
    void onRemoteUpdateAvailable();
    
    // Backup slots
    void onBackupRequested(const QString &name);
    void onRestoreRequested(const QString &name);
    void onBackupDeleted(const QString &name);
    void onAutoBackupRequested();
    
    // Search and filter slots
    void onSearchRequested(const QString &query);
    void onFilterRequested(const QMap<QString, QVariant> &filters);
    void onTagFilterRequested(const QString &tag);
    void onRecentlyUpdatedRequested(int count);
    void onMostUsedRequested(int count);
    
    // Statistics slots
    void onStatisticsRequested();
    void onStatisticsReset();
    void onStatusReportRequested();
    void onValidationReportRequested();
    void onUpdateReportRequested();
    
    // Configuration slots
    void onConfigurationLoaded();
    void onConfigurationSaved();
    void onConfigurationReset();
    void onConfigurationChanged(const QJsonObject &config);
    
signals:
    void gameDetected(const GameInfo &info);
    void gameLost();
    void gameVersionChanged(const QString &version);
    void gameProcessChanged(const QString &processName);
    
    void offsetAdded(const QString &name, const OffsetInfo &info);
    void offsetUpdated(const QString &name, const OffsetInfo &info);
    void offsetRemoved(const QString &name);
    void offsetValidated(const QString &name, bool valid);
    void offsetStatusChanged(const QString &name, OffsetStatus status);
    void offsetReliabilityChanged(const QString &name, float reliability);
    
    void categoryAdded(const QString &name, const OffsetCategory &category);
    void categoryUpdated(const QString &name, const OffsetCategory &category);
    void categoryRemoved(const QString &name);
    void categoryValidated(const QString &name, bool valid);
    
    void updateStarted(UpdateSource source);
    void updateCompleted(UpdateSource source, int updatedCount);
    void updateFailed(UpdateSource source, const QString &error);
    void updateAvailable(const QStringList &offsets);
    void autoUpdateToggled(bool enabled);
    
    void patternFound(const QString &name, quint64 address);
    void patternNotFound(const QString &name);
    void signatureFound(const QString &name, quint64 address);
    void signatureNotFound(const QString &name);
    void pointerResolved(const QString &name, quint64 address);
    void pointerFailed(const QString &name);
    
    void remoteUpdateAvailable();
    void remoteUpdateDownloaded();
    void remoteUpdateFailed(const QString &error);
    void offsetsUploaded();
    void uploadFailed(const QString &error);
    void syncCompleted();
    void syncFailed(const QString &error);
    
    void backupCreated(const QString &name);
    void backupRestored(const QString &name);
    void backupDeleted(const QString &name);
    void backupFailed(const QString &error);
    
    void searchCompleted(const QList<OffsetInfo> &results);
    void filterCompleted(const QList<OffsetInfo> &results);
    
    void statisticsUpdated(const OffsetStatistics &stats);
    void configurationChanged();
    void error(const QString &message);
    void warning(const QString &message);
    void info(const QString &message);
    
private slots:
    void onUpdateTimer();
    void onValidationTimer();
    void onStatisticsTimer();
    void onBackupTimer();
    void onNetworkReplyFinished();
    void onNetworkError(QNetworkReply::NetworkError error);
    
private:
    // Core functionality
    void initializeOffsets();
    void loadDefaultOffsets();
    void detectGameVersion();
    void detectGamePlatform();
    void updateGameInfo();
    
    // Offset resolution
    quint64 resolveStaticOffset(const OffsetInfo &info) const;
    quint64 resolveDynamicOffset(const OffsetInfo &info) const;
    quint64 resolvePointerOffset(const OffsetInfo &info) const;
    quint64 resolvePatternOffset(const OffsetInfo &info) const;
    quint64 resolveSignatureOffset(const OffsetInfo &info) const;
    quint64 resolveModuleOffset(const OffsetInfo &info) const;
    
    // Pattern and signature processing
    QByteArray processPattern(const QString &pattern) const;
    QByteArray processSignature(const QString &signature) const;
    QString normalizePattern(const QString &pattern) const;
    QString normalizeSignature(const QString &signature) const;
    bool isValidPattern(const QString &pattern) const;
    bool isValidSignature(const QString &signature) const;
    
    // Validation implementation
    bool validateStaticOffset(const OffsetInfo &info);
    bool validateDynamicOffset(const OffsetInfo &info);
    bool validatePointerOffset(const OffsetInfo &info);
    bool validatePatternOffset(const OffsetInfo &info);
    bool validateSignatureOffset(const OffsetInfo &info);
    bool validateModuleOffset(const OffsetInfo &info);
    
    // Update implementation
    void performAutoUpdate();
    void updateFromLocal();
    void updateFromRemote();
    void updateFromCommunity();
    void updateFromPattern(const QString &name);
    void updateFromSignature(const QString &name);
    void applyUpdate(const OffsetUpdate &update);
    
    // File operations
    bool saveOffsetsToFile(const QString &filename, const QList<OffsetInfo> &offsets) const;
    QList<OffsetInfo> loadOffsetsFromFile(const QString &filename) const;
    bool saveCategoryToFile(const QString &filename, const OffsetCategory &category) const;
    OffsetCategory loadCategoryFromFile(const QString &filename) const;
    
    // JSON serialization
    QJsonObject offsetToJson(const OffsetInfo &info) const;
    OffsetInfo offsetFromJson(const QJsonObject &json) const;
    QJsonObject categoryToJson(const OffsetCategory &category) const;
    OffsetCategory categoryFromJson(const QJsonObject &json) const;
    QJsonObject statisticsToJson(const OffsetStatistics &stats) const;
    OffsetStatistics statisticsFromJson(const QJsonObject &json) const;
    
    // Network operations
    void downloadOffsetsFromUrl(const QString &url);
    void uploadOffsetsToUrl(const QString &url, const QStringList &names);
    void processNetworkReply(QNetworkReply *reply);
    void handleNetworkError(const QString &error);
    
    // Statistics and monitoring
    void updateOffsetStatistics();
    void updateValidationStatistics();
    void updateUsageStatistics(const QString &name);
    void updateReliabilityStatistics(const QString &name, bool success);
    void logOffsetEvent(const QString &event, const QString &name);
    
    // Backup implementation
    void createBackupFile(const QString &name);
    void restoreFromBackupFile(const QString &name);
    void cleanupOldBackups();
    QString generateBackupName() const;
    
    // Search and filter implementation
    bool matchesSearchQuery(const OffsetInfo &info, const QString &query) const;
    bool matchesFilter(const OffsetInfo &info, const QMap<QString, QVariant> &filters) const;
    QList<OffsetInfo> sortOffsets(const QList<OffsetInfo> &offsets, const QString &sortBy) const;
    
    // Utility functions
    QString getConfigFilePath() const;
    QString getOffsetsFilePath() const;
    QString getBackupDirectory() const;
    QString getCacheDirectory() const;
    bool createDirectoryIfNotExists(const QString &path) const;
    QString generateChecksum(const QByteArray &data) const;
    bool isAddressValid(quint64 address) const;
    
    // Error handling
    void handleOffsetError(const QString &name, const QString &error);
    void handleValidationError(const QString &name, const QString &error);
    void handleUpdateError(const QString &error);
    void handleNetworkError(const QString &error);
    void recoverFromError();
    
    // Core components
    MemoryManager *m_memoryManager;
    Logger *m_logger;
    MemoryScanner *m_memoryScanner;
    
    // Game information
    GameInfo m_gameInfo;
    bool m_gameDetected;
    QDateTime m_lastGameDetection;
    
    // Offset storage
    QMap<QString, OffsetInfo> m_offsets;
    QMap<QString, OffsetCategory> m_categories;
    QList<OffsetUpdate> m_pendingUpdates;
    QMap<QString, int> m_usageCount;
    
    // Configuration
    QJsonObject m_configuration;
    QString m_configFilePath;
    QString m_offsetsFilePath;
    bool m_autoUpdateEnabled;
    int m_updateInterval;
    QString m_remoteUpdateUrl;
    
    // Statistics
    OffsetStatistics m_statistics;
    QDateTime m_lastStatisticsUpdate;
    
    // Timers
    QTimer *m_updateTimer;
    QTimer *m_validationTimer;
    QTimer *m_statisticsTimer;
    QTimer *m_backupTimer;
    
    // Network
    QNetworkAccessManager *m_networkManager;
    QMap<QNetworkReply*, QString> m_pendingRequests;
    
    // Threading
    QMutex m_offsetsMutex;
    QMutex m_statisticsMutex;
    
    // State
    bool m_initialized;
    bool m_updating;
    bool m_validating;
    QDateTime m_lastUpdate;
    QDateTime m_lastValidation;
    
    // Constants
    static const int DEFAULT_UPDATE_INTERVAL = 3600; // 1 hour
    static const int DEFAULT_VALIDATION_INTERVAL = 300; // 5 minutes
    static const int DEFAULT_STATISTICS_INTERVAL = 60; // 1 minute
    static const int DEFAULT_BACKUP_INTERVAL = 86400; // 24 hours
    static const int MAX_BACKUP_COUNT = 10;
    static const int MAX_PENDING_UPDATES = 100;
    static const float MIN_RELIABILITY_THRESHOLD = 0.5f;
    static const float MIN_CONFIDENCE_THRESHOLD = 0.7f;
};

#endif // OFFSET_MANAGER_H