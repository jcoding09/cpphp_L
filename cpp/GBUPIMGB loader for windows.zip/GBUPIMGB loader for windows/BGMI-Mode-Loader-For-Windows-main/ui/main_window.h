#ifndef MAIN_WINDOW_H
#define MAIN_WINDOW_H

#include <QtWidgets/QMainWindow>
#include <QtWidgets/QWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QLabel>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QSystemTrayIcon>
#include <QtWidgets/QFrame>
#include <QtCore/QTimer>
#include <QtCore/QSettings>
#include <QtGui/QIcon>
#include <QtGui/QPixmap>
#include <QtGui/QMovie>
#include <memory>

// Forward declarations
class InjectionManager;
class MemoryManager;
class GameInterface;
class Logger;
class StatusMonitor;
class ModSettingsPanel;
class LoggingPanel;
class StatusPanel;
class GameConnectionPanel;
class PerformancePanel;
class SecurityPanel;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    // Window management
    void setupUI();
    void setupMenuBar();
    void setupToolBar();
    void setupStatusBar();
    void setupSystemTray();
    void setupConnections();
    void setupTheme();
    
    // Settings management
    void loadSettings();
    void saveSettings();
    void resetSettings();
    
    // UI state management
    void updateUI();
    void updateConnectionStatus(bool connected);
    void updateInjectionStatus(const QString& status);
    void updateGameStatus(const QString& status);
    void updatePerformanceMetrics();
    
public slots:
    // Main actions
    void onInjectButtonClicked();
    void onEjectButtonClicked();
    void onConnectGameClicked();
    void onDisconnectGameClicked();
    void onStartMonitoringClicked();
    void onStopMonitoringClicked();
    
    // Settings actions
    void onSettingsChanged();
    void onThemeChanged();
    void onLanguageChanged();
    
    // System tray actions
    void onSystemTrayActivated(QSystemTrayIcon::ActivationReason reason);
    void showMainWindow();
    void hideToTray();
    
    // Status updates
    void onStatusUpdate(const QString& message);
    void onErrorOccurred(const QString& error);
    void onSuccessMessage(const QString& message);
    void onProgressUpdate(int percentage);
    
    // Game events
    void onGameConnected();
    void onGameDisconnected();
    void onGameDataUpdated();
    
    // Injection events
    void onInjectionStarted();
    void onInjectionCompleted();
    void onInjectionFailed(const QString& error);
    void onEjectionCompleted();
    
    // Memory events
    void onMemoryScanned();
    void onMemoryModified();
    void onOffsetsUpdated();
    
    // Security events
    void onSecurityAlert(const QString& alert);
    void onAntiCheatDetected();
    void onBypassActivated();
    
protected:
    void closeEvent(QCloseEvent *event) override;
    void changeEvent(QEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;
    void moveEvent(QMoveEvent *event) override;
    bool eventFilter(QObject *obj, QEvent *event) override;
    
private slots:
    void updateTimer();
    void checkGameStatus();
    void checkInjectionStatus();
    void updateSystemMetrics();
    void handleEmergencyStop();
    
private:
    // Core components
    std::unique_ptr<InjectionManager> m_injectionManager;
    std::unique_ptr<MemoryManager> m_memoryManager;
    std::unique_ptr<GameInterface> m_gameInterface;
    std::unique_ptr<Logger> m_logger;
    std::unique_ptr<StatusMonitor> m_statusMonitor;
    
    // UI Components
    QWidget *m_centralWidget;
    QTabWidget *m_tabWidget;
    QSplitter *m_mainSplitter;
    QSplitter *m_rightSplitter;
    
    // Main panels
    std::unique_ptr<ModSettingsPanel> m_modSettingsPanel;
    std::unique_ptr<LoggingPanel> m_loggingPanel;
    std::unique_ptr<StatusPanel> m_statusPanel;
    std::unique_ptr<GameConnectionPanel> m_gameConnectionPanel;
    std::unique_ptr<PerformancePanel> m_performancePanel;
    std::unique_ptr<SecurityPanel> m_securityPanel;
    
    // Control panels
    QGroupBox *m_injectionControlGroup;
    QGroupBox *m_gameControlGroup;
    QGroupBox *m_monitoringControlGroup;
    QGroupBox *m_quickActionsGroup;
    
    // Injection controls
    QPushButton *m_injectButton;
    QPushButton *m_ejectButton;
    QPushButton *m_refreshProcessButton;
    QComboBox *m_processComboBox;
    QComboBox *m_injectionMethodComboBox;
    QProgressBar *m_injectionProgressBar;
    QLabel *m_injectionStatusLabel;
    
    // Game controls
    QPushButton *m_connectGameButton;
    QPushButton *m_disconnectGameButton;
    QPushButton *m_scanOffsetsButton;
    QPushButton *m_updateOffsetsButton;
    QLabel *m_gameStatusLabel;
    QLabel *m_gameVersionLabel;
    QLabel *m_playerCountLabel;
    
    // Monitoring controls
    QPushButton *m_startMonitoringButton;
    QPushButton *m_stopMonitoringButton;
    QPushButton *m_clearLogsButton;
    QPushButton *m_exportLogsButton;
    QCheckBox *m_autoMonitoringCheckBox;
    QCheckBox *m_realTimeUpdatesCheckBox;
    
    // Quick actions
    QPushButton *m_emergencyStopButton;
    QPushButton *m_hideWindowButton;
    QPushButton *m_screenshotButton;
    QPushButton *m_settingsButton;
    QPushButton *m_aboutButton;
    
    // Status indicators
    QLabel *m_connectionStatusIcon;
    QLabel *m_injectionStatusIcon;
    QLabel *m_securityStatusIcon;
    QLabel *m_performanceStatusIcon;
    QLabel *m_connectionStatusText;
    QLabel *m_injectionStatusText;
    QLabel *m_securityStatusText;
    QLabel *m_performanceStatusText;
    
    // Progress indicators
    QProgressBar *m_overallProgressBar;
    QProgressBar *m_memoryProgressBar;
    QProgressBar *m_networkProgressBar;
    QProgressBar *m_cpuUsageBar;
    QProgressBar *m_memoryUsageBar;
    
    // Menu and toolbar
    QMenuBar *m_menuBar;
    QToolBar *m_toolBar;
    QStatusBar *m_statusBar;
    
    // System tray
    QSystemTrayIcon *m_systemTrayIcon;
    QMenu *m_trayMenu;
    
    // Timers
    QTimer *m_updateTimer;
    QTimer *m_gameStatusTimer;
    QTimer *m_injectionStatusTimer;
    QTimer *m_metricsTimer;
    
    // Settings
    QSettings *m_settings;
    
    // State variables
    bool m_isInjected;
    bool m_isGameConnected;
    bool m_isMonitoring;
    bool m_isMinimizedToTray;
    QString m_currentTheme;
    QString m_currentLanguage;
    
    // Animation and effects
    QMovie *m_loadingAnimation;
    QTimer *m_blinkTimer;
    
    // Helper methods
    void createInjectionControls();
    void createGameControls();
    void createMonitoringControls();
    void createQuickActions();
    void createStatusIndicators();
    void createProgressBars();
    
    void setupInjectionControlLayout();
    void setupGameControlLayout();
    void setupMonitoringControlLayout();
    void setupQuickActionsLayout();
    void setupStatusLayout();
    
    void updateInjectionControls();
    void updateGameControls();
    void updateMonitoringControls();
    void updateStatusIndicators();
    
    void enableInjectionControls(bool enabled);
    void enableGameControls(bool enabled);
    void enableMonitoringControls(bool enabled);
    
    void setStatusIcon(QLabel *iconLabel, const QString &iconPath, const QString &tooltip);
    void setProgressBarStyle(QProgressBar *progressBar, const QString &color);
    void showNotification(const QString &title, const QString &message, QSystemTrayIcon::MessageIcon icon);
    
    QString formatUptime(qint64 seconds);
    QString formatMemorySize(qint64 bytes);
    QString formatPercentage(double value);
    
    void applyDarkTheme();
    void applyLightTheme();
    void applyCustomTheme(const QString &themeName);
    
    void saveWindowGeometry();
    void restoreWindowGeometry();
    
    bool confirmAction(const QString &title, const QString &message);
    void showErrorDialog(const QString &title, const QString &message);
    void showInfoDialog(const QString &title, const QString &message);
    
    // Constants
    static const int UPDATE_INTERVAL = 1000; // 1 second
    static const int GAME_STATUS_INTERVAL = 5000; // 5 seconds
    static const int INJECTION_STATUS_INTERVAL = 2000; // 2 seconds
    static const int METRICS_INTERVAL = 3000; // 3 seconds
    
    static const QString WINDOW_TITLE;
    static const QString VERSION_STRING;
    static const QString ORGANIZATION_NAME;
    static const QString APPLICATION_NAME;
};

#endif // MAIN_WINDOW_H