#ifndef STATUS_PANEL_H
#define STATUS_PANEL_H

#include <QtWidgets/QWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QSlider>
#include <QtWidgets/QFrame>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSplitter>
#include <QtCore/QTimer>
#include <QtCore/QDateTime>
#include <QtCore/QSettings>
#include <QtGui/QPixmap>
#include <QtGui/QMovie>
#include <QtGui/QIcon>
#include <QtGui/QColor>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <QtCharts/QAreaSeries>
#include <QtCharts/QValueAxis>
#include <QtCharts/QDateTimeAxis>
#include <memory>

// Forward declarations
class StatusMonitor;
class Logger;

enum class SystemStatus {
    Unknown = 0,
    Healthy = 1,
    Warning = 2,
    Error = 3,
    Critical = 4
};

enum class ComponentStatus {
    Inactive = 0,
    Starting = 1,
    Active = 2,
    Warning = 3,
    Error = 4,
    Stopping = 5
};

struct SystemMetrics {
    double cpuUsage = 0.0;
    double memoryUsage = 0.0;
    double diskUsage = 0.0;
    double networkUsage = 0.0;
    qint64 totalMemory = 0;
    qint64 availableMemory = 0;
    qint64 usedMemory = 0;
    qint64 totalDisk = 0;
    qint64 freeDisk = 0;
    qint64 networkBytesReceived = 0;
    qint64 networkBytesSent = 0;
    int processCount = 0;
    int threadCount = 0;
    double temperature = 0.0;
    QDateTime timestamp;
};

struct ComponentInfo {
    QString name;
    ComponentStatus status;
    QString description;
    QString version;
    QDateTime lastUpdate;
    QString errorMessage;
    double healthScore = 100.0;
    qint64 uptime = 0;
    qint64 memoryUsage = 0;
    double cpuUsage = 0.0;
};

struct PerformanceMetrics {
    double averageResponseTime = 0.0;
    double peakResponseTime = 0.0;
    qint64 totalRequests = 0;
    qint64 successfulRequests = 0;
    qint64 failedRequests = 0;
    double successRate = 100.0;
    double throughput = 0.0;
    QDateTime startTime;
    qint64 uptime = 0;
};

struct GameConnectionInfo {
    bool isConnected = false;
    QString gameVersion;
    QString serverRegion;
    int ping = 0;
    int playerCount = 0;
    QString mapName;
    QString gameMode;
    QDateTime connectionTime;
    qint64 connectionDuration = 0;
    qint64 packetsReceived = 0;
    qint64 packetsSent = 0;
    double packetLoss = 0.0;
};

class StatusPanel : public QWidget
{
    Q_OBJECT

public:
    explicit StatusPanel(QWidget *parent = nullptr);
    ~StatusPanel();
    
    // Component integration
    void setStatusMonitor(StatusMonitor *statusMonitor);
    void setLogger(Logger *logger);
    
    // Status updates
    void updateSystemStatus(const SystemMetrics &metrics);
    void updateComponentStatus(const QString &componentName, ComponentStatus status, const QString &message = QString());
    void updatePerformanceMetrics(const PerformanceMetrics &metrics);
    void updateGameConnection(const GameConnectionInfo &info);
    
    // Settings
    void loadSettings();
    void saveSettings();
    
    // UI management
    void updateUI();
    void refreshDisplay();
    
public slots:
    // System status slots
    void onSystemMetricsUpdated(const SystemMetrics &metrics);
    void onSystemStatusChanged(SystemStatus status);
    void onSystemAlert(const QString &message, int severity);
    
    // Component status slots
    void onComponentStatusChanged(const QString &component, int status, const QString &message);
    void onComponentStarted(const QString &component);
    void onComponentStopped(const QString &component);
    void onComponentError(const QString &component, const QString &error);
    
    // Performance slots
    void onPerformanceUpdated(const PerformanceMetrics &metrics);
    void onResponseTimeUpdated(double responseTime);
    void onThroughputUpdated(double throughput);
    
    // Game connection slots
    void onGameConnected(const GameConnectionInfo &info);
    void onGameDisconnected();
    void onGameDataUpdated(const GameConnectionInfo &info);
    void onPingUpdated(int ping);
    
    // Control slots
    void onRefreshClicked();
    void onResetMetricsClicked();
    void onExportStatusClicked();
    void onShowDetailsClicked();
    void onAutoRefreshToggled(bool enabled);
    void onRefreshIntervalChanged(int interval);
    
    // Chart slots
    void onChartTypeChanged(int type);
    void onTimeRangeChanged(int range);
    void onShowGridToggled(bool show);
    void onShowLegendToggled(bool show);
    
signals:
    void statusChanged(SystemStatus status);
    void componentStatusChanged(const QString &component, ComponentStatus status);
    void alertGenerated(const QString &message, int severity);
    void refreshRequested();
    void exportRequested(const QString &filePath);
    
private slots:
    void updateDisplayTimer();
    void updateChartsTimer();
    void checkAlerts();
    void rotateMetricsHistory();
    
private:
    // UI setup
    void setupUI();
    void setupSystemStatusPanel();
    void setupComponentStatusPanel();
    void setupPerformancePanel();
    void setupGameConnectionPanel();
    void setupChartsPanel();
    void setupControlPanel();
    void setupAlertsPanel();
    
    void createSystemMetricsDisplay();
    void createComponentList();
    void createPerformanceCharts();
    void createGameInfoDisplay();
    void createControlButtons();
    void createAlertsList();
    
    void setupSystemMetricsLayout();
    void setupComponentListLayout();
    void setupPerformanceChartsLayout();
    void setupGameInfoLayout();
    void setupControlLayout();
    void setupAlertsLayout();
    
    // UI helpers
    QGroupBox* createGroupBox(const QString &title);
    QLabel* createMetricLabel(const QString &text, const QString &value = QString());
    QProgressBar* createProgressBar(int min = 0, int max = 100);
    QPushButton* createButton(const QString &text, const QString &tooltip = QString());
    
    void connectSignals();
    void setupToolTips();
    void setupContextMenus();
    
    // Status processing
    void processSystemMetrics(const SystemMetrics &metrics);
    void processComponentStatus(const ComponentInfo &info);
    void processPerformanceMetrics(const PerformanceMetrics &metrics);
    void processGameConnection(const GameConnectionInfo &info);
    
    void updateSystemMetricsDisplay();
    void updateComponentStatusDisplay();
    void updatePerformanceDisplay();
    void updateGameConnectionDisplay();
    void updateChartsDisplay();
    void updateAlertsDisplay();
    
    // Chart management
    void initializeCharts();
    void updateCPUChart();
    void updateMemoryChart();
    void updateNetworkChart();
    void updatePerformanceChart();
    void updateResponseTimeChart();
    
    void addDataPoint(QtCharts::QLineSeries *series, const QDateTime &time, double value);
    void limitSeriesData(QtCharts::QLineSeries *series, int maxPoints);
    void updateChartAxes(QtCharts::QChartView *chartView);
    
    // Alert management
    void checkSystemAlerts(const SystemMetrics &metrics);
    void checkComponentAlerts();
    void checkPerformanceAlerts(const PerformanceMetrics &metrics);
    void checkGameConnectionAlerts(const GameConnectionInfo &info);
    
    void addAlert(const QString &message, int severity, const QString &source = QString());
    void clearAlerts();
    void removeOldAlerts();
    
    // Utility functions
    QString formatBytes(qint64 bytes) const;
    QString formatPercentage(double value) const;
    QString formatDuration(qint64 milliseconds) const;
    QString formatUptime(qint64 seconds) const;
    QString formatTimestamp(const QDateTime &timestamp) const;
    
    QColor getStatusColor(SystemStatus status) const;
    QColor getComponentStatusColor(ComponentStatus status) const;
    QIcon getStatusIcon(SystemStatus status) const;
    QIcon getComponentStatusIcon(ComponentStatus status) const;
    
    QString getStatusText(SystemStatus status) const;
    QString getComponentStatusText(ComponentStatus status) const;
    
    SystemStatus calculateOverallStatus() const;
    double calculateHealthScore() const;
    
    // Export functionality
    bool exportStatusReport(const QString &filePath) const;
    QString generateStatusReport() const;
    QString generateSystemReport() const;
    QString generateComponentReport() const;
    QString generatePerformanceReport() const;
    QString generateGameReport() const;
    
    // Core components
    StatusMonitor *m_statusMonitor;
    Logger *m_logger;
    
    // Data storage
    SystemMetrics m_currentMetrics;
    QList<SystemMetrics> m_metricsHistory;
    QMap<QString, ComponentInfo> m_components;
    PerformanceMetrics m_performanceMetrics;
    GameConnectionInfo m_gameConnection;
    QList<QString> m_alerts;
    
    // UI Components
    QVBoxLayout *m_mainLayout;
    QSplitter *m_mainSplitter;
    QSplitter *m_topSplitter;
    QSplitter *m_bottomSplitter;
    
    // System status panel
    QGroupBox *m_systemStatusGroup;
    QLabel *m_systemStatusIcon;
    QLabel *m_systemStatusText;
    QLabel *m_systemUptimeLabel;
    QLabel *m_systemHealthLabel;
    
    // System metrics display
    QGroupBox *m_systemMetricsGroup;
    QLabel *m_cpuUsageLabel;
    QProgressBar *m_cpuUsageBar;
    QLabel *m_memoryUsageLabel;
    QProgressBar *m_memoryUsageBar;
    QLabel *m_diskUsageLabel;
    QProgressBar *m_diskUsageBar;
    QLabel *m_networkUsageLabel;
    QProgressBar *m_networkUsageBar;
    QLabel *m_temperatureLabel;
    QLabel *m_processCountLabel;
    QLabel *m_threadCountLabel;
    
    // Component status panel
    QGroupBox *m_componentStatusGroup;
    QTreeWidget *m_componentTree;
    QLabel *m_activeComponentsLabel;
    QLabel *m_errorComponentsLabel;
    
    // Performance panel
    QGroupBox *m_performanceGroup;
    QLabel *m_responseTimeLabel;
    QLabel *m_throughputLabel;
    QLabel *m_successRateLabel;
    QLabel *m_totalRequestsLabel;
    QLabel *m_failedRequestsLabel;
    QProgressBar *m_successRateBar;
    
    // Game connection panel
    QGroupBox *m_gameConnectionGroup;
    QLabel *m_connectionStatusIcon;
    QLabel *m_connectionStatusText;
    QLabel *m_gameVersionLabel;
    QLabel *m_serverRegionLabel;
    QLabel *m_pingLabel>
    QLabel *m_playerCountLabel;
    QLabel *m_mapNameLabel;
    QLabel *m_gameModeLabel;
    QLabel *m_connectionDurationLabel;
    QLabel *m_packetLossLabel;
    
    // Charts panel
    QGroupBox *m_chartsGroup;
    QtCharts::QChartView *m_cpuChartView;
    QtCharts::QChartView *m_memoryChartView;
    QtCharts::QChartView *m_networkChartView;
    QtCharts::QChartView *m_performanceChartView;
    
    QtCharts::QLineSeries *m_cpuSeries;
    QtCharts::QLineSeries *m_memorySeries;
    QtCharts::QLineSeries *m_networkSeries;
    QtCharts::QLineSeries *m_responseTimeSeries;
    QtCharts::QLineSeries *m_throughputSeries;
    
    // Control panel
    QGroupBox *m_controlGroup;
    QPushButton *m_refreshButton;
    QPushButton *m_resetMetricsButton;
    QPushButton *m_exportStatusButton;
    QPushButton *m_showDetailsButton;
    QCheckBox *m_autoRefreshCheckBox;
    QSpinBox *m_refreshIntervalSpinBox;
    QComboBox *m_chartTypeComboBox;
    QComboBox *m_timeRangeComboBox;
    QCheckBox *m_showGridCheckBox;
    QCheckBox *m_showLegendCheckBox;
    
    // Alerts panel
    QGroupBox *m_alertsGroup;
    QListWidget *m_alertsList;
    QLabel *m_alertCountLabel;
    QPushButton *m_clearAlertsButton;
    
    // Status indicators
    QLabel *m_overallStatusIcon;
    QLabel *m_overallStatusText;
    QProgressBar *m_healthScoreBar;
    
    // Timers
    QTimer *m_displayUpdateTimer;
    QTimer *m_chartsUpdateTimer;
    QTimer *m_alertCheckTimer;
    QTimer *m_historyRotationTimer;
    
    // Settings
    QSettings *m_settings;
    
    // Configuration
    int m_refreshInterval;
    int m_maxHistoryPoints;
    int m_maxAlerts;
    bool m_autoRefresh;
    bool m_showCharts;
    bool m_showGrid;
    bool m_showLegend;
    int m_chartTimeRange;
    int m_chartType;
    
    // Alert thresholds
    double m_cpuAlertThreshold;
    double m_memoryAlertThreshold;
    double m_diskAlertThreshold;
    double m_temperatureAlertThreshold;
    int m_pingAlertThreshold;
    double m_packetLossAlertThreshold;
    
    // State variables
    SystemStatus m_currentSystemStatus;
    bool m_updatingUI;
    QDateTime m_lastUpdate;
    qint64 m_systemUptime;
    
    // Animation
    QMovie *m_loadingAnimation;
    QTimer *m_blinkTimer;
    
    // Constants
    static const int DEFAULT_REFRESH_INTERVAL = 1000; // 1 second
    static const int DEFAULT_MAX_HISTORY_POINTS = 100;
    static const int DEFAULT_MAX_ALERTS = 50;
    static const int DEFAULT_CHART_TIME_RANGE = 300; // 5 minutes
    
    static const double DEFAULT_CPU_ALERT_THRESHOLD = 80.0;
    static const double DEFAULT_MEMORY_ALERT_THRESHOLD = 85.0;
    static const double DEFAULT_DISK_ALERT_THRESHOLD = 90.0;
    static const double DEFAULT_TEMPERATURE_ALERT_THRESHOLD = 70.0;
    static const int DEFAULT_PING_ALERT_THRESHOLD = 100;
    static const double DEFAULT_PACKET_LOSS_ALERT_THRESHOLD = 5.0;
};

#endif // STATUS_PANEL_H