#ifndef INJECTION_PANEL_H
#define INJECTION_PANEL_H

#include <QtWidgets/QWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QSlider>
#include <QtWidgets/QFrame>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QFileDialog>
#include <QtWidgets/QMessageBox>
#include <QtCore/QTimer>
#include <QtCore/QDateTime>
#include <QtCore/QSettings>
#include <QtCore/QProcess>
#include <QtGui/QPixmap>
#include <QtGui/QMovie>
#include <QtGui/QIcon>
#include <QtGui/QColor>
#include <QtGui/QFont>
#include <memory>

// Forward declarations
class InjectionManager;
class Logger;
class StatusMonitor;

enum class InjectionMethod {
    ManualMap = 0,
    ReflectiveDLL = 1,
    ProcessHollowing = 2,
    ThreadHijacking = 3,
    SetWindowsHookEx = 4,
    NtCreateThreadEx = 5,
    RtlCreateUserThread = 6
};

enum class InjectionStatus {
    Idle = 0,
    Preparing = 1,
    Scanning = 2,
    Injecting = 3,
    Verifying = 4,
    Success = 5,
    Failed = 6,
    Retrying = 7
};

enum class ProcessStatus {
    NotFound = 0,
    Found = 1,
    Accessible = 2,
    Protected = 3,
    Suspended = 4,
    Terminated = 5
};

struct InjectionConfig {
    InjectionMethod method = InjectionMethod::ManualMap;
    QString dllPath;
    QString processName = "BGMI.exe";
    bool autoInject = false;
    bool stealthMode = true;
    bool bypassAnticheat = true;
    bool hideFromDebugger = true;
    bool eraseHeaders = true;
    bool randomizeBaseAddress = true;
    int injectionDelay = 1000;
    int retryAttempts = 3;
    int retryDelay = 2000;
    bool enableLogging = true;
    bool showProgress = true;
    QString backupPath;
    bool createBackup = true;
};

struct ProcessInfo {
    QString name;
    quint32 processId = 0;
    QString path;
    QString version;
    qint64 memoryUsage = 0;
    int threadCount = 0;
    ProcessStatus status = ProcessStatus::NotFound;
    QDateTime startTime;
    QString architecture;
    bool isElevated = false;
    bool isProtected = false;
    QString windowTitle;
    QRect windowRect;
};

struct InjectionResult {
    bool success = false;
    QString errorMessage;
    InjectionMethod method;
    QString dllPath;
    quint32 processId = 0;
    qint64 baseAddress = 0;
    qint64 entryPoint = 0;
    QDateTime timestamp;
    qint64 injectionTime = 0;
    QString additionalInfo;
};

struct InjectionStep {
    QString description;
    bool completed = false;
    bool success = false;
    QString errorMessage;
    QDateTime timestamp;
    qint64 duration = 0;
};

class InjectionPanel : public QWidget
{
    Q_OBJECT

public:
    explicit InjectionPanel(QWidget *parent = nullptr);
    ~InjectionPanel();
    
    // Component integration
    void setInjectionManager(InjectionManager *injectionManager);
    void setLogger(Logger *logger);
    void setStatusMonitor(StatusMonitor *statusMonitor);
    
    // Configuration
    void setInjectionConfig(const InjectionConfig &config);
    InjectionConfig getInjectionConfig() const;
    
    // Process management
    void updateProcessInfo(const ProcessInfo &info);
    void refreshProcessList();
    
    // Injection control
    void startInjection();
    void stopInjection();
    void retryInjection();
    
    // Settings
    void loadSettings();
    void saveSettings();
    
    // UI management
    void updateUI();
    void resetUI();
    
public slots:
    // Injection process slots
    void onInjectionStarted();
    void onInjectionProgress(int percentage, const QString &step);
    void onInjectionStepCompleted(const QString &step, bool success, const QString &message);
    void onInjectionCompleted(bool success, const QString &message);
    void onInjectionFailed(const QString &error);
    void onInjectionRetrying(int attempt, int maxAttempts);
    
    // Process monitoring slots
    void onProcessFound(const ProcessInfo &info);
    void onProcessLost();
    void onProcessStatusChanged(ProcessStatus status);
    void onProcessListUpdated(const QList<ProcessInfo> &processes);
    
    // Control slots
    void onInjectButtonClicked();
    void onStopButtonClicked();
    void onRetryButtonClicked();
    void onRefreshProcessesClicked();
    void onSelectDllClicked();
    void onCreateBackupClicked();
    void onRestoreBackupClicked();
    void onClearLogClicked();
    void onSaveLogClicked();
    
    // Configuration slots
    void onInjectionMethodChanged(int method);
    void onProcessNameChanged(const QString &name);
    void onDllPathChanged(const QString &path);
    void onAutoInjectToggled(bool enabled);
    void onStealthModeToggled(bool enabled);
    void onBypassAnticheatToggled(bool enabled);
    void onHideFromDebuggerToggled(bool enabled);
    void onEraseHeadersToggled(bool enabled);
    void onRandomizeBaseAddressToggled(bool enabled);
    void onInjectionDelayChanged(int delay);
    void onRetryAttemptsChanged(int attempts);
    void onRetryDelayChanged(int delay);
    void onEnableLoggingToggled(bool enabled);
    void onShowProgressToggled(bool enabled);
    void onCreateBackupToggled(bool enabled);
    
    // Advanced slots
    void onAdvancedSettingsClicked();
    void onTestInjectionClicked();
    void onValidateDllClicked();
    void onAnalyzeProcessClicked();
    void onExportConfigClicked();
    void onImportConfigClicked();
    
signals:
    void injectionRequested(const InjectionConfig &config);
    void injectionStopped();
    void injectionRetryRequested();
    void processRefreshRequested();
    void configurationChanged(const InjectionConfig &config);
    void dllValidationRequested(const QString &path);
    void processAnalysisRequested(quint32 processId);
    void backupRequested(const QString &path);
    void restoreRequested(const QString &path);
    void logExportRequested(const QString &path);
    
private slots:
    void updateStatusTimer();
    void updateProgressTimer();
    void checkProcessTimer();
    void autoInjectTimer();
    void blinkStatusTimer();
    
private:
    // UI setup
    void setupUI();
    void setupInjectionControlPanel();
    void setupConfigurationPanel();
    void setupProcessPanel();
    void setupProgressPanel();
    void setupLogPanel();
    void setupAdvancedPanel();
    
    void createInjectionControls();
    void createConfigurationControls();
    void createProcessList();
    void createProgressDisplay();
    void createLogDisplay();
    void createAdvancedControls();
    
    void setupInjectionControlsLayout();
    void setupConfigurationLayout();
    void setupProcessListLayout();
    void setupProgressLayout();
    void setupLogLayout();
    void setupAdvancedLayout();
    
    // UI helpers
    QGroupBox* createGroupBox(const QString &title);
    QPushButton* createButton(const QString &text, const QString &tooltip = QString());
    QLabel* createLabel(const QString &text, const QString &tooltip = QString());
    QComboBox* createComboBox(const QStringList &items);
    QCheckBox* createCheckBox(const QString &text, const QString &tooltip = QString());
    QSpinBox* createSpinBox(int min, int max, int value, const QString &suffix = QString());
    
    void connectSignals();
    void setupToolTips();
    void setupContextMenus();
    void setupValidators();
    
    // Status management
    void updateInjectionStatus(InjectionStatus status);
    void updateProcessStatus(ProcessStatus status);
    void updateProgress(int percentage, const QString &step = QString());
    void updateStepProgress(const InjectionStep &step);
    
    void displayInjectionResult(const InjectionResult &result);
    void displayProcessInfo(const ProcessInfo &info);
    void displayErrorMessage(const QString &error);
    void displaySuccessMessage(const QString &message);
    
    // Process management
    void scanForProcesses();
    void validateProcess(const ProcessInfo &info);
    void analyzeProcess(quint32 processId);
    void monitorProcess();
    
    void populateProcessList(const QList<ProcessInfo> &processes);
    void selectProcess(const ProcessInfo &info);
    void refreshProcessInfo();
    
    // DLL management
    void validateDll(const QString &path);
    void analyzeDll(const QString &path);
    void selectDllFile();
    void verifyDllCompatibility(const QString &dllPath, const ProcessInfo &processInfo);
    
    // Configuration management
    void applyConfiguration();
    void resetConfiguration();
    void validateConfiguration();
    void exportConfiguration(const QString &filePath);
    void importConfiguration(const QString &filePath);
    
    InjectionConfig getDefaultConfig() const;
    void setDefaultConfig();
    
    // Backup management
    void createProcessBackup();
    void restoreProcessBackup();
    void validateBackup(const QString &path);
    void cleanupBackups();
    
    // Log management
    void addLogEntry(const QString &message, const QString &level = "INFO");
    void clearLog();
    void saveLog(const QString &filePath);
    void exportLog();
    
    void updateLogDisplay();
    void filterLogEntries(const QString &filter);
    
    // Utility functions
    QString formatInjectionMethod(InjectionMethod method) const;
    QString formatInjectionStatus(InjectionStatus status) const;
    QString formatProcessStatus(ProcessStatus status) const;
    QString formatFileSize(qint64 size) const;
    QString formatDuration(qint64 milliseconds) const;
    QString formatTimestamp(const QDateTime &timestamp) const;
    
    QColor getStatusColor(InjectionStatus status) const;
    QColor getProcessStatusColor(ProcessStatus status) const;
    QIcon getStatusIcon(InjectionStatus status) const;
    QIcon getProcessStatusIcon(ProcessStatus status) const;
    
    bool isValidDllPath(const QString &path) const;
    bool isValidProcessName(const QString &name) const;
    bool isConfigurationValid() const;
    
    // Security functions
    bool checkPermissions() const;
    bool checkAnticheatStatus() const;
    bool checkDebuggerPresence() const;
    bool checkVirtualMachine() const;
    
    void enableStealthMode();
    void disableStealthMode();
    void randomizeTimings();
    
    // Core components
    InjectionManager *m_injectionManager;
    Logger *m_logger;
    StatusMonitor *m_statusMonitor;
    
    // Configuration
    InjectionConfig m_config;
    ProcessInfo m_targetProcess;
    QList<ProcessInfo> m_availableProcesses;
    QList<InjectionStep> m_injectionSteps;
    InjectionResult m_lastResult;
    
    // UI Components
    QVBoxLayout *m_mainLayout;
    QSplitter *m_mainSplitter;
    QSplitter *m_topSplitter;
    QSplitter *m_bottomSplitter;
    
    // Injection control panel
    QGroupBox *m_injectionControlGroup;
    QPushButton *m_injectButton;
    QPushButton *m_stopButton;
    QPushButton *m_retryButton;
    QLabel *m_injectionStatusIcon;
    QLabel *m_injectionStatusText;
    QProgressBar *m_injectionProgressBar;
    QLabel *m_injectionTimeLabel;
    QLabel *m_injectionAttemptsLabel;
    
    // Configuration panel
    QGroupBox *m_configurationGroup;
    QComboBox *m_injectionMethodCombo;
    QLineEdit *m_processNameEdit;
    QLineEdit *m_dllPathEdit;
    QPushButton *m_selectDllButton;
    QCheckBox *m_autoInjectCheckBox;
    QCheckBox *m_stealthModeCheckBox;
    QCheckBox *m_bypassAnticheatCheckBox;
    QCheckBox *m_hideFromDebuggerCheckBox;
    QCheckBox *m_eraseHeadersCheckBox;
    QCheckBox *m_randomizeBaseAddressCheckBox;
    QSpinBox *m_injectionDelaySpinBox;
    QSpinBox *m_retryAttemptsSpinBox;
    QSpinBox *m_retryDelaySpinBox;
    QCheckBox *m_enableLoggingCheckBox;
    QCheckBox *m_showProgressCheckBox;
    QCheckBox *m_createBackupCheckBox;
    
    // Process panel
    QGroupBox *m_processGroup;
    QTreeWidget *m_processTree;
    QPushButton *m_refreshProcessesButton;
    QPushButton *m_analyzeProcessButton;
    QLabel *m_processStatusIcon;
    QLabel *m_processStatusText;
    QLabel *m_processIdLabel;
    QLabel *m_processPathLabel;
    QLabel *m_processVersionLabel;
    QLabel *m_processMemoryLabel;
    QLabel *m_processThreadsLabel;
    QLabel *m_processArchitectureLabel;
    QLabel *m_processElevatedLabel;
    QLabel *m_processProtectedLabel>
    
    // Progress panel
    QGroupBox *m_progressGroup;
    QProgressBar *m_overallProgressBar;
    QTreeWidget *m_stepsTree;
    QLabel *m_currentStepLabel;
    QLabel *m_elapsedTimeLabel;
    QLabel *m_estimatedTimeLabel;
    
    // Log panel
    QGroupBox *m_logGroup;
    QTextEdit *m_logTextEdit;
    QPushButton *m_clearLogButton;
    QPushButton *m_saveLogButton;
    QLineEdit *m_logFilterEdit;
    QComboBox *m_logLevelCombo;
    QLabel *m_logCountLabel;
    
    // Advanced panel
    QGroupBox *m_advancedGroup;
    QPushButton *m_advancedSettingsButton;
    QPushButton *m_testInjectionButton;
    QPushButton *m_validateDllButton;
    QPushButton *m_createBackupButton;
    QPushButton *m_restoreBackupButton;
    QPushButton *m_exportConfigButton;
    QPushButton *m_importConfigButton>
    QLabel *m_securityStatusLabel;
    QLabel *m_anticheatStatusLabel;
    QLabel *m_debuggerStatusLabel;
    QLabel *m_vmStatusLabel;
    
    // Status indicators
    QLabel *m_overallStatusIcon;
    QLabel *m_overallStatusText;
    QLabel *m_lastInjectionLabel;
    QLabel *m_successRateLabel;
    
    // Timers
    QTimer *m_statusUpdateTimer;
    QTimer *m_progressUpdateTimer;
    QTimer *m_processCheckTimer;
    QTimer *m_autoInjectTimer;
    QTimer *m_blinkTimer;
    
    // Settings
    QSettings *m_settings;
    
    // State variables
    InjectionStatus m_currentStatus;
    ProcessStatus m_processStatus;
    bool m_injectionInProgress;
    bool m_autoInjectEnabled;
    bool m_stealthModeEnabled;
    int m_currentAttempt;
    int m_maxAttempts;
    QDateTime m_injectionStartTime;
    qint64 m_injectionDuration;
    int m_successfulInjections;
    int m_totalInjections;
    
    // Animation
    QMovie *m_loadingAnimation;
    QTimer *m_animationTimer;
    
    // File dialogs
    QFileDialog *m_dllFileDialog;
    QFileDialog *m_backupFileDialog;
    QFileDialog *m_configFileDialog;
    QFileDialog *m_logFileDialog;
    
    // Constants
    static const int DEFAULT_INJECTION_DELAY = 1000;
    static const int DEFAULT_RETRY_ATTEMPTS = 3;
    static const int DEFAULT_RETRY_DELAY = 2000;
    static const int DEFAULT_STATUS_UPDATE_INTERVAL = 500;
    static const int DEFAULT_PROGRESS_UPDATE_INTERVAL = 100;
    static const int DEFAULT_PROCESS_CHECK_INTERVAL = 2000;
    static const int DEFAULT_AUTO_INJECT_DELAY = 5000;
    
    static const QString DEFAULT_PROCESS_NAME;
    static const QString DEFAULT_DLL_FILTER;
    static const QString DEFAULT_CONFIG_FILTER;
    static const QString DEFAULT_LOG_FILTER;
    static const QString DEFAULT_BACKUP_FILTER;
};

#endif // INJECTION_PANEL_H