#include "mod_settings_panel.h"
#include "../core/game_interface.h"
#include "../core/logger.h"

#include <QtWidgets/QApplication>
#include <QtWidgets/QColorDialog>
#include <QtWidgets/QFontDialog>
#include <QtWidgets/QFileDialog>
#include <QtWidgets/QMessageBox>
#include <QtCore/QStandardPaths>
#include <QtCore/QDir>
#include <QtCore/QJsonDocument>
#include <QtCore/QJsonObject>
#include <QtCore/QJsonArray>
#include <QtGui/QKeySequence>

// Constants
static const int PREVIEW_UPDATE_INTERVAL = 100; // ms
static const int VALIDATION_INTERVAL = 500; // ms
static const QString SETTINGS_GROUP = "ModSettings";
static const QString PRESETS_DIR = "presets";

ModSettingsPanel::ModSettingsPanel(QWidget *parent)
    : QWidget(parent)
    , m_gameInterface(nullptr)
    , m_logger(nullptr)
    , m_mainLayout(nullptr)
    , m_tabWidget(nullptr)
    , m_scrollArea(nullptr)
    , m_aimbotTab(nullptr)
    , m_espTab(nullptr)
    , m_wallhackTab(nullptr)
    , m_radarTab(nullptr)
    , m_miscTab(nullptr)
    , m_presetsTab(nullptr)
    , m_aimbotEnabledCheckBox(nullptr)
    , m_smoothAimingCheckBox(nullptr)
    , m_autoFireCheckBox(nullptr)
    , m_autoReloadCheckBox(nullptr)
    , m_targetPredictionCheckBox(nullptr)
    , m_visibilityCheckCheckBox(nullptr)
    , m_teamCheckCheckBox(nullptr)
    , m_knockedCheckCheckBox(nullptr)
    , m_aimbotFOVSlider(nullptr)
    , m_aimbotFOVSpinBox(nullptr)
    , m_aimbotSmoothnessSlider(nullptr)
    , m_aimbotSmoothnessSpinBox(nullptr)
    , m_aimbotDistanceSlider(nullptr)
    , m_aimbotDistanceSpinBox(nullptr)
    , m_reactionTimeSlider(nullptr)
    , m_reactionTimeSpinBox(nullptr)
    , m_targetBoneComboBox(nullptr)
    , m_aimKeyComboBox(nullptr)
    , m_aimPriorityComboBox(nullptr)
    , m_targetFilterComboBox(nullptr)
    , m_testAimbotButton(nullptr)
    , m_espEnabledCheckBox(nullptr)
    , m_playerESPCheckBox(nullptr)
    , m_vehicleESPCheckBox(nullptr)
    , m_itemESPCheckBox(nullptr)
    , m_weaponESPCheckBox(nullptr)
    , m_grenadeESPCheckBox(nullptr)
    , m_supplyESPCheckBox(nullptr)
    , m_playerBoxCheckBox(nullptr)
    , m_playerNameCheckBox(nullptr)
    , m_playerHealthCheckBox(nullptr)
    , m_playerDistanceCheckBox(nullptr)
    , m_playerWeaponCheckBox(nullptr)
    , m_playerDirectionCheckBox(nullptr)
    , m_skeletonESPCheckBox(nullptr)
    , m_headDotCheckBox(nullptr)
    , m_snapLinesCheckBox(nullptr)
    , m_healthBarCheckBox(nullptr)
    , m_armorBarCheckBox(nullptr)
    , m_espDistanceSlider(nullptr)
    , m_espDistanceSpinBox(nullptr)
    , m_boxThicknessSlider(nullptr)
    , m_boxThicknessSpinBox(nullptr)
    , m_lineThicknessSlider(nullptr)
    , m_lineThicknessSpinBox(nullptr)
    , m_textSizeSlider(nullptr)
    , m_textSizeSpinBox(nullptr)
    , m_enemyColorButton(nullptr)
    , m_teamColorButton(nullptr)
    , m_vehicleColorButton(nullptr)
    , m_itemColorButton(nullptr)
    , m_weaponColorButton(nullptr)
    , m_fontButton(nullptr)
    , m_testESPButton(nullptr)
    , m_wallhackEnabledCheckBox(nullptr)
    , m_playerWallhackCheckBox(nullptr)
    , m_vehicleWallhackCheckBox(nullptr)
    , m_itemWallhackCheckBox(nullptr)
    , m_xrayModeRadio(nullptr)
    , m_outlineModeRadio(nullptr)
    , m_glowModeRadio(nullptr)
    , m_wallhackModeGroup(nullptr)
    , m_wallhackDistanceSlider(nullptr)
    , m_wallhackDistanceSpinBox(nullptr)
    , m_transparencySlider(nullptr)
    , m_transparencySpinBox(nullptr)
    , m_glowIntensitySlider(nullptr)
    , m_glowIntensitySpinBox(nullptr)
    , m_wallhackPlayerColorButton(nullptr)
    , m_wallhackVehicleColorButton(nullptr)
    , m_wallhackItemColorButton(nullptr)
    , m_testWallhackButton(nullptr)
    , m_radarEnabledCheckBox(nullptr)
    , m_playerRadarCheckBox(nullptr)
    , m_vehicleRadarCheckBox(nullptr)
    , m_itemRadarCheckBox(nullptr)
    , m_miniMapCheckBox(nullptr)
    , m_fullScreenCheckBox(nullptr)
    , m_rotateWithPlayerCheckBox(nullptr)
    , m_radarSizeSlider(nullptr)
    , m_radarSizeSpinBox(nullptr)
    , m_radarRangeSlider(nullptr)
    , m_radarRangeSpinBox(nullptr)
    , m_radarScaleSlider(nullptr)
    , m_radarScaleSpinBox(nullptr)
    , m_radarXSpinBox(nullptr)
    , m_radarYSpinBox(nullptr)
    , m_radarBackgroundColorButton(nullptr)
    , m_radarBorderColorButton(nullptr)
    , m_radarPlayerDotColorButton(nullptr)
    , m_radarEnemyDotColorButton(nullptr)
    , m_testRadarButton(nullptr)
    , m_noRecoilCheckBox(nullptr)
    , m_noSpreadCheckBox(nullptr)
    , m_rapidFireCheckBox(nullptr)
    , m_infiniteAmmoCheckBox(nullptr)
    , m_noFallDamageCheckBox(nullptr)
    , m_speedHackCheckBox(nullptr)
    , m_jumpHackCheckBox(nullptr)
    , m_flyHackCheckBox(nullptr)
    , m_instantHealCheckBox(nullptr)
    , m_instantReviveCheckBox(nullptr)
    , m_fastLootCheckBox(nullptr)
    , m_autoLootCheckBox(nullptr)
    , m_fogRemovalCheckBox(nullptr)
    , m_grassRemovalCheckBox(nullptr)
    , m_shadowRemovalCheckBox(nullptr)
    , m_weatherRemovalCheckBox(nullptr)
    , m_speedMultiplierSlider(nullptr)
    , m_speedMultiplierSpinBox(nullptr)
    , m_jumpHeightSlider(nullptr)
    , m_jumpHeightSpinBox(nullptr)
    , m_flySpeedSlider(nullptr)
    , m_flySpeedSpinBox(nullptr)
    , m_rapidFireRateSlider(nullptr)
    , m_rapidFireRateSpinBox(nullptr)
    , m_autoLootRadiusSlider(nullptr)
    , m_autoLootRadiusSpinBox(nullptr)
    , m_presetComboBox(nullptr)
    , m_loadPresetButton(nullptr)
    , m_savePresetButton(nullptr)
    , m_deletePresetButton(nullptr)
    , m_importSettingsButton(nullptr)
    , m_exportSettingsButton(nullptr)
    , m_presetNameLineEdit(nullptr)
    , m_presetDescriptionTextEdit(nullptr)
    , m_applyButton(nullptr)
    , m_resetButton(nullptr)
    , m_defaultsButton(nullptr)
    , m_previewTimer(nullptr)
    , m_validationTimer(nullptr)
    , m_settings(nullptr)
    , m_settingsLoaded(false)
    , m_updatingUI(false)
    , m_currentPreset("Default")
{
    // Initialize QSettings
    m_settings = new QSettings(this);
    
    // Setup UI
    setupUI();
    
    // Initialize timers
    m_previewTimer = new QTimer(this);
    m_previewTimer->setInterval(PREVIEW_UPDATE_INTERVAL);
    m_previewTimer->setSingleShot(false);
    connect(m_previewTimer, &QTimer::timeout, this, &ModSettingsPanel::updatePreviewTimer);
    
    m_validationTimer = new QTimer(this);
    m_validationTimer->setInterval(VALIDATION_INTERVAL);
    m_validationTimer->setSingleShot(true);
    connect(m_validationTimer, &QTimer::timeout, this, &ModSettingsPanel::validateSettings);
    
    // Load settings
    loadSettings();
    
    // Start preview timer
    m_previewTimer->start();
}

ModSettingsPanel::~ModSettingsPanel()
{
    // Stop timers
    if (m_previewTimer) {
        m_previewTimer->stop();
    }
    if (m_validationTimer) {
        m_validationTimer->stop();
    }
    
    // Save settings
    saveSettings();
}

void ModSettingsPanel::setGameInterface(GameInterface *gameInterface)
{
    m_gameInterface = gameInterface;
}

void ModSettingsPanel::setLogger(Logger *logger)
{
    m_logger = logger;
}

void ModSettingsPanel::loadSettings()
{
    if (!m_settings) return;
    
    m_updatingUI = true;
    
    m_settings->beginGroup(SETTINGS_GROUP);
    
    // Load aimbot settings
    m_aimbotSettings.enabled = m_settings->value("aimbot/enabled", false).toBool();
    m_aimbotSettings.smoothAiming = m_settings->value("aimbot/smoothAiming", true).toBool();
    m_aimbotSettings.autoFire = m_settings->value("aimbot/autoFire", false).toBool();
    m_aimbotSettings.autoReload = m_settings->value("aimbot/autoReload", false).toBool();
    m_aimbotSettings.targetPrediction = m_settings->value("aimbot/targetPrediction", true).toBool();
    m_aimbotSettings.visibilityCheck = m_settings->value("aimbot/visibilityCheck", true).toBool();
    m_aimbotSettings.teamCheck = m_settings->value("aimbot/teamCheck", true).toBool();
    m_aimbotSettings.knockedCheck = m_settings->value("aimbot/knockedCheck", false).toBool();
    m_aimbotSettings.fov = m_settings->value("aimbot/fov", 90.0f).toFloat();
    m_aimbotSettings.smoothness = m_settings->value("aimbot/smoothness", 5.0f).toFloat();
    m_aimbotSettings.maxDistance = m_settings->value("aimbot/maxDistance", 300.0f).toFloat();
    m_aimbotSettings.reactionTime = m_settings->value("aimbot/reactionTime", 0.1f).toFloat();
    m_aimbotSettings.predictionMultiplier = m_settings->value("aimbot/predictionMultiplier", 1.0f).toFloat();
    m_aimbotSettings.targetBone = m_settings->value("aimbot/targetBone", 0).toInt();
    m_aimbotSettings.aimKey = m_settings->value("aimbot/aimKey", 0x02).toInt();
    m_aimbotSettings.priority = m_settings->value("aimbot/priority", 0).toInt();
    m_aimbotSettings.targetFilter = m_settings->value("aimbot/targetFilter", "All").toString();
    
    // Load ESP settings
    m_espSettings.enabled = m_settings->value("esp/enabled", false).toBool();
    m_espSettings.playerESP = m_settings->value("esp/playerESP", true).toBool();
    m_espSettings.vehicleESP = m_settings->value("esp/vehicleESP", true).toBool();
    m_espSettings.itemESP = m_settings->value("esp/itemESP", true).toBool();
    m_espSettings.weaponESP = m_settings->value("esp/weaponESP", true).toBool();
    m_espSettings.grenadeESP = m_settings->value("esp/grenadeESP", true).toBool();
    m_espSettings.supplyESP = m_settings->value("esp/supplyESP", true).toBool();
    m_espSettings.playerBox = m_settings->value("esp/playerBox", true).toBool();
    m_espSettings.playerName = m_settings->value("esp/playerName", true).toBool();
    m_espSettings.playerHealth = m_settings->value("esp/playerHealth", true).toBool();
    m_espSettings.playerDistance = m_settings->value("esp/playerDistance", true).toBool();
    m_espSettings.playerWeapon = m_settings->value("esp/playerWeapon", true).toBool();
    m_espSettings.playerDirection = m_settings->value("esp/playerDirection", false).toBool();
    m_espSettings.skeletonESP = m_settings->value("esp/skeletonESP", false).toBool();
    m_espSettings.headDot = m_settings->value("esp/headDot", true).toBool();
    m_espSettings.snapLines = m_settings->value("esp/snapLines", false).toBool();
    m_espSettings.healthBar = m_settings->value("esp/healthBar", true).toBool();
    m_espSettings.armorBar = m_settings->value("esp/armorBar", false).toBool();
    m_espSettings.maxDistance = m_settings->value("esp/maxDistance", 500.0f).toFloat();
    m_espSettings.boxThickness = m_settings->value("esp/boxThickness", 1.0f).toFloat();
    m_espSettings.lineThickness = m_settings->value("esp/lineThickness", 1.0f).toFloat();
    m_espSettings.enemyColor = m_settings->value("esp/enemyColor", QColor(255, 0, 0)).value<QColor>();
    m_espSettings.teamColor = m_settings->value("esp/teamColor", QColor(0, 255, 0)).value<QColor>();
    m_espSettings.vehicleColor = m_settings->value("esp/vehicleColor", QColor(255, 255, 0)).value<QColor>();
    m_espSettings.itemColor = m_settings->value("esp/itemColor", QColor(255, 255, 255)).value<QColor>();
    m_espSettings.weaponColor = m_settings->value("esp/weaponColor", QColor(255, 165, 0)).value<QColor>();
    m_espSettings.textFont = m_settings->value("esp/textFont", QFont("Arial", 10)).value<QFont>();
    m_espSettings.textSize = m_settings->value("esp/textSize", 12).toInt();
    
    // Load wallhack settings
    m_wallhackSettings.enabled = m_settings->value("wallhack/enabled", false).toBool();
    m_wallhackSettings.playerWallhack = m_settings->value("wallhack/playerWallhack", true).toBool();
    m_wallhackSettings.vehicleWallhack = m_settings->value("wallhack/vehicleWallhack", true).toBool();
    m_wallhackSettings.itemWallhack = m_settings->value("wallhack/itemWallhack", false).toBool();
    m_wallhackSettings.outlineMode = m_settings->value("wallhack/outlineMode", true).toBool();
    m_wallhackSettings.glowMode = m_settings->value("wallhack/glowMode", false).toBool();
    m_wallhackSettings.maxDistance = m_settings->value("wallhack/maxDistance", 200.0f).toFloat();
    m_wallhackSettings.transparency = m_settings->value("wallhack/transparency", 0.7f).toFloat();
    m_wallhackSettings.glowIntensity = m_settings->value("wallhack/glowIntensity", 1.0f).toFloat();
    m_wallhackSettings.playerColor = m_settings->value("wallhack/playerColor", QColor(255, 0, 0, 180)).value<QColor>();
    m_wallhackSettings.vehicleColor = m_settings->value("wallhack/vehicleColor", QColor(255, 255, 0, 180)).value<QColor>();
    m_wallhackSettings.itemColor = m_settings->value("wallhack/itemColor", QColor(255, 255, 255, 180)).value<QColor>();
    
    // Load radar settings
    m_radarSettings.enabled = m_settings->value("radar/enabled", false).toBool();
    m_radarSettings.playerRadar = m_settings->value("radar/playerRadar", true).toBool();
    m_radarSettings.vehicleRadar = m_settings->value("radar/vehicleRadar", true).toBool();
    m_radarSettings.itemRadar = m_settings->value("radar/itemRadar", false).toBool();
    m_radarSettings.miniMap = m_settings->value("radar/miniMap", true).toBool();
    m_radarSettings.fullScreen = m_settings->value("radar/fullScreen", false).toBool();
    m_radarSettings.rotateWithPlayer = m_settings->value("radar/rotateWithPlayer", true).toBool();
    m_radarSettings.radarSize = m_settings->value("radar/radarSize", 200.0f).toFloat();
    m_radarSettings.radarRange = m_settings->value("radar/radarRange", 500.0f).toFloat();
    m_radarSettings.radarScale = m_settings->value("radar/radarScale", 1.0f).toFloat();
    m_radarSettings.radarX = m_settings->value("radar/radarX", 50).toInt();
    m_radarSettings.radarY = m_settings->value("radar/radarY", 50).toInt();
    m_radarSettings.backgroundColor = m_settings->value("radar/backgroundColor", QColor(0, 0, 0, 128)).value<QColor>();
    m_radarSettings.borderColor = m_settings->value("radar/borderColor", QColor(255, 255, 255)).value<QColor>();
    m_radarSettings.playerDotColor = m_settings->value("radar/playerDotColor", QColor(0, 255, 0)).value<QColor>();
    m_radarSettings.enemyDotColor = m_settings->value("radar/enemyDotColor", QColor(255, 0, 0)).value<QColor>();
    
    // Load misc settings
    m_miscSettings.noRecoil = m_settings->value("misc/noRecoil", false).toBool();
    m_miscSettings.noSpread = m_settings->value("misc/noSpread", false).toBool();
    m_miscSettings.rapidFire = m_settings->value("misc/rapidFire", false).toBool();
    m_miscSettings.infiniteAmmo = m_settings->value("misc/infiniteAmmo", false).toBool();
    m_miscSettings.noFallDamage = m_settings->value("misc/noFallDamage", false).toBool();
    m_miscSettings.speedHack = m_settings->value("misc/speedHack", false).toBool();
    m_miscSettings.jumpHack = m_settings->value("misc/jumpHack", false).toBool();
    m_miscSettings.flyHack = m_settings->value("misc/flyHack", false).toBool();
    m_miscSettings.instantHeal = m_settings->value("misc/instantHeal", false).toBool();
    m_miscSettings.instantRevive = m_settings->value("misc/instantRevive", false).toBool();
    m_miscSettings.fastLoot = m_settings->value("misc/fastLoot", false).toBool();
    m_miscSettings.autoLoot = m_settings->value("misc/autoLoot", false).toBool();
    m_miscSettings.fogRemoval = m_settings->value("misc/fogRemoval", false).toBool();
    m_miscSettings.grassRemoval = m_settings->value("misc/grassRemoval", false).toBool();
    m_miscSettings.shadowRemoval = m_settings->value("misc/shadowRemoval", false).toBool();
    m_miscSettings.weatherRemoval = m_settings->value("misc/weatherRemoval", false).toBool();
    m_miscSettings.speedMultiplier = m_settings->value("misc/speedMultiplier", 1.5f).toFloat();
    m_miscSettings.jumpHeight = m_settings->value("misc/jumpHeight", 2.0f).toFloat();
    m_miscSettings.flySpeed = m_settings->value("misc/flySpeed", 10.0f).toFloat();
    m_miscSettings.rapidFireRate = m_settings->value("misc/rapidFireRate", 100).toInt();
    m_miscSettings.autoLootRadius = m_settings->value("misc/autoLootRadius", 50).toInt();
    
    m_currentPreset = m_settings->value("currentPreset", "Default").toString();
    
    m_settings->endGroup();
    
    m_settingsLoaded = true;
    m_updatingUI = false;
    
    // Update UI
    updateUI();
}

void ModSettingsPanel::saveSettings()
{
    if (!m_settings || !m_settingsLoaded) return;
    
    m_settings->beginGroup(SETTINGS_GROUP);
    
    // Save aimbot settings
    m_settings->setValue("aimbot/enabled", m_aimbotSettings.enabled);
    m_settings->setValue("aimbot/smoothAiming", m_aimbotSettings.smoothAiming);
    m_settings->setValue("aimbot/autoFire", m_aimbotSettings.autoFire);
    m_settings->setValue("aimbot/autoReload", m_aimbotSettings.autoReload);
    m_settings->setValue("aimbot/targetPrediction", m_aimbotSettings.targetPrediction);
    m_settings->setValue("aimbot/visibilityCheck", m_aimbotSettings.visibilityCheck);
    m_settings->setValue("aimbot/teamCheck", m_aimbotSettings.teamCheck);
    m_settings->setValue("aimbot/knockedCheck", m_aimbotSettings.knockedCheck);
    m_settings->setValue("aimbot/fov", m_aimbotSettings.fov);
    m_settings->setValue("aimbot/smoothness", m_aimbotSettings.smoothness);
    m_settings->setValue("aimbot/maxDistance", m_aimbotSettings.maxDistance);
    m_settings->setValue("aimbot/reactionTime", m_aimbotSettings.reactionTime);
    m_settings->setValue("aimbot/predictionMultiplier", m_aimbotSettings.predictionMultiplier);
    m_settings->setValue("aimbot/targetBone", m_aimbotSettings.targetBone);
    m_settings->setValue("aimbot/aimKey", m_aimbotSettings.aimKey);
    m_settings->setValue("aimbot/priority", m_aimbotSettings.priority);
    m_settings->setValue("aimbot/targetFilter", m_aimbotSettings.targetFilter);
    
    // Save ESP settings
    m_settings->setValue("esp/enabled", m_espSettings.enabled);
    m_settings->setValue("esp/playerESP", m_espSettings.playerESP);
    m_settings->setValue("esp/vehicleESP", m_espSettings.vehicleESP);
    m_settings->setValue("esp/itemESP", m_espSettings.itemESP);
    m_settings->setValue("esp/weaponESP", m_espSettings.weaponESP);
    m_settings->setValue("esp/grenadeESP", m_espSettings.grenadeESP);
    m_settings->setValue("esp/supplyESP", m_espSettings.supplyESP);
    m_settings->setValue("esp/playerBox", m_espSettings.playerBox);
    m_settings->setValue("esp/playerName", m_espSettings.playerName);
    m_settings->setValue("esp/playerHealth", m_espSettings.playerHealth);
    m_settings->setValue("esp/playerDistance", m_espSettings.playerDistance);
    m_settings->setValue("esp/playerWeapon", m_espSettings.playerWeapon);
    m_settings->setValue("esp/playerDirection", m_espSettings.playerDirection);
    m_settings->setValue("esp/skeletonESP", m_espSettings.skeletonESP);
    m_settings->setValue("esp/headDot", m_espSettings.headDot);
    m_settings->setValue("esp/snapLines", m_espSettings.snapLines);
    m_settings->setValue("esp/healthBar", m_espSettings.healthBar);
    m_settings->setValue("esp/armorBar", m_espSettings.armorBar);
    m_settings->setValue("esp/maxDistance", m_espSettings.maxDistance);
    m_settings->setValue("esp/boxThickness", m_espSettings.boxThickness);
    m_settings->setValue("esp/lineThickness", m_espSettings.lineThickness);
    m_settings->setValue("esp/enemyColor", m_espSettings.enemyColor);
    m_settings->setValue("esp/teamColor", m_espSettings.teamColor);
    m_settings->setValue("esp/vehicleColor", m_espSettings.vehicleColor);
    m_settings->setValue("esp/itemColor", m_espSettings.itemColor);
    m_settings->setValue("esp/weaponColor", m_espSettings.weaponColor);
    m_settings->setValue("esp/textFont", m_espSettings.textFont);
    m_settings->setValue("esp/textSize", m_espSettings.textSize);
    
    // Save wallhack settings
    m_settings->setValue("wallhack/enabled", m_wallhackSettings.enabled);
    m_settings->setValue("wallhack/playerWallhack", m_wallhackSettings.playerWallhack);
    m_settings->setValue("wallhack/vehicleWallhack", m_wallhackSettings.vehicleWallhack);
    m_settings->setValue("wallhack/itemWallhack", m_wallhackSettings.itemWallhack);
    m_settings->setValue("wallhack/outlineMode", m_wallhackSettings.outlineMode);
    m_settings->setValue("wallhack/glowMode", m_wallhackSettings.glowMode);
    m_settings->setValue("wallhack/maxDistance", m_wallhackSettings.maxDistance);
    m_settings->setValue("wallhack/transparency", m_wallhackSettings.transparency);
    m_settings->setValue("wallhack/glowIntensity", m_wallhackSettings.glowIntensity);
    m_settings->setValue("wallhack/playerColor", m_wallhackSettings.playerColor);
    m_settings->setValue("wallhack/vehicleColor", m_wallhackSettings.vehicleColor);
    m_settings->setValue("wallhack/itemColor", m_wallhackSettings.itemColor);
    
    // Save radar settings
    m_settings->setValue("radar/enabled", m_radarSettings.enabled);
    m_settings->setValue("radar/playerRadar", m_radarSettings.playerRadar);
    m_settings->setValue("radar/vehicleRadar", m_radarSettings.vehicleRadar);
    m_settings->setValue("radar/itemRadar", m_radarSettings.itemRadar);
    m_settings->setValue("radar/miniMap", m_radarSettings.miniMap);
    m_settings->setValue("radar/fullScreen", m_radarSettings.fullScreen);
    m_settings->setValue("radar/rotateWithPlayer", m_radarSettings.rotateWithPlayer);
    m_settings->setValue("radar/radarSize", m_radarSettings.radarSize);
    m_settings->setValue("radar/radarRange", m_radarSettings.radarRange);
    m_settings->setValue("radar/radarScale", m_radarSettings.radarScale);
    m_settings->setValue("radar/radarX", m_radarSettings.radarX);
    m_settings->setValue("radar/radarY", m_radarSettings.radarY);
    m_settings->setValue("radar/backgroundColor", m_radarSettings.backgroundColor);
    m_settings->setValue("radar/borderColor", m_radarSettings.borderColor);
    m_settings->setValue("radar/playerDotColor", m_radarSettings.playerDotColor);
    m_settings->setValue("radar/enemyDotColor", m_radarSettings.enemyDotColor);
    
    // Save misc settings
    m_settings->setValue("misc/noRecoil", m_miscSettings.noRecoil);
    m_settings->setValue("misc/noSpread", m_miscSettings.noSpread);
    m_settings->setValue("misc/rapidFire", m_miscSettings.rapidFire);
    m_settings->setValue("misc/infiniteAmmo", m_miscSettings.infiniteAmmo);
    m_settings->setValue("misc/noFallDamage", m_miscSettings.noFallDamage);
    m_settings->setValue("misc/speedHack", m_miscSettings.speedHack);
    m_settings->setValue("misc/jumpHack", m_miscSettings.jumpHack);
    m_settings->setValue("misc/flyHack", m_miscSettings.flyHack);
    m_settings->setValue("misc/instantHeal", m_miscSettings.instantHeal);
    m_settings->setValue("misc/instantRevive", m_miscSettings.instantRevive);
    m_settings->setValue("misc/fastLoot", m_miscSettings.fastLoot);
    m_settings->setValue("misc/autoLoot", m_miscSettings.autoLoot);
    m_settings->setValue("misc/fogRemoval", m_miscSettings.fogRemoval);
    m_settings->setValue("misc/grassRemoval", m_miscSettings.grassRemoval);
    m_settings->setValue("misc/shadowRemoval", m_miscSettings.shadowRemoval);
    m_settings->setValue("misc/weatherRemoval", m_miscSettings.weatherRemoval);
    m_settings->setValue("misc/speedMultiplier", m_miscSettings.speedMultiplier);
    m_settings->setValue("misc/jumpHeight", m_miscSettings.jumpHeight);
    m_settings->setValue("misc/flySpeed", m_miscSettings.flySpeed);
    m_settings->setValue("misc/rapidFireRate", m_miscSettings.rapidFireRate);
    m_settings->setValue("misc/autoLootRadius", m_miscSettings.autoLootRadius);
    
    m_settings->setValue("currentPreset", m_currentPreset);
    
    m_settings->endGroup();
    m_settings->sync();
}

void ModSettingsPanel::resetSettings()
{
    // Reset to default values
    m_aimbotSettings = AimbotSettings();
    m_espSettings = ESPSettings();
    m_wallhackSettings = WallhackSettings();
    m_radarSettings = RadarSettings();
    m_miscSettings = MiscSettings();
    
    updateUI();
    emit settingsChanged();
}

void ModSettingsPanel::applySettings()
{
    // Apply settings to game interface
    if (m_gameInterface) {
        // TODO: Apply settings to game interface
    }
    
    // Save settings
    saveSettings();
    
    // Emit signals
    emit settingsChanged();
    emit aimbotSettingsChanged(m_aimbotSettings);
    emit espSettingsChanged(m_espSettings);
    emit wallhackSettingsChanged(m_wallhackSettings);
    emit radarSettingsChanged(m_radarSettings);
    emit miscSettingsChanged(m_miscSettings);
}

void ModSettingsPanel::updateUI()
{
    if (m_updatingUI) return;
    
    m_updatingUI = true;
    
    updateAimbotUI();
    updateESPUI();
    updateWallhackUI();
    updateRadarUI();
    updateMiscUI();
    updatePresetUI();
    
    m_updatingUI = false;
}

void ModSettingsPanel::updatePreview()
{
    // TODO: Update preview display
}

// Slot implementations
void ModSettingsPanel::onAimbotToggled(bool enabled)
{
    m_aimbotSettings.enabled = enabled;
    enableAimbotControls(enabled);
    emit aimbotSettingsChanged(m_aimbotSettings);
}

void ModSettingsPanel::onESPToggled(bool enabled)
{
    m_espSettings.enabled = enabled;
    enableESPControls(enabled);
    emit espSettingsChanged(m_espSettings);
}

void ModSettingsPanel::onWallhackToggled(bool enabled)
{
    m_wallhackSettings.enabled = enabled;
    enableWallhackControls(enabled);
    emit wallhackSettingsChanged(m_wallhackSettings);
}

void ModSettingsPanel::onRadarToggled(bool enabled)
{
    m_radarSettings.enabled = enabled;
    enableRadarControls(enabled);
    emit radarSettingsChanged(m_radarSettings);
}

// Stub implementations for remaining slots and methods
void ModSettingsPanel::onAimbotSettingsChanged() { /* TODO */ }
void ModSettingsPanel::onAimbotFOVChanged(int value) { /* TODO */ }
void ModSettingsPanel::onAimbotSmoothnessChanged(int value) { /* TODO */ }
void ModSettingsPanel::onAimbotDistanceChanged(int value) { /* TODO */ }
void ModSettingsPanel::onAimbotBoneChanged(int index) { /* TODO */ }
void ModSettingsPanel::onAimbotKeyChanged() { /* TODO */ }
void ModSettingsPanel::onAimbotPriorityChanged(int index) { /* TODO */ }
void ModSettingsPanel::onESPSettingsChanged() { /* TODO */ }
void ModSettingsPanel::onESPDistanceChanged(int value) { /* TODO */ }
void ModSettingsPanel::onESPColorChanged() { /* TODO */ }
void ModSettingsPanel::onESPFontChanged() { /* TODO */ }
void ModSettingsPanel::onESPSizeChanged(int value) { /* TODO */ }
void ModSettingsPanel::onWallhackSettingsChanged() { /* TODO */ }
void ModSettingsPanel::onWallhackModeChanged() { /* TODO */ }
void ModSettingsPanel::onWallhackDistanceChanged(int value) { /* TODO */ }
void ModSettingsPanel::onWallhackTransparencyChanged(int value) { /* TODO */ }
void ModSettingsPanel::onWallhackColorChanged() { /* TODO */ }
void ModSettingsPanel::onRadarSettingsChanged() { /* TODO */ }
void ModSettingsPanel::onRadarSizeChanged(int value) { /* TODO */ }
void ModSettingsPanel::onRadarRangeChanged(int value) { /* TODO */ }
void ModSettingsPanel::onRadarPositionChanged() { /* TODO */ }
void ModSettingsPanel::onRadarColorChanged() { /* TODO */ }
void ModSettingsPanel::onMiscSettingsChanged() { /* TODO */ }
void ModSettingsPanel::onSpeedMultiplierChanged(int value) { /* TODO */ }
void ModSettingsPanel::onJumpHeightChanged(int value) { /* TODO */ }
void ModSettingsPanel::onRapidFireRateChanged(int value) { /* TODO */ }
void ModSettingsPanel::onLoadPreset() { /* TODO */ }
void ModSettingsPanel::onSavePreset() { /* TODO */ }
void ModSettingsPanel::onDeletePreset() { /* TODO */ }
void ModSettingsPanel::onPresetChanged(const QString &presetName) { /* TODO */ }
void ModSettingsPanel::onImportSettings() { /* TODO */ }
void ModSettingsPanel::onExportSettings() { /* TODO */ }
void ModSettingsPanel::onTestAimbot() { /* TODO */ }
void ModSettingsPanel::onTestESP() { /* TODO */ }
void ModSettingsPanel::onTestWallhack() { /* TODO */ }
void ModSettingsPanel::onTestRadar() { /* TODO */ }
void ModSettingsPanel::updatePreviewTimer() { /* TODO */ }
void ModSettingsPanel::validateSettings() { /* TODO */ }
void ModSettingsPanel::setupUI() { /* TODO */ }
void ModSettingsPanel::setupAimbotTab() { /* TODO */ }
void ModSettingsPanel::setupESPTab() { /* TODO */ }
void ModSettingsPanel::setupWallhackTab() { /* TODO */ }
void ModSettingsPanel::setupRadarTab() { /* TODO */ }
void ModSettingsPanel::setupMiscTab() { /* TODO */ }
void ModSettingsPanel::setupPresetsTab() { /* TODO */ }
void ModSettingsPanel::setupAimbotControls() { /* TODO */ }
void ModSettingsPanel::setupESPControls() { /* TODO */ }
void ModSettingsPanel::setupWallhackControls() { /* TODO */ }
void ModSettingsPanel::setupRadarControls() { /* TODO */ }
void ModSettingsPanel::setupMiscControls() { /* TODO */ }
void ModSettingsPanel::setupPresetControls() { /* TODO */ }
QGroupBox* ModSettingsPanel::createGroupBox(const QString &title, QWidget *parent) { return new QGroupBox(title, parent); }
QHBoxLayout* ModSettingsPanel::createSliderLayout(const QString &label, QSlider *slider, QSpinBox *spinBox) { return new QHBoxLayout(); }
QHBoxLayout* ModSettingsPanel::createDoubleSliderLayout(const QString &label, QSlider *slider, QDoubleSpinBox *doubleSpinBox) { return new QHBoxLayout(); }
QHBoxLayout* ModSettingsPanel::createCheckBoxLayout(QCheckBox *checkBox, const QString &tooltip) { return new QHBoxLayout(); }
QHBoxLayout* ModSettingsPanel::createComboBoxLayout(const QString &label, QComboBox *comboBox) { return new QHBoxLayout(); }
QPushButton* ModSettingsPanel::createColorButton(const QColor &color) { return new QPushButton(); }
void ModSettingsPanel::connectAimbotSignals() { /* TODO */ }
void ModSettingsPanel::connectESPSignals() { /* TODO */ }
void ModSettingsPanel::connectWallhackSignals() { /* TODO */ }
void ModSettingsPanel::connectRadarSignals() { /* TODO */ }
void ModSettingsPanel::connectMiscSignals() { /* TODO */ }
void ModSettingsPanel::connectPresetSignals() { /* TODO */ }
void ModSettingsPanel::updateAimbotUI() { /* TODO */ }
void ModSettingsPanel::updateESPUI() { /* TODO */ }
void ModSettingsPanel::updateWallhackUI() { /* TODO */ }
void ModSettingsPanel::updateRadarUI() { /* TODO */ }
void ModSettingsPanel::updateMiscUI() { /* TODO */ }
void ModSettingsPanel::updatePresetUI() { /* TODO */ }
void ModSettingsPanel::enableAimbotControls(bool enabled) { /* TODO */ }
void ModSettingsPanel::enableESPControls(bool enabled) { /* TODO */ }
void ModSettingsPanel::enableWallhackControls(bool enabled) { /* TODO */ }
void ModSettingsPanel::enableRadarControls(bool enabled) { /* TODO */ }
void ModSettingsPanel::validateAimbotSettings() { /* TODO */ }
void ModSettingsPanel::validateESPSettings() { /* TODO */ }
void ModSettingsPanel::validateWallhackSettings() { /* TODO */ }
void ModSettingsPanel::validateRadarSettings() { /* TODO */ }
void ModSettingsPanel::validateMiscSettings() { /* TODO */ }
QString ModSettingsPanel::getPresetPath() const { return QString(); }
QStringList ModSettingsPanel::getAvailablePresets() const { return QStringList(); }
bool ModSettingsPanel::loadPresetFromFile(const QString &filePath) { return false; }
bool ModSettingsPanel::savePresetToFile(const QString &filePath) { return false; }

#include "mod_settings_panel.moc"