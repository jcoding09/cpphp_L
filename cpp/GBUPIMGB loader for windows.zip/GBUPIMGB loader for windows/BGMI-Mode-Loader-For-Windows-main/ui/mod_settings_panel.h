#ifndef MOD_SETTINGS_PANEL_H
#define MOD_SETTINGS_PANEL_H

#include <QtWidgets/QWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QFrame>
#include <QtWidgets/QButtonGroup>
#include <QtCore/QTimer>
#include <QtCore/QSettings>
#include <QtGui/QColor>
#include <QtGui/QFont>
#include <memory>

// Forward declarations
class GameInterface;
class Logger;

struct AimbotSettings {
    bool enabled = false;
    bool smoothAiming = true;
    bool autoFire = false;
    bool autoReload = false;
    bool targetPrediction = true;
    bool visibilityCheck = true;
    bool teamCheck = true;
    bool knockedCheck = false;
    
    float fov = 90.0f;
    float smoothness = 5.0f;
    float maxDistance = 300.0f;
    float reactionTime = 0.1f;
    float predictionMultiplier = 1.0f;
    
    int targetBone = 0; // 0=Head, 1=Chest, 2=Stomach
    int aimKey = 0x02; // Right mouse button
    int priority = 0; // 0=Distance, 1=Health, 2=Crosshair
    
    QString targetFilter = "All";
};

struct ESPSettings {
    bool enabled = false;
    bool playerESP = true;
    bool vehicleESP = true;
    bool itemESP = true;
    bool weaponESP = true;
    bool grenadeESP = true;
    bool supplyESP = true;
    
    bool playerBox = true;
    bool playerName = true;
    bool playerHealth = true;
    bool playerDistance = true;
    bool playerWeapon = true;
    bool playerDirection = false;
    
    bool skeletonESP = false;
    bool headDot = true;
    bool snapLines = false;
    bool healthBar = true;
    bool armorBar = false;
    
    float maxDistance = 500.0f;
    float boxThickness = 1.0f;
    float lineThickness = 1.0f;
    
    QColor enemyColor = QColor(255, 0, 0);
    QColor teamColor = QColor(0, 255, 0);
    QColor vehicleColor = QColor(255, 255, 0);
    QColor itemColor = QColor(255, 255, 255);
    QColor weaponColor = QColor(255, 165, 0);
    
    QFont textFont = QFont("Arial", 10);
    int textSize = 12;
};

struct WallhackSettings {
    bool enabled = false;
    bool playerWallhack = true;
    bool vehicleWallhack = true;
    bool itemWallhack = false;
    
    bool xrayMode = false;
    bool outlineMode = true;
    bool glowMode = false;
    
    float maxDistance = 200.0f;
    float transparency = 0.7f;
    float glowIntensity = 1.0f;
    
    QColor playerColor = QColor(255, 0, 0, 180);
    QColor vehicleColor = QColor(255, 255, 0, 180);
    QColor itemColor = QColor(255, 255, 255, 180);
};

struct RadarSettings {
    bool enabled = false;
    bool playerRadar = true;
    bool vehicleRadar = true;
    bool itemRadar = false;
    
    bool miniMap = true;
    bool fullScreen = false;
    bool rotateWithPlayer = true;
    
    float radarSize = 200.0f;
    float radarRange = 500.0f;
    float radarScale = 1.0f;
    
    int radarX = 50;
    int radarY = 50;
    
    QColor backgroundColor = QColor(0, 0, 0, 128);
    QColor borderColor = QColor(255, 255, 255);
    QColor playerDotColor = QColor(0, 255, 0);
    QColor enemyDotColor = QColor(255, 0, 0);
};

struct MiscSettings {
    bool noRecoil = false;
    bool noSpread = false;
    bool rapidFire = false;
    bool infiniteAmmo = false;
    bool noFallDamage = false;
    bool speedHack = false;
    bool jumpHack = false;
    bool flyHack = false;
    
    bool instantHeal = false;
    bool instantRevive = false;
    bool fastLoot = false;
    bool autoLoot = false;
    
    bool fogRemoval = false;
    bool grassRemoval = false;
    bool shadowRemoval = false;
    bool weatherRemoval = false;
    
    float speedMultiplier = 1.5f;
    float jumpHeight = 2.0f;
    float flySpeed = 10.0f;
    
    int rapidFireRate = 100;
    int autoLootRadius = 50;
};

class ModSettingsPanel : public QWidget
{
    Q_OBJECT

public:
    explicit ModSettingsPanel(QWidget *parent = nullptr);
    ~ModSettingsPanel();
    
    // Settings management
    void loadSettings();
    void saveSettings();
    void resetSettings();
    void applySettings();
    
    // Getters
    const AimbotSettings& getAimbotSettings() const { return m_aimbotSettings; }
    const ESPSettings& getESPSettings() const { return m_espSettings; }
    const WallhackSettings& getWallhackSettings() const { return m_wallhackSettings; }
    const RadarSettings& getRadarSettings() const { return m_radarSettings; }
    const MiscSettings& getMiscSettings() const { return m_miscSettings; }
    
    // Setters
    void setGameInterface(GameInterface *gameInterface);
    void setLogger(Logger *logger);
    
    // UI updates
    void updateUI();
    void updatePreview();
    
public slots:
    // Main toggles
    void onAimbotToggled(bool enabled);
    void onESPToggled(bool enabled);
    void onWallhackToggled(bool enabled);
    void onRadarToggled(bool enabled);
    
    // Aimbot slots
    void onAimbotSettingsChanged();
    void onAimbotFOVChanged(int value);
    void onAimbotSmoothnessChanged(int value);
    void onAimbotDistanceChanged(int value);
    void onAimbotBoneChanged(int index);
    void onAimbotKeyChanged();
    void onAimbotPriorityChanged(int index);
    
    // ESP slots
    void onESPSettingsChanged();
    void onESPDistanceChanged(int value);
    void onESPColorChanged();
    void onESPFontChanged();
    void onESPSizeChanged(int value);
    
    // Wallhack slots
    void onWallhackSettingsChanged();
    void onWallhackModeChanged();
    void onWallhackDistanceChanged(int value);
    void onWallhackTransparencyChanged(int value);
    void onWallhackColorChanged();
    
    // Radar slots
    void onRadarSettingsChanged();
    void onRadarSizeChanged(int value);
    void onRadarRangeChanged(int value);
    void onRadarPositionChanged();
    void onRadarColorChanged();
    
    // Misc slots
    void onMiscSettingsChanged();
    void onSpeedMultiplierChanged(int value);
    void onJumpHeightChanged(int value);
    void onRapidFireRateChanged(int value);
    
    // Preset management
    void onLoadPreset();
    void onSavePreset();
    void onDeletePreset();
    void onPresetChanged(const QString &presetName);
    
    // Import/Export
    void onImportSettings();
    void onExportSettings();
    
    // Testing
    void onTestAimbot();
    void onTestESP();
    void onTestWallhack();
    void onTestRadar();
    
signals:
    void settingsChanged();
    void aimbotSettingsChanged(const AimbotSettings &settings);
    void espSettingsChanged(const ESPSettings &settings);
    void wallhackSettingsChanged(const WallhackSettings &settings);
    void radarSettingsChanged(const RadarSettings &settings);
    void miscSettingsChanged(const MiscSettings &settings);
    
private slots:
    void updatePreviewTimer();
    void validateSettings();
    
private:
    // UI setup
    void setupUI();
    void setupAimbotTab();
    void setupESPTab();
    void setupWallhackTab();
    void setupRadarTab();
    void setupMiscTab();
    void setupPresetsTab();
    
    void setupAimbotControls();
    void setupESPControls();
    void setupWallhackControls();
    void setupRadarControls();
    void setupMiscControls();
    void setupPresetControls();
    
    // UI helpers
    QGroupBox* createGroupBox(const QString &title, QWidget *parent = nullptr);
    QHBoxLayout* createSliderLayout(const QString &label, QSlider *slider, QSpinBox *spinBox);
    QHBoxLayout* createDoubleSliderLayout(const QString &label, QSlider *slider, QDoubleSpinBox *doubleSpinBox);
    QHBoxLayout* createCheckBoxLayout(QCheckBox *checkBox, const QString &tooltip = QString());
    QHBoxLayout* createComboBoxLayout(const QString &label, QComboBox *comboBox);
    QPushButton* createColorButton(const QColor &color);
    
    void connectAimbotSignals();
    void connectESPSignals();
    void connectWallhackSignals();
    void connectRadarSignals();
    void connectMiscSignals();
    void connectPresetSignals();
    
    void updateAimbotUI();
    void updateESPUI();
    void updateWallhackUI();
    void updateRadarUI();
    void updateMiscUI();
    void updatePresetUI();
    
    void enableAimbotControls(bool enabled);
    void enableESPControls(bool enabled);
    void enableWallhackControls(bool enabled);
    void enableRadarControls(bool enabled);
    
    void validateAimbotSettings();
    void validateESPSettings();
    void validateWallhackSettings();
    void validateRadarSettings();
    void validateMiscSettings();
    
    QString getPresetPath() const;
    QStringList getAvailablePresets() const;
    bool loadPresetFromFile(const QString &filePath);
    bool savePresetToFile(const QString &filePath);
    
    // Core components
    GameInterface *m_gameInterface;
    Logger *m_logger;
    
    // Settings
    AimbotSettings m_aimbotSettings;
    ESPSettings m_espSettings;
    WallhackSettings m_wallhackSettings;
    RadarSettings m_radarSettings;
    MiscSettings m_miscSettings;
    
    // Main UI
    QVBoxLayout *m_mainLayout;
    QTabWidget *m_tabWidget;
    QScrollArea *m_scrollArea;
    
    // Tab widgets
    QWidget *m_aimbotTab;
    QWidget *m_espTab;
    QWidget *m_wallhackTab;
    QWidget *m_radarTab;
    QWidget *m_miscTab;
    QWidget *m_presetsTab;
    
    // Aimbot controls
    QCheckBox *m_aimbotEnabledCheckBox;
    QCheckBox *m_smoothAimingCheckBox;
    QCheckBox *m_autoFireCheckBox;
    QCheckBox *m_autoReloadCheckBox;
    QCheckBox *m_targetPredictionCheckBox;
    QCheckBox *m_visibilityCheckCheckBox;
    QCheckBox *m_teamCheckCheckBox;
    QCheckBox *m_knockedCheckCheckBox;
    
    QSlider *m_aimbotFOVSlider;
    QSpinBox *m_aimbotFOVSpinBox;
    QSlider *m_aimbotSmoothnessSlider;
    QSpinBox *m_aimbotSmoothnessSpinBox;
    QSlider *m_aimbotDistanceSlider;
    QSpinBox *m_aimbotDistanceSpinBox;
    QSlider *m_reactionTimeSlider;
    QDoubleSpinBox *m_reactionTimeSpinBox;
    
    QComboBox *m_targetBoneComboBox;
    QComboBox *m_aimKeyComboBox;
    QComboBox *m_aimPriorityComboBox;
    QComboBox *m_targetFilterComboBox;
    
    QPushButton *m_testAimbotButton;
    
    // ESP controls
    QCheckBox *m_espEnabledCheckBox;
    QCheckBox *m_playerESPCheckBox;
    QCheckBox *m_vehicleESPCheckBox;
    QCheckBox *m_itemESPCheckBox;
    QCheckBox *m_weaponESPCheckBox;
    QCheckBox *m_grenadeESPCheckBox;
    QCheckBox *m_supplyESPCheckBox;
    
    QCheckBox *m_playerBoxCheckBox;
    QCheckBox *m_playerNameCheckBox;
    QCheckBox *m_playerHealthCheckBox;
    QCheckBox *m_playerDistanceCheckBox;
    QCheckBox *m_playerWeaponCheckBox;
    QCheckBox *m_playerDirectionCheckBox;
    
    QCheckBox *m_skeletonESPCheckBox;
    QCheckBox *m_headDotCheckBox;
    QCheckBox *m_snapLinesCheckBox;
    QCheckBox *m_healthBarCheckBox;
    QCheckBox *m_armorBarCheckBox;
    
    QSlider *m_espDistanceSlider;
    QSpinBox *m_espDistanceSpinBox;
    QSlider *m_boxThicknessSlider;
    QDoubleSpinBox *m_boxThicknessSpinBox;
    QSlider *m_lineThicknessSlider;
    QDoubleSpinBox *m_lineThicknessSpinBox;
    QSlider *m_textSizeSlider;
    QSpinBox *m_textSizeSpinBox;
    
    QPushButton *m_enemyColorButton;
    QPushButton *m_teamColorButton;
    QPushButton *m_vehicleColorButton;
    QPushButton *m_itemColorButton;
    QPushButton *m_weaponColorButton;
    QPushButton *m_fontButton;
    QPushButton *m_testESPButton;
    
    // Wallhack controls
    QCheckBox *m_wallhackEnabledCheckBox;
    QCheckBox *m_playerWallhackCheckBox;
    QCheckBox *m_vehicleWallhackCheckBox;
    QCheckBox *m_itemWallhackCheckBox;
    
    QRadioButton *m_xrayModeRadio;
    QRadioButton *m_outlineModeRadio;
    QRadioButton *m_glowModeRadio;
    QButtonGroup *m_wallhackModeGroup;
    
    QSlider *m_wallhackDistanceSlider;
    QSpinBox *m_wallhackDistanceSpinBox;
    QSlider *m_transparencySlider;
    QDoubleSpinBox *m_transparencySpinBox;
    QSlider *m_glowIntensitySlider;
    QDoubleSpinBox *m_glowIntensitySpinBox;
    
    QPushButton *m_wallhackPlayerColorButton;
    QPushButton *m_wallhackVehicleColorButton;
    QPushButton *m_wallhackItemColorButton;
    QPushButton *m_testWallhackButton;
    
    // Radar controls
    QCheckBox *m_radarEnabledCheckBox;
    QCheckBox *m_playerRadarCheckBox;
    QCheckBox *m_vehicleRadarCheckBox;
    QCheckBox *m_itemRadarCheckBox;
    
    QCheckBox *m_miniMapCheckBox;
    QCheckBox *m_fullScreenCheckBox;
    QCheckBox *m_rotateWithPlayerCheckBox;
    
    QSlider *m_radarSizeSlider;
    QSpinBox *m_radarSizeSpinBox;
    QSlider *m_radarRangeSlider;
    QSpinBox *m_radarRangeSpinBox;
    QSlider *m_radarScaleSlider;
    QDoubleSpinBox *m_radarScaleSpinBox;
    
    QSpinBox *m_radarXSpinBox;
    QSpinBox *m_radarYSpinBox;
    
    QPushButton *m_radarBackgroundColorButton;
    QPushButton *m_radarBorderColorButton;
    QPushButton *m_radarPlayerDotColorButton;
    QPushButton *m_radarEnemyDotColorButton;
    QPushButton *m_testRadarButton;
    
    // Misc controls
    QCheckBox *m_noRecoilCheckBox;
    QCheckBox *m_noSpreadCheckBox;
    QCheckBox *m_rapidFireCheckBox;
    QCheckBox *m_infiniteAmmoCheckBox;
    QCheckBox *m_noFallDamageCheckBox;
    QCheckBox *m_speedHackCheckBox;
    QCheckBox *m_jumpHackCheckBox;
    QCheckBox *m_flyHackCheckBox;
    
    QCheckBox *m_instantHealCheckBox;
    QCheckBox *m_instantReviveCheckBox;
    QCheckBox *m_fastLootCheckBox;
    QCheckBox *m_autoLootCheckBox;
    
    QCheckBox *m_fogRemovalCheckBox;
    QCheckBox *m_grassRemovalCheckBox;
    QCheckBox *m_shadowRemovalCheckBox;
    QCheckBox *m_weatherRemovalCheckBox;
    
    QSlider *m_speedMultiplierSlider;
    QDoubleSpinBox *m_speedMultiplierSpinBox;
    QSlider *m_jumpHeightSlider;
    QDoubleSpinBox *m_jumpHeightSpinBox;
    QSlider *m_flySpeedSlider;
    QDoubleSpinBox *m_flySpeedSpinBox;
    
    QSlider *m_rapidFireRateSlider;
    QSpinBox *m_rapidFireRateSpinBox;
    QSlider *m_autoLootRadiusSlider;
    QSpinBox *m_autoLootRadiusSpinBox;
    
    // Preset controls
    QComboBox *m_presetComboBox;
    QPushButton *m_loadPresetButton;
    QPushButton *m_savePresetButton;
    QPushButton *m_deletePresetButton;
    QPushButton *m_importSettingsButton;
    QPushButton *m_exportSettingsButton;
    QLineEdit *m_presetNameLineEdit;
    QTextEdit *m_presetDescriptionTextEdit;
    
    // Control buttons
    QPushButton *m_applyButton;
    QPushButton *m_resetButton;
    QPushButton *m_defaultsButton;
    
    // Timers
    QTimer *m_previewTimer;
    QTimer *m_validationTimer;
    
    // Settings
    QSettings *m_settings;
    
    // State
    bool m_settingsLoaded;
    bool m_updatingUI;
    QString m_currentPreset;
};

#endif // MOD_SETTINGS_PANEL_H