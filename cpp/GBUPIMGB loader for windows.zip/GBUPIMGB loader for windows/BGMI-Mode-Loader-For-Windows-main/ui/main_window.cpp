#include "main_window.h"
#include "../core/logger.h"
#include "../core/injection_manager.h"
#include "../core/memory_manager.h"
#include "../core/game_interface.h"
#include "../core/status_monitor.h"
#include <QApplication>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QGroupBox>
#include <QPushButton>
#include <QLabel>
#include <QProgressBar>
#include <QTextEdit>
#include <QCheckBox>
#include <QSlider>
#include <QComboBox>
#include <QSpinBox>
#include <QTabWidget>
#include <QSplitter>
#include <QMenuBar>
#include <QStatusBar>
#include <QToolBar>
#include <QAction>
#include <QFileDialog>
#include <QMessageBox>
#include <QTimer>
#include <QThread>
#include <QMutex>
#include <QMutexLocker>
#include <QSettings>
#include <QCloseEvent>
#include <QSystemTrayIcon>
#include <QMenu>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , m_injectionManager(nullptr)
    , m_memoryManager(nullptr)
    , m_gameInterface(nullptr)
    , m_statusMonitor(nullptr)
    , m_logger(nullptr)
    , m_isInjected(false)
    , m_autoInject(false)
    , m_minimizeToTray(true)
    , m_startMinimized(false)
    , m_updateTimer(nullptr)
    , m_systemTrayIcon(nullptr)
    , m_trayMenu(nullptr)
{
    setWindowTitle("GhostPulse BGMI Mod Loader v3.9");
    setWindowIcon(QIcon(":/icons/app.ico"));
    setMinimumSize(1200, 800);
    resize(1400, 900);
    
    // Initialize core components
    initializeComponents();
    
    // Setup UI
    setupUI();
    setupMenuBar();
    setupToolBar();
    setupStatusBar();
    setupSystemTray();
    
    // Connect signals
    connectSignals();
    
    // Load settings
    loadSettings();
    
    // Apply theme
    applyTheme();
    
    // Start monitoring
    if (m_statusMonitor) {
        m_statusMonitor->startMonitoring();
    }
    
    Logger::instance()->info("MainWindow initialized", "UI");
}

MainWindow::~MainWindow()
{
    saveSettings();
    
    if (m_statusMonitor) {
        m_statusMonitor->stopMonitoring();
    }
    
    if (m_isInjected && m_injectionManager) {
        m_injectionManager->uninject();
    }
}

void MainWindow::initializeComponents()
{
    // Initialize logger first
    m_logger = Logger::instance();
    
    // Initialize core components
    m_injectionManager = new InjectionManager(this);
    m_memoryManager = new MemoryManager(this);
    m_gameInterface = new GameInterface(this);
    m_statusMonitor = new StatusMonitor(this);
    
    // Setup update timer
    m_updateTimer = new QTimer(this);
    m_updateTimer->setInterval(100); // 100ms updates
    connect(m_updateTimer, &QTimer::timeout, this, &MainWindow::updateUI);
    m_updateTimer->start();
}

void MainWindow::setupUI()
{
    // Create central widget
    QWidget *centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);
    
    // Create main layout
    QHBoxLayout *mainLayout = new QHBoxLayout(centralWidget);
    
    // Create splitter for resizable panels
    QSplitter *mainSplitter = new QSplitter(Qt::Horizontal, this);
    mainLayout->addWidget(mainSplitter);
    
    // Create left panel (controls)
    QWidget *leftPanel = createControlPanel();
    leftPanel->setMaximumWidth(400);
    leftPanel->setMinimumWidth(350);
    mainSplitter->addWidget(leftPanel);
    
    // Create right panel (tabs)
    QTabWidget *rightPanel = createTabWidget();
    mainSplitter->addWidget(rightPanel);
    
    // Set splitter proportions
    mainSplitter->setStretchFactor(0, 0);
    mainSplitter->setStretchFactor(1, 1);
    mainSplitter->setSizes({350, 1050});
}

QWidget* MainWindow::createControlPanel()
{
    QWidget *panel = new QWidget();
    QVBoxLayout *layout = new QVBoxLayout(panel);
    
    // Game Status Group
    QGroupBox *gameGroup = new QGroupBox("Game Status");
    QVBoxLayout *gameLayout = new QVBoxLayout(gameGroup);
    
    m_gameStatusLabel = new QLabel("Game: Not Detected");
    m_gameStatusLabel->setStyleSheet("color: #ff6b6b; font-weight: bold;");
    gameLayout->addWidget(m_gameStatusLabel);
    
    m_processStatusLabel = new QLabel("Process: Not Found");
    gameLayout->addWidget(m_processStatusLabel);
    
    m_injectionStatusLabel = new QLabel("Injection: Not Injected");
    gameLayout->addWidget(m_injectionStatusLabel);
    
    layout->addWidget(gameGroup);
    
    // Injection Control Group
    QGroupBox *injectionGroup = new QGroupBox("Injection Control");
    QVBoxLayout *injectionLayout = new QVBoxLayout(injectionGroup);
    
    // Injection method
    QHBoxLayout *methodLayout = new QHBoxLayout();
    methodLayout->addWidget(new QLabel("Method:"));
    m_injectionMethodCombo = new QComboBox();
    m_injectionMethodCombo->addItems({"DLL Injection", "Manual Map", "Process Hollowing"});
    methodLayout->addWidget(m_injectionMethodCombo);
    injectionLayout->addLayout(methodLayout);
    
    // Auto-inject checkbox
    m_autoInjectCheckBox = new QCheckBox("Auto-inject when game detected");
    injectionLayout->addWidget(m_autoInjectCheckBox);
    
    // Injection buttons
    QHBoxLayout *buttonLayout = new QHBoxLayout();
    m_injectButton = new QPushButton("Inject");
    m_injectButton->setStyleSheet("QPushButton { background-color: #4CAF50; color: white; font-weight: bold; padding: 8px; }");
    m_uninjectButton = new QPushButton("Uninject");
    m_uninjectButton->setStyleSheet("QPushButton { background-color: #f44336; color: white; font-weight: bold; padding: 8px; }");
    m_uninjectButton->setEnabled(false);
    
    buttonLayout->addWidget(m_injectButton);
    buttonLayout->addWidget(m_uninjectButton);
    injectionLayout->addLayout(buttonLayout);
    
    // Progress bar
    m_progressBar = new QProgressBar();
    m_progressBar->setVisible(false);
    injectionLayout->addWidget(m_progressBar);
    
    layout->addWidget(injectionGroup);
    
    // Module Settings Group
    QGroupBox *moduleGroup = new QGroupBox("Module Settings");
    QVBoxLayout *moduleLayout = new QVBoxLayout(moduleGroup);
    
    // Aimbot settings
    QGroupBox *aimbotGroup = new QGroupBox("Aimbot");
    QVBoxLayout *aimbotLayout = new QVBoxLayout(aimbotGroup);
    
    m_aimbotEnabledCheckBox = new QCheckBox("Enable Aimbot");
    aimbotLayout->addWidget(m_aimbotEnabledCheckBox);
    
    QHBoxLayout *aimbotSensLayout = new QHBoxLayout();
    aimbotSensLayout->addWidget(new QLabel("Sensitivity:"));
    m_aimbotSensitivitySlider = new QSlider(Qt::Horizontal);
    m_aimbotSensitivitySlider->setRange(1, 100);
    m_aimbotSensitivitySlider->setValue(50);
    m_aimbotSensitivityLabel = new QLabel("50");
    aimbotSensLayout->addWidget(m_aimbotSensitivitySlider);
    aimbotSensLayout->addWidget(m_aimbotSensitivityLabel);
    aimbotLayout->addLayout(aimbotSensLayout);
    
    QHBoxLayout *aimbotFovLayout = new QHBoxLayout();
    aimbotFovLayout->addWidget(new QLabel("FOV:"));
    m_aimbotFovSlider = new QSlider(Qt::Horizontal);
    m_aimbotFovSlider->setRange(10, 180);
    m_aimbotFovSlider->setValue(90);
    m_aimbotFovLabel = new QLabel("90");
    aimbotFovLayout->addWidget(m_aimbotFovSlider);
    aimbotFovLayout->addWidget(m_aimbotFovLabel);
    aimbotLayout->addLayout(aimbotFovLayout);
    
    moduleLayout->addWidget(aimbotGroup);
    
    // ESP settings
    QGroupBox *espGroup = new QGroupBox("ESP");
    QVBoxLayout *espLayout = new QVBoxLayout(espGroup);
    
    m_espEnabledCheckBox = new QCheckBox("Enable ESP");
    espLayout->addWidget(m_espEnabledCheckBox);
    
    m_espPlayersCheckBox = new QCheckBox("Show Players");
    m_espItemsCheckBox = new QCheckBox("Show Items");
    m_espVehiclesCheckBox = new QCheckBox("Show Vehicles");
    
    espLayout->addWidget(m_espPlayersCheckBox);
    espLayout->addWidget(m_espItemsCheckBox);
    espLayout->addWidget(m_espVehiclesCheckBox);
    
    QHBoxLayout *espDistanceLayout = new QHBoxLayout();
    espDistanceLayout->addWidget(new QLabel("Max Distance:"));
    m_espDistanceSlider = new QSlider(Qt::Horizontal);
    m_espDistanceSlider->setRange(50, 1000);
    m_espDistanceSlider->setValue(500);
    m_espDistanceLabel = new QLabel("500m");
    espDistanceLayout->addWidget(m_espDistanceSlider);
    espDistanceLayout->addWidget(m_espDistanceLabel);
    espLayout->addLayout(espDistanceLayout);
    
    moduleLayout->addWidget(espGroup);
    
    // Wallhack settings
    QGroupBox *wallhackGroup = new QGroupBox("Wallhack");
    QVBoxLayout *wallhackLayout = new QVBoxLayout(wallhackGroup);
    
    m_wallhackEnabledCheckBox = new QCheckBox("Enable Wallhack");
    wallhackLayout->addWidget(m_wallhackEnabledCheckBox);
    
    QHBoxLayout *wallhackOpacityLayout = new QHBoxLayout();
    wallhackOpacityLayout->addWidget(new QLabel("Opacity:"));
    m_wallhackOpacitySlider = new QSlider(Qt::Horizontal);
    m_wallhackOpacitySlider->setRange(10, 100);
    m_wallhackOpacitySlider->setValue(70);
    m_wallhackOpacityLabel = new QLabel("70%");
    wallhackOpacityLayout->addWidget(m_wallhackOpacitySlider);
    wallhackOpacityLayout->addWidget(m_wallhackOpacityLabel);
    wallhackLayout->addLayout(wallhackOpacityLayout);
    
    moduleLayout->addWidget(wallhackGroup);
    
    layout->addWidget(moduleGroup);
    
    // Add stretch to push everything to top
    layout->addStretch();
    
    return panel;
}

QTabWidget* MainWindow::createTabWidget()
{
    QTabWidget *tabWidget = new QTabWidget();
    
    // Log tab
    m_logTextEdit = new QTextEdit();
    m_logTextEdit->setReadOnly(true);
    m_logTextEdit->setFont(QFont("Consolas", 9));
    m_logTextEdit->setStyleSheet("QTextEdit { background-color: #1e1e1e; color: #ffffff; border: 1px solid #555; }");
    tabWidget->addTab(m_logTextEdit, "Logs");
    
    // Status tab
    QWidget *statusTab = createStatusTab();
    tabWidget->addTab(statusTab, "System Status");
    
    // Settings tab
    QWidget *settingsTab = createSettingsTab();
    tabWidget->addTab(settingsTab, "Settings");
    
    // About tab
    QWidget *aboutTab = createAboutTab();
    tabWidget->addTab(aboutTab, "About");
    
    return tabWidget;
}

QWidget* MainWindow::createStatusTab()
{
    QWidget *tab = new QWidget();
    QVBoxLayout *layout = new QVBoxLayout(tab);
    
    // System Information Group
    QGroupBox *systemGroup = new QGroupBox("System Information");
    QGridLayout *systemLayout = new QGridLayout(systemGroup);
    
    m_cpuUsageLabel = new QLabel("CPU Usage: 0%");
    m_memoryUsageLabel = new QLabel("Memory Usage: 0%");
    m_diskUsageLabel = new QLabel("Disk Usage: 0%");
    m_networkUsageLabel = new QLabel("Network Usage: 0%");
    
    m_cpuUsageBar = new QProgressBar();
    m_memoryUsageBar = new QProgressBar();
    m_diskUsageBar = new QProgressBar();
    m_networkUsageBar = new QProgressBar();
    
    systemLayout->addWidget(m_cpuUsageLabel, 0, 0);
    systemLayout->addWidget(m_cpuUsageBar, 0, 1);
    systemLayout->addWidget(m_memoryUsageLabel, 1, 0);
    systemLayout->addWidget(m_memoryUsageBar, 1, 1);
    systemLayout->addWidget(m_diskUsageLabel, 2, 0);
    systemLayout->addWidget(m_diskUsageBar, 2, 1);
    systemLayout->addWidget(m_networkUsageLabel, 3, 0);
    systemLayout->addWidget(m_networkUsageBar, 3, 1);
    
    layout->addWidget(systemGroup);
    
    // Game Information Group
    QGroupBox *gameInfoGroup = new QGroupBox("Game Information");
    QVBoxLayout *gameInfoLayout = new QVBoxLayout(gameInfoGroup);
    
    m_gameInfoLabel = new QLabel("No game detected");
    gameInfoLayout->addWidget(m_gameInfoLabel);
    
    layout->addWidget(gameInfoGroup);
    
    layout->addStretch();
    
    return tab;
}

QWidget* MainWindow::createSettingsTab()
{
    QWidget *tab = new QWidget();
    QVBoxLayout *layout = new QVBoxLayout(tab);
    
    // General Settings Group
    QGroupBox *generalGroup = new QGroupBox("General Settings");
    QVBoxLayout *generalLayout = new QVBoxLayout(generalGroup);
    
    m_minimizeToTrayCheckBox = new QCheckBox("Minimize to system tray");
    m_minimizeToTrayCheckBox->setChecked(m_minimizeToTray);
    generalLayout->addWidget(m_minimizeToTrayCheckBox);
    
    m_startMinimizedCheckBox = new QCheckBox("Start minimized");
    m_startMinimizedCheckBox->setChecked(m_startMinimized);
    generalLayout->addWidget(m_startMinimizedCheckBox);
    
    layout->addWidget(generalGroup);
    
    // Security Settings Group
    QGroupBox *securityGroup = new QGroupBox("Security Settings");
    QVBoxLayout *securityLayout = new QVBoxLayout(securityGroup);
    
    m_antiDetectionCheckBox = new QCheckBox("Enable anti-detection");
    m_antiDetectionCheckBox->setChecked(true);
    securityLayout->addWidget(m_antiDetectionCheckBox);
    
    m_stealthModeCheckBox = new QCheckBox("Enable stealth mode");
    m_stealthModeCheckBox->setChecked(true);
    securityLayout->addWidget(m_stealthModeCheckBox);
    
    layout->addWidget(securityGroup);
    
    layout->addStretch();
    
    return tab;
}

QWidget* MainWindow::createAboutTab()
{
    QWidget *tab = new QWidget();
    QVBoxLayout *layout = new QVBoxLayout(tab);
    
    QLabel *titleLabel = new QLabel("GhostPulse BGMI Mod Loader");
    titleLabel->setStyleSheet("font-size: 24px; font-weight: bold; color: #4CAF50;");
    titleLabel->setAlignment(Qt::AlignCenter);
    layout->addWidget(titleLabel);
    
    QLabel *versionLabel = new QLabel("Version 3.9.0");
    versionLabel->setStyleSheet("font-size: 16px; color: #888;");
    versionLabel->setAlignment(Qt::AlignCenter);
    layout->addWidget(versionLabel);
    
    QLabel *descLabel = new QLabel(
        "A powerful and secure mod loader for BGMI/PUBG Mobile.\n\n"
        "Features:\n"
        "• Advanced Aimbot with customizable settings\n"
        "• ESP (Extra Sensory Perception) for players, items, and vehicles\n"
        "• Wallhack with adjustable opacity\n"
        "• Radar system for enhanced awareness\n"
        "• Anti-detection and stealth capabilities\n"
        "• Real-time system monitoring\n\n"
        "⚠️ Educational purposes only. Use responsibly."
    );
    descLabel->setWordWrap(true);
    descLabel->setStyleSheet("font-size: 12px; line-height: 1.4;");
    layout->addWidget(descLabel);
    
    layout->addStretch();
    
    return tab;
}

void MainWindow::setupMenuBar()
{
    // File menu
    QMenu *fileMenu = menuBar()->addMenu("&File");
    
    QAction *loadConfigAction = new QAction("&Load Configuration...", this);
    loadConfigAction->setShortcut(QKeySequence::Open);
    connect(loadConfigAction, &QAction::triggered, this, &MainWindow::loadConfiguration);
    fileMenu->addAction(loadConfigAction);
    
    QAction *saveConfigAction = new QAction("&Save Configuration...", this);
    saveConfigAction->setShortcut(QKeySequence::Save);
    connect(saveConfigAction, &QAction::triggered, this, &MainWindow::saveConfiguration);
    fileMenu->addAction(saveConfigAction);
    
    fileMenu->addSeparator();
    
    QAction *exitAction = new QAction("E&xit", this);
    exitAction->setShortcut(QKeySequence::Quit);
    connect(exitAction, &QAction::triggered, this, &QWidget::close);
    fileMenu->addAction(exitAction);
    
    // Tools menu
    QMenu *toolsMenu = menuBar()->addMenu("&Tools");
    
    QAction *clearLogsAction = new QAction("&Clear Logs", this);
    connect(clearLogsAction, &QAction::triggered, this, &MainWindow::clearLogs);
    toolsMenu->addAction(clearLogsAction);
    
    QAction *exportLogsAction = new QAction("&Export Logs...", this);
    connect(exportLogsAction, &QAction::triggered, this, &MainWindow::exportLogs);
    toolsMenu->addAction(exportLogsAction);
    
    // Help menu
    QMenu *helpMenu = menuBar()->addMenu("&Help");
    
    QAction *aboutAction = new QAction("&About", this);
    connect(aboutAction, &QAction::triggered, this, &MainWindow::showAbout);
    helpMenu->addAction(aboutAction);
}

void MainWindow::setupToolBar()
{
    QToolBar *toolBar = addToolBar("Main");
    toolBar->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
    
    QAction *injectAction = new QAction(QIcon(":/icons/inject.png"), "Inject", this);
    connect(injectAction, &QAction::triggered, this, &MainWindow::onInjectClicked);
    toolBar->addAction(injectAction);
    
    QAction *uninjectAction = new QAction(QIcon(":/icons/uninject.png"), "Uninject", this);
    connect(uninjectAction, &QAction::triggered, this, &MainWindow::onUninjectClicked);
    toolBar->addAction(uninjectAction);
    
    toolBar->addSeparator();
    
    QAction *refreshAction = new QAction(QIcon(":/icons/refresh.png"), "Refresh", this);
    connect(refreshAction, &QAction::triggered, this, &MainWindow::refreshStatus);
    toolBar->addAction(refreshAction);
}

void MainWindow::setupStatusBar()
{
    m_statusLabel = new QLabel("Ready");
    statusBar()->addWidget(m_statusLabel);
    
    statusBar()->addPermanentWidget(new QLabel("GhostPulse v3.9"));
}

void MainWindow::setupSystemTray()
{
    if (!QSystemTrayIcon::isSystemTrayAvailable()) {
        return;
    }
    
    m_systemTrayIcon = new QSystemTrayIcon(this);
    m_systemTrayIcon->setIcon(QIcon(":/icons/app.ico"));
    m_systemTrayIcon->setToolTip("GhostPulse BGMI Mod Loader");
    
    m_trayMenu = new QMenu(this);
    
    QAction *showAction = new QAction("Show", this);
    connect(showAction, &QAction::triggered, this, &QWidget::showNormal);
    m_trayMenu->addAction(showAction);
    
    QAction *hideAction = new QAction("Hide", this);
    connect(hideAction, &QAction::triggered, this, &QWidget::hide);
    m_trayMenu->addAction(hideAction);
    
    m_trayMenu->addSeparator();
    
    QAction *quitAction = new QAction("Quit", this);
    connect(quitAction, &QAction::triggered, qApp, &QApplication::quit);
    m_trayMenu->addAction(quitAction);
    
    m_systemTrayIcon->setContextMenu(m_trayMenu);
    
    connect(m_systemTrayIcon, &QSystemTrayIcon::activated,
            this, &MainWindow::onSystemTrayActivated);
    
    m_systemTrayIcon->show();
}

void MainWindow::connectSignals()
{
    // Injection Manager signals
    if (m_injectionManager) {
        connect(m_injectionManager, &InjectionManager::injectionStarted,
                this, &MainWindow::onInjectionStarted);
        connect(m_injectionManager, &InjectionManager::injectionCompleted,
                this, &MainWindow::onInjectionCompleted);
        connect(m_injectionManager, &InjectionManager::injectionFailed,
                this, &MainWindow::onInjectionFailed);
        connect(m_injectionManager, &InjectionManager::uninjectionCompleted,
                this, &MainWindow::onUninjectionCompleted);
        connect(m_injectionManager, &InjectionManager::processDetected,
                this, &MainWindow::onProcessDetected);
        connect(m_injectionManager, &InjectionManager::processLost,
                this, &MainWindow::onProcessLost);
    }
    
    // Game Interface signals
    if (m_gameInterface) {
        connect(m_gameInterface, &GameInterface::gameConnected,
                this, &MainWindow::onGameConnected);
        connect(m_gameInterface, &GameInterface::gameDisconnected,
                this, &MainWindow::onGameDisconnected);
        connect(m_gameInterface, &GameInterface::gameDataUpdated,
                this, &MainWindow::onGameDataUpdated);
    }
    
    // Status Monitor signals
    if (m_statusMonitor) {
        connect(m_statusMonitor, &StatusMonitor::cpuUsageChanged,
                this, &MainWindow::onCpuUsageChanged);
        connect(m_statusMonitor, &StatusMonitor::memoryUsageChanged,
                this, &MainWindow::onMemoryUsageChanged);
        connect(m_statusMonitor, &StatusMonitor::diskUsageChanged,
                this, &MainWindow::onDiskUsageChanged);
        connect(m_statusMonitor, &StatusMonitor::networkUsageChanged,
                this, &MainWindow::onNetworkUsageChanged);
    }
    
    // Logger signals
    if (m_logger) {
        connect(m_logger, &Logger::messageLogged,
                this, &MainWindow::onLogMessage);
    }
    
    // UI control signals
    connect(m_injectButton, &QPushButton::clicked,
            this, &MainWindow::onInjectClicked);
    connect(m_uninjectButton, &QPushButton::clicked,
            this, &MainWindow::onUninjectClicked);
    
    connect(m_autoInjectCheckBox, &QCheckBox::toggled,
            this, &MainWindow::onAutoInjectToggled);
    
    // Module setting signals
    connect(m_aimbotSensitivitySlider, &QSlider::valueChanged,
            this, &MainWindow::onAimbotSensitivityChanged);
    connect(m_aimbotFovSlider, &QSlider::valueChanged,
            this, &MainWindow::onAimbotFovChanged);
    connect(m_espDistanceSlider, &QSlider::valueChanged,
            this, &MainWindow::onEspDistanceChanged);
    connect(m_wallhackOpacitySlider, &QSlider::valueChanged,
            this, &MainWindow::onWallhackOpacityChanged);
    
    // Settings signals
    connect(m_minimizeToTrayCheckBox, &QCheckBox::toggled,
            this, &MainWindow::onMinimizeToTrayToggled);
    connect(m_startMinimizedCheckBox, &QCheckBox::toggled,
            this, &MainWindow::onStartMinimizedToggled);
}

void MainWindow::applyTheme()
{
    QString darkTheme = R"(
        QMainWindow {
            background-color: #2b2b2b;
            color: #ffffff;
        }
        QGroupBox {
            font-weight: bold;
            border: 2px solid #555;
            border-radius: 5px;
            margin-top: 1ex;
            padding-top: 10px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 5px 0 5px;
        }
        QLabel {
            color: #ffffff;
        }
        QPushButton {
            background-color: #404040;
            border: 1px solid #555;
            padding: 5px;
            border-radius: 3px;
            color: #ffffff;
        }
        QPushButton:hover {
            background-color: #505050;
        }
        QPushButton:pressed {
            background-color: #353535;
        }
        QCheckBox {
            color: #ffffff;
        }
        QCheckBox::indicator {
            width: 13px;
            height: 13px;
        }
        QCheckBox::indicator:unchecked {
            border: 1px solid #555;
            background-color: #2b2b2b;
        }
        QCheckBox::indicator:checked {
            border: 1px solid #4CAF50;
            background-color: #4CAF50;
        }
        QSlider::groove:horizontal {
            border: 1px solid #555;
            height: 8px;
            background: #404040;
            margin: 2px 0;
            border-radius: 4px;
        }
        QSlider::handle:horizontal {
            background: #4CAF50;
            border: 1px solid #4CAF50;
            width: 18px;
            margin: -2px 0;
            border-radius: 9px;
        }
        QComboBox {
            border: 1px solid #555;
            border-radius: 3px;
            padding: 1px 18px 1px 3px;
            background-color: #404040;
            color: #ffffff;
        }
        QComboBox::drop-down {
            subcontrol-origin: padding;
            subcontrol-position: top right;
            width: 15px;
            border-left-width: 1px;
            border-left-color: #555;
            border-left-style: solid;
        }
        QProgressBar {
            border: 1px solid #555;
            border-radius: 3px;
            text-align: center;
            background-color: #404040;
        }
        QProgressBar::chunk {
            background-color: #4CAF50;
            border-radius: 2px;
        }
        QTabWidget::pane {
            border: 1px solid #555;
            background-color: #2b2b2b;
        }
        QTabBar::tab {
            background-color: #404040;
            border: 1px solid #555;
            padding: 8px 16px;
            margin-right: 2px;
        }
        QTabBar::tab:selected {
            background-color: #4CAF50;
            color: #ffffff;
        }
        QMenuBar {
            background-color: #2b2b2b;
            color: #ffffff;
        }
        QMenuBar::item {
            background-color: transparent;
            padding: 4px 8px;
        }
        QMenuBar::item:selected {
            background-color: #4CAF50;
        }
        QMenu {
            background-color: #2b2b2b;
            color: #ffffff;
            border: 1px solid #555;
        }
        QMenu::item:selected {
            background-color: #4CAF50;
        }
        QToolBar {
            background-color: #2b2b2b;
            border: none;
        }
        QStatusBar {
            background-color: #2b2b2b;
            color: #ffffff;
        }
    )";
    
    setStyleSheet(darkTheme);
}

void MainWindow::updateUI()
{
    // Update injection status
    if (m_injectionManager) {
        bool isInjected = m_injectionManager->isInjected();
        if (isInjected != m_isInjected) {
            m_isInjected = isInjected;
            updateInjectionStatus();
        }
    }
    
    // Update game status
    if (m_gameInterface) {
        bool isConnected = m_gameInterface->isConnected();
        updateGameStatus(isConnected);
    }
}

void MainWindow::updateInjectionStatus()
{
    if (m_isInjected) {
        m_injectionStatusLabel->setText("Injection: Injected");
        m_injectionStatusLabel->setStyleSheet("color: #4CAF50; font-weight: bold;");
        m_injectButton->setEnabled(false);
        m_uninjectButton->setEnabled(true);
        m_statusLabel->setText("Injected successfully");
    } else {
        m_injectionStatusLabel->setText("Injection: Not Injected");
        m_injectionStatusLabel->setStyleSheet("color: #ff6b6b; font-weight: bold;");
        m_injectButton->setEnabled(true);
        m_uninjectButton->setEnabled(false);
        m_statusLabel->setText("Ready");
    }
}

void MainWindow::updateGameStatus(bool connected)
{
    if (connected) {
        m_gameStatusLabel->setText("Game: Detected");
        m_gameStatusLabel->setStyleSheet("color: #4CAF50; font-weight: bold;");
        m_processStatusLabel->setText("Process: Found");
        
        // Auto-inject if enabled
        if (m_autoInject && !m_isInjected) {
            onInjectClicked();
        }
    } else {
        m_gameStatusLabel->setText("Game: Not Detected");
        m_gameStatusLabel->setStyleSheet("color: #ff6b6b; font-weight: bold;");
        m_processStatusLabel->setText("Process: Not Found");
    }
}

void MainWindow::loadSettings()
{
    QSettings settings;
    
    // Load window geometry
    restoreGeometry(settings.value("geometry").toByteArray());
    restoreState(settings.value("windowState").toByteArray());
    
    // Load general settings
    m_minimizeToTray = settings.value("minimizeToTray", true).toBool();
    m_startMinimized = settings.value("startMinimized", false).toBool();
    m_autoInject = settings.value("autoInject", false).toBool();
    
    // Load module settings
    m_aimbotEnabledCheckBox->setChecked(settings.value("aimbot/enabled", false).toBool());
    m_aimbotSensitivitySlider->setValue(settings.value("aimbot/sensitivity", 50).toInt());
    m_aimbotFovSlider->setValue(settings.value("aimbot/fov", 90).toInt());
    
    m_espEnabledCheckBox->setChecked(settings.value("esp/enabled", false).toBool());
    m_espPlayersCheckBox->setChecked(settings.value("esp/players", true).toBool());
    m_espItemsCheckBox->setChecked(settings.value("esp/items", true).toBool());
    m_espVehiclesCheckBox->setChecked(settings.value("esp/vehicles", true).toBool());
    m_espDistanceSlider->setValue(settings.value("esp/distance", 500).toInt());
    
    m_wallhackEnabledCheckBox->setChecked(settings.value("wallhack/enabled", false).toBool());
    m_wallhackOpacitySlider->setValue(settings.value("wallhack/opacity", 70).toInt());
    
    // Update UI
    m_autoInjectCheckBox->setChecked(m_autoInject);
    m_minimizeToTrayCheckBox->setChecked(m_minimizeToTray);
    m_startMinimizedCheckBox->setChecked(m_startMinimized);
    
    // Update slider labels
    onAimbotSensitivityChanged(m_aimbotSensitivitySlider->value());
    onAimbotFovChanged(m_aimbotFovSlider->value());
    onEspDistanceChanged(m_espDistanceSlider->value());
    onWallhackOpacityChanged(m_wallhackOpacitySlider->value());
}

void MainWindow::saveSettings()
{
    QSettings settings;
    
    // Save window geometry
    settings.setValue("geometry", saveGeometry());
    settings.setValue("windowState", saveState());
    
    // Save general settings
    settings.setValue("minimizeToTray", m_minimizeToTray);
    settings.setValue("startMinimized", m_startMinimized);
    settings.setValue("autoInject", m_autoInject);
    
    // Save module settings
    settings.setValue("aimbot/enabled", m_aimbotEnabledCheckBox->isChecked());
    settings.setValue("aimbot/sensitivity", m_aimbotSensitivitySlider->value());
    settings.setValue("aimbot/fov", m_aimbotFovSlider->value());
    
    settings.setValue("esp/enabled", m_espEnabledCheckBox->isChecked());
    settings.setValue("esp/players", m_espPlayersCheckBox->isChecked());
    settings.setValue("esp/items", m_espItemsCheckBox->isChecked());
    settings.setValue("esp/vehicles", m_espVehiclesCheckBox->isChecked());
    settings.setValue("esp/distance", m_espDistanceSlider->value());
    
    settings.setValue("wallhack/enabled", m_wallhackEnabledCheckBox->isChecked());
    settings.setValue("wallhack/opacity", m_wallhackOpacitySlider->value());
}

// Slot implementations
void MainWindow::onInjectClicked()
{
    if (!m_injectionManager || m_isInjected) {
        return;
    }
    
    m_progressBar->setVisible(true);
    m_progressBar->setRange(0, 0); // Indeterminate progress
    m_statusLabel->setText("Injecting...");
    
    // Start injection in a separate thread
    QThread *injectionThread = QThread::create([this]() {
        m_injectionManager->inject();
    });
    
    connect(injectionThread, &QThread::finished, injectionThread, &QThread::deleteLater);
    injectionThread->start();
}

void MainWindow::onUninjectClicked()
{
    if (!m_injectionManager || !m_isInjected) {
        return;
    }
    
    m_statusLabel->setText("Uninjecting...");
    m_injectionManager->uninject();
}

void MainWindow::onAutoInjectToggled(bool enabled)
{
    m_autoInject = enabled;
}

void MainWindow::onInjectionStarted()
{
    m_statusLabel->setText("Injection started...");
}

void MainWindow::onInjectionCompleted()
{
    m_progressBar->setVisible(false);
    m_statusLabel->setText("Injection completed successfully");
    
    if (m_systemTrayIcon) {
        m_systemTrayIcon->showMessage("GhostPulse", "Injection completed successfully",
                                     QSystemTrayIcon::Information, 3000);
    }
}

void MainWindow::onInjectionFailed(const QString& error)
{
    m_progressBar->setVisible(false);
    m_statusLabel->setText("Injection failed");
    
    QMessageBox::critical(this, "Injection Failed", 
                         QString("Failed to inject: %1").arg(error));
    
    if (m_systemTrayIcon) {
        m_systemTrayIcon->showMessage("GhostPulse", "Injection failed",
                                     QSystemTrayIcon::Critical, 3000);
    }
}

void MainWindow::onUninjectionCompleted()
{
    m_statusLabel->setText("Uninjection completed");
    
    if (m_systemTrayIcon) {
        m_systemTrayIcon->showMessage("GhostPulse", "Uninjection completed",
                                     QSystemTrayIcon::Information, 3000);
    }
}

void MainWindow::onProcessDetected(const QString& processName)
{
    m_statusLabel->setText(QString("Process detected: %1").arg(processName));
}

void MainWindow::onProcessLost()
{
    m_statusLabel->setText("Process lost");
}

void MainWindow::onGameConnected()
{
    m_gameInfoLabel->setText("Game connected and ready");
}

void MainWindow::onGameDisconnected()
{
    m_gameInfoLabel->setText("Game disconnected");
}

void MainWindow::onGameDataUpdated()
{
    // Update game information display
    if (m_gameInterface) {
        // Get game data and update UI
        // This would be implemented based on the actual game data structure
    }
}

void MainWindow::onCpuUsageChanged(double usage)
{
    m_cpuUsageLabel->setText(QString("CPU Usage: %1%").arg(usage, 0, 'f', 1));
    m_cpuUsageBar->setValue(static_cast<int>(usage));
}

void MainWindow::onMemoryUsageChanged(double usage)
{
    m_memoryUsageLabel->setText(QString("Memory Usage: %1%").arg(usage, 0, 'f', 1));
    m_memoryUsageBar->setValue(static_cast<int>(usage));
}

void MainWindow::onDiskUsageChanged(double usage)
{
    m_diskUsageLabel->setText(QString("Disk Usage: %1%").arg(usage, 0, 'f', 1));
    m_diskUsageBar->setValue(static_cast<int>(usage));
}

void MainWindow::onNetworkUsageChanged(double usage)
{
    m_networkUsageLabel->setText(QString("Network Usage: %1%").arg(usage, 0, 'f', 1));
    m_networkUsageBar->setValue(static_cast<int>(usage));
}

void MainWindow::onLogMessage(const QString& message, const QString& level, const QString& category)
{
    QString timestamp = QDateTime::currentDateTime().toString("hh:mm:ss");
    QString coloredMessage;
    
    if (level == "ERROR") {
        coloredMessage = QString("<span style='color: #ff6b6b;'>[%1] [%2] %3: %4</span>")
                        .arg(timestamp, level, category, message);
    } else if (level == "WARNING") {
        coloredMessage = QString("<span style='color: #ffa726;'>[%1] [%2] %3: %4</span>")
                        .arg(timestamp, level, category, message);
    } else if (level == "INFO") {
        coloredMessage = QString("<span style='color: #4CAF50;'>[%1] [%2] %3: %4</span>")
                        .arg(timestamp, level, category, message);
    } else {
        coloredMessage = QString("<span style='color: #ffffff;'>[%1] [%2] %3: %4</span>")
                        .arg(timestamp, level, category, message);
    }
    
    m_logTextEdit->append(coloredMessage);
    
    // Auto-scroll to bottom
    QTextCursor cursor = m_logTextEdit->textCursor();
    cursor.movePosition(QTextCursor::End);
    m_logTextEdit->setTextCursor(cursor);
}

void MainWindow::onAimbotSensitivityChanged(int value)
{
    m_aimbotSensitivityLabel->setText(QString::number(value));
    // Apply setting to aimbot module if injected
}

void MainWindow::onAimbotFovChanged(int value)
{
    m_aimbotFovLabel->setText(QString::number(value));
    // Apply setting to aimbot module if injected
}

void MainWindow::onEspDistanceChanged(int value)
{
    m_espDistanceLabel->setText(QString("%1m").arg(value));
    // Apply setting to ESP module if injected
}

void MainWindow::onWallhackOpacityChanged(int value)
{
    m_wallhackOpacityLabel->setText(QString("%1%").arg(value));
    // Apply setting to wallhack module if injected
}

void MainWindow::onMinimizeToTrayToggled(bool enabled)
{
    m_minimizeToTray = enabled;
}

void MainWindow::onStartMinimizedToggled(bool enabled)
{
    m_startMinimized = enabled;
}

void MainWindow::onSystemTrayActivated(QSystemTrayIcon::ActivationReason reason)
{
    if (reason == QSystemTrayIcon::DoubleClick) {
        if (isVisible()) {
            hide();
        } else {
            showNormal();
            activateWindow();
            raise();
        }
    }
}

void MainWindow::loadConfiguration()
{
    QString fileName = QFileDialog::getOpenFileName(this,
        "Load Configuration", "", "JSON Files (*.json)");
    
    if (!fileName.isEmpty()) {
        // Load configuration from file
        // Implementation would depend on configuration format
        m_statusLabel->setText("Configuration loaded");
    }
}

void MainWindow::saveConfiguration()
{
    QString fileName = QFileDialog::getSaveFileName(this,
        "Save Configuration", "", "JSON Files (*.json)");
    
    if (!fileName.isEmpty()) {
        // Save configuration to file
        // Implementation would depend on configuration format
        m_statusLabel->setText("Configuration saved");
    }
}

void MainWindow::clearLogs()
{
    m_logTextEdit->clear();
    m_statusLabel->setText("Logs cleared");
}

void MainWindow::exportLogs()
{
    QString fileName = QFileDialog::getSaveFileName(this,
        "Export Logs", "", "Text Files (*.txt)");
    
    if (!fileName.isEmpty()) {
        QFile file(fileName);
        if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            QTextStream out(&file);
            out << m_logTextEdit->toPlainText();
            file.close();
            m_statusLabel->setText("Logs exported");
        }
    }
}

void MainWindow::refreshStatus()
{
    if (m_statusMonitor) {
        // Force update of status information
        m_statusLabel->setText("Status refreshed");
    }
}

void MainWindow::showAbout()
{
    QMessageBox::about(this, "About GhostPulse",
        "GhostPulse BGMI Mod Loader v3.9\n\n"
        "A powerful and secure mod loader for BGMI/PUBG Mobile.\n\n"
        "Features advanced aimbot, ESP, wallhack, and anti-detection capabilities.\n\n"
        "⚠️ For educational purposes only. Use responsibly.");
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    if (m_minimizeToTray && m_systemTrayIcon && m_systemTrayIcon->isVisible()) {
        hide();
        event->ignore();
        
        if (!m_systemTrayIcon->supportsMessages()) {
            QMessageBox::information(this, "GhostPulse",
                "The program will keep running in the system tray. "
                "To terminate the program, choose Quit in the context menu "
                "of the system tray entry.");
        }
    } else {
        saveSettings();
        event->accept();
    }
}