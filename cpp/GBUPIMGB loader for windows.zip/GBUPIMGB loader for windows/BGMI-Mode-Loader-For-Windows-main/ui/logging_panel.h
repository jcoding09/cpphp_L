#ifndef LOGGING_PANEL_H
#define LOGGING_PANEL_H

#include <QtWidgets/QWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTableWidgetItem>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QFrame>
#include <QtWidgets/QToolButton>
#include <QtCore/QTimer>
#include <QtCore/QDateTime>
#include <QtCore/QSettings>
#include <QtCore/QMutex>
#include <QtCore/QQueue>
#include <QtGui/QTextCursor>
#include <QtGui/QTextCharFormat>
#include <QtGui/QFont>
#include <QtGui/QColor>
#include <QtGui/QIcon>
#include <memory>

// Forward declarations
class Logger;

enum class LogLevel {
    Debug = 0,
    Info = 1,
    Warning = 2,
    Error = 3,
    Critical = 4,
    Success = 5
};

enum class LogCategory {
    General = 0,
    Injection = 1,
    Memory = 2,
    Game = 3,
    Network = 4,
    Security = 5,
    UI = 6,
    Cheat = 7,
    Performance = 8
};

struct LogEntry {
    QDateTime timestamp;
    LogLevel level;
    LogCategory category;
    QString message;
    QString details;
    QString source;
    QString thread;
    qint64 processId;
    qint64 threadId;
    
    LogEntry() = default;
    LogEntry(LogLevel lvl, LogCategory cat, const QString &msg, const QString &det = QString())
        : timestamp(QDateTime::currentDateTime())
        , level(lvl)
        , category(cat)
        , message(msg)
        , details(det)
        , processId(0)
        , threadId(0) {}
};

struct LogFilter {
    bool enabledLevels[6] = {true, true, true, true, true, true}; // Debug, Info, Warning, Error, Critical, Success
    bool enabledCategories[9] = {true, true, true, true, true, true, true, true, true}; // All categories
    QString searchText;
    QDateTime startTime;
    QDateTime endTime;
    QString sourceFilter;
    bool useTimeFilter = false;
    bool useSourceFilter = false;
    bool caseSensitive = false;
    bool useRegex = false;
};

struct LogStatistics {
    int totalEntries = 0;
    int debugCount = 0;
    int infoCount = 0;
    int warningCount = 0;
    int errorCount = 0;
    int criticalCount = 0;
    int successCount = 0;
    
    int categoryCount[9] = {0}; // Per category counts
    
    QDateTime firstEntry;
    QDateTime lastEntry;
    
    void reset() {
        totalEntries = debugCount = infoCount = warningCount = 0;
        errorCount = criticalCount = successCount = 0;
        for (int i = 0; i < 9; ++i) categoryCount[i] = 0;
        firstEntry = lastEntry = QDateTime();
    }
};

class LoggingPanel : public QWidget
{
    Q_OBJECT

public:
    explicit LoggingPanel(QWidget *parent = nullptr);
    ~LoggingPanel();
    
    // Logger integration
    void setLogger(Logger *logger);
    
    // Log management
    void addLogEntry(const LogEntry &entry);
    void addLogEntry(LogLevel level, LogCategory category, const QString &message, const QString &details = QString());
    void clearLogs();
    void clearCategory(LogCategory category);
    void clearLevel(LogLevel level);
    
    // Filter management
    void setFilter(const LogFilter &filter);
    LogFilter getFilter() const { return m_filter; }
    void resetFilter();
    void applyFilter();
    
    // Export/Import
    bool exportLogs(const QString &filePath, const QString &format = "txt");
    bool exportFilteredLogs(const QString &filePath, const QString &format = "txt");
    bool importLogs(const QString &filePath);
    
    // Statistics
    LogStatistics getStatistics() const { return m_statistics; }
    LogStatistics getFilteredStatistics() const;
    
    // Settings
    void loadSettings();
    void saveSettings();
    
    // UI updates
    void updateUI();
    void updateStatistics();
    void updateFilter();
    
public slots:
    // Log entry slots
    void onLogEntryAdded(const QString &message, int level, int category);
    void onDebugMessage(const QString &message, const QString &category = "General");
    void onInfoMessage(const QString &message, const QString &category = "General");
    void onWarningMessage(const QString &message, const QString &category = "General");
    void onErrorMessage(const QString &message, const QString &category = "General");
    void onCriticalMessage(const QString &message, const QString &category = "General");
    void onSuccessMessage(const QString &message, const QString &category = "General");
    
    // Filter slots
    void onFilterChanged();
    void onLevelFilterChanged();
    void onCategoryFilterChanged();
    void onSearchTextChanged();
    void onTimeFilterChanged();
    void onSourceFilterChanged();
    
    // Action slots
    void onClearLogs();
    void onClearFiltered();
    void onExportLogs();
    void onExportFiltered();
    void onImportLogs();
    void onSaveLogs();
    void onLoadLogs();
    
    // View slots
    void onLogItemSelected();
    void onLogItemDoubleClicked();
    void onShowDetails(bool show);
    void onAutoScroll(bool enabled);
    void onWordWrap(bool enabled);
    void onShowTimestamp(bool show);
    void onShowCategory(bool show);
    void onShowLevel(bool show);
    void onShowSource(bool show);
    
    // Search slots
    void onSearchNext();
    void onSearchPrevious();
    void onSearchClear();
    void onSearchModeChanged();
    
    // Statistics slots
    void onShowStatistics();
    void onRefreshStatistics();
    
signals:
    void logEntrySelected(const LogEntry &entry);
    void filterChanged(const LogFilter &filter);
    void statisticsUpdated(const LogStatistics &statistics);
    void exportRequested(const QString &filePath, const QString &format);
    void importRequested(const QString &filePath);
    
private slots:
    void updateDisplay();
    void processLogQueue();
    void autoSaveLogs();
    void checkLogSize();
    void highlightSearchResults();
    
private:
    // UI setup
    void setupUI();
    void setupLogDisplay();
    void setupFilterControls();
    void setupActionButtons();
    void setupStatisticsPanel();
    void setupSearchPanel();
    void setupDetailsPanel();
    
    void setupLogTable();
    void setupLogText();
    void setupFilterPanel();
    void setupToolbar();
    
    // UI helpers
    void createLevelFilterControls();
    void createCategoryFilterControls();
    void createTimeFilterControls();
    void createSearchControls();
    void createActionControls();
    void createViewControls();
    
    void connectSignals();
    void setupContextMenu();
    void setupToolTips();
    
    // Log processing
    void addLogEntryInternal(const LogEntry &entry);
    void updateLogDisplay();
    void updateFilteredDisplay();
    void refreshLogTable();
    void refreshLogText();
    
    bool passesFilter(const LogEntry &entry) const;
    QList<LogEntry> getFilteredEntries() const;
    
    void formatLogEntry(const LogEntry &entry, QString &formattedText, QTextCharFormat &format);
    void formatLogTableItem(const LogEntry &entry, int row);
    
    // Statistics
    void updateStatisticsInternal();
    void calculateStatistics();
    void displayStatistics();
    
    // Search functionality
    void performSearch(const QString &searchText, bool forward = true);
    void highlightSearchText(const QString &text);
    void clearSearchHighlight();
    
    // Export/Import helpers
    QString formatLogForExport(const LogEntry &entry, const QString &format) const;
    bool exportToText(const QString &filePath, const QList<LogEntry> &entries);
    bool exportToCSV(const QString &filePath, const QList<LogEntry> &entries);
    bool exportToJSON(const QString &filePath, const QList<LogEntry> &entries);
    bool exportToXML(const QString &filePath, const QList<LogEntry> &entries);
    
    // Utility functions
    QString levelToString(LogLevel level) const;
    QString categoryToString(LogCategory category) const;
    QColor levelToColor(LogLevel level) const;
    QIcon levelToIcon(LogLevel level) const;
    
    LogLevel stringToLevel(const QString &levelStr) const;
    LogCategory stringToCategory(const QString &categoryStr) const;
    
    QString formatTimestamp(const QDateTime &timestamp) const;
    QString formatDuration(qint64 milliseconds) const;
    QString formatFileSize(qint64 bytes) const;
    
    void limitLogEntries();
    void rotateLogFile();
    
    // Core components
    Logger *m_logger;
    
    // Log data
    QList<LogEntry> m_logEntries;
    QQueue<LogEntry> m_logQueue;
    LogFilter m_filter;
    LogStatistics m_statistics;
    
    // UI Components
    QVBoxLayout *m_mainLayout;
    QSplitter *m_mainSplitter;
    QSplitter *m_rightSplitter;
    
    // Log display
    QTabWidget *m_displayTabWidget;
    QTableWidget *m_logTable;
    QPlainTextEdit *m_logTextEdit;
    QTextEdit *m_detailsTextEdit;
    
    // Filter panel
    QGroupBox *m_filterGroupBox;
    QVBoxLayout *m_filterLayout;
    
    // Level filters
    QGroupBox *m_levelFilterGroup;
    QCheckBox *m_debugCheckBox;
    QCheckBox *m_infoCheckBox;
    QCheckBox *m_warningCheckBox;
    QCheckBox *m_errorCheckBox;
    QCheckBox *m_criticalCheckBox;
    QCheckBox *m_successCheckBox;
    QPushButton *m_selectAllLevelsButton;
    QPushButton *m_clearAllLevelsButton;
    
    // Category filters
    QGroupBox *m_categoryFilterGroup;
    QCheckBox *m_generalCheckBox;
    QCheckBox *m_injectionCheckBox;
    QCheckBox *m_memoryCheckBox;
    QCheckBox *m_gameCheckBox;
    QCheckBox *m_networkCheckBox;
    QCheckBox *m_securityCheckBox;
    QCheckBox *m_uiCheckBox;
    QCheckBox *m_cheatCheckBox;
    QCheckBox *m_performanceCheckBox;
    QPushButton *m_selectAllCategoriesButton;
    QPushButton *m_clearAllCategoriesButton;
    
    // Search controls
    QGroupBox *m_searchGroup;
    QLineEdit *m_searchLineEdit;
    QPushButton *m_searchNextButton;
    QPushButton *m_searchPreviousButton;
    QPushButton *m_searchClearButton;
    QCheckBox *m_caseSensitiveCheckBox;
    QCheckBox *m_regexCheckBox;
    
    // Time filter controls
    QGroupBox *m_timeFilterGroup;
    QCheckBox *m_useTimeFilterCheckBox;
    QDateTimeEdit *m_startTimeEdit;
    QDateTimeEdit *m_endTimeEdit;
    QPushButton *m_resetTimeButton;
    
    // Source filter controls
    QGroupBox *m_sourceFilterGroup;
    QCheckBox *m_useSourceFilterCheckBox;
    QComboBox *m_sourceComboBox;
    QLineEdit *m_sourceLineEdit;
    
    // Action buttons
    QGroupBox *m_actionsGroup;
    QPushButton *m_clearLogsButton;
    QPushButton *m_clearFilteredButton;
    QPushButton *m_exportLogsButton;
    QPushButton *m_exportFilteredButton;
    QPushButton *m_importLogsButton;
    QPushButton *m_saveLogsButton;
    QPushButton *m_loadLogsButton;
    
    // View controls
    QGroupBox *m_viewGroup;
    QCheckBox *m_autoScrollCheckBox;
    QCheckBox *m_wordWrapCheckBox;
    QCheckBox *m_showTimestampCheckBox;
    QCheckBox *m_showCategoryCheckBox;
    QCheckBox *m_showLevelCheckBox;
    QCheckBox *m_showSourceCheckBox;
    QCheckBox *m_showDetailsCheckBox;
    
    // Statistics panel
    QGroupBox *m_statisticsGroup;
    QLabel *m_totalEntriesLabel;
    QLabel *m_debugCountLabel;
    QLabel *m_infoCountLabel;
    QLabel *m_warningCountLabel;
    QLabel *m_errorCountLabel;
    QLabel *m_criticalCountLabel;
    QLabel *m_successCountLabel;
    QLabel *m_timeRangeLabel;
    QPushButton *m_showStatisticsButton;
    QPushButton *m_refreshStatisticsButton;
    
    // Progress and status
    QProgressBar *m_processingProgressBar;
    QLabel *m_statusLabel;
    QLabel *m_filteredCountLabel;
    
    // Timers
    QTimer *m_displayUpdateTimer;
    QTimer *m_queueProcessTimer;
    QTimer *m_autoSaveTimer;
    QTimer *m_sizeCheckTimer;
    
    // Settings
    QSettings *m_settings;
    
    // Threading and synchronization
    QMutex m_logMutex;
    
    // Configuration
    int m_maxLogEntries;
    int m_maxDisplayEntries;
    int m_autoSaveInterval;
    int m_queueProcessInterval;
    bool m_autoScroll;
    bool m_wordWrap;
    bool m_showTimestamp;
    bool m_showCategory;
    bool m_showLevel;
    bool m_showSource;
    bool m_showDetails;
    
    // Search state
    QString m_lastSearchText;
    int m_searchPosition;
    QList<int> m_searchResults;
    
    // Display state
    bool m_updatingUI;
    bool m_filteringInProgress;
    int m_selectedLogIndex;
    
    // File management
    QString m_logFilePath;
    qint64 m_maxLogFileSize;
    int m_logFileRotationCount;
    
    // Constants
    static const int DEFAULT_MAX_LOG_ENTRIES = 10000;
    static const int DEFAULT_MAX_DISPLAY_ENTRIES = 1000;
    static const int DEFAULT_AUTO_SAVE_INTERVAL = 60000; // 1 minute
    static const int DEFAULT_QUEUE_PROCESS_INTERVAL = 100; // 100ms
    static const qint64 DEFAULT_MAX_LOG_FILE_SIZE = 10 * 1024 * 1024; // 10MB
    static const int DEFAULT_LOG_FILE_ROTATION_COUNT = 5;
};

#endif // LOGGING_PANEL_H