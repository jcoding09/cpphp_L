#include "game_interface.h"
#include "logger.h"
#include "memory_manager.h"
#include <QTimer>
#include <QMutexLocker>
#include <windows.h>
#include <tlhelp32.h>

GameInterface::GameInterface(QObject *parent)
    : QObject(parent)
    , m_memoryManager(nullptr)
    , m_gameState(GameState::NotRunning)
    , m_gameVersion("Unknown")
    , m_gameProcessId(0)
    , m_gameBaseAddress(0)
    , m_autoDetection(true)
    , m_detectionInterval(1000)
    , m_updateInterval(100)
    , m_localPlayer(nullptr)
    , m_gameWorld(nullptr)
    , m_gameCamera(nullptr)
    , m_gameRenderer(nullptr)
    , m_gameInput(nullptr)
    , m_gameNetwork(nullptr)
    , m_gameAudio(nullptr)
    , m_gamePhysics(nullptr)
    , m_gameUI(nullptr)
    , m_gameConfig(nullptr)
{
    // Initialize timers
    m_detectionTimer = new QTimer(this);
    m_detectionTimer->setSingleShot(false);
    m_detectionTimer->setInterval(m_detectionInterval);
    connect(m_detectionTimer, &QTimer::timeout, this, &GameInterface::detectGame);
    
    m_updateTimer = new QTimer(this);
    m_updateTimer->setSingleShot(false);
    m_updateTimer->setInterval(m_updateInterval);
    connect(m_updateTimer, &QTimer::timeout, this, &GameInterface::updateGameData);
    
    // Start auto-detection if enabled
    if (m_autoDetection) {
        m_detectionTimer->start();
    }
    
    Logger::instance()->info("GameInterface initialized", "Game");
}

GameInterface::~GameInterface()
{
    disconnect();
}

void GameInterface::setMemoryManager(MemoryManager* memoryManager)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_memoryManager != memoryManager) {
        m_memoryManager = memoryManager;
        
        if (m_memoryManager) {
            // Connect memory manager signals
            connect(m_memoryManager, &MemoryManager::processAttached,
                    this, &GameInterface::onProcessAttached);
            connect(m_memoryManager, &MemoryManager::processDetached,
                    this, &GameInterface::onProcessDetached);
        }
        
        emit memoryManagerChanged(memoryManager);
    }
}

MemoryManager* GameInterface::memoryManager() const
{
    QMutexLocker locker(&m_mutex);
    return m_memoryManager;
}

bool GameInterface::connectToGame()
{
    QMutexLocker locker(&m_mutex);
    
    if (m_gameState == GameState::Connected) {
        return true; // Already connected
    }
    
    if (!detectGame()) {
        Logger::instance()->error("Game not detected", "Game");
        return false;
    }
    
    if (!m_memoryManager) {
        Logger::instance()->error("Memory manager not set", "Game");
        return false;
    }
    
    // Attach to game process
    if (!m_memoryManager->attachToProcess(m_gameProcessId)) {
        Logger::instance()->error("Failed to attach to game process", "Game");
        return false;
    }
    
    // Initialize game components
    if (!initializeGameComponents()) {
        Logger::instance()->error("Failed to initialize game components", "Game");
        m_memoryManager->detachFromProcess();
        return false;
    }
    
    m_gameState = GameState::Connected;
    
    // Start update timer
    m_updateTimer->start();
    
    Logger::instance()->info("Connected to game", "Game");
    emit gameConnected();
    emit gameStateChanged(m_gameState);
    
    return true;
}

void GameInterface::disconnect()
{
    QMutexLocker locker(&m_mutex);
    
    if (m_gameState == GameState::NotRunning) {
        return; // Already disconnected
    }
    
    // Stop timers
    m_updateTimer->stop();
    
    // Clean up game components
    cleanupGameComponents();
    
    // Detach from process
    if (m_memoryManager) {
        m_memoryManager->detachFromProcess();
    }
    
    m_gameState = GameState::NotRunning;
    m_gameProcessId = 0;
    m_gameBaseAddress = 0;
    
    Logger::instance()->info("Disconnected from game", "Game");
    emit gameDisconnected();
    emit gameStateChanged(m_gameState);
}

bool GameInterface::isConnected() const
{
    QMutexLocker locker(&m_mutex);
    return m_gameState == GameState::Connected;
}

GameInterface::GameState GameInterface::gameState() const
{
    QMutexLocker locker(&m_mutex);
    return m_gameState;
}

QString GameInterface::gameVersion() const
{
    QMutexLocker locker(&m_mutex);
    return m_gameVersion;
}

quint32 GameInterface::gameProcessId() const
{
    QMutexLocker locker(&m_mutex);
    return m_gameProcessId;
}

qint64 GameInterface::gameBaseAddress() const
{
    QMutexLocker locker(&m_mutex);
    return m_gameBaseAddress;
}

GameInterface::PlayerInfo GameInterface::getLocalPlayer() const
{
    QMutexLocker locker(&m_mutex);
    
    PlayerInfo player;
    
    if (!m_memoryManager || !isConnected()) {
        return player;
    }
    
    // Read local player data from memory
    // This is a placeholder implementation
    // In a real implementation, you would read actual game memory offsets
    
    try {
        // Example offsets (these would be real game offsets)
        qint64 localPlayerPtr = 0x12345678; // Placeholder
        qint64 playerBase = readPointer(localPlayerPtr);
        
        if (playerBase) {
            player.id = readValue<quint32>(playerBase + 0x10);
            player.teamId = readValue<quint32>(playerBase + 0x14);
            player.health = readValue<float>(playerBase + 0x18);
            player.maxHealth = readValue<float>(playerBase + 0x1C);
            player.armor = readValue<float>(playerBase + 0x20);
            player.maxArmor = readValue<float>(playerBase + 0x24);
            
            // Read position
            player.position.x = readValue<float>(playerBase + 0x30);
            player.position.y = readValue<float>(playerBase + 0x34);
            player.position.z = readValue<float>(playerBase + 0x38);
            
            // Read rotation
            player.rotation.x = readValue<float>(playerBase + 0x40);
            player.rotation.y = readValue<float>(playerBase + 0x44);
            player.rotation.z = readValue<float>(playerBase + 0x48);
            
            // Read velocity
            player.velocity.x = readValue<float>(playerBase + 0x50);
            player.velocity.y = readValue<float>(playerBase + 0x54);
            player.velocity.z = readValue<float>(playerBase + 0x58);
            
            player.isAlive = player.health > 0;
            player.isValid = true;
        }
    } catch (...) {
        Logger::instance()->error("Failed to read local player data", "Game");
    }
    
    return player;
}

QList<GameInterface::PlayerInfo> GameInterface::getAllPlayers() const
{
    QMutexLocker locker(&m_mutex);
    
    QList<PlayerInfo> players;
    
    if (!m_memoryManager || !isConnected()) {
        return players;
    }
    
    // Read all players from memory
    // This is a placeholder implementation
    
    try {
        // Example implementation
        qint64 playerListPtr = 0x87654321; // Placeholder
        qint64 playerListBase = readPointer(playerListPtr);
        
        if (playerListBase) {
            quint32 playerCount = readValue<quint32>(playerListBase + 0x08);
            qint64 playerArrayPtr = readPointer(playerListBase + 0x10);
            
            for (quint32 i = 0; i < playerCount && i < 100; ++i) {
                qint64 playerPtr = readPointer(playerArrayPtr + i * 8);
                
                if (playerPtr) {
                    PlayerInfo player;
                    player.id = readValue<quint32>(playerPtr + 0x10);
                    player.teamId = readValue<quint32>(playerPtr + 0x14);
                    player.health = readValue<float>(playerPtr + 0x18);
                    player.maxHealth = readValue<float>(playerPtr + 0x1C);
                    
                    // Read position
                    player.position.x = readValue<float>(playerPtr + 0x30);
                    player.position.y = readValue<float>(playerPtr + 0x34);
                    player.position.z = readValue<float>(playerPtr + 0x38);
                    
                    player.isAlive = player.health > 0;
                    player.isValid = true;
                    
                    players.append(player);
                }
            }
        }
    } catch (...) {
        Logger::instance()->error("Failed to read player list", "Game");
    }
    
    return players;
}

QList<GameInterface::EntityInfo> GameInterface::getAllEntities() const
{
    QMutexLocker locker(&m_mutex);
    
    QList<EntityInfo> entities;
    
    if (!m_memoryManager || !isConnected()) {
        return entities;
    }
    
    // Read all entities from memory
    // This is a placeholder implementation
    
    try {
        // Example implementation for items, vehicles, etc.
        qint64 entityListPtr = 0x11223344; // Placeholder
        qint64 entityListBase = readPointer(entityListPtr);
        
        if (entityListBase) {
            quint32 entityCount = readValue<quint32>(entityListBase + 0x08);
            qint64 entityArrayPtr = readPointer(entityListBase + 0x10);
            
            for (quint32 i = 0; i < entityCount && i < 1000; ++i) {
                qint64 entityPtr = readPointer(entityArrayPtr + i * 8);
                
                if (entityPtr) {
                    EntityInfo entity;
                    entity.id = readValue<quint32>(entityPtr + 0x10);
                    entity.type = static_cast<EntityType>(readValue<quint32>(entityPtr + 0x14));
                    
                    // Read position
                    entity.position.x = readValue<float>(entityPtr + 0x20);
                    entity.position.y = readValue<float>(entityPtr + 0x24);
                    entity.position.z = readValue<float>(entityPtr + 0x28);
                    
                    // Read rotation
                    entity.rotation.x = readValue<float>(entityPtr + 0x30);
                    entity.rotation.y = readValue<float>(entityPtr + 0x34);
                    entity.rotation.z = readValue<float>(entityPtr + 0x38);
                    
                    entity.isValid = true;
                    
                    entities.append(entity);
                }
            }
        }
    } catch (...) {
        Logger::instance()->error("Failed to read entity list", "Game");
    }
    
    return entities;
}

GameInterface::WeaponInfo GameInterface::getCurrentWeapon() const
{
    QMutexLocker locker(&m_mutex);
    
    WeaponInfo weapon;
    
    if (!m_memoryManager || !isConnected()) {
        return weapon;
    }
    
    // Read current weapon data
    // This is a placeholder implementation
    
    try {
        PlayerInfo localPlayer = getLocalPlayer();
        if (localPlayer.isValid) {
            // Example weapon reading
            qint64 weaponPtr = 0x55667788; // Placeholder
            qint64 weaponBase = readPointer(weaponPtr);
            
            if (weaponBase) {
                weapon.id = readValue<quint32>(weaponBase + 0x10);
                weapon.type = static_cast<WeaponType>(readValue<quint32>(weaponBase + 0x14));
                weapon.ammo = readValue<quint32>(weaponBase + 0x18);
                weapon.maxAmmo = readValue<quint32>(weaponBase + 0x1C);
                weapon.damage = readValue<float>(weaponBase + 0x20);
                weapon.range = readValue<float>(weaponBase + 0x24);
                weapon.accuracy = readValue<float>(weaponBase + 0x28);
                weapon.recoil = readValue<float>(weaponBase + 0x2C);
                weapon.fireRate = readValue<float>(weaponBase + 0x30);
                weapon.isValid = true;
            }
        }
    } catch (...) {
        Logger::instance()->error("Failed to read weapon data", "Game");
    }
    
    return weapon;
}

GameInterface::GameInfo GameInterface::getGameInfo() const
{
    QMutexLocker locker(&m_mutex);
    
    GameInfo info;
    info.isInGame = (m_gameState == GameState::Connected);
    info.gameMode = "Battle Royale"; // Placeholder
    info.mapName = "Erangel"; // Placeholder
    info.playersAlive = 50; // Placeholder
    info.totalPlayers = 100; // Placeholder
    info.gameTime = 1200; // Placeholder (20 minutes)
    info.zonePhase = 3; // Placeholder
    
    return info;
}

void GameInterface::setAutoDetection(bool enable)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_autoDetection != enable) {
        m_autoDetection = enable;
        
        if (enable) {
            m_detectionTimer->start();
        } else {
            m_detectionTimer->stop();
        }
        
        emit autoDetectionChanged(enable);
    }
}

bool GameInterface::autoDetection() const
{
    QMutexLocker locker(&m_mutex);
    return m_autoDetection;
}

void GameInterface::setDetectionInterval(int interval)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_detectionInterval != interval) {
        m_detectionInterval = interval;
        m_detectionTimer->setInterval(interval);
        emit detectionIntervalChanged(interval);
    }
}

int GameInterface::detectionInterval() const
{
    QMutexLocker locker(&m_mutex);
    return m_detectionInterval;
}

void GameInterface::setUpdateInterval(int interval)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_updateInterval != interval) {
        m_updateInterval = interval;
        m_updateTimer->setInterval(interval);
        emit updateIntervalChanged(interval);
    }
}

int GameInterface::updateInterval() const
{
    QMutexLocker locker(&m_mutex);
    return m_updateInterval;
}

bool GameInterface::detectGame()
{
    // Look for BGMI/PUBG Mobile process
    QStringList processNames = {
        "BGMI.exe",
        "PUBGMobile.exe",
        "GameLoop.exe",
        "AndroidEmulator.exe",
        "HD-Player.exe" // BlueStacks
    };
    
    HANDLE hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hProcessSnap == INVALID_HANDLE_VALUE) {
        return false;
    }
    
    PROCESSENTRY32W pe32;
    pe32.dwSize = sizeof(PROCESSENTRY32W);
    
    bool found = false;
    
    if (Process32FirstW(hProcessSnap, &pe32)) {
        do {
            QString processName = QString::fromWCharArray(pe32.szExeFile);
            
            for (const QString& targetName : processNames) {
                if (processName.compare(targetName, Qt::CaseInsensitive) == 0) {
                    m_gameProcessId = pe32.th32ProcessID;
                    m_gameVersion = detectGameVersion();
                    found = true;
                    break;
                }
            }
            
            if (found) break;
            
        } while (Process32NextW(hProcessSnap, &pe32));
    }
    
    CloseHandle(hProcessSnap);
    
    if (found && m_gameState == GameState::NotRunning) {
        m_gameState = GameState::Detected;
        Logger::instance()->info(QString("Game detected: PID %1").arg(m_gameProcessId), "Game");
        emit gameDetected(m_gameProcessId);
        emit gameStateChanged(m_gameState);
    } else if (!found && m_gameState != GameState::NotRunning) {
        disconnect();
    }
    
    return found;
}

QString GameInterface::detectGameVersion()
{
    // Placeholder version detection
    // In a real implementation, you would read version info from the game executable
    return "3.9.0";
}

bool GameInterface::initializeGameComponents()
{
    // Initialize game component interfaces
    // This is where you would set up pointers to various game systems
    
    try {
        // Get base address
        if (m_memoryManager) {
            m_gameBaseAddress = m_memoryManager->baseAddress();
        }
        
        // Initialize component pointers (placeholders)
        m_localPlayer = reinterpret_cast<void*>(0x12345678);
        m_gameWorld = reinterpret_cast<void*>(0x23456789);
        m_gameCamera = reinterpret_cast<void*>(0x34567890);
        m_gameRenderer = reinterpret_cast<void*>(0x45678901);
        m_gameInput = reinterpret_cast<void*>(0x56789012);
        m_gameNetwork = reinterpret_cast<void*>(0x67890123);
        m_gameAudio = reinterpret_cast<void*>(0x78901234);
        m_gamePhysics = reinterpret_cast<void*>(0x89012345);
        m_gameUI = reinterpret_cast<void*>(0x90123456);
        m_gameConfig = reinterpret_cast<void*>(0x01234567);
        
        Logger::instance()->info("Game components initialized", "Game");
        return true;
        
    } catch (...) {
        Logger::instance()->error("Failed to initialize game components", "Game");
        return false;
    }
}

void GameInterface::cleanupGameComponents()
{
    // Clean up game component interfaces
    m_localPlayer = nullptr;
    m_gameWorld = nullptr;
    m_gameCamera = nullptr;
    m_gameRenderer = nullptr;
    m_gameInput = nullptr;
    m_gameNetwork = nullptr;
    m_gameAudio = nullptr;
    m_gamePhysics = nullptr;
    m_gameUI = nullptr;
    m_gameConfig = nullptr;
    
    Logger::instance()->info("Game components cleaned up", "Game");
}

void GameInterface::updateGameData()
{
    if (!isConnected()) {
        return;
    }
    
    // Update game data periodically
    try {
        // Emit signals with updated data
        emit playerDataUpdated(getLocalPlayer());
        emit gameInfoUpdated(getGameInfo());
        
        // Update other data less frequently
        static int updateCounter = 0;
        if (++updateCounter % 10 == 0) { // Every 1 second if update interval is 100ms
            emit playersUpdated(getAllPlayers());
            emit entitiesUpdated(getAllEntities());
        }
        
    } catch (...) {
        Logger::instance()->error("Error updating game data", "Game");
    }
}

void GameInterface::onProcessAttached(quint32 processId)
{
    if (processId == m_gameProcessId) {
        Logger::instance()->info("Memory manager attached to game process", "Game");
    }
}

void GameInterface::onProcessDetached()
{
    Logger::instance()->info("Memory manager detached from game process", "Game");
    
    if (m_gameState == GameState::Connected) {
        disconnect();
    }
}

template<typename T>
T GameInterface::readValue(qint64 address) const
{
    if (!m_memoryManager) {
        return T{};
    }
    
    QByteArray data = m_memoryManager->readMemory(address, sizeof(T));
    if (data.size() == sizeof(T)) {
        return *reinterpret_cast<const T*>(data.constData());
    }
    
    return T{};
}

qint64 GameInterface::readPointer(qint64 address) const
{
    return readValue<qint64>(address);
}

template<typename T>
bool GameInterface::writeValue(qint64 address, const T& value) const
{
    if (!m_memoryManager) {
        return false;
    }
    
    QByteArray data(reinterpret_cast<const char*>(&value), sizeof(T));
    return m_memoryManager->writeMemory(address, data);
}

// Explicit template instantiations
template quint8 GameInterface::readValue<quint8>(qint64) const;
template quint16 GameInterface::readValue<quint16>(qint64) const;
template quint32 GameInterface::readValue<quint32>(qint64) const;
template quint64 GameInterface::readValue<quint64>(qint64) const;
template float GameInterface::readValue<float>(qint64) const;
template double GameInterface::readValue<double>(qint64) const;

template bool GameInterface::writeValue<quint8>(qint64, const quint8&) const;
template bool GameInterface::writeValue<quint16>(qint64, const quint16&) const;
template bool GameInterface::writeValue<quint32>(qint64, const quint32&) const;
template bool GameInterface::writeValue<quint64>(qint64, const quint64&) const;
template bool GameInterface::writeValue<float>(qint64, const float&) const;
template bool GameInterface::writeValue<double>(qint64, const double&) const;