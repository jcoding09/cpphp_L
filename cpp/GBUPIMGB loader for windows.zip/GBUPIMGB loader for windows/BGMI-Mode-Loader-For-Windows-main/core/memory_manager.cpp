#include "memory_manager.h"
#include "logger.h"
#include <QMutexLocker>
#include <QTimer>
#include <windows.h>
#include <psapi.h>
#include <tlhelp32.h>

MemoryManager::MemoryManager(QObject *parent)
    : QObject(parent)
    , m_targetProcessId(0)
    , m_processHandle(nullptr)
    , m_baseAddress(0)
    , m_moduleSize(0)
    , m_readAccess(true)
    , m_writeAccess(true)
    , m_executeAccess(false)
    , m_cacheEnabled(true)
    , m_cacheSize(1000)
    , m_autoRefresh(true)
    , m_refreshInterval(1000)
{
    // Initialize refresh timer
    m_refreshTimer = new QTimer(this);
    m_refreshTimer->setSingleShot(false);
    m_refreshTimer->setInterval(m_refreshInterval);
    connect(m_refreshTimer, &QTimer::timeout, this, &MemoryManager::refreshMemoryInfo);
    
    if (m_autoRefresh) {
        m_refreshTimer->start();
    }
    
    Logger::instance()->info("MemoryManager initialized", "Memory");
}

MemoryManager::~MemoryManager()
{
    detachFromProcess();
}

bool MemoryManager::attachToProcess(quint32 processId)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_targetProcessId == processId && m_processHandle) {
        return true; // Already attached
    }
    
    // Detach from current process if any
    if (m_processHandle) {
        detachFromProcess();
    }
    
    // Open target process
    DWORD access = PROCESS_QUERY_INFORMATION | PROCESS_VM_READ;
    if (m_writeAccess) {
        access |= PROCESS_VM_WRITE;
    }
    if (m_executeAccess) {
        access |= PROCESS_VM_OPERATION;
    }
    
    m_processHandle = OpenProcess(access, FALSE, processId);
    if (!m_processHandle) {
        Logger::instance()->error(QString("Failed to attach to process %1").arg(processId), "Memory");
        emit attachmentFailed(QString("Failed to open process: %1").arg(GetLastError()));
        return false;
    }
    
    m_targetProcessId = processId;
    
    // Get process information
    updateProcessInfo();
    
    Logger::instance()->info(QString("Attached to process %1").arg(processId), "Memory");
    emit processAttached(processId);
    
    return true;
}

void MemoryManager::detachFromProcess()
{
    QMutexLocker locker(&m_mutex);
    
    if (m_processHandle) {
        CloseHandle(m_processHandle);
        m_processHandle = nullptr;
    }
    
    m_targetProcessId = 0;
    m_baseAddress = 0;
    m_moduleSize = 0;
    m_memoryRegions.clear();
    m_moduleList.clear();
    m_readCache.clear();
    
    Logger::instance()->info("Detached from process", "Memory");
    emit processDetached();
}

bool MemoryManager::isAttached() const
{
    QMutexLocker locker(&m_mutex);
    return m_processHandle != nullptr;
}

quint32 MemoryManager::targetProcessId() const
{
    QMutexLocker locker(&m_mutex);
    return m_targetProcessId;
}

qint64 MemoryManager::baseAddress() const
{
    QMutexLocker locker(&m_mutex);
    return m_baseAddress;
}

qint64 MemoryManager::moduleSize() const
{
    QMutexLocker locker(&m_mutex);
    return m_moduleSize;
}

QByteArray MemoryManager::readMemory(qint64 address, qint64 size)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_processHandle) {
        Logger::instance()->error("Not attached to any process", "Memory");
        return QByteArray();
    }
    
    if (size <= 0 || size > MAX_READ_SIZE) {
        Logger::instance()->error(QString("Invalid read size: %1").arg(size), "Memory");
        return QByteArray();
    }
    
    // Check cache first
    if (m_cacheEnabled) {
        QString cacheKey = QString("%1_%2").arg(address).arg(size);
        if (m_readCache.contains(cacheKey)) {
            return m_readCache.value(cacheKey);
        }
    }
    
    QByteArray buffer(size, 0);
    SIZE_T bytesRead = 0;
    
    if (!ReadProcessMemory(m_processHandle, (LPCVOID)address, buffer.data(), size, &bytesRead)) {
        DWORD error = GetLastError();
        Logger::instance()->error(QString("Failed to read memory at 0x%1: %2")
                                 .arg(address, 0, 16).arg(error), "Memory");
        emit readFailed(address, size, QString("ReadProcessMemory failed: %1").arg(error));
        return QByteArray();
    }
    
    if (bytesRead != static_cast<SIZE_T>(size)) {
        Logger::instance()->warning(QString("Partial read: requested %1, got %2")
                                   .arg(size).arg(bytesRead), "Memory");
        buffer.resize(bytesRead);
    }
    
    // Cache the result
    if (m_cacheEnabled && bytesRead > 0) {
        QString cacheKey = QString("%1_%2").arg(address).arg(bytesRead);
        m_readCache.insert(cacheKey, buffer);
        
        // Limit cache size
        if (m_readCache.size() > m_cacheSize) {
            auto it = m_readCache.begin();
            m_readCache.erase(it);
        }
    }
    
    emit memoryRead(address, buffer);
    return buffer;
}

bool MemoryManager::writeMemory(qint64 address, const QByteArray& data)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_processHandle) {
        Logger::instance()->error("Not attached to any process", "Memory");
        return false;
    }
    
    if (!m_writeAccess) {
        Logger::instance()->error("Write access not enabled", "Memory");
        return false;
    }
    
    if (data.isEmpty() || data.size() > MAX_WRITE_SIZE) {
        Logger::instance()->error(QString("Invalid write size: %1").arg(data.size()), "Memory");
        return false;
    }
    
    SIZE_T bytesWritten = 0;
    
    if (!WriteProcessMemory(m_processHandle, (LPVOID)address, data.constData(), data.size(), &bytesWritten)) {
        DWORD error = GetLastError();
        Logger::instance()->error(QString("Failed to write memory at 0x%1: %2")
                                 .arg(address, 0, 16).arg(error), "Memory");
        emit writeFailed(address, data, QString("WriteProcessMemory failed: %1").arg(error));
        return false;
    }
    
    if (bytesWritten != static_cast<SIZE_T>(data.size())) {
        Logger::instance()->warning(QString("Partial write: requested %1, wrote %2")
                                   .arg(data.size()).arg(bytesWritten), "Memory");
    }
    
    // Invalidate cache for this region
    if (m_cacheEnabled) {
        invalidateCache(address, data.size());
    }
    
    Logger::instance()->debug(QString("Wrote %1 bytes to 0x%2")
                             .arg(bytesWritten).arg(address, 0, 16), "Memory");
    emit memoryWritten(address, data);
    
    return bytesWritten == static_cast<SIZE_T>(data.size());
}

qint64 MemoryManager::findPattern(const QByteArray& pattern, const QByteArray& mask, qint64 startAddress, qint64 endAddress)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_processHandle) {
        Logger::instance()->error("Not attached to any process", "Memory");
        return 0;
    }
    
    if (pattern.isEmpty() || pattern.size() != mask.size()) {
        Logger::instance()->error("Invalid pattern or mask", "Memory");
        return 0;
    }
    
    if (startAddress >= endAddress) {
        Logger::instance()->error("Invalid address range", "Memory");
        return 0;
    }
    
    const qint64 chunkSize = 4096; // Read in 4KB chunks
    qint64 currentAddress = startAddress;
    
    while (currentAddress < endAddress) {
        qint64 readSize = qMin(chunkSize, endAddress - currentAddress);
        QByteArray chunk = readMemory(currentAddress, readSize);
        
        if (chunk.isEmpty()) {
            currentAddress += chunkSize;
            continue;
        }
        
        // Search for pattern in chunk
        for (int i = 0; i <= chunk.size() - pattern.size(); ++i) {
            bool found = true;
            for (int j = 0; j < pattern.size(); ++j) {
                if (mask[j] == 'x' && chunk[i + j] != pattern[j]) {
                    found = false;
                    break;
                }
            }
            
            if (found) {
                qint64 foundAddress = currentAddress + i;
                Logger::instance()->info(QString("Pattern found at 0x%1").arg(foundAddress, 0, 16), "Memory");
                emit patternFound(foundAddress, pattern);
                return foundAddress;
            }
        }
        
        currentAddress += readSize - pattern.size() + 1; // Overlap to catch patterns across chunks
    }
    
    Logger::instance()->info("Pattern not found", "Memory");
    return 0;
}

QList<qint64> MemoryManager::findAllPatterns(const QByteArray& pattern, const QByteArray& mask, qint64 startAddress, qint64 endAddress)
{
    QMutexLocker locker(&m_mutex);
    
    QList<qint64> results;
    
    if (!m_processHandle) {
        Logger::instance()->error("Not attached to any process", "Memory");
        return results;
    }
    
    if (pattern.isEmpty() || pattern.size() != mask.size()) {
        Logger::instance()->error("Invalid pattern or mask", "Memory");
        return results;
    }
    
    if (startAddress >= endAddress) {
        Logger::instance()->error("Invalid address range", "Memory");
        return results;
    }
    
    const qint64 chunkSize = 4096;
    qint64 currentAddress = startAddress;
    
    while (currentAddress < endAddress) {
        qint64 readSize = qMin(chunkSize, endAddress - currentAddress);
        QByteArray chunk = readMemory(currentAddress, readSize);
        
        if (chunk.isEmpty()) {
            currentAddress += chunkSize;
            continue;
        }
        
        // Search for all patterns in chunk
        for (int i = 0; i <= chunk.size() - pattern.size(); ++i) {
            bool found = true;
            for (int j = 0; j < pattern.size(); ++j) {
                if (mask[j] == 'x' && chunk[i + j] != pattern[j]) {
                    found = false;
                    break;
                }
            }
            
            if (found) {
                qint64 foundAddress = currentAddress + i;
                results.append(foundAddress);
                emit patternFound(foundAddress, pattern);
            }
        }
        
        currentAddress += readSize - pattern.size() + 1;
    }
    
    Logger::instance()->info(QString("Found %1 pattern matches").arg(results.size()), "Memory");
    return results;
}

QList<MemoryManager::MemoryRegion> MemoryManager::getMemoryRegions() const
{
    QMutexLocker locker(&m_mutex);
    return m_memoryRegions;
}

QList<MemoryManager::ModuleInfo> MemoryManager::getModuleList() const
{
    QMutexLocker locker(&m_mutex);
    return m_moduleList;
}

MemoryManager::ModuleInfo MemoryManager::getModuleInfo(const QString& moduleName) const
{
    QMutexLocker locker(&m_mutex);
    
    for (const ModuleInfo& module : m_moduleList) {
        if (module.name.compare(moduleName, Qt::CaseInsensitive) == 0) {
            return module;
        }
    }
    
    return ModuleInfo();
}

qint64 MemoryManager::getModuleAddress(const QString& moduleName) const
{
    ModuleInfo module = getModuleInfo(moduleName);
    return module.baseAddress;
}

void MemoryManager::setReadAccess(bool enable)
{
    QMutexLocker locker(&m_mutex);
    m_readAccess = enable;
    emit readAccessChanged(enable);
}

bool MemoryManager::readAccess() const
{
    QMutexLocker locker(&m_mutex);
    return m_readAccess;
}

void MemoryManager::setWriteAccess(bool enable)
{
    QMutexLocker locker(&m_mutex);
    m_writeAccess = enable;
    emit writeAccessChanged(enable);
}

bool MemoryManager::writeAccess() const
{
    QMutexLocker locker(&m_mutex);
    return m_writeAccess;
}

void MemoryManager::setCacheEnabled(bool enable)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_cacheEnabled != enable) {
        m_cacheEnabled = enable;
        if (!enable) {
            m_readCache.clear();
        }
        emit cacheEnabledChanged(enable);
    }
}

bool MemoryManager::cacheEnabled() const
{
    QMutexLocker locker(&m_mutex);
    return m_cacheEnabled;
}

void MemoryManager::clearCache()
{
    QMutexLocker locker(&m_mutex);
    m_readCache.clear();
    Logger::instance()->info("Memory cache cleared", "Memory");
    emit cacheCleared();
}

void MemoryManager::refreshMemoryInfo()
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_processHandle) {
        return;
    }
    
    updateProcessInfo();
    updateMemoryRegions();
    updateModuleList();
    
    emit memoryInfoRefreshed();
}

void MemoryManager::updateProcessInfo()
{
    if (!m_processHandle) {
        return;
    }
    
    // Get main module information
    HMODULE hMods[1024];
    DWORD cbNeeded;
    
    if (EnumProcessModules(m_processHandle, hMods, sizeof(hMods), &cbNeeded)) {
        MODULEINFO modInfo;
        if (GetModuleInformation(m_processHandle, hMods[0], &modInfo, sizeof(modInfo))) {
            m_baseAddress = reinterpret_cast<qint64>(modInfo.lpBaseOfDll);
            m_moduleSize = modInfo.SizeOfImage;
        }
    }
}

void MemoryManager::updateMemoryRegions()
{
    if (!m_processHandle) {
        return;
    }
    
    m_memoryRegions.clear();
    
    MEMORY_BASIC_INFORMATION mbi;
    qint64 address = 0;
    
    while (VirtualQueryEx(m_processHandle, (LPCVOID)address, &mbi, sizeof(mbi))) {
        MemoryRegion region;
        region.baseAddress = reinterpret_cast<qint64>(mbi.BaseAddress);
        region.size = mbi.RegionSize;
        region.state = mbi.State;
        region.protect = mbi.Protect;
        region.type = mbi.Type;
        
        m_memoryRegions.append(region);
        
        address = region.baseAddress + region.size;
        
        // Prevent infinite loop
        if (address == 0) {
            break;
        }
    }
}

void MemoryManager::updateModuleList()
{
    if (!m_processHandle) {
        return;
    }
    
    m_moduleList.clear();
    
    HMODULE hMods[1024];
    DWORD cbNeeded;
    
    if (EnumProcessModules(m_processHandle, hMods, sizeof(hMods), &cbNeeded)) {
        DWORD moduleCount = cbNeeded / sizeof(HMODULE);
        
        for (DWORD i = 0; i < moduleCount; ++i) {
            ModuleInfo module;
            
            // Get module name
            wchar_t szModName[MAX_PATH];
            if (GetModuleBaseNameW(m_processHandle, hMods[i], szModName, sizeof(szModName) / sizeof(wchar_t))) {
                module.name = QString::fromWCharArray(szModName);
            }
            
            // Get module path
            wchar_t szModPath[MAX_PATH];
            if (GetModuleFileNameExW(m_processHandle, hMods[i], szModPath, sizeof(szModPath) / sizeof(wchar_t))) {
                module.path = QString::fromWCharArray(szModPath);
            }
            
            // Get module information
            MODULEINFO modInfo;
            if (GetModuleInformation(m_processHandle, hMods[i], &modInfo, sizeof(modInfo))) {
                module.baseAddress = reinterpret_cast<qint64>(modInfo.lpBaseOfDll);
                module.size = modInfo.SizeOfImage;
                module.entryPoint = reinterpret_cast<qint64>(modInfo.EntryPoint);
            }
            
            m_moduleList.append(module);
        }
    }
}

void MemoryManager::invalidateCache(qint64 address, qint64 size)
{
    auto it = m_readCache.begin();
    while (it != m_readCache.end()) {
        QStringList parts = it.key().split('_');
        if (parts.size() == 2) {
            qint64 cacheAddress = parts[0].toLongLong();
            qint64 cacheSize = parts[1].toLongLong();
            
            // Check if cache entry overlaps with invalidated region
            if (cacheAddress < address + size && cacheAddress + cacheSize > address) {
                it = m_readCache.erase(it);
            } else {
                ++it;
            }
        } else {
            ++it;
        }
    }
}