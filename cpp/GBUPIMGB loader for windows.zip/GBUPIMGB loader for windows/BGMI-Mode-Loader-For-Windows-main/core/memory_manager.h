#pragma once

#include <QtCore/QObject>
#include <QtCore/QTimer>
#include <memory>
#include <vector>
#include <unordered_map>
#include <windows.h>
#include <psapi.h>

struct MemoryRegion {
    uintptr_t baseAddress;
    size_t size;
    DWORD protection;
    bool isExecutable;
    bool isWritable;
    bool isReadable;
};

struct ScanResult {
    uintptr_t address;
    std::vector<uint8_t> value;
    size_t size;
};

class MemoryManager : public QObject {
    Q_OBJECT

public:
    enum ScanType {
        ExactValue,
        UnknownValue,
        IncreasedValue,
        DecreasedValue,
        ChangedValue,
        UnchangedValue
    };
    
    enum ValueType {
        Byte,
        Short,
        Integer,
        Long,
        Float,
        Double,
        String,
        ByteArray
    };

    explicit MemoryManager(QObject* parent = nullptr);
    ~MemoryManager();
    
    // Process attachment
    bool attachToProcess(DWORD processId);
    bool detachFromProcess();
    bool isAttached() const { return m_processHandle != nullptr; }
    
    // Memory reading/writing
    bool readMemory(uintptr_t address, void* buffer, size_t size);
    bool writeMemory(uintptr_t address, const void* data, size_t size);
    
    template<typename T>
    bool readValue(uintptr_t address, T& value);
    
    template<typename T>
    bool writeValue(uintptr_t address, const T& value);
    
    // Memory scanning
    std::vector<ScanResult> scanMemory(const std::vector<uint8_t>& pattern, 
                                      const std::vector<uint8_t>& mask = {});
    std::vector<ScanResult> scanForValue(const void* value, size_t valueSize, ValueType type);
    std::vector<ScanResult> scanForString(const std::string& text, bool caseSensitive = false);
    
    // Advanced scanning
    std::vector<ScanResult> nextScan(ScanType scanType, const void* value = nullptr, size_t valueSize = 0);
    void resetScan();
    
    // Memory protection
    bool protectMemory(uintptr_t address, size_t size, DWORD newProtection, DWORD* oldProtection = nullptr);
    bool allocateMemory(size_t size, uintptr_t* allocatedAddress, DWORD protection = PAGE_EXECUTE_READWRITE);
    bool freeMemory(uintptr_t address);
    
    // Memory regions
    std::vector<MemoryRegion> getMemoryRegions();
    MemoryRegion getMemoryRegion(uintptr_t address);
    
    // Offset management
    void addOffset(const QString& name, uintptr_t offset);
    uintptr_t getOffset(const QString& name) const;
    void removeOffset(const QString& name);
    void clearOffsets();
    
    // Pointer chains
    uintptr_t followPointerChain(uintptr_t baseAddress, const std::vector<uintptr_t>& offsets);
    
    // Statistics
    size_t getScanResultCount() const { return m_lastScanResults.size(); }
    QString getLastError() const { return m_lastError; }
    
signals:
    void scanProgress(int percentage, const QString& status);
    void scanComplete(int resultCount);
    void memoryChanged(uintptr_t address, const QByteArray& oldValue, const QByteArray& newValue);

private slots:
    void monitorMemoryChanges();

private:
    // Helper functions
    bool isValidAddress(uintptr_t address);
    bool isAddressInRegion(uintptr_t address, const MemoryRegion& region);
    std::vector<uint8_t> createMask(const std::vector<uint8_t>& pattern);
    bool compareWithMask(const uint8_t* data, const uint8_t* pattern, const uint8_t* mask, size_t size);
    
    // Scanning helpers
    void scanRegion(const MemoryRegion& region, const std::vector<uint8_t>& pattern, 
                   const std::vector<uint8_t>& mask, std::vector<ScanResult>& results);
    void scanRegionForValue(const MemoryRegion& region, const void* value, size_t valueSize, 
                           ValueType type, std::vector<ScanResult>& results);
    
    // Member variables
    HANDLE m_processHandle;
    DWORD m_processId;
    QString m_lastError;
    
    // Scan data
    std::vector<ScanResult> m_lastScanResults;
    std::vector<ScanResult> m_currentScanResults;
    std::vector<MemoryRegion> m_memoryRegions;
    
    // Offset storage
    std::unordered_map<QString, uintptr_t> m_offsets;
    
    // Memory monitoring
    QTimer* m_memoryMonitor;
    std::unordered_map<uintptr_t, std::vector<uint8_t>> m_watchedAddresses;
    
    // Allocated memory tracking
    std::vector<uintptr_t> m_allocatedMemory;
};

// Template implementations
template<typename T>
bool MemoryManager::readValue(uintptr_t address, T& value) {
    return readMemory(address, &value, sizeof(T));
}

template<typename T>
bool MemoryManager::writeValue(uintptr_t address, const T& value) {
    return writeMemory(address, &value, sizeof(T));
}

// Implementation

MemoryManager::MemoryManager(QObject* parent)
    : QObject(parent)
    , m_processHandle(nullptr)
    , m_processId(0)
{
    m_memoryMonitor = new QTimer(this);
    connect(m_memoryMonitor, &QTimer::timeout, this, &MemoryManager::monitorMemoryChanges);
}

MemoryManager::~MemoryManager() {
    detachFromProcess();
    
    // Free any allocated memory
    for (uintptr_t address : m_allocatedMemory) {
        freeMemory(address);
    }
}

bool MemoryManager::attachToProcess(DWORD processId) {
    if (m_processHandle) {
        detachFromProcess();
    }
    
    m_processHandle = OpenProcess(PROCESS_ALL_ACCESS, FALSE, processId);
    if (!m_processHandle) {
        m_lastError = QString("Failed to open process %1. Error: %2")
                     .arg(processId).arg(GetLastError());
        return false;
    }
    
    m_processId = processId;
    
    // Update memory regions
    m_memoryRegions = getMemoryRegions();
    
    // Start memory monitoring
    m_memoryMonitor->start(1000); // Check every second
    
    return true;
}

bool MemoryManager::detachFromProcess() {
    if (m_processHandle) {
        m_memoryMonitor->stop();
        CloseHandle(m_processHandle);
        m_processHandle = nullptr;
        m_processId = 0;
        
        // Clear scan results
        m_lastScanResults.clear();
        m_currentScanResults.clear();
        m_memoryRegions.clear();
        m_watchedAddresses.clear();
        
        return true;
    }
    return false;
}

bool MemoryManager::readMemory(uintptr_t address, void* buffer, size_t size) {
    if (!m_processHandle) {
        m_lastError = "No process attached";
        return false;
    }
    
    if (!isValidAddress(address)) {
        m_lastError = QString("Invalid address: 0x%1").arg(address, 0, 16);
        return false;
    }
    
    SIZE_T bytesRead;
    if (!ReadProcessMemory(m_processHandle, reinterpret_cast<LPCVOID>(address), 
                          buffer, size, &bytesRead)) {
        m_lastError = QString("ReadProcessMemory failed. Error: %1").arg(GetLastError());
        return false;
    }
    
    if (bytesRead != size) {
        m_lastError = QString("Partial read: %1/%2 bytes").arg(bytesRead).arg(size);
        return false;
    }
    
    return true;
}

bool MemoryManager::writeMemory(uintptr_t address, const void* data, size_t size) {
    if (!m_processHandle) {
        m_lastError = "No process attached";
        return false;
    }
    
    if (!isValidAddress(address)) {
        m_lastError = QString("Invalid address: 0x%1").arg(address, 0, 16);
        return false;
    }
    
    // Store old value for change notification
    std::vector<uint8_t> oldValue(size);
    bool hadOldValue = readMemory(address, oldValue.data(), size);
    
    SIZE_T bytesWritten;
    if (!WriteProcessMemory(m_processHandle, reinterpret_cast<LPVOID>(address), 
                           data, size, &bytesWritten)) {
        m_lastError = QString("WriteProcessMemory failed. Error: %1").arg(GetLastError());
        return false;
    }
    
    if (bytesWritten != size) {
        m_lastError = QString("Partial write: %1/%2 bytes").arg(bytesWritten).arg(size);
        return false;
    }
    
    // Emit change notification
    if (hadOldValue) {
        QByteArray oldData(reinterpret_cast<const char*>(oldValue.data()), size);
        QByteArray newData(reinterpret_cast<const char*>(data), size);
        emit memoryChanged(address, oldData, newData);
    }
    
    return true;
}

std::vector<ScanResult> MemoryManager::scanMemory(const std::vector<uint8_t>& pattern, 
                                                 const std::vector<uint8_t>& mask) {
    std::vector<ScanResult> results;
    
    if (!m_processHandle) {
        m_lastError = "No process attached";
        return results;
    }
    
    if (pattern.empty()) {
        m_lastError = "Empty pattern";
        return results;
    }
    
    emit scanProgress(0, "Starting memory scan...");
    
    // Use provided mask or create default mask
    std::vector<uint8_t> scanMask = mask.empty() ? createMask(pattern) : mask;
    
    // Scan each memory region
    for (size_t i = 0; i < m_memoryRegions.size(); ++i) {
        const auto& region = m_memoryRegions[i];
        
        // Skip non-readable regions
        if (!region.isReadable) {
            continue;
        }
        
        emit scanProgress(static_cast<int>((i * 100) / m_memoryRegions.size()), 
                         QString("Scanning region 0x%1...").arg(region.baseAddress, 0, 16));
        
        scanRegion(region, pattern, scanMask, results);
    }
    
    m_lastScanResults = results;
    emit scanProgress(100, QString("Scan complete. Found %1 results.").arg(results.size()));
    emit scanComplete(results.size());
    
    return results;
}

std::vector<ScanResult> MemoryManager::scanForValue(const void* value, size_t valueSize, ValueType type) {
    std::vector<ScanResult> results;
    
    if (!m_processHandle) {
        m_lastError = "No process attached";
        return results;
    }
    
    emit scanProgress(0, "Starting value scan...");
    
    // Scan each memory region
    for (size_t i = 0; i < m_memoryRegions.size(); ++i) {
        const auto& region = m_memoryRegions[i];
        
        if (!region.isReadable) {
            continue;
        }
        
        emit scanProgress(static_cast<int>((i * 100) / m_memoryRegions.size()), 
                         QString("Scanning region 0x%1...").arg(region.baseAddress, 0, 16));
        
        scanRegionForValue(region, value, valueSize, type, results);
    }
    
    m_lastScanResults = results;
    emit scanProgress(100, QString("Value scan complete. Found %1 results.").arg(results.size()));
    emit scanComplete(results.size());
    
    return results;
}

std::vector<ScanResult> MemoryManager::scanForString(const std::string& text, bool caseSensitive) {
    std::vector<uint8_t> pattern;
    
    if (caseSensitive) {
        pattern.assign(text.begin(), text.end());
    } else {
        // Convert to lowercase for case-insensitive search
        std::string lowerText = text;
        std::transform(lowerText.begin(), lowerText.end(), lowerText.begin(), ::tolower);
        pattern.assign(lowerText.begin(), lowerText.end());
    }
    
    return scanMemory(pattern);
}

std::vector<MemoryRegion> MemoryManager::getMemoryRegions() {
    std::vector<MemoryRegion> regions;
    
    if (!m_processHandle) {
        return regions;
    }
    
    MEMORY_BASIC_INFORMATION mbi;
    uintptr_t address = 0;
    
    while (VirtualQueryEx(m_processHandle, reinterpret_cast<LPCVOID>(address), &mbi, sizeof(mbi))) {
        if (mbi.State == MEM_COMMIT) {
            MemoryRegion region;
            region.baseAddress = reinterpret_cast<uintptr_t>(mbi.BaseAddress);
            region.size = mbi.RegionSize;
            region.protection = mbi.Protect;
            region.isReadable = (mbi.Protect & (PAGE_READONLY | PAGE_READWRITE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE)) != 0;
            region.isWritable = (mbi.Protect & (PAGE_READWRITE | PAGE_EXECUTE_READWRITE)) != 0;
            region.isExecutable = (mbi.Protect & (PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE)) != 0;
            
            regions.push_back(region);
        }
        
        address = reinterpret_cast<uintptr_t>(mbi.BaseAddress) + mbi.RegionSize;
    }
    
    return regions;
}

bool MemoryManager::protectMemory(uintptr_t address, size_t size, DWORD newProtection, DWORD* oldProtection) {
    if (!m_processHandle) {
        m_lastError = "No process attached";
        return false;
    }
    
    DWORD oldProt;
    if (!VirtualProtectEx(m_processHandle, reinterpret_cast<LPVOID>(address), 
                         size, newProtection, &oldProt)) {
        m_lastError = QString("VirtualProtectEx failed. Error: %1").arg(GetLastError());
        return false;
    }
    
    if (oldProtection) {
        *oldProtection = oldProt;
    }
    
    return true;
}

bool MemoryManager::allocateMemory(size_t size, uintptr_t* allocatedAddress, DWORD protection) {
    if (!m_processHandle) {
        m_lastError = "No process attached";
        return false;
    }
    
    LPVOID memory = VirtualAllocEx(m_processHandle, nullptr, size, 
                                  MEM_COMMIT | MEM_RESERVE, protection);
    if (!memory) {
        m_lastError = QString("VirtualAllocEx failed. Error: %1").arg(GetLastError());
        return false;
    }
    
    *allocatedAddress = reinterpret_cast<uintptr_t>(memory);
    m_allocatedMemory.push_back(*allocatedAddress);
    
    return true;
}

bool MemoryManager::freeMemory(uintptr_t address) {
    if (!m_processHandle) {
        m_lastError = "No process attached";
        return false;
    }
    
    if (!VirtualFreeEx(m_processHandle, reinterpret_cast<LPVOID>(address), 0, MEM_RELEASE)) {
        m_lastError = QString("VirtualFreeEx failed. Error: %1").arg(GetLastError());
        return false;
    }
    
    // Remove from tracking
    auto it = std::find(m_allocatedMemory.begin(), m_allocatedMemory.end(), address);
    if (it != m_allocatedMemory.end()) {
        m_allocatedMemory.erase(it);
    }
    
    return true;
}

void MemoryManager::addOffset(const QString& name, uintptr_t offset) {
    m_offsets[name] = offset;
}

uintptr_t MemoryManager::getOffset(const QString& name) const {
    auto it = m_offsets.find(name);
    return (it != m_offsets.end()) ? it->second : 0;
}

void MemoryManager::removeOffset(const QString& name) {
    m_offsets.erase(name);
}

void MemoryManager::clearOffsets() {
    m_offsets.clear();
}

uintptr_t MemoryManager::followPointerChain(uintptr_t baseAddress, const std::vector<uintptr_t>& offsets) {
    uintptr_t currentAddress = baseAddress;
    
    for (size_t i = 0; i < offsets.size(); ++i) {
        uintptr_t pointer;
        if (!readValue(currentAddress, pointer)) {
            return 0;
        }
        
        currentAddress = pointer + offsets[i];
        
        // For the last offset, don't dereference
        if (i == offsets.size() - 1) {
            return currentAddress;
        }
    }
    
    return currentAddress;
}

bool MemoryManager::isValidAddress(uintptr_t address) {
    if (!m_processHandle) {
        return false;
    }
    
    MEMORY_BASIC_INFORMATION mbi;
    if (!VirtualQueryEx(m_processHandle, reinterpret_cast<LPCVOID>(address), &mbi, sizeof(mbi))) {
        return false;
    }
    
    return (mbi.State == MEM_COMMIT) && (mbi.Protect != PAGE_NOACCESS);
}

std::vector<uint8_t> MemoryManager::createMask(const std::vector<uint8_t>& pattern) {
    std::vector<uint8_t> mask(pattern.size(), 0xFF);
    return mask;
}

bool MemoryManager::compareWithMask(const uint8_t* data, const uint8_t* pattern, 
                                   const uint8_t* mask, size_t size) {
    for (size_t i = 0; i < size; ++i) {
        if ((data[i] & mask[i]) != (pattern[i] & mask[i])) {
            return false;
        }
    }
    return true;
}

void MemoryManager::scanRegion(const MemoryRegion& region, const std::vector<uint8_t>& pattern, 
                              const std::vector<uint8_t>& mask, std::vector<ScanResult>& results) {
    const size_t bufferSize = 4096; // 4KB buffer
    std::vector<uint8_t> buffer(bufferSize);
    
    for (uintptr_t addr = region.baseAddress; addr < region.baseAddress + region.size; addr += bufferSize - pattern.size() + 1) {
        size_t readSize = std::min(bufferSize, static_cast<size_t>(region.baseAddress + region.size - addr));
        
        if (!readMemory(addr, buffer.data(), readSize)) {
            continue;
        }
        
        // Search for pattern in buffer
        for (size_t i = 0; i <= readSize - pattern.size(); ++i) {
            if (compareWithMask(buffer.data() + i, pattern.data(), mask.data(), pattern.size())) {
                ScanResult result;
                result.address = addr + i;
                result.value = std::vector<uint8_t>(buffer.begin() + i, buffer.begin() + i + pattern.size());
                result.size = pattern.size();
                results.push_back(result);
            }
        }
    }
}

void MemoryManager::scanRegionForValue(const MemoryRegion& region, const void* value, 
                                      size_t valueSize, ValueType type, std::vector<ScanResult>& results) {
    const size_t bufferSize = 4096;
    std::vector<uint8_t> buffer(bufferSize);
    const uint8_t* searchValue = static_cast<const uint8_t*>(value);
    
    for (uintptr_t addr = region.baseAddress; addr < region.baseAddress + region.size; addr += bufferSize - valueSize + 1) {
        size_t readSize = std::min(bufferSize, static_cast<size_t>(region.baseAddress + region.size - addr));
        
        if (!readMemory(addr, buffer.data(), readSize)) {
            continue;
        }
        
        // Search for value in buffer
        for (size_t i = 0; i <= readSize - valueSize; ++i) {
            if (memcmp(buffer.data() + i, searchValue, valueSize) == 0) {
                ScanResult result;
                result.address = addr + i;
                result.value = std::vector<uint8_t>(buffer.begin() + i, buffer.begin() + i + valueSize);
                result.size = valueSize;
                results.push_back(result);
            }
        }
    }
}

void MemoryManager::monitorMemoryChanges() {
    for (auto& [address, oldValue] : m_watchedAddresses) {
        std::vector<uint8_t> currentValue(oldValue.size());
        if (readMemory(address, currentValue.data(), currentValue.size())) {
            if (currentValue != oldValue) {
                QByteArray oldData(reinterpret_cast<const char*>(oldValue.data()), oldValue.size());
                QByteArray newData(reinterpret_cast<const char*>(currentValue.data()), currentValue.size());
                emit memoryChanged(address, oldData, newData);
                oldValue = currentValue;
            }
        }
    }
}

void MemoryManager::resetScan() {
    m_lastScanResults.clear();
    m_currentScanResults.clear();
}