#pragma once

#include <QtCore/QObject>
#include <QtCore/QTimer>
#include <QtCore/QDateTime>
#include <QtCore/QJsonObject>
#include <QtCore/QJsonArray>
#include <QtCore/QMutex>
#include <QtCore/QThread>
#include <QtCore/QProcess>
#include <QtWidgets/QSystemTrayIcon>
#include <memory>
#include <vector>
#include <map>

class StatusMonitor : public QObject {
    Q_OBJECT

public:
    enum SystemStatus {
        Unknown = 0,
        Healthy = 1,
        Warning = 2,
        Critical = 3,
        Error = 4
    };
    
    enum ComponentStatus {
        Offline = 0,
        Starting = 1,
        Running = 2,
        Stopping = 3,
        Failed = 4,
        Maintenance = 5
    };
    
    struct SystemMetrics {
        double cpuUsage;           // Percentage
        double memoryUsage;        // Percentage
        qint64 memoryUsedMB;       // MB
        qint64 memoryTotalMB;      // MB
        double diskUsage;          // Percentage
        qint64 diskFreeMB;         // MB
        qint64 networkBytesIn;     // Bytes
        qint64 networkBytesOut;    // Bytes
        int processCount;          // Number of processes
        int threadCount;           // Number of threads
        double temperature;        // Celsius (if available)
        QDateTime timestamp;
        
        SystemMetrics() : cpuUsage(0), memoryUsage(0), memoryUsedMB(0), 
                         memoryTotalMB(0), diskUsage(0), diskFreeMB(0),
                         networkBytesIn(0), networkBytesOut(0), 
                         processCount(0), threadCount(0), temperature(0) {
            timestamp = QDateTime::currentDateTime();
        }
    };
    
    struct ComponentInfo {
        QString name;
        ComponentStatus status;
        QString description;
        QDateTime lastUpdate;
        QDateTime startTime;
        qint64 uptime;             // Seconds
        int errorCount;
        int warningCount;
        QJsonObject metadata;
        
        ComponentInfo() : status(Offline), uptime(0), errorCount(0), warningCount(0) {
            lastUpdate = QDateTime::currentDateTime();
        }
    };
    
    struct PerformanceMetrics {
        QString operation;
        qint64 executionTime;      // Milliseconds
        qint64 memoryUsed;         // Bytes
        bool success;
        QDateTime timestamp;
        QJsonObject details;
        
        PerformanceMetrics() : executionTime(0), memoryUsed(0), success(false) {
            timestamp = QDateTime::currentDateTime();
        }
    };
    
    struct GameConnectionInfo {
        bool connected;
        QString gameVersion;
        QString processName;
        quint32 processId;
        uintptr_t baseAddress;
        qint64 connectionTime;
        int injectionAttempts;
        bool anticheatDetected;
        QString lastError;
        QDateTime lastUpdate;
        
        GameConnectionInfo() : connected(false), processId(0), baseAddress(0),
                              connectionTime(0), injectionAttempts(0), 
                              anticheatDetected(false) {
            lastUpdate = QDateTime::currentDateTime();
        }
    };

    explicit StatusMonitor(QObject* parent = nullptr);
    ~StatusMonitor();
    
    // System monitoring
    void startMonitoring();
    void stopMonitoring();
    bool isMonitoring() const { return m_monitoring; }
    
    // Configuration
    void setUpdateInterval(int milliseconds);
    void setMetricsRetentionTime(int hours);
    void setAlertThresholds(double cpuThreshold, double memoryThreshold, double diskThreshold);
    void enableSystemTrayNotifications(bool enabled);
    
    // Component management
    void registerComponent(const QString& name, const QString& description = QString());
    void updateComponentStatus(const QString& name, ComponentStatus status, 
                              const QString& description = QString(),
                              const QJsonObject& metadata = QJsonObject());
    void removeComponent(const QString& name);
    
    // Performance tracking
    void recordPerformance(const QString& operation, qint64 executionTime, 
                          qint64 memoryUsed = 0, bool success = true,
                          const QJsonObject& details = QJsonObject());
    void startPerformanceTimer(const QString& operation);
    qint64 stopPerformanceTimer(const QString& operation, bool success = true,
                               const QJsonObject& details = QJsonObject());
    
    // Game connection monitoring
    void updateGameConnection(bool connected, const QString& gameVersion = QString(),
                             const QString& processName = QString(), quint32 processId = 0,
                             uintptr_t baseAddress = 0);
    void recordInjectionAttempt(bool success, const QString& error = QString());
    void setAnticheatDetected(bool detected);
    
    // Data retrieval
    SystemMetrics getCurrentMetrics() const;
    std::vector<SystemMetrics> getMetricsHistory(int count = 100) const;
    std::map<QString, ComponentInfo> getComponentStatuses() const;
    ComponentInfo getComponentStatus(const QString& name) const;
    std::vector<PerformanceMetrics> getPerformanceHistory(const QString& operation = QString(), 
                                                         int count = 100) const;
    GameConnectionInfo getGameConnectionInfo() const;
    
    // Status assessment
    SystemStatus getOverallStatus() const;
    QJsonObject getStatusReport() const;
    QJsonObject getDetailedReport() const;
    std::vector<QString> getActiveAlerts() const;
    
    // Statistics
    QJsonObject getStatistics() const;
    double getAveragePerformance(const QString& operation, int hours = 24) const;
    double getSystemLoad() const;
    qint64 getUptime() const;
    
    // Alerts and notifications
    void addCustomAlert(const QString& id, const QString& message, 
                       SystemStatus severity = Warning);
    void removeCustomAlert(const QString& id);
    void clearAllAlerts();
    
    // Export and logging
    void exportMetrics(const QString& filePath, const QDateTime& start = QDateTime(),
                      const QDateTime& end = QDateTime()) const;
    void enableAutoExport(const QString& directory, int intervalHours = 24);
    void disableAutoExport();

signals:
    void metricsUpdated(const SystemMetrics& metrics);
    void componentStatusChanged(const QString& name, ComponentStatus status);
    void performanceRecorded(const PerformanceMetrics& metrics);
    void gameConnectionChanged(bool connected);
    void alertTriggered(const QString& message, SystemStatus severity);
    void alertCleared(const QString& alertId);
    void systemStatusChanged(SystemStatus status);
    void criticalErrorDetected(const QString& error);

private slots:
    void updateMetrics();
    void checkAlerts();
    void cleanupOldData();
    void autoExportMetrics();
    void handleSystemTrayActivation(QSystemTrayIcon::ActivationReason reason);

private:
    // System metrics collection
    SystemMetrics collectSystemMetrics();
    double getCpuUsage();
    void getMemoryInfo(qint64& used, qint64& total);
    double getDiskUsage();
    void getNetworkStats(qint64& bytesIn, qint64& bytesOut);
    int getProcessCount();
    int getThreadCount();
    double getSystemTemperature();
    
    // Alert management
    void checkSystemAlerts(const SystemMetrics& metrics);
    void checkComponentAlerts();
    void triggerAlert(const QString& message, SystemStatus severity, 
                     const QString& alertId = QString());
    void clearAlert(const QString& alertId);
    
    // Data management
    void addMetricsToHistory(const SystemMetrics& metrics);
    void cleanupMetricsHistory();
    void cleanupPerformanceHistory();
    
    // Utility functions
    QString statusToString(SystemStatus status) const;
    QString componentStatusToString(ComponentStatus status) const;
    QJsonObject metricsToJson(const SystemMetrics& metrics) const;
    QJsonObject componentToJson(const ComponentInfo& component) const;
    QJsonObject performanceToJson(const PerformanceMetrics& performance) const;
    
    // Member variables
    bool m_monitoring;
    QDateTime m_startTime;
    
    // Timers
    QTimer* m_updateTimer;
    QTimer* m_alertTimer;
    QTimer* m_cleanupTimer;
    QTimer* m_exportTimer;
    
    // Configuration
    int m_updateInterval;          // Milliseconds
    int m_metricsRetentionHours;
    double m_cpuThreshold;
    double m_memoryThreshold;
    double m_diskThreshold;
    bool m_systemTrayEnabled;
    
    // Data storage
    mutable QMutex m_metricsMutex;
    std::vector<SystemMetrics> m_metricsHistory;
    static const int MAX_METRICS_HISTORY = 10000;
    
    mutable QMutex m_componentsMutex;
    std::map<QString, ComponentInfo> m_components;
    
    mutable QMutex m_performanceMutex;
    std::vector<PerformanceMetrics> m_performanceHistory;
    std::map<QString, QDateTime> m_performanceTimers;
    static const int MAX_PERFORMANCE_HISTORY = 5000;
    
    mutable QMutex m_gameInfoMutex;
    GameConnectionInfo m_gameInfo;
    
    mutable QMutex m_alertsMutex;
    std::map<QString, QString> m_activeAlerts;
    std::map<QString, SystemStatus> m_alertSeverities;
    
    // System tray
    QSystemTrayIcon* m_systemTray;
    
    // Auto export
    QString m_exportDirectory;
    bool m_autoExportEnabled;
    
    // Platform-specific handles
#ifdef Q_OS_WIN
    void* m_pdh_query;
    void* m_pdh_counter_cpu;
#endif
};

// Implementation

StatusMonitor::StatusMonitor(QObject* parent)
    : QObject(parent)
    , m_monitoring(false)
    , m_updateInterval(1000)  // 1 second
    , m_metricsRetentionHours(24)
    , m_cpuThreshold(80.0)
    , m_memoryThreshold(85.0)
    , m_diskThreshold(90.0)
    , m_systemTrayEnabled(false)
    , m_autoExportEnabled(false)
    , m_systemTray(nullptr)
#ifdef Q_OS_WIN
    , m_pdh_query(nullptr)
    , m_pdh_counter_cpu(nullptr)
#endif
{
    m_startTime = QDateTime::currentDateTime();
    
    // Initialize timers
    m_updateTimer = new QTimer(this);
    m_alertTimer = new QTimer(this);
    m_cleanupTimer = new QTimer(this);
    m_exportTimer = new QTimer(this);
    
    connect(m_updateTimer, &QTimer::timeout, this, &StatusMonitor::updateMetrics);
    connect(m_alertTimer, &QTimer::timeout, this, &StatusMonitor::checkAlerts);
    connect(m_cleanupTimer, &QTimer::timeout, this, &StatusMonitor::cleanupOldData);
    connect(m_exportTimer, &QTimer::timeout, this, &StatusMonitor::autoExportMetrics);
    
    // Set timer intervals
    m_updateTimer->setInterval(m_updateInterval);
    m_alertTimer->setInterval(5000);    // Check alerts every 5 seconds
    m_cleanupTimer->setInterval(3600000); // Cleanup every hour
    
    // Initialize system tray if available
    if (QSystemTrayIcon::isSystemTrayAvailable()) {
        m_systemTray = new QSystemTrayIcon(this);
        connect(m_systemTray, &QSystemTrayIcon::activated,
                this, &StatusMonitor::handleSystemTrayActivation);
    }
    
    // Register core components
    registerComponent("StatusMonitor", "System status monitoring service");
    updateComponentStatus("StatusMonitor", Running, "Initialized successfully");
}

StatusMonitor::~StatusMonitor() {
    stopMonitoring();
    
#ifdef Q_OS_WIN
    // Cleanup PDH resources
    if (m_pdh_query) {
        // PdhCloseQuery(m_pdh_query);
    }
#endif
}

void StatusMonitor::startMonitoring() {
    if (m_monitoring) {
        return;
    }
    
    m_monitoring = true;
    
    // Start timers
    m_updateTimer->start();
    m_alertTimer->start();
    m_cleanupTimer->start();
    
    // Initial metrics collection
    updateMetrics();
    
    updateComponentStatus("StatusMonitor", Running, "Monitoring started");
    emit systemStatusChanged(getOverallStatus());
}

void StatusMonitor::stopMonitoring() {
    if (!m_monitoring) {
        return;
    }
    
    m_monitoring = false;
    
    // Stop timers
    m_updateTimer->stop();
    m_alertTimer->stop();
    m_cleanupTimer->stop();
    m_exportTimer->stop();
    
    updateComponentStatus("StatusMonitor", Stopping, "Monitoring stopped");
    emit systemStatusChanged(getOverallStatus());
}

void StatusMonitor::setUpdateInterval(int milliseconds) {
    m_updateInterval = milliseconds;
    m_updateTimer->setInterval(milliseconds);
}

void StatusMonitor::setMetricsRetentionTime(int hours) {
    m_metricsRetentionHours = hours;
}

void StatusMonitor::setAlertThresholds(double cpuThreshold, double memoryThreshold, double diskThreshold) {
    m_cpuThreshold = cpuThreshold;
    m_memoryThreshold = memoryThreshold;
    m_diskThreshold = diskThreshold;
}

void StatusMonitor::enableSystemTrayNotifications(bool enabled) {
    m_systemTrayEnabled = enabled;
    
    if (m_systemTray) {
        if (enabled) {
            m_systemTray->show();
        } else {
            m_systemTray->hide();
        }
    }
}

void StatusMonitor::registerComponent(const QString& name, const QString& description) {
    QMutexLocker locker(&m_componentsMutex);
    
    ComponentInfo info;
    info.name = name;
    info.description = description;
    info.status = Offline;
    info.startTime = QDateTime::currentDateTime();
    
    m_components[name] = info;
    
    emit componentStatusChanged(name, Offline);
}

void StatusMonitor::updateComponentStatus(const QString& name, ComponentStatus status,
                                        const QString& description, const QJsonObject& metadata) {
    QMutexLocker locker(&m_componentsMutex);
    
    auto it = m_components.find(name);
    if (it != m_components.end()) {
        ComponentInfo& info = it->second;
        
        // Update status
        ComponentStatus oldStatus = info.status;
        info.status = status;
        info.lastUpdate = QDateTime::currentDateTime();
        
        if (!description.isEmpty()) {
            info.description = description;
        }
        
        if (!metadata.isEmpty()) {
            info.metadata = metadata;
        }
        
        // Calculate uptime
        if (status == Running) {
            info.uptime = info.startTime.secsTo(QDateTime::currentDateTime());
        }
        
        // Track errors and warnings
        if (status == Failed) {
            info.errorCount++;
        }
        
        locker.unlock();
        
        if (oldStatus != status) {
            emit componentStatusChanged(name, status);
        }
    }
}

void StatusMonitor::removeComponent(const QString& name) {
    QMutexLocker locker(&m_componentsMutex);
    m_components.erase(name);
}

void StatusMonitor::recordPerformance(const QString& operation, qint64 executionTime,
                                    qint64 memoryUsed, bool success, const QJsonObject& details) {
    QMutexLocker locker(&m_performanceMutex);
    
    PerformanceMetrics metrics;
    metrics.operation = operation;
    metrics.executionTime = executionTime;
    metrics.memoryUsed = memoryUsed;
    metrics.success = success;
    metrics.details = details;
    
    m_performanceHistory.push_back(metrics);
    
    // Limit history size
    if (m_performanceHistory.size() > MAX_PERFORMANCE_HISTORY) {
        m_performanceHistory.erase(m_performanceHistory.begin());
    }
    
    locker.unlock();
    
    emit performanceRecorded(metrics);
}

void StatusMonitor::startPerformanceTimer(const QString& operation) {
    QMutexLocker locker(&m_performanceMutex);
    m_performanceTimers[operation] = QDateTime::currentDateTime();
}

qint64 StatusMonitor::stopPerformanceTimer(const QString& operation, bool success, const QJsonObject& details) {
    QMutexLocker locker(&m_performanceMutex);
    
    auto it = m_performanceTimers.find(operation);
    if (it != m_performanceTimers.end()) {
        QDateTime startTime = it->second;
        QDateTime endTime = QDateTime::currentDateTime();
        qint64 executionTime = startTime.msecsTo(endTime);
        
        m_performanceTimers.erase(it);
        
        locker.unlock();
        
        recordPerformance(operation, executionTime, 0, success, details);
        
        return executionTime;
    }
    
    return 0;
}

void StatusMonitor::updateGameConnection(bool connected, const QString& gameVersion,
                                       const QString& processName, quint32 processId,
                                       uintptr_t baseAddress) {
    QMutexLocker locker(&m_gameInfoMutex);
    
    bool wasConnected = m_gameInfo.connected;
    
    m_gameInfo.connected = connected;
    m_gameInfo.gameVersion = gameVersion;
    m_gameInfo.processName = processName;
    m_gameInfo.processId = processId;
    m_gameInfo.baseAddress = baseAddress;
    m_gameInfo.lastUpdate = QDateTime::currentDateTime();
    
    if (connected && !wasConnected) {
        m_gameInfo.connectionTime = QDateTime::currentMSecsSinceEpoch();
    }
    
    locker.unlock();
    
    if (wasConnected != connected) {
        emit gameConnectionChanged(connected);
    }
}

void StatusMonitor::recordInjectionAttempt(bool success, const QString& error) {
    QMutexLocker locker(&m_gameInfoMutex);
    
    m_gameInfo.injectionAttempts++;
    
    if (!success && !error.isEmpty()) {
        m_gameInfo.lastError = error;
    }
    
    m_gameInfo.lastUpdate = QDateTime::currentDateTime();
}

void StatusMonitor::setAnticheatDetected(bool detected) {
    QMutexLocker locker(&m_gameInfoMutex);
    
    bool wasDetected = m_gameInfo.anticheatDetected;
    m_gameInfo.anticheatDetected = detected;
    m_gameInfo.lastUpdate = QDateTime::currentDateTime();
    
    locker.unlock();
    
    if (!wasDetected && detected) {
        triggerAlert("Anticheat detection warning", Critical, "anticheat_detected");
    } else if (wasDetected && !detected) {
        clearAlert("anticheat_detected");
    }
}

StatusMonitor::SystemMetrics StatusMonitor::getCurrentMetrics() const {
    QMutexLocker locker(&m_metricsMutex);
    
    if (!m_metricsHistory.empty()) {
        return m_metricsHistory.back();
    }
    
    return SystemMetrics();
}

std::vector<StatusMonitor::SystemMetrics> StatusMonitor::getMetricsHistory(int count) const {
    QMutexLocker locker(&m_metricsMutex);
    
    std::vector<SystemMetrics> result;
    int startIndex = std::max(0, static_cast<int>(m_metricsHistory.size()) - count);
    
    for (int i = startIndex; i < m_metricsHistory.size(); ++i) {
        result.push_back(m_metricsHistory[i]);
    }
    
    return result;
}

std::map<QString, StatusMonitor::ComponentInfo> StatusMonitor::getComponentStatuses() const {
    QMutexLocker locker(&m_componentsMutex);
    return m_components;
}

StatusMonitor::ComponentInfo StatusMonitor::getComponentStatus(const QString& name) const {
    QMutexLocker locker(&m_componentsMutex);
    
    auto it = m_components.find(name);
    if (it != m_components.end()) {
        return it->second;
    }
    
    return ComponentInfo();
}

StatusMonitor::GameConnectionInfo StatusMonitor::getGameConnectionInfo() const {
    QMutexLocker locker(&m_gameInfoMutex);
    return m_gameInfo;
}

StatusMonitor::SystemStatus StatusMonitor::getOverallStatus() const {
    SystemMetrics metrics = getCurrentMetrics();
    
    // Check system metrics
    if (metrics.cpuUsage > m_cpuThreshold || 
        metrics.memoryUsage > m_memoryThreshold || 
        metrics.diskUsage > m_diskThreshold) {
        return Critical;
    }
    
    // Check component statuses
    auto components = getComponentStatuses();
    bool hasWarnings = false;
    
    for (const auto& pair : components) {
        const ComponentInfo& info = pair.second;
        
        if (info.status == Failed) {
            return Error;
        } else if (info.status == Maintenance || info.errorCount > 0) {
            hasWarnings = true;
        }
    }
    
    // Check active alerts
    QMutexLocker locker(&m_alertsMutex);
    if (!m_activeAlerts.empty()) {
        for (const auto& pair : m_alertSeverities) {
            if (pair.second == Critical || pair.second == Error) {
                return pair.second;
            } else if (pair.second == Warning) {
                hasWarnings = true;
            }
        }
    }
    
    return hasWarnings ? Warning : Healthy;
}

QJsonObject StatusMonitor::getStatusReport() const {
    QJsonObject report;
    
    // Overall status
    report["overall_status"] = statusToString(getOverallStatus());
    report["timestamp"] = QDateTime::currentDateTime().toString(Qt::ISODate);
    report["uptime_seconds"] = getUptime();
    
    // System metrics
    SystemMetrics metrics = getCurrentMetrics();
    report["system_metrics"] = metricsToJson(metrics);
    
    // Component statuses
    QJsonObject components;
    auto componentMap = getComponentStatuses();
    for (const auto& pair : componentMap) {
        components[pair.first] = componentStatusToString(pair.second.status);
    }
    report["components"] = components;
    
    // Game connection
    GameConnectionInfo gameInfo = getGameConnectionInfo();
    QJsonObject gameStatus;
    gameStatus["connected"] = gameInfo.connected;
    gameStatus["process_name"] = gameInfo.processName;
    gameStatus["process_id"] = static_cast<qint64>(gameInfo.processId);
    gameStatus["anticheat_detected"] = gameInfo.anticheatDetected;
    report["game_connection"] = gameStatus;
    
    // Active alerts
    QJsonArray alerts;
    QMutexLocker locker(&m_alertsMutex);
    for (const auto& pair : m_activeAlerts) {
        QJsonObject alert;
        alert["id"] = pair.first;
        alert["message"] = pair.second;
        alert["severity"] = statusToString(m_alertSeverities.at(pair.first));
        alerts.append(alert);
    }
    report["active_alerts"] = alerts;
    
    return report;
}

void StatusMonitor::updateMetrics() {
    if (!m_monitoring) {
        return;
    }
    
    SystemMetrics metrics = collectSystemMetrics();
    addMetricsToHistory(metrics);
    
    emit metricsUpdated(metrics);
}

void StatusMonitor::checkAlerts() {
    if (!m_monitoring) {
        return;
    }
    
    SystemMetrics metrics = getCurrentMetrics();
    checkSystemAlerts(metrics);
    checkComponentAlerts();
}

StatusMonitor::SystemMetrics StatusMonitor::collectSystemMetrics() {
    SystemMetrics metrics;
    
    metrics.cpuUsage = getCpuUsage();
    getMemoryInfo(metrics.memoryUsedMB, metrics.memoryTotalMB);
    
    if (metrics.memoryTotalMB > 0) {
        metrics.memoryUsage = (static_cast<double>(metrics.memoryUsedMB) / metrics.memoryTotalMB) * 100.0;
    }
    
    metrics.diskUsage = getDiskUsage();
    getNetworkStats(metrics.networkBytesIn, metrics.networkBytesOut);
    metrics.processCount = getProcessCount();
    metrics.threadCount = getThreadCount();
    metrics.temperature = getSystemTemperature();
    
    return metrics;
}

void StatusMonitor::addMetricsToHistory(const SystemMetrics& metrics) {
    QMutexLocker locker(&m_metricsMutex);
    
    m_metricsHistory.push_back(metrics);
    
    // Limit history size
    if (m_metricsHistory.size() > MAX_METRICS_HISTORY) {
        m_metricsHistory.erase(m_metricsHistory.begin());
    }
}

void StatusMonitor::checkSystemAlerts(const SystemMetrics& metrics) {
    // CPU usage alert
    if (metrics.cpuUsage > m_cpuThreshold) {
        triggerAlert(QString("High CPU usage: %1%").arg(metrics.cpuUsage, 0, 'f', 1),
                    Warning, "high_cpu");
    } else {
        clearAlert("high_cpu");
    }
    
    // Memory usage alert
    if (metrics.memoryUsage > m_memoryThreshold) {
        triggerAlert(QString("High memory usage: %1%").arg(metrics.memoryUsage, 0, 'f', 1),
                    Warning, "high_memory");
    } else {
        clearAlert("high_memory");
    }
    
    // Disk usage alert
    if (metrics.diskUsage > m_diskThreshold) {
        triggerAlert(QString("High disk usage: %1%").arg(metrics.diskUsage, 0, 'f', 1),
                    Critical, "high_disk");
    } else {
        clearAlert("high_disk");
    }
}

void StatusMonitor::triggerAlert(const QString& message, SystemStatus severity, const QString& alertId) {
    QString id = alertId.isEmpty() ? QString::number(QDateTime::currentMSecsSinceEpoch()) : alertId;
    
    {
        QMutexLocker locker(&m_alertsMutex);
        m_activeAlerts[id] = message;
        m_alertSeverities[id] = severity;
    }
    
    emit alertTriggered(message, severity);
    
    // System tray notification
    if (m_systemTrayEnabled && m_systemTray && m_systemTray->isVisible()) {
        QSystemTrayIcon::MessageIcon icon = QSystemTrayIcon::Information;
        if (severity == Critical || severity == Error) {
            icon = QSystemTrayIcon::Critical;
        } else if (severity == Warning) {
            icon = QSystemTrayIcon::Warning;
        }
        
        m_systemTray->showMessage("GhostPulse Status Alert", message, icon, 5000);
    }
}

void StatusMonitor::clearAlert(const QString& alertId) {
    {
        QMutexLocker locker(&m_alertsMutex);
        m_activeAlerts.erase(alertId);
        m_alertSeverities.erase(alertId);
    }
    
    emit alertCleared(alertId);
}

qint64 StatusMonitor::getUptime() const {
    return m_startTime.secsTo(QDateTime::currentDateTime());
}

QString StatusMonitor::statusToString(SystemStatus status) const {
    switch (status) {
        case Unknown: return "Unknown";
        case Healthy: return "Healthy";
        case Warning: return "Warning";
        case Critical: return "Critical";
        case Error: return "Error";
        default: return "Unknown";
    }
}

QString StatusMonitor::componentStatusToString(ComponentStatus status) const {
    switch (status) {
        case Offline: return "Offline";
        case Starting: return "Starting";
        case Running: return "Running";
        case Stopping: return "Stopping";
        case Failed: return "Failed";
        case Maintenance: return "Maintenance";
        default: return "Unknown";
    }
}

QJsonObject StatusMonitor::metricsToJson(const SystemMetrics& metrics) const {
    QJsonObject json;
    json["cpu_usage"] = metrics.cpuUsage;
    json["memory_usage"] = metrics.memoryUsage;
    json["memory_used_mb"] = metrics.memoryUsedMB;
    json["memory_total_mb"] = metrics.memoryTotalMB;
    json["disk_usage"] = metrics.diskUsage;
    json["disk_free_mb"] = metrics.diskFreeMB;
    json["network_bytes_in"] = metrics.networkBytesIn;
    json["network_bytes_out"] = metrics.networkBytesOut;
    json["process_count"] = metrics.processCount;
    json["thread_count"] = metrics.threadCount;
    json["temperature"] = metrics.temperature;
    json["timestamp"] = metrics.timestamp.toString(Qt::ISODate);
    return json;
}

// Platform-specific implementations would go here
// For now, providing stub implementations

double StatusMonitor::getCpuUsage() {
    // Platform-specific CPU usage implementation
    return 0.0;
}

void StatusMonitor::getMemoryInfo(qint64& used, qint64& total) {
    // Platform-specific memory info implementation
    used = 0;
    total = 0;
}

double StatusMonitor::getDiskUsage() {
    // Platform-specific disk usage implementation
    return 0.0;
}

void StatusMonitor::getNetworkStats(qint64& bytesIn, qint64& bytesOut) {
    // Platform-specific network stats implementation
    bytesIn = 0;
    bytesOut = 0;
}

int StatusMonitor::getProcessCount() {
    // Platform-specific process count implementation
    return 0;
}

int StatusMonitor::getThreadCount() {
    // Platform-specific thread count implementation
    return 0;
}

double StatusMonitor::getSystemTemperature() {
    // Platform-specific temperature implementation
    return 0.0;
}

void StatusMonitor::cleanupOldData() {
    // Implementation for cleaning up old metrics and performance data
}

void StatusMonitor::autoExportMetrics() {
    // Implementation for auto-exporting metrics
}

void StatusMonitor::handleSystemTrayActivation(QSystemTrayIcon::ActivationReason reason) {
    // Implementation for system tray interaction
}

void StatusMonitor::checkComponentAlerts() {
    // Implementation for checking component-specific alerts
}

void StatusMonitor::addCustomAlert(const QString& id, const QString& message, SystemStatus severity) {
    triggerAlert(message, severity, id);
}

void StatusMonitor::removeCustomAlert(const QString& id) {
    clearAlert(id);
}

void StatusMonitor::clearAllAlerts() {
    QMutexLocker locker(&m_alertsMutex);
    m_activeAlerts.clear();
    m_alertSeverities.clear();
}

std::vector<QString> StatusMonitor::getActiveAlerts() const {
    QMutexLocker locker(&m_alertsMutex);
    
    std::vector<QString> alerts;
    for (const auto& pair : m_activeAlerts) {
        alerts.push_back(pair.second);
    }
    
    return alerts;
}

QJsonObject StatusMonitor::getStatistics() const {
    QJsonObject stats;
    
    // Add implementation for detailed statistics
    stats["uptime_seconds"] = getUptime();
    stats["metrics_count"] = static_cast<qint64>(m_metricsHistory.size());
    stats["performance_records"] = static_cast<qint64>(m_performanceHistory.size());
    stats["active_alerts"] = static_cast<qint64>(m_activeAlerts.size());
    stats["registered_components"] = static_cast<qint64>(m_components.size());
    
    return stats;
}

double StatusMonitor::getAveragePerformance(const QString& operation, int hours) const {
    // Implementation for calculating average performance
    return 0.0;
}

double StatusMonitor::getSystemLoad() const {
    SystemMetrics metrics = getCurrentMetrics();
    return (metrics.cpuUsage + metrics.memoryUsage) / 2.0;
}

std::vector<StatusMonitor::PerformanceMetrics> StatusMonitor::getPerformanceHistory(
    const QString& operation, int count) const {
    
    QMutexLocker locker(&m_performanceMutex);
    
    std::vector<PerformanceMetrics> result;
    
    if (operation.isEmpty()) {
        // Return all performance metrics
        int startIndex = std::max(0, static_cast<int>(m_performanceHistory.size()) - count);
        for (int i = startIndex; i < m_performanceHistory.size(); ++i) {
            result.push_back(m_performanceHistory[i]);
        }
    } else {
        // Filter by operation
        int found = 0;
        for (auto it = m_performanceHistory.rbegin(); 
             it != m_performanceHistory.rend() && found < count; ++it) {
            if (it->operation == operation) {
                result.insert(result.begin(), *it);
                found++;
            }
        }
    }
    
    return result;
}

QJsonObject StatusMonitor::getDetailedReport() const {
    QJsonObject report = getStatusReport();
    
    // Add detailed component information
    QJsonObject detailedComponents;
    auto components = getComponentStatuses();
    for (const auto& pair : components) {
        detailedComponents[pair.first] = componentToJson(pair.second);
    }
    report["detailed_components"] = detailedComponents;
    
    // Add performance metrics
    QJsonArray performanceArray;
    auto performance = getPerformanceHistory("", 50);
    for (const auto& perf : performance) {
        performanceArray.append(performanceToJson(perf));
    }
    report["recent_performance"] = performanceArray;
    
    // Add metrics history
    QJsonArray metricsArray;
    auto metrics = getMetricsHistory(20);
    for (const auto& metric : metrics) {
        metricsArray.append(metricsToJson(metric));
    }
    report["metrics_history"] = metricsArray;
    
    return report;
}

QJsonObject StatusMonitor::componentToJson(const ComponentInfo& component) const {
    QJsonObject json;
    json["name"] = component.name;
    json["status"] = componentStatusToString(component.status);
    json["description"] = component.description;
    json["last_update"] = component.lastUpdate.toString(Qt::ISODate);
    json["start_time"] = component.startTime.toString(Qt::ISODate);
    json["uptime_seconds"] = component.uptime;
    json["error_count"] = component.errorCount;
    json["warning_count"] = component.warningCount;
    json["metadata"] = component.metadata;
    return json;
}

QJsonObject StatusMonitor::performanceToJson(const PerformanceMetrics& performance) const {
    QJsonObject json;
    json["operation"] = performance.operation;
    json["execution_time_ms"] = performance.executionTime;
    json["memory_used_bytes"] = performance.memoryUsed;
    json["success"] = performance.success;
    json["timestamp"] = performance.timestamp.toString(Qt::ISODate);
    json["details"] = performance.details;
    return json;
}

void StatusMonitor::exportMetrics(const QString& filePath, const QDateTime& start, const QDateTime& end) const {
    // Implementation for exporting metrics to file
}

void StatusMonitor::enableAutoExport(const QString& directory, int intervalHours) {
    m_exportDirectory = directory;
    m_autoExportEnabled = true;
    m_exportTimer->setInterval(intervalHours * 3600000); // Convert to milliseconds
    m_exportTimer->start();
}

void StatusMonitor::disableAutoExport() {
    m_autoExportEnabled = false;
    m_exportTimer->stop();
}