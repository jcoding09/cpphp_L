#include "injection_manager.h"
#include "logger.h"
#include <QDir>
#include <QFileInfo>
#include <QThread>
#include <QTimer>
#include <QMutexLocker>
#include <windows.h>
#include <tlhelp32.h>
#include <psapi.h>

InjectionManager::InjectionManager(QObject *parent)
    : QObject(parent)
    , m_injectionMethod(InjectionMethod::DLL)
    , m_injectionStatus(InjectionStatus::NotInjected)
    , m_targetProcessId(0)
    , m_injectedModuleHandle(nullptr)
    , m_autoInject(false)
    , m_autoDetect(true)
    , m_stealthMode(true)
    , m_verifyInjection(true)
    , m_retryCount(3)
    , m_retryDelay(1000)
    , m_processMonitorInterval(2000)
{
    // Initialize process monitor timer
    m_processMonitor = new QTimer(this);
    m_processMonitor->setSingleShot(false);
    m_processMonitor->setInterval(m_processMonitorInterval);
    connect(m_processMonitor, &QTimer::timeout, this, &InjectionManager::monitorProcess);
    
    // Initialize injection timer
    m_injectionTimer = new QTimer(this);
    m_injectionTimer->setSingleShot(true);
    connect(m_injectionTimer, &QTimer::timeout, this, &InjectionManager::performInjection);
    
    // Start process monitoring if auto-detect is enabled
    if (m_autoDetect) {
        startProcessMonitoring();
    }
    
    Logger::instance()->info("InjectionManager initialized", "Injection");
}

InjectionManager::~InjectionManager()
{
    if (m_injectionStatus == InjectionStatus::Injected) {
        uninject();
    }
    
    stopProcessMonitoring();
}

void InjectionManager::setTargetProcess(const QString& processName)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_targetProcessName != processName) {
        m_targetProcessName = processName;
        m_targetProcessId = 0;
        
        Logger::instance()->info(QString("Target process set to: %1").arg(processName), "Injection");
        emit targetProcessChanged(processName);
        
        // Try to find the process immediately
        if (m_autoDetect) {
            findTargetProcess();
        }
    }
}

QString InjectionManager::targetProcess() const
{
    QMutexLocker locker(&m_mutex);
    return m_targetProcessName;
}

void InjectionManager::setDllPath(const QString& path)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_dllPath != path) {
        m_dllPath = path;
        Logger::instance()->info(QString("DLL path set to: %1").arg(path), "Injection");
        emit dllPathChanged(path);
    }
}

QString InjectionManager::dllPath() const
{
    QMutexLocker locker(&m_mutex);
    return m_dllPath;
}

void InjectionManager::setInjectionMethod(InjectionMethod method)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_injectionMethod != method) {
        m_injectionMethod = method;
        Logger::instance()->info(QString("Injection method set to: %1").arg(static_cast<int>(method)), "Injection");
        emit injectionMethodChanged(method);
    }
}

InjectionManager::InjectionMethod InjectionManager::injectionMethod() const
{
    QMutexLocker locker(&m_mutex);
    return m_injectionMethod;
}

InjectionManager::InjectionStatus InjectionManager::injectionStatus() const
{
    QMutexLocker locker(&m_mutex);
    return m_injectionStatus;
}

quint32 InjectionManager::targetProcessId() const
{
    QMutexLocker locker(&m_mutex);
    return m_targetProcessId;
}

void InjectionManager::setAutoInject(bool enable)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_autoInject != enable) {
        m_autoInject = enable;
        Logger::instance()->info(QString("Auto-inject %1").arg(enable ? "enabled" : "disabled"), "Injection");
        emit autoInjectChanged(enable);
    }
}

bool InjectionManager::autoInject() const
{
    QMutexLocker locker(&m_mutex);
    return m_autoInject;
}

void InjectionManager::setAutoDetect(bool enable)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_autoDetect != enable) {
        m_autoDetect = enable;
        Logger::instance()->info(QString("Auto-detect %1").arg(enable ? "enabled" : "disabled"), "Injection");
        emit autoDetectChanged(enable);
        
        if (enable) {
            startProcessMonitoring();
        } else {
            stopProcessMonitoring();
        }
    }
}

bool InjectionManager::autoDetect() const
{
    QMutexLocker locker(&m_mutex);
    return m_autoDetect;
}

bool InjectionManager::inject()
{
    QMutexLocker locker(&m_mutex);
    
    if (m_injectionStatus == InjectionStatus::Injected) {
        Logger::instance()->warning("Already injected", "Injection");
        return true;
    }
    
    if (m_injectionStatus == InjectionStatus::Injecting) {
        Logger::instance()->warning("Injection already in progress", "Injection");
        return false;
    }
    
    // Validate inputs
    if (m_targetProcessName.isEmpty()) {
        Logger::instance()->error("Target process name not set", "Injection");
        emit injectionFailed("Target process name not set");
        return false;
    }
    
    if (m_dllPath.isEmpty() || !QFileInfo::exists(m_dllPath)) {
        Logger::instance()->error("DLL path not set or file doesn't exist", "Injection");
        emit injectionFailed("DLL path not set or file doesn't exist");
        return false;
    }
    
    // Find target process if not already found
    if (m_targetProcessId == 0) {
        if (!findTargetProcess()) {
            Logger::instance()->error("Target process not found", "Injection");
            emit injectionFailed("Target process not found");
            return false;
        }
    }
    
    // Start injection
    setInjectionStatus(InjectionStatus::Injecting);
    Logger::instance()->info("Starting injection...", "Injection");
    
    // Perform injection in a separate thread to avoid blocking UI
    QTimer::singleShot(0, this, &InjectionManager::performInjection);
    
    return true;
}

bool InjectionManager::uninject()
{
    QMutexLocker locker(&m_mutex);
    
    if (m_injectionStatus != InjectionStatus::Injected) {
        Logger::instance()->warning("Not currently injected", "Injection");
        return true;
    }
    
    Logger::instance()->info("Starting uninjection...", "Injection");
    setInjectionStatus(InjectionStatus::Uninjecting);
    
    bool success = false;
    
    if (m_injectedModuleHandle && m_targetProcessId != 0) {
        HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, m_targetProcessId);
        if (hProcess) {
            // Get FreeLibrary address
            HMODULE hKernel32 = GetModuleHandleA("kernel32.dll");
            if (hKernel32) {
                FARPROC pFreeLibrary = GetProcAddress(hKernel32, "FreeLibrary");
                if (pFreeLibrary) {
                    // Create remote thread to call FreeLibrary
                    HANDLE hThread = CreateRemoteThread(
                        hProcess,
                        nullptr,
                        0,
                        (LPTHREAD_START_ROUTINE)pFreeLibrary,
                        m_injectedModuleHandle,
                        0,
                        nullptr
                    );
                    
                    if (hThread) {
                        WaitForSingleObject(hThread, INFINITE);
                        CloseHandle(hThread);
                        success = true;
                        Logger::instance()->info("DLL uninjected successfully", "Injection");
                    }
                }
            }
            CloseHandle(hProcess);
        }
    }
    
    // Reset state
    m_injectedModuleHandle = nullptr;
    
    if (success) {
        setInjectionStatus(InjectionStatus::NotInjected);
        emit injectionRemoved();
    } else {
        Logger::instance()->error("Failed to uninject DLL", "Injection");
        setInjectionStatus(InjectionStatus::Injected); // Revert status
        emit injectionFailed("Failed to uninject DLL");
    }
    
    return success;
}

bool InjectionManager::isInjected() const
{
    QMutexLocker locker(&m_mutex);
    return m_injectionStatus == InjectionStatus::Injected;
}

void InjectionManager::startProcessMonitoring()
{
    if (!m_processMonitor->isActive()) {
        m_processMonitor->start();
        Logger::instance()->info("Process monitoring started", "Injection");
    }
}

void InjectionManager::stopProcessMonitoring()
{
    if (m_processMonitor->isActive()) {
        m_processMonitor->stop();
        Logger::instance()->info("Process monitoring stopped", "Injection");
    }
}

void InjectionManager::monitorProcess()
{
    QMutexLocker locker(&m_mutex);
    
    if (m_targetProcessName.isEmpty()) {
        return;
    }
    
    // Check if target process is still running
    if (m_targetProcessId != 0) {
        HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, m_targetProcessId);
        if (!hProcess) {
            // Process is no longer running
            Logger::instance()->info("Target process terminated", "Injection");
            m_targetProcessId = 0;
            m_injectedModuleHandle = nullptr;
            setInjectionStatus(InjectionStatus::NotInjected);
            emit processTerminated();
        } else {
            CloseHandle(hProcess);
        }
    }
    
    // Try to find the process if we don't have it
    if (m_targetProcessId == 0) {
        if (findTargetProcess()) {
            emit processDetected(m_targetProcessId);
            
            // Auto-inject if enabled
            if (m_autoInject && m_injectionStatus == InjectionStatus::NotInjected) {
                Logger::instance()->info("Auto-injecting into detected process", "Injection");
                QTimer::singleShot(1000, this, &InjectionManager::inject); // Small delay
            }
        }
    }
}

bool InjectionManager::findTargetProcess()
{
    if (m_targetProcessName.isEmpty()) {
        return false;
    }
    
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnapshot == INVALID_HANDLE_VALUE) {
        return false;
    }
    
    PROCESSENTRY32W pe32;
    pe32.dwSize = sizeof(PROCESSENTRY32W);
    
    bool found = false;
    if (Process32FirstW(hSnapshot, &pe32)) {
        do {
            QString processName = QString::fromWCharArray(pe32.szExeFile);
            if (processName.compare(m_targetProcessName, Qt::CaseInsensitive) == 0) {
                m_targetProcessId = pe32.th32ProcessID;
                found = true;
                Logger::instance()->info(QString("Target process found: PID %1").arg(m_targetProcessId), "Injection");
                break;
            }
        } while (Process32NextW(hSnapshot, &pe32));
    }
    
    CloseHandle(hSnapshot);
    return found;
}

void InjectionManager::performInjection()
{
    QMutexLocker locker(&m_mutex);
    
    bool success = false;
    QString errorMessage;
    
    switch (m_injectionMethod) {
        case InjectionMethod::DLL:
            success = injectDLL(errorMessage);
            break;
        case InjectionMethod::Shellcode:
            success = injectShellcode(errorMessage);
            break;
        case InjectionMethod::Manual:
            success = injectManual(errorMessage);
            break;
        case InjectionMethod::ProcessHollowing:
            success = injectProcessHollowing(errorMessage);
            break;
        default:
            errorMessage = "Unknown injection method";
            break;
    }
    
    if (success) {
        setInjectionStatus(InjectionStatus::Injected);
        Logger::instance()->info("Injection completed successfully", "Injection");
        emit injectionCompleted();
        
        // Verify injection if enabled
        if (m_verifyInjection) {
            QTimer::singleShot(1000, this, &InjectionManager::verifyInjection);
        }
    } else {
        setInjectionStatus(InjectionStatus::NotInjected);
        Logger::instance()->error(QString("Injection failed: %1").arg(errorMessage), "Injection");
        emit injectionFailed(errorMessage);
    }
}

bool InjectionManager::injectDLL(QString& errorMessage)
{
    HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, m_targetProcessId);
    if (!hProcess) {
        errorMessage = "Failed to open target process";
        return false;
    }
    
    // Allocate memory for DLL path
    QByteArray dllPathBytes = m_dllPath.toLocal8Bit();
    SIZE_T pathSize = dllPathBytes.size() + 1;
    
    LPVOID pRemotePath = VirtualAllocEx(hProcess, nullptr, pathSize, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!pRemotePath) {
        CloseHandle(hProcess);
        errorMessage = "Failed to allocate memory in target process";
        return false;
    }
    
    // Write DLL path to target process
    SIZE_T bytesWritten;
    if (!WriteProcessMemory(hProcess, pRemotePath, dllPathBytes.constData(), pathSize, &bytesWritten)) {
        VirtualFreeEx(hProcess, pRemotePath, 0, MEM_RELEASE);
        CloseHandle(hProcess);
        errorMessage = "Failed to write DLL path to target process";
        return false;
    }
    
    // Get LoadLibraryA address
    HMODULE hKernel32 = GetModuleHandleA("kernel32.dll");
    if (!hKernel32) {
        VirtualFreeEx(hProcess, pRemotePath, 0, MEM_RELEASE);
        CloseHandle(hProcess);
        errorMessage = "Failed to get kernel32.dll handle";
        return false;
    }
    
    FARPROC pLoadLibrary = GetProcAddress(hKernel32, "LoadLibraryA");
    if (!pLoadLibrary) {
        VirtualFreeEx(hProcess, pRemotePath, 0, MEM_RELEASE);
        CloseHandle(hProcess);
        errorMessage = "Failed to get LoadLibraryA address";
        return false;
    }
    
    // Create remote thread
    HANDLE hThread = CreateRemoteThread(
        hProcess,
        nullptr,
        0,
        (LPTHREAD_START_ROUTINE)pLoadLibrary,
        pRemotePath,
        0,
        nullptr
    );
    
    if (!hThread) {
        VirtualFreeEx(hProcess, pRemotePath, 0, MEM_RELEASE);
        CloseHandle(hProcess);
        errorMessage = "Failed to create remote thread";
        return false;
    }
    
    // Wait for thread completion
    WaitForSingleObject(hThread, INFINITE);
    
    // Get thread exit code (module handle)
    DWORD exitCode;
    GetExitCodeThread(hThread, &exitCode);
    m_injectedModuleHandle = (HMODULE)exitCode;
    
    // Cleanup
    CloseHandle(hThread);
    VirtualFreeEx(hProcess, pRemotePath, 0, MEM_RELEASE);
    CloseHandle(hProcess);
    
    if (!m_injectedModuleHandle) {
        errorMessage = "LoadLibrary failed in target process";
        return false;
    }
    
    return true;
}

bool InjectionManager::injectShellcode(QString& errorMessage)
{
    // Placeholder for shellcode injection
    errorMessage = "Shellcode injection not implemented yet";
    return false;
}

bool InjectionManager::injectManual(QString& errorMessage)
{
    // Placeholder for manual DLL mapping
    errorMessage = "Manual injection not implemented yet";
    return false;
}

bool InjectionManager::injectProcessHollowing(QString& errorMessage)
{
    // Placeholder for process hollowing
    errorMessage = "Process hollowing not implemented yet";
    return false;
}

void InjectionManager::verifyInjection()
{
    // Placeholder for injection verification
    Logger::instance()->info("Injection verification completed", "Injection");
}

void InjectionManager::setInjectionStatus(InjectionStatus status)
{
    if (m_injectionStatus != status) {
        m_injectionStatus = status;
        emit injectionStatusChanged(status);
    }
}