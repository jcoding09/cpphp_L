#pragma once

#include <QtCore/QObject>
#include <QtCore/QDateTime>
#include <QtCore/QFile>
#include <QtCore/QTextStream>
#include <QtCore/QMutex>
#include <QtCore/QTimer>
#include <QtCore/QJsonObject>
#include <QtCore/QJsonDocument>
#include <QtCore/QJsonArray>
#include <QtCore/QDir>
#include <memory>
#include <queue>
#include <vector>

class Logger : public QObject {
    Q_OBJECT

public:
    enum LogLevel {
        Debug = 0,
        Info = 1,
        Warning = 2,
        Error = 3,
        Critical = 4,
        Success = 5
    };
    
    enum LogCategory {
        General,
        Injection,
        Memory,
        Game,
        Network,
        Security,
        UI,
        Cheat,
        Performance
    };
    
    struct LogEntry {
        QDateTime timestamp;
        LogLevel level;
        LogCategory category;
        QString message;
        QString details;
        QString function;
        QString file;
        int line;
        QJsonObject metadata;
        
        LogEntry() : level(Info), category(General), line(0) {}
    };
    
    struct LogStats {
        int totalEntries;
        int debugCount;
        int infoCount;
        int warningCount;
        int errorCount;
        int criticalCount;
        int successCount;
        QDateTime firstEntry;
        QDateTime lastEntry;
        
        LogStats() : totalEntries(0), debugCount(0), infoCount(0), 
                    warningCount(0), errorCount(0), criticalCount(0), successCount(0) {}
    };

    explicit Logger(QObject* parent = nullptr);
    ~Logger();
    
    // Singleton access
    static Logger* instance();
    static void setInstance(Logger* logger);
    
    // Configuration
    void setLogLevel(LogLevel minLevel);
    void setLogFile(const QString& filePath);
    void setMaxFileSize(qint64 maxSize); // in bytes
    void setMaxFiles(int maxFiles);
    void setAutoFlush(bool enabled);
    void setConsoleOutput(bool enabled);
    
    // Logging functions
    void log(LogLevel level, LogCategory category, const QString& message, 
             const QString& details = QString(), const QString& function = QString(),
             const QString& file = QString(), int line = 0, 
             const QJsonObject& metadata = QJsonObject());
    
    // Convenience functions
    void debug(const QString& message, LogCategory category = General, 
               const QString& details = QString());
    void info(const QString& message, LogCategory category = General, 
              const QString& details = QString());
    void warning(const QString& message, LogCategory category = General, 
                 const QString& details = QString());
    void error(const QString& message, LogCategory category = General, 
               const QString& details = QString());
    void critical(const QString& message, LogCategory category = General, 
                  const QString& details = QString());
    void success(const QString& message, LogCategory category = General, 
                 const QString& details = QString());
    
    // Specialized logging
    void logInjectionStep(const QString& step, bool success, const QString& details = QString());
    void logMemoryOperation(const QString& operation, bool success, 
                           uintptr_t address = 0, size_t size = 0);
    void logGameEvent(const QString& event, const QJsonObject& data = QJsonObject());
    void logCheatAction(const QString& cheat, const QString& action, bool success);
    void logPerformance(const QString& operation, qint64 durationMs, 
                       const QJsonObject& metrics = QJsonObject());
    void logSecurityEvent(const QString& event, const QString& details, 
                         LogLevel level = Warning);
    
    // Error tracking
    void trackError(const QString& errorCode, const QString& description, 
                   const QJsonObject& context = QJsonObject());
    void trackSuccess(const QString& operation, const QString& description,
                     const QJsonObject& context = QJsonObject());
    
    // Retrieval functions
    std::vector<LogEntry> getRecentEntries(int count = 100);
    std::vector<LogEntry> getEntriesByLevel(LogLevel level, int maxCount = 100);
    std::vector<LogEntry> getEntriesByCategory(LogCategory category, int maxCount = 100);
    std::vector<LogEntry> getEntriesInTimeRange(const QDateTime& start, 
                                               const QDateTime& end);
    std::vector<LogEntry> searchEntries(const QString& searchText, int maxCount = 100);
    
    // Statistics
    LogStats getStatistics();
    QJsonObject getDetailedStats();
    std::vector<LogEntry> getErrors(int maxCount = 50);
    std::vector<LogEntry> getSuccesses(int maxCount = 50);
    
    // File management
    void flush();
    void clear();
    void rotateLogs();
    void exportLogs(const QString& filePath, const QDateTime& start = QDateTime(),
                   const QDateTime& end = QDateTime());
    
    // Utility
    QString levelToString(LogLevel level);
    QString categoryToString(LogCategory category);
    LogLevel stringToLevel(const QString& levelStr);
    LogCategory stringToCategory(const QString& categoryStr);
    
    // Settings
    LogLevel getLogLevel() const { return m_minLogLevel; }
    QString getLogFile() const { return m_logFilePath; }
    bool isConsoleOutputEnabled() const { return m_consoleOutput; }
    bool isAutoFlushEnabled() const { return m_autoFlush; }
    
signals:
    void logEntryAdded(const LogEntry& entry);
    void errorLogged(const LogEntry& entry);
    void criticalErrorLogged(const LogEntry& entry);
    void successLogged(const LogEntry& entry);
    void logFileRotated(const QString& newFile);
    void logLevelChanged(LogLevel newLevel);

private slots:
    void flushBuffer();
    void checkFileSize();

private:
    void writeToFile(const LogEntry& entry);
    void writeToConsole(const LogEntry& entry);
    QString formatLogEntry(const LogEntry& entry);
    QString formatJsonEntry(const LogEntry& entry);
    void ensureLogDirectory();
    void initializeLogFile();
    void updateStatistics(const LogEntry& entry);
    
    // Member variables
    static Logger* s_instance;
    
    LogLevel m_minLogLevel;
    QString m_logFilePath;
    QString m_logDirectory;
    qint64 m_maxFileSize;
    int m_maxFiles;
    bool m_autoFlush;
    bool m_consoleOutput;
    
    // File handling
    std::unique_ptr<QFile> m_logFile;
    std::unique_ptr<QTextStream> m_logStream;
    QMutex m_fileMutex;
    
    // Buffering
    std::queue<LogEntry> m_logBuffer;
    QMutex m_bufferMutex;
    QTimer* m_flushTimer;
    QTimer* m_fileSizeTimer;
    
    // Statistics
    LogStats m_stats;
    QMutex m_statsMutex;
    
    // Recent entries cache
    std::vector<LogEntry> m_recentEntries;
    QMutex m_entriesMutex;
    static const int MAX_RECENT_ENTRIES = 1000;
};

// Macro definitions for easy logging with file/line information
#define LOG_DEBUG(message, category) \
    Logger::instance()->log(Logger::Debug, category, message, QString(), \
                           Q_FUNC_INFO, __FILE__, __LINE__)

#define LOG_INFO(message, category) \
    Logger::instance()->log(Logger::Info, category, message, QString(), \
                           Q_FUNC_INFO, __FILE__, __LINE__)

#define LOG_WARNING(message, category) \
    Logger::instance()->log(Logger::Warning, category, message, QString(), \
                           Q_FUNC_INFO, __FILE__, __LINE__)

#define LOG_ERROR(message, category) \
    Logger::instance()->log(Logger::Error, category, message, QString(), \
                           Q_FUNC_INFO, __FILE__, __LINE__)

#define LOG_CRITICAL(message, category) \
    Logger::instance()->log(Logger::Critical, category, message, QString(), \
                           Q_FUNC_INFO, __FILE__, __LINE__)

#define LOG_SUCCESS(message, category) \
    Logger::instance()->log(Logger::Success, category, message, QString(), \
                           Q_FUNC_INFO, __FILE__, __LINE__)

// Detailed logging macros
#define LOG_DEBUG_DETAILED(message, details, category) \
    Logger::instance()->log(Logger::Debug, category, message, details, \
                           Q_FUNC_INFO, __FILE__, __LINE__)

#define LOG_INFO_DETAILED(message, details, category) \
    Logger::instance()->log(Logger::Info, category, message, details, \
                           Q_FUNC_INFO, __FILE__, __LINE__)

#define LOG_WARNING_DETAILED(message, details, category) \
    Logger::instance()->log(Logger::Warning, category, message, details, \
                           Q_FUNC_INFO, __FILE__, __LINE__)

#define LOG_ERROR_DETAILED(message, details, category) \
    Logger::instance()->log(Logger::Error, category, message, details, \
                           Q_FUNC_INFO, __FILE__, __LINE__)

#define LOG_CRITICAL_DETAILED(message, details, category) \
    Logger::instance()->log(Logger::Critical, category, message, details, \
                           Q_FUNC_INFO, __FILE__, __LINE__)

#define LOG_SUCCESS_DETAILED(message, details, category) \
    Logger::instance()->log(Logger::Success, category, message, details, \
                           Q_FUNC_INFO, __FILE__, __LINE__)

// Implementation

Logger* Logger::s_instance = nullptr;

Logger::Logger(QObject* parent)
    : QObject(parent)
    , m_minLogLevel(Info)
    , m_maxFileSize(10 * 1024 * 1024) // 10 MB
    , m_maxFiles(5)
    , m_autoFlush(true)
    , m_consoleOutput(true)
{
    // Set default log directory
    m_logDirectory = QDir::currentPath() + "/logs";
    m_logFilePath = m_logDirectory + "/ghostpulse.log";
    
    // Initialize timers
    m_flushTimer = new QTimer(this);
    m_fileSizeTimer = new QTimer(this);
    
    connect(m_flushTimer, &QTimer::timeout, this, &Logger::flushBuffer);
    connect(m_fileSizeTimer, &QTimer::timeout, this, &Logger::checkFileSize);
    
    // Start timers
    m_flushTimer->start(1000); // Flush every second
    m_fileSizeTimer->start(10000); // Check file size every 10 seconds
    
    // Initialize log file
    ensureLogDirectory();
    initializeLogFile();
    
    // Log startup
    info("Logger initialized", General, QString("Log file: %1").arg(m_logFilePath));
}

Logger::~Logger() {
    flush();
    if (m_logFile) {
        m_logFile->close();
    }
}

Logger* Logger::instance() {
    if (!s_instance) {
        s_instance = new Logger();
    }
    return s_instance;
}

void Logger::setInstance(Logger* logger) {
    if (s_instance && s_instance != logger) {
        delete s_instance;
    }
    s_instance = logger;
}

void Logger::setLogLevel(LogLevel minLevel) {
    m_minLogLevel = minLevel;
    emit logLevelChanged(minLevel);
    info(QString("Log level changed to %1").arg(levelToString(minLevel)));
}

void Logger::setLogFile(const QString& filePath) {
    QMutexLocker locker(&m_fileMutex);
    
    // Close current file
    if (m_logFile) {
        m_logFile->close();
        m_logFile.reset();
        m_logStream.reset();
    }
    
    m_logFilePath = filePath;
    m_logDirectory = QFileInfo(filePath).absolutePath();
    
    ensureLogDirectory();
    initializeLogFile();
    
    info(QString("Log file changed to %1").arg(filePath));
}

void Logger::setMaxFileSize(qint64 maxSize) {
    m_maxFileSize = maxSize;
    info(QString("Max file size set to %1 bytes").arg(maxSize));
}

void Logger::setMaxFiles(int maxFiles) {
    m_maxFiles = maxFiles;
    info(QString("Max files set to %1").arg(maxFiles));
}

void Logger::setAutoFlush(bool enabled) {
    m_autoFlush = enabled;
    if (enabled) {
        m_flushTimer->start(1000);
    } else {
        m_flushTimer->stop();
    }
    info(QString("Auto flush %1").arg(enabled ? "enabled" : "disabled"));
}

void Logger::setConsoleOutput(bool enabled) {
    m_consoleOutput = enabled;
    info(QString("Console output %1").arg(enabled ? "enabled" : "disabled"));
}

void Logger::log(LogLevel level, LogCategory category, const QString& message,
                const QString& details, const QString& function,
                const QString& file, int line, const QJsonObject& metadata) {
    
    if (level < m_minLogLevel) {
        return;
    }
    
    LogEntry entry;
    entry.timestamp = QDateTime::currentDateTime();
    entry.level = level;
    entry.category = category;
    entry.message = message;
    entry.details = details;
    entry.function = function;
    entry.file = file;
    entry.line = line;
    entry.metadata = metadata;
    
    // Update statistics
    updateStatistics(entry);
    
    // Add to recent entries cache
    {
        QMutexLocker locker(&m_entriesMutex);
        m_recentEntries.push_back(entry);
        if (m_recentEntries.size() > MAX_RECENT_ENTRIES) {
            m_recentEntries.erase(m_recentEntries.begin());
        }
    }
    
    // Add to buffer
    {
        QMutexLocker locker(&m_bufferMutex);
        m_logBuffer.push(entry);
    }
    
    // Write to console if enabled
    if (m_consoleOutput) {
        writeToConsole(entry);
    }
    
    // Emit signals
    emit logEntryAdded(entry);
    
    if (level == Error) {
        emit errorLogged(entry);
    } else if (level == Critical) {
        emit criticalErrorLogged(entry);
    } else if (level == Success) {
        emit successLogged(entry);
    }
    
    // Auto flush if enabled
    if (m_autoFlush) {
        flushBuffer();
    }
}

void Logger::debug(const QString& message, LogCategory category, const QString& details) {
    log(Debug, category, message, details);
}

void Logger::info(const QString& message, LogCategory category, const QString& details) {
    log(Info, category, message, details);
}

void Logger::warning(const QString& message, LogCategory category, const QString& details) {
    log(Warning, category, message, details);
}

void Logger::error(const QString& message, LogCategory category, const QString& details) {
    log(Error, category, message, details);
}

void Logger::critical(const QString& message, LogCategory category, const QString& details) {
    log(Critical, category, message, details);
}

void Logger::success(const QString& message, LogCategory category, const QString& details) {
    log(Success, category, message, details);
}

void Logger::logInjectionStep(const QString& step, bool success, const QString& details) {
    LogLevel level = success ? Success : Error;
    QString message = QString("Injection step: %1 - %2").arg(step).arg(success ? "SUCCESS" : "FAILED");
    log(level, Injection, message, details);
}

void Logger::logMemoryOperation(const QString& operation, bool success, 
                               uintptr_t address, size_t size) {
    LogLevel level = success ? Success : Error;
    QString message = QString("Memory operation: %1 - %2").arg(operation).arg(success ? "SUCCESS" : "FAILED");
    QString details = QString("Address: 0x%1, Size: %2 bytes")
                     .arg(QString::number(address, 16).toUpper())
                     .arg(size);
    log(level, Memory, message, details);
}

void Logger::logGameEvent(const QString& event, const QJsonObject& data) {
    log(Info, Game, QString("Game event: %1").arg(event), QString(), QString(), QString(), 0, data);
}

void Logger::logCheatAction(const QString& cheat, const QString& action, bool success) {
    LogLevel level = success ? Success : Warning;
    QString message = QString("Cheat action: %1 %2 - %3")
                     .arg(cheat).arg(action).arg(success ? "SUCCESS" : "FAILED");
    log(level, Cheat, message);
}

void Logger::logPerformance(const QString& operation, qint64 durationMs, 
                           const QJsonObject& metrics) {
    QString message = QString("Performance: %1 took %2ms").arg(operation).arg(durationMs);
    log(Info, Performance, message, QString(), QString(), QString(), 0, metrics);
}

void Logger::logSecurityEvent(const QString& event, const QString& details, LogLevel level) {
    log(level, Security, QString("Security event: %1").arg(event), details);
}

void Logger::trackError(const QString& errorCode, const QString& description, 
                       const QJsonObject& context) {
    QJsonObject metadata = context;
    metadata["error_code"] = errorCode;
    log(Error, General, QString("Error tracked: %1").arg(errorCode), description, 
        QString(), QString(), 0, metadata);
}

void Logger::trackSuccess(const QString& operation, const QString& description,
                         const QJsonObject& context) {
    QJsonObject metadata = context;
    metadata["operation"] = operation;
    log(Success, General, QString("Success tracked: %1").arg(operation), description,
        QString(), QString(), 0, metadata);
}

std::vector<Logger::LogEntry> Logger::getRecentEntries(int count) {
    QMutexLocker locker(&m_entriesMutex);
    
    std::vector<LogEntry> result;
    int startIndex = std::max(0, static_cast<int>(m_recentEntries.size()) - count);
    
    for (int i = startIndex; i < m_recentEntries.size(); ++i) {
        result.push_back(m_recentEntries[i]);
    }
    
    return result;
}

std::vector<Logger::LogEntry> Logger::getEntriesByLevel(LogLevel level, int maxCount) {
    QMutexLocker locker(&m_entriesMutex);
    
    std::vector<LogEntry> result;
    int count = 0;
    
    for (auto it = m_recentEntries.rbegin(); it != m_recentEntries.rend() && count < maxCount; ++it) {
        if (it->level == level) {
            result.insert(result.begin(), *it);
            count++;
        }
    }
    
    return result;
}

std::vector<Logger::LogEntry> Logger::getEntriesByCategory(LogCategory category, int maxCount) {
    QMutexLocker locker(&m_entriesMutex);
    
    std::vector<LogEntry> result;
    int count = 0;
    
    for (auto it = m_recentEntries.rbegin(); it != m_recentEntries.rend() && count < maxCount; ++it) {
        if (it->category == category) {
            result.insert(result.begin(), *it);
            count++;
        }
    }
    
    return result;
}

std::vector<Logger::LogEntry> Logger::getErrors(int maxCount) {
    return getEntriesByLevel(Error, maxCount);
}

std::vector<Logger::LogEntry> Logger::getSuccesses(int maxCount) {
    return getEntriesByLevel(Success, maxCount);
}

Logger::LogStats Logger::getStatistics() {
    QMutexLocker locker(&m_statsMutex);
    return m_stats;
}

QJsonObject Logger::getDetailedStats() {
    QMutexLocker locker(&m_statsMutex);
    
    QJsonObject stats;
    stats["total_entries"] = m_stats.totalEntries;
    stats["debug_count"] = m_stats.debugCount;
    stats["info_count"] = m_stats.infoCount;
    stats["warning_count"] = m_stats.warningCount;
    stats["error_count"] = m_stats.errorCount;
    stats["critical_count"] = m_stats.criticalCount;
    stats["success_count"] = m_stats.successCount;
    stats["first_entry"] = m_stats.firstEntry.toString(Qt::ISODate);
    stats["last_entry"] = m_stats.lastEntry.toString(Qt::ISODate);
    
    return stats;
}

void Logger::flush() {
    flushBuffer();
    
    QMutexLocker locker(&m_fileMutex);
    if (m_logStream) {
        m_logStream->flush();
    }
    if (m_logFile) {
        m_logFile->flush();
    }
}

void Logger::clear() {
    {
        QMutexLocker locker(&m_entriesMutex);
        m_recentEntries.clear();
    }
    
    {
        QMutexLocker locker(&m_statsMutex);
        m_stats = LogStats();
    }
    
    {
        QMutexLocker locker(&m_bufferMutex);
        while (!m_logBuffer.empty()) {
            m_logBuffer.pop();
        }
    }
    
    info("Log cleared");
}

void Logger::flushBuffer() {
    QMutexLocker locker(&m_bufferMutex);
    
    while (!m_logBuffer.empty()) {
        LogEntry entry = m_logBuffer.front();
        m_logBuffer.pop();
        
        locker.unlock();
        writeToFile(entry);
        locker.relock();
    }
}

void Logger::checkFileSize() {
    QMutexLocker locker(&m_fileMutex);
    
    if (m_logFile && m_logFile->size() > m_maxFileSize) {
        locker.unlock();
        rotateLogs();
    }
}

void Logger::writeToFile(const LogEntry& entry) {
    QMutexLocker locker(&m_fileMutex);
    
    if (!m_logStream) {
        return;
    }
    
    QString formattedEntry = formatLogEntry(entry);
    *m_logStream << formattedEntry << Qt::endl;
}

void Logger::writeToConsole(const LogEntry& entry) {
    QString formattedEntry = formatLogEntry(entry);
    
    // Use different output streams based on log level
    if (entry.level >= Error) {
        fprintf(stderr, "%s\n", formattedEntry.toLocal8Bit().constData());
    } else {
        printf("%s\n", formattedEntry.toLocal8Bit().constData());
    }
}

QString Logger::formatLogEntry(const LogEntry& entry) {
    QString timestamp = entry.timestamp.toString("yyyy-MM-dd hh:mm:ss.zzz");
    QString level = levelToString(entry.level);
    QString category = categoryToString(entry.category);
    
    QString formatted = QString("[%1] [%2] [%3] %4")
                       .arg(timestamp)
                       .arg(level)
                       .arg(category)
                       .arg(entry.message);
    
    if (!entry.details.isEmpty()) {
        formatted += QString(" - %1").arg(entry.details);
    }
    
    if (!entry.function.isEmpty()) {
        formatted += QString(" (%1)").arg(entry.function);
    }
    
    return formatted;
}

void Logger::ensureLogDirectory() {
    QDir dir;
    if (!dir.exists(m_logDirectory)) {
        dir.mkpath(m_logDirectory);
    }
}

void Logger::initializeLogFile() {
    QMutexLocker locker(&m_fileMutex);
    
    m_logFile = std::make_unique<QFile>(m_logFilePath);
    
    if (m_logFile->open(QIODevice::WriteOnly | QIODevice::Append)) {
        m_logStream = std::make_unique<QTextStream>(m_logFile.get());
        m_logStream->setCodec("UTF-8");
    }
}

void Logger::updateStatistics(const LogEntry& entry) {
    QMutexLocker locker(&m_statsMutex);
    
    m_stats.totalEntries++;
    
    switch (entry.level) {
        case Debug: m_stats.debugCount++; break;
        case Info: m_stats.infoCount++; break;
        case Warning: m_stats.warningCount++; break;
        case Error: m_stats.errorCount++; break;
        case Critical: m_stats.criticalCount++; break;
        case Success: m_stats.successCount++; break;
    }
    
    if (m_stats.totalEntries == 1) {
        m_stats.firstEntry = entry.timestamp;
    }
    m_stats.lastEntry = entry.timestamp;
}

void Logger::rotateLogs() {
    QMutexLocker locker(&m_fileMutex);
    
    // Close current file
    if (m_logFile) {
        m_logFile->close();
        m_logFile.reset();
        m_logStream.reset();
    }
    
    // Rotate existing files
    for (int i = m_maxFiles - 1; i > 0; --i) {
        QString oldFile = QString("%1.%2").arg(m_logFilePath).arg(i);
        QString newFile = QString("%1.%2").arg(m_logFilePath).arg(i + 1);
        
        if (QFile::exists(oldFile)) {
            QFile::remove(newFile);
            QFile::rename(oldFile, newFile);
        }
    }
    
    // Move current log to .1
    QString rotatedFile = QString("%1.1").arg(m_logFilePath);
    if (QFile::exists(m_logFilePath)) {
        QFile::remove(rotatedFile);
        QFile::rename(m_logFilePath, rotatedFile);
    }
    
    // Create new log file
    initializeLogFile();
    
    emit logFileRotated(m_logFilePath);
    info("Log file rotated");
}

QString Logger::levelToString(LogLevel level) {
    switch (level) {
        case Debug: return "DEBUG";
        case Info: return "INFO";
        case Warning: return "WARN";
        case Error: return "ERROR";
        case Critical: return "CRITICAL";
        case Success: return "SUCCESS";
        default: return "UNKNOWN";
    }
}

QString Logger::categoryToString(LogCategory category) {
    switch (category) {
        case General: return "GENERAL";
        case Injection: return "INJECTION";
        case Memory: return "MEMORY";
        case Game: return "GAME";
        case Network: return "NETWORK";
        case Security: return "SECURITY";
        case UI: return "UI";
        case Cheat: return "CHEAT";
        case Performance: return "PERFORMANCE";
        default: return "UNKNOWN";
    }
}

Logger::LogLevel Logger::stringToLevel(const QString& levelStr) {
    QString upper = levelStr.toUpper();
    if (upper == "DEBUG") return Debug;
    if (upper == "INFO") return Info;
    if (upper == "WARN" || upper == "WARNING") return Warning;
    if (upper == "ERROR") return Error;
    if (upper == "CRITICAL") return Critical;
    if (upper == "SUCCESS") return Success;
    return Info; // Default
}

Logger::LogCategory Logger::stringToCategory(const QString& categoryStr) {
    QString upper = categoryStr.toUpper();
    if (upper == "GENERAL") return General;
    if (upper == "INJECTION") return Injection;
    if (upper == "MEMORY") return Memory;
    if (upper == "GAME") return Game;
    if (upper == "NETWORK") return Network;
    if (upper == "SECURITY") return Security;
    if (upper == "UI") return UI;
    if (upper == "CHEAT") return Cheat;
    if (upper == "PERFORMANCE") return Performance;
    return General; // Default
}