#pragma once

#include <QtCore/QObject>
#include <QtCore/QTimer>
#include <QtCore/QJsonObject>
#include <QtCore/QJsonDocument>
#include <memory>
#include <vector>
#include <unordered_map>
#include <windows.h>

// Game structures
struct Vector3 {
    float x, y, z;
    Vector3() : x(0), y(0), z(0) {}
    Vector3(float x_, float y_, float z_) : x(x_), y(y_), z(z_) {}
};

struct Vector2 {
    float x, y;
    Vector2() : x(0), y(0) {}
    Vector2(float x_, float y_) : x(x_), y(y_) {}
};

struct PlayerInfo {
    uintptr_t address;
    Vector3 position;
    Vector3 rotation;
    float health;
    float armor;
    bool isValid;
    bool isVisible;
    bool isEnemy;
    QString name;
    int teamId;
    float distance;
};

struct WeaponInfo {
    uintptr_t address;
    QString name;
    int ammo;
    int maxAmmo;
    float damage;
    float range;
    bool isAutomatic;
};

struct VehicleInfo {
    uintptr_t address;
    Vector3 position;
    float health;
    QString type;
    bool isOccupied;
};

struct ItemInfo {
    uintptr_t address;
    Vector3 position;
    QString name;
    QString category;
    int quantity;
    float distance;
};

class GameInterface : public QObject {
    Q_OBJECT

public:
    enum GameState {
        NotConnected,
        MainMenu,
        InLobby,
        InGame,
        Loading,
        Paused
    };
    
    enum CheatType {
        Aimbot,
        ESP,
        Wallhack,
        SpeedHack,
        NoRecoil,
        InfiniteAmmo,
        GodMode
    };

    explicit GameInterface(QObject* parent = nullptr);
    ~GameInterface();
    
    // Connection management
    bool connectToGame();
    bool disconnectFromGame();
    bool isConnected() const { return m_gameState != NotConnected; }
    
    // Game state
    GameState getGameState() const { return m_gameState; }
    bool isInGame() const { return m_gameState == InGame; }
    
    // Player information
    PlayerInfo getLocalPlayer();
    std::vector<PlayerInfo> getAllPlayers();
    std::vector<PlayerInfo> getEnemyPlayers();
    std::vector<PlayerInfo> getTeammates();
    
    // World information
    std::vector<VehicleInfo> getNearbyVehicles(float maxDistance = 500.0f);
    std::vector<ItemInfo> getNearbyItems(float maxDistance = 100.0f);
    
    // Weapon information
    WeaponInfo getCurrentWeapon();
    std::vector<WeaponInfo> getAllWeapons();
    
    // Camera/View
    Vector3 getCameraPosition();
    Vector3 getCameraRotation();
    bool worldToScreen(const Vector3& worldPos, Vector2& screenPos);
    
    // Cheat functions
    void enableCheat(CheatType type, bool enabled);
    bool isCheatEnabled(CheatType type) const;
    
    // Aimbot
    void setAimbotTarget(const PlayerInfo& target);
    void setAimbotSettings(float fov, float smoothness, bool autoShoot);
    PlayerInfo getBestAimbotTarget();
    
    // ESP settings
    void setESPSettings(bool showPlayers, bool showItems, bool showVehicles, 
                       bool showHealth, bool showDistance, bool showNames);
    
    // Memory offsets
    void updateOffsets();
    bool validateOffsets();
    
    // Game version detection
    QString getGameVersion();
    bool isGameVersionSupported();
    
    QString getLastError() const { return m_lastError; }
    
signals:
    void gameStateChanged(GameState newState);
    void playerListUpdated(const std::vector<PlayerInfo>& players);
    void localPlayerUpdated(const PlayerInfo& player);
    void connectionStatusChanged(bool connected);
    void cheatStatusChanged(CheatType type, bool enabled);

private slots:
    void updateGameData();
    void checkGameConnection();
    void processAimbot();
    void processESP();

private:
    // Core functions
    bool initializeGameHooks();
    void cleanupGameHooks();
    bool findGameOffsets();
    
    // Memory reading helpers
    template<typename T>
    bool readGameMemory(uintptr_t address, T& value);
    
    template<typename T>
    bool writeGameMemory(uintptr_t address, const T& value);
    
    // Player functions
    bool readPlayerInfo(uintptr_t playerAddress, PlayerInfo& player);
    bool isPlayerValid(uintptr_t playerAddress);
    bool isPlayerVisible(const PlayerInfo& player);
    float calculateDistance(const Vector3& pos1, const Vector3& pos2);
    
    // Offset management
    struct GameOffsets {
        uintptr_t playerList;
        uintptr_t localPlayer;
        uintptr_t playerPosition;
        uintptr_t playerHealth;
        uintptr_t playerArmor;
        uintptr_t playerName;
        uintptr_t playerTeamId;
        uintptr_t cameraPosition;
        uintptr_t cameraRotation;
        uintptr_t viewMatrix;
        uintptr_t weaponManager;
        uintptr_t currentWeapon;
        uintptr_t weaponAmmo;
        uintptr_t itemList;
        uintptr_t vehicleList;
    };
    
    // Cheat implementations
    void performAimbot();
    void performESP();
    void performWallhack();
    void performSpeedHack();
    void performNoRecoil();
    void performInfiniteAmmo();
    void performGodMode();
    
    // Utility functions
    Vector2 calculateAimbotAngles(const Vector3& from, const Vector3& to);
    bool isTargetInFOV(const PlayerInfo& target, float fov);
    void smoothAim(const Vector2& targetAngles, float smoothness);
    
    // Member variables
    GameState m_gameState;
    QString m_lastError;
    
    // Game connection
    HANDLE m_gameProcess;
    DWORD m_gameProcessId;
    uintptr_t m_gameBaseAddress;
    
    // Game data
    PlayerInfo m_localPlayer;
    std::vector<PlayerInfo> m_allPlayers;
    WeaponInfo m_currentWeapon;
    std::vector<VehicleInfo> m_vehicles;
    std::vector<ItemInfo> m_items;
    
    // Offsets
    GameOffsets m_offsets;
    QString m_gameVersion;
    
    // Cheat states
    std::unordered_map<CheatType, bool> m_cheatStates;
    
    // Aimbot settings
    float m_aimbotFOV;
    float m_aimbotSmoothness;
    bool m_aimbotAutoShoot;
    PlayerInfo m_aimbotTarget;
    
    // ESP settings
    bool m_espShowPlayers;
    bool m_espShowItems;
    bool m_espShowVehicles;
    bool m_espShowHealth;
    bool m_espShowDistance;
    bool m_espShowNames;
    
    // Timers
    QTimer* m_gameUpdateTimer;
    QTimer* m_connectionCheckTimer;
    QTimer* m_aimbotTimer;
    QTimer* m_espTimer;
    
    // View matrix for world-to-screen conversion
    float m_viewMatrix[16];
};

// Template implementations
template<typename T>
bool GameInterface::readGameMemory(uintptr_t address, T& value) {
    if (!m_gameProcess) {
        return false;
    }
    
    SIZE_T bytesRead;
    return ReadProcessMemory(m_gameProcess, reinterpret_cast<LPCVOID>(address), 
                           &value, sizeof(T), &bytesRead) && bytesRead == sizeof(T);
}

template<typename T>
bool GameInterface::writeGameMemory(uintptr_t address, const T& value) {
    if (!m_gameProcess) {
        return false;
    }
    
    SIZE_T bytesWritten;
    return WriteProcessMemory(m_gameProcess, reinterpret_cast<LPVOID>(address), 
                            &value, sizeof(T), &bytesWritten) && bytesWritten == sizeof(T);
}

// Implementation

GameInterface::GameInterface(QObject* parent)
    : QObject(parent)
    , m_gameState(NotConnected)
    , m_gameProcess(nullptr)
    , m_gameProcessId(0)
    , m_gameBaseAddress(0)
    , m_aimbotFOV(60.0f)
    , m_aimbotSmoothness(5.0f)
    , m_aimbotAutoShoot(false)
    , m_espShowPlayers(true)
    , m_espShowItems(false)
    , m_espShowVehicles(false)
    , m_espShowHealth(true)
    , m_espShowDistance(true)
    , m_espShowNames(true)
{
    // Initialize cheat states
    m_cheatStates[Aimbot] = false;
    m_cheatStates[ESP] = false;
    m_cheatStates[Wallhack] = false;
    m_cheatStates[SpeedHack] = false;
    m_cheatStates[NoRecoil] = false;
    m_cheatStates[InfiniteAmmo] = false;
    m_cheatStates[GodMode] = false;
    
    // Initialize timers
    m_gameUpdateTimer = new QTimer(this);
    m_connectionCheckTimer = new QTimer(this);
    m_aimbotTimer = new QTimer(this);
    m_espTimer = new QTimer(this);
    
    connect(m_gameUpdateTimer, &QTimer::timeout, this, &GameInterface::updateGameData);
    connect(m_connectionCheckTimer, &QTimer::timeout, this, &GameInterface::checkGameConnection);
    connect(m_aimbotTimer, &QTimer::timeout, this, &GameInterface::processAimbot);
    connect(m_espTimer, &QTimer::timeout, this, &GameInterface::processESP);
    
    // Start connection checking
    m_connectionCheckTimer->start(2000); // Check every 2 seconds
}

GameInterface::~GameInterface() {
    disconnectFromGame();
}

bool GameInterface::connectToGame() {
    // Find BGMI process
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) {
        m_lastError = "Failed to create process snapshot";
        return false;
    }
    
    PROCESSENTRY32W processEntry;
    processEntry.dwSize = sizeof(PROCESSENTRY32W);
    
    bool found = false;
    if (Process32FirstW(snapshot, &processEntry)) {
        do {
            std::wstring processName = processEntry.szExeFile;
            if (processName.find(L"BGMI") != std::wstring::npos ||
                processName.find(L"bgmi") != std::wstring::npos ||
                processName.find(L"pubgm") != std::wstring::npos) {
                
                m_gameProcessId = processEntry.th32ProcessID;
                found = true;
                break;
            }
        } while (Process32NextW(snapshot, &processEntry));
    }
    
    CloseHandle(snapshot);
    
    if (!found) {
        m_lastError = "BGMI process not found";
        return false;
    }
    
    // Open process
    m_gameProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, m_gameProcessId);
    if (!m_gameProcess) {
        m_lastError = QString("Failed to open BGMI process. Error: %1").arg(GetLastError());
        return false;
    }
    
    // Get base address
    HMODULE modules[1024];
    DWORD needed;
    if (EnumProcessModules(m_gameProcess, modules, sizeof(modules), &needed)) {
        m_gameBaseAddress = reinterpret_cast<uintptr_t>(modules[0]);
    }
    
    // Find game offsets
    if (!findGameOffsets()) {
        m_lastError = "Failed to find game offsets";
        CloseHandle(m_gameProcess);
        m_gameProcess = nullptr;
        return false;
    }
    
    // Initialize hooks
    if (!initializeGameHooks()) {
        m_lastError = "Failed to initialize game hooks";
        CloseHandle(m_gameProcess);
        m_gameProcess = nullptr;
        return false;
    }
    
    m_gameState = MainMenu;
    emit gameStateChanged(m_gameState);
    emit connectionStatusChanged(true);
    
    // Start update timers
    m_gameUpdateTimer->start(16); // ~60 FPS
    m_aimbotTimer->start(10);     // 100 FPS for aimbot
    m_espTimer->start(33);        // ~30 FPS for ESP
    
    return true;
}

bool GameInterface::disconnectFromGame() {
    if (m_gameProcess) {
        // Stop timers
        m_gameUpdateTimer->stop();
        m_aimbotTimer->stop();
        m_espTimer->stop();
        
        // Cleanup hooks
        cleanupGameHooks();
        
        // Close process handle
        CloseHandle(m_gameProcess);
        m_gameProcess = nullptr;
        m_gameProcessId = 0;
        m_gameBaseAddress = 0;
        
        m_gameState = NotConnected;
        emit gameStateChanged(m_gameState);
        emit connectionStatusChanged(false);
        
        return true;
    }
    return false;
}

PlayerInfo GameInterface::getLocalPlayer() {
    if (!isConnected() || !m_offsets.localPlayer) {
        return PlayerInfo();
    }
    
    uintptr_t localPlayerAddress;
    if (!readGameMemory(m_gameBaseAddress + m_offsets.localPlayer, localPlayerAddress)) {
        return PlayerInfo();
    }
    
    PlayerInfo player;
    if (readPlayerInfo(localPlayerAddress, player)) {
        m_localPlayer = player;
        emit localPlayerUpdated(player);
    }
    
    return player;
}

std::vector<PlayerInfo> GameInterface::getAllPlayers() {
    std::vector<PlayerInfo> players;
    
    if (!isConnected() || !m_offsets.playerList) {
        return players;
    }
    
    // Read player list
    uintptr_t playerListAddress;
    if (!readGameMemory(m_gameBaseAddress + m_offsets.playerList, playerListAddress)) {
        return players;
    }
    
    // Read player count (assuming it's stored before the list)
    int playerCount;
    if (!readGameMemory(playerListAddress - 4, playerCount) || playerCount <= 0 || playerCount > 100) {
        return players;
    }
    
    // Read each player
    for (int i = 0; i < playerCount; ++i) {
        uintptr_t playerAddress;
        if (readGameMemory(playerListAddress + (i * sizeof(uintptr_t)), playerAddress)) {
            PlayerInfo player;
            if (readPlayerInfo(playerAddress, player)) {
                players.push_back(player);
            }
        }
    }
    
    m_allPlayers = players;
    emit playerListUpdated(players);
    
    return players;
}

bool GameInterface::readPlayerInfo(uintptr_t playerAddress, PlayerInfo& player) {
    if (!playerAddress || !isPlayerValid(playerAddress)) {
        return false;
    }
    
    player.address = playerAddress;
    
    // Read position
    if (!readGameMemory(playerAddress + m_offsets.playerPosition, player.position)) {
        return false;
    }
    
    // Read health
    if (!readGameMemory(playerAddress + m_offsets.playerHealth, player.health)) {
        return false;
    }
    
    // Read armor
    if (!readGameMemory(playerAddress + m_offsets.playerArmor, player.armor)) {
        return false;
    }
    
    // Read team ID
    if (!readGameMemory(playerAddress + m_offsets.playerTeamId, player.teamId)) {
        return false;
    }
    
    // Calculate distance from local player
    if (m_localPlayer.isValid) {
        player.distance = calculateDistance(m_localPlayer.position, player.position);
    }
    
    // Check if enemy
    player.isEnemy = (player.teamId != m_localPlayer.teamId);
    
    // Check visibility
    player.isVisible = isPlayerVisible(player);
    
    player.isValid = true;
    
    return true;
}

bool GameInterface::isPlayerValid(uintptr_t playerAddress) {
    if (!playerAddress) {
        return false;
    }
    
    // Check if player object is valid by reading a known field
    float health;
    if (!readGameMemory(playerAddress + m_offsets.playerHealth, health)) {
        return false;
    }
    
    return health > 0 && health <= 100;
}

bool GameInterface::isPlayerVisible(const PlayerInfo& player) {
    // Implement line-of-sight check
    // This would involve raycasting from camera to player position
    // For now, return true as a placeholder
    return true;
}

float GameInterface::calculateDistance(const Vector3& pos1, const Vector3& pos2) {
    float dx = pos1.x - pos2.x;
    float dy = pos1.y - pos2.y;
    float dz = pos1.z - pos2.z;
    return sqrt(dx*dx + dy*dy + dz*dz);
}

bool GameInterface::worldToScreen(const Vector3& worldPos, Vector2& screenPos) {
    // Read view matrix
    if (!readGameMemory(m_gameBaseAddress + m_offsets.viewMatrix, m_viewMatrix)) {
        return false;
    }
    
    // Perform world-to-screen transformation
    float w = m_viewMatrix[3] * worldPos.x + m_viewMatrix[7] * worldPos.y + 
              m_viewMatrix[11] * worldPos.z + m_viewMatrix[15];
    
    if (w < 0.01f) {
        return false; // Behind camera
    }
    
    float x = m_viewMatrix[0] * worldPos.x + m_viewMatrix[4] * worldPos.y + 
              m_viewMatrix[8] * worldPos.z + m_viewMatrix[12];
    float y = m_viewMatrix[1] * worldPos.x + m_viewMatrix[5] * worldPos.y + 
              m_viewMatrix[9] * worldPos.z + m_viewMatrix[13];
    
    // Assume screen size (this should be read from game or system)
    const float screenWidth = 1920.0f;
    const float screenHeight = 1080.0f;
    
    screenPos.x = (screenWidth / 2.0f) + (x / w) * (screenWidth / 2.0f);
    screenPos.y = (screenHeight / 2.0f) - (y / w) * (screenHeight / 2.0f);
    
    return (screenPos.x >= 0 && screenPos.x <= screenWidth && 
            screenPos.y >= 0 && screenPos.y <= screenHeight);
}

void GameInterface::enableCheat(CheatType type, bool enabled) {
    m_cheatStates[type] = enabled;
    emit cheatStatusChanged(type, enabled);
}

bool GameInterface::isCheatEnabled(CheatType type) const {
    auto it = m_cheatStates.find(type);
    return (it != m_cheatStates.end()) ? it->second : false;
}

void GameInterface::setAimbotSettings(float fov, float smoothness, bool autoShoot) {
    m_aimbotFOV = fov;
    m_aimbotSmoothness = smoothness;
    m_aimbotAutoShoot = autoShoot;
}

PlayerInfo GameInterface::getBestAimbotTarget() {
    PlayerInfo bestTarget;
    float bestScore = FLT_MAX;
    
    for (const auto& player : m_allPlayers) {
        if (!player.isValid || !player.isEnemy || player.health <= 0) {
            continue;
        }
        
        if (!isTargetInFOV(player, m_aimbotFOV)) {
            continue;
        }
        
        // Calculate score based on distance and visibility
        float score = player.distance;
        if (!player.isVisible) {
            score *= 2.0f; // Penalize non-visible targets
        }
        
        if (score < bestScore) {
            bestScore = score;
            bestTarget = player;
        }
    }
    
    return bestTarget;
}

bool GameInterface::isTargetInFOV(const PlayerInfo& target, float fov) {
    Vector2 screenPos;
    if (!worldToScreen(target.position, screenPos)) {
        return false;
    }
    
    // Calculate angle from screen center
    const float screenCenterX = 1920.0f / 2.0f;
    const float screenCenterY = 1080.0f / 2.0f;
    
    float dx = screenPos.x - screenCenterX;
    float dy = screenPos.y - screenCenterY;
    float distance = sqrt(dx*dx + dy*dy);
    
    // Convert FOV to pixels (approximate)
    float fovPixels = (fov / 90.0f) * (1920.0f / 4.0f);
    
    return distance <= fovPixels;
}

void GameInterface::updateGameData() {
    if (!isConnected()) {
        return;
    }
    
    // Update local player
    getLocalPlayer();
    
    // Update all players (less frequently)
    static int playerUpdateCounter = 0;
    if (++playerUpdateCounter >= 4) { // Update every 4 frames
        getAllPlayers();
        playerUpdateCounter = 0;
    }
}

void GameInterface::checkGameConnection() {
    if (m_gameProcess) {
        // Check if process is still running
        DWORD exitCode;
        if (!GetExitCodeProcess(m_gameProcess, &exitCode) || exitCode != STILL_ACTIVE) {
            disconnectFromGame();
        }
    } else {
        // Try to reconnect
        connectToGame();
    }
}

void GameInterface::processAimbot() {
    if (!isCheatEnabled(Aimbot) || !isInGame()) {
        return;
    }
    
    PlayerInfo target = getBestAimbotTarget();
    if (target.isValid) {
        m_aimbotTarget = target;
        performAimbot();
    }
}

void GameInterface::processESP() {
    if (!isCheatEnabled(ESP) || !isInGame()) {
        return;
    }
    
    performESP();
}

void GameInterface::performAimbot() {
    if (!m_aimbotTarget.isValid) {
        return;
    }
    
    Vector2 targetAngles = calculateAimbotAngles(m_localPlayer.position, m_aimbotTarget.position);
    smoothAim(targetAngles, m_aimbotSmoothness);
}

Vector2 GameInterface::calculateAimbotAngles(const Vector3& from, const Vector3& to) {
    Vector3 delta = { to.x - from.x, to.y - from.y, to.z - from.z };
    float distance = sqrt(delta.x*delta.x + delta.y*delta.y + delta.z*delta.z);
    
    Vector2 angles;
    angles.x = atan2(delta.y, delta.x) * (180.0f / 3.14159f);
    angles.y = asin(delta.z / distance) * (180.0f / 3.14159f);
    
    return angles;
}

void GameInterface::smoothAim(const Vector2& targetAngles, float smoothness) {
    // Read current camera angles
    Vector3 currentRotation;
    if (!readGameMemory(m_gameBaseAddress + m_offsets.cameraRotation, currentRotation)) {
        return;
    }
    
    // Calculate smooth movement
    float deltaX = targetAngles.x - currentRotation.x;
    float deltaY = targetAngles.y - currentRotation.y;
    
    // Normalize angles
    while (deltaX > 180.0f) deltaX -= 360.0f;
    while (deltaX < -180.0f) deltaX += 360.0f;
    
    // Apply smoothing
    Vector3 newRotation;
    newRotation.x = currentRotation.x + (deltaX / smoothness);
    newRotation.y = currentRotation.y + (deltaY / smoothness);
    newRotation.z = currentRotation.z;
    
    // Write new angles
    writeGameMemory(m_gameBaseAddress + m_offsets.cameraRotation, newRotation);
}

void GameInterface::performESP() {
    // ESP rendering would be handled by the UI layer
    // This function would prepare the data for rendering
}

bool GameInterface::findGameOffsets() {
    // This would involve pattern scanning to find memory offsets
    // For demonstration, using placeholder values
    
    m_offsets.playerList = 0x1000000;
    m_offsets.localPlayer = 0x1000100;
    m_offsets.playerPosition = 0x100;
    m_offsets.playerHealth = 0x200;
    m_offsets.playerArmor = 0x204;
    m_offsets.playerName = 0x300;
    m_offsets.playerTeamId = 0x400;
    m_offsets.cameraPosition = 0x2000000;
    m_offsets.cameraRotation = 0x2000100;
    m_offsets.viewMatrix = 0x3000000;
    
    return validateOffsets();
}

bool GameInterface::validateOffsets() {
    // Validate that offsets point to valid memory
    // This is a simplified validation
    return m_offsets.localPlayer != 0 && m_offsets.playerList != 0;
}

bool GameInterface::initializeGameHooks() {
    // Initialize any necessary hooks
    return true;
}

void GameInterface::cleanupGameHooks() {
    // Cleanup hooks
}

QString GameInterface::getGameVersion() {
    // Read game version from memory or file
    return "3.9.0";
}

bool GameInterface::isGameVersionSupported() {
    QString version = getGameVersion();
    return version.startsWith("3.9");
}