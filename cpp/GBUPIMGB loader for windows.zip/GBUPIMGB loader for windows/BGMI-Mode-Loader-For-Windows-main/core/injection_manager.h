#pragma once

#include <QtCore/QObject>
#include <QtCore/QProcess>
#include <QtCore/QTimer>
#include <memory>
#include <string>
#include <vector>
#include <windows.h>
#include <tlhelp32.h>
#include <psapi.h>

class InjectionManager : public QObject {
    Q_OBJECT

public:
    enum InjectionMethod {
        ManualMap,
        ReflectiveDLL,
        ProcessHollowing
    };
    
    enum InjectionStatus {
        Idle,
        Injecting,
        Injected,
        Failed,
        Stopped
    };

    explicit InjectionManager(QObject* parent = nullptr);
    ~InjectionManager();
    
    bool inject();
    bool uninject();
    bool isInjected() const { return m_status == Injected; }
    
    void setInjectionMethod(const QString& method);
    InjectionMethod getInjectionMethod() const { return m_injectionMethod; }
    InjectionStatus getStatus() const { return m_status; }
    
    DWORD getTargetProcessId() const { return m_targetProcessId; }
    QString getLastError() const { return m_lastError; }

signals:
    void progressUpdate(int percentage, const QString& status);
    void injectionComplete(bool success);
    void statusChanged(InjectionStatus status);

private slots:
    void checkInjectionHealth();

private:
    // Core injection methods
    bool injectManualMap();
    bool injectReflectiveDLL();
    bool injectProcessHollowing();
    
    // Helper functions
    DWORD findTargetProcess();
    bool enableDebugPrivileges();
    bool validateTargetProcess(DWORD processId);
    bool loadPayload();
    bool allocateMemoryInTarget(HANDLE process, size_t size, void** allocatedMemory);
    bool writePayloadToTarget(HANDLE process, void* targetMemory);
    bool createRemoteThread(HANDLE process, void* entryPoint);
    
    // Security functions
    bool bypassAnticheat();
    bool obfuscatePayload();
    bool validateIntegrity();
    
    // Cleanup functions
    void cleanupInjection();
    void restoreTargetProcess();
    
    // Member variables
    InjectionMethod m_injectionMethod;
    InjectionStatus m_status;
    DWORD m_targetProcessId;
    HANDLE m_targetProcessHandle;
    QString m_lastError;
    
    // Payload data
    std::vector<uint8_t> m_payload;
    void* m_allocatedMemory;
    size_t m_payloadSize;
    
    // Monitoring
    QTimer* m_healthCheckTimer;
    
    // Security
    std::vector<uint8_t> m_originalBytes;
    std::vector<void*> m_hooks;
};

// Implementation

InjectionManager::InjectionManager(QObject* parent)
    : QObject(parent)
    , m_injectionMethod(ManualMap)
    , m_status(Idle)
    , m_targetProcessId(0)
    , m_targetProcessHandle(nullptr)
    , m_allocatedMemory(nullptr)
    , m_payloadSize(0)
{
    m_healthCheckTimer = new QTimer(this);
    connect(m_healthCheckTimer, &QTimer::timeout, this, &InjectionManager::checkInjectionHealth);
}

InjectionManager::~InjectionManager() {
    if (m_status == Injected) {
        uninject();
    }
}

bool InjectionManager::inject() {
    emit progressUpdate(0, "Starting injection process...");
    
    try {
        // Step 1: Enable debug privileges
        emit progressUpdate(10, "Enabling debug privileges...");
        if (!enableDebugPrivileges()) {
            m_lastError = "Failed to enable debug privileges";
            emit progressUpdate(0, "Failed: " + m_lastError);
            return false;
        }
        
        // Step 2: Find target process
        emit progressUpdate(20, "Searching for BGMI process...");
        m_targetProcessId = findTargetProcess();
        if (m_targetProcessId == 0) {
            m_lastError = "BGMI process not found";
            emit progressUpdate(0, "Failed: " + m_lastError);
            return false;
        }
        
        // Step 3: Validate target process
        emit progressUpdate(30, "Validating target process...");
        if (!validateTargetProcess(m_targetProcessId)) {
            m_lastError = "Target process validation failed";
            emit progressUpdate(0, "Failed: " + m_lastError);
            return false;
        }
        
        // Step 4: Load and prepare payload
        emit progressUpdate(40, "Loading payload...");
        if (!loadPayload()) {
            m_lastError = "Failed to load payload";
            emit progressUpdate(0, "Failed: " + m_lastError);
            return false;
        }
        
        // Step 5: Bypass anticheat
        emit progressUpdate(50, "Bypassing anticheat...");
        if (!bypassAnticheat()) {
            m_lastError = "Failed to bypass anticheat";
            emit progressUpdate(0, "Failed: " + m_lastError);
            return false;
        }
        
        // Step 6: Perform injection based on method
        emit progressUpdate(60, "Performing injection...");
        bool injectionSuccess = false;
        
        switch (m_injectionMethod) {
            case ManualMap:
                injectionSuccess = injectManualMap();
                break;
            case ReflectiveDLL:
                injectionSuccess = injectReflectiveDLL();
                break;
            case ProcessHollowing:
                injectionSuccess = injectProcessHollowing();
                break;
        }
        
        if (!injectionSuccess) {
            emit progressUpdate(0, "Failed: " + m_lastError);
            return false;
        }
        
        // Step 7: Validate injection
        emit progressUpdate(80, "Validating injection...");
        if (!validateIntegrity()) {
            m_lastError = "Injection integrity validation failed";
            emit progressUpdate(0, "Failed: " + m_lastError);
            cleanupInjection();
            return false;
        }
        
        // Step 8: Start health monitoring
        emit progressUpdate(90, "Starting health monitoring...");
        m_status = Injected;
        m_healthCheckTimer->start(5000); // Check every 5 seconds
        
        emit progressUpdate(100, "Injection completed successfully!");
        emit injectionComplete(true);
        emit statusChanged(m_status);
        
        return true;
        
    } catch (const std::exception& e) {
        m_lastError = QString("Exception during injection: %1").arg(e.what());
        emit progressUpdate(0, "Failed: " + m_lastError);
        cleanupInjection();
        return false;
    }
}

bool InjectionManager::uninject() {
    if (m_status != Injected) {
        return true;
    }
    
    try {
        m_healthCheckTimer->stop();
        
        // Restore original process state
        restoreTargetProcess();
        
        // Cleanup allocated memory
        cleanupInjection();
        
        m_status = Stopped;
        emit statusChanged(m_status);
        
        return true;
    } catch (const std::exception& e) {
        m_lastError = QString("Exception during uninjection: %1").arg(e.what());
        return false;
    }
}

void InjectionManager::setInjectionMethod(const QString& method) {
    if (method == "Manual Map") {
        m_injectionMethod = ManualMap;
    } else if (method == "Reflective DLL") {
        m_injectionMethod = ReflectiveDLL;
    } else if (method == "Process Hollowing") {
        m_injectionMethod = ProcessHollowing;
    }
}

DWORD InjectionManager::findTargetProcess() {
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) {
        return 0;
    }
    
    PROCESSENTRY32W processEntry;
    processEntry.dwSize = sizeof(PROCESSENTRY32W);
    
    if (Process32FirstW(snapshot, &processEntry)) {
        do {
            // Look for BGMI process names
            std::wstring processName = processEntry.szExeFile;
            if (processName.find(L"BGMI") != std::wstring::npos ||
                processName.find(L"bgmi") != std::wstring::npos ||
                processName.find(L"pubgm") != std::wstring::npos ||
                processName.find(L"PUBGM") != std::wstring::npos) {
                
                CloseHandle(snapshot);
                return processEntry.th32ProcessID;
            }
        } while (Process32NextW(snapshot, &processEntry));
    }
    
    CloseHandle(snapshot);
    return 0;
}

bool InjectionManager::enableDebugPrivileges() {
    HANDLE token;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token)) {
        return false;
    }
    
    TOKEN_PRIVILEGES privileges;
    privileges.PrivilegeCount = 1;
    privileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
    
    if (!LookupPrivilegeValueA(nullptr, SE_DEBUG_NAME, &privileges.Privileges[0].Luid)) {
        CloseHandle(token);
        return false;
    }
    
    bool result = AdjustTokenPrivileges(token, FALSE, &privileges, sizeof(privileges), nullptr, nullptr);
    CloseHandle(token);
    
    return result && GetLastError() == ERROR_SUCCESS;
}

bool InjectionManager::validateTargetProcess(DWORD processId) {
    m_targetProcessHandle = OpenProcess(PROCESS_ALL_ACCESS, FALSE, processId);
    if (!m_targetProcessHandle) {
        return false;
    }
    
    // Check if process is still running
    DWORD exitCode;
    if (!GetExitCodeProcess(m_targetProcessHandle, &exitCode) || exitCode != STILL_ACTIVE) {
        CloseHandle(m_targetProcessHandle);
        m_targetProcessHandle = nullptr;
        return false;
    }
    
    return true;
}

bool InjectionManager::loadPayload() {
    // Load the DLL payload from resources or file
    // This is a simplified version - in practice, you'd load from encrypted resources
    
    try {
        // For demonstration, create a minimal payload
        // In real implementation, this would be your actual mod DLL
        m_payload = {
            0x4D, 0x5A, 0x90, 0x00, // MZ header
            // ... rest of DLL content would go here
        };
        
        m_payloadSize = m_payload.size();
        
        // Obfuscate payload
        return obfuscatePayload();
        
    } catch (const std::exception&) {
        return false;
    }
}

bool InjectionManager::obfuscatePayload() {
    // Simple XOR obfuscation - in practice, use more sophisticated methods
    const uint8_t xorKey = 0xAA;
    
    for (auto& byte : m_payload) {
        byte ^= xorKey;
    }
    
    return true;
}

bool InjectionManager::bypassAnticheat() {
    // Implement anticheat bypass techniques
    // This is highly game-specific and would require reverse engineering
    
    // For demonstration purposes, just return true
    // Real implementation would involve:
    // - Hooking anticheat functions
    // - Memory protection bypass
    // - Signature masking
    
    return true;
}

bool InjectionManager::injectManualMap() {
    try {
        // Allocate memory in target process
        if (!allocateMemoryInTarget(m_targetProcessHandle, m_payloadSize, &m_allocatedMemory)) {
            return false;
        }
        
        // Write payload to target
        if (!writePayloadToTarget(m_targetProcessHandle, m_allocatedMemory)) {
            return false;
        }
        
        // Create remote thread to execute payload
        if (!createRemoteThread(m_targetProcessHandle, m_allocatedMemory)) {
            return false;
        }
        
        return true;
        
    } catch (const std::exception&) {
        return false;
    }
}

bool InjectionManager::injectReflectiveDLL() {
    // Implement reflective DLL injection
    // This would involve loading the DLL without using LoadLibrary
    return injectManualMap(); // Simplified for demo
}

bool InjectionManager::injectProcessHollowing() {
    // Implement process hollowing technique
    // This would involve creating a suspended process and replacing its memory
    return injectManualMap(); // Simplified for demo
}

bool InjectionManager::allocateMemoryInTarget(HANDLE process, size_t size, void** allocatedMemory) {
    *allocatedMemory = VirtualAllocEx(process, nullptr, size, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    return *allocatedMemory != nullptr;
}

bool InjectionManager::writePayloadToTarget(HANDLE process, void* targetMemory) {
    SIZE_T bytesWritten;
    return WriteProcessMemory(process, targetMemory, m_payload.data(), m_payloadSize, &bytesWritten) &&
           bytesWritten == m_payloadSize;
}

bool InjectionManager::createRemoteThread(HANDLE process, void* entryPoint) {
    HANDLE thread = CreateRemoteThread(process, nullptr, 0, 
                                      reinterpret_cast<LPTHREAD_START_ROUTINE>(entryPoint), 
                                      nullptr, 0, nullptr);
    
    if (thread) {
        CloseHandle(thread);
        return true;
    }
    
    return false;
}

bool InjectionManager::validateIntegrity() {
    // Verify that the injection was successful and the payload is intact
    if (!m_allocatedMemory || !m_targetProcessHandle) {
        return false;
    }
    
    // Read back some bytes to verify
    std::vector<uint8_t> readBuffer(min(m_payloadSize, size_t(64)));
    SIZE_T bytesRead;
    
    if (!ReadProcessMemory(m_targetProcessHandle, m_allocatedMemory, 
                          readBuffer.data(), readBuffer.size(), &bytesRead)) {
        return false;
    }
    
    // Simple integrity check - compare first few bytes
    return bytesRead > 0;
}

void InjectionManager::checkInjectionHealth() {
    if (m_status != Injected) {
        return;
    }
    
    // Check if target process is still running
    if (!validateTargetProcess(m_targetProcessId)) {
        m_status = Failed;
        m_lastError = "Target process terminated";
        emit statusChanged(m_status);
        m_healthCheckTimer->stop();
        return;
    }
    
    // Check if our payload is still intact
    if (!validateIntegrity()) {
        m_status = Failed;
        m_lastError = "Payload integrity compromised";
        emit statusChanged(m_status);
        m_healthCheckTimer->stop();
        return;
    }
}

void InjectionManager::cleanupInjection() {
    if (m_allocatedMemory && m_targetProcessHandle) {
        VirtualFreeEx(m_targetProcessHandle, m_allocatedMemory, 0, MEM_RELEASE);
        m_allocatedMemory = nullptr;
    }
    
    if (m_targetProcessHandle) {
        CloseHandle(m_targetProcessHandle);
        m_targetProcessHandle = nullptr;
    }
    
    m_targetProcessId = 0;
    m_status = Idle;
}

void InjectionManager::restoreTargetProcess() {
    // Restore any hooks or modifications made to the target process
    for (auto hook : m_hooks) {
        // Restore original bytes
        // Implementation would depend on hook type
    }
    m_hooks.clear();
}