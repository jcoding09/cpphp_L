#include "status_monitor.h"
#include "logger.h"
#include <QTimer>
#include <QMutexLocker>
#include <QProcess>
#include <QStorageInfo>
#include <QNetworkInterface>
#include <QSysInfo>
#include <windows.h>
#include <psapi.h>
#include <pdh.h>
#include <pdhmsg.h>

#pragma comment(lib, "pdh.lib")

StatusMonitor::StatusMonitor(QObject *parent)
    : QObject(parent)
    , m_updateInterval(1000)
    , m_enableCpuMonitoring(true)
    , m_enableMemoryMonitoring(true)
    , m_enableDiskMonitoring(true)
    , m_enableNetworkMonitoring(true)
    , m_enableProcessMonitoring(true)
    , m_enableSystemMonitoring(true)
    , m_enablePerformanceMonitoring(true)
    , m_enableSecurityMonitoring(true)
    , m_cpuUsage(0.0)
    , m_memoryUsage(0.0)
    , m_diskUsage(0.0)
    , m_networkUsage(0.0)
    , m_processCount(0)
    , m_threadCount(0)
    , m_handleCount(0)
    , m_isMonitoring(false)
    , m_hQuery(nullptr)
    , m_hCpuCounter(nullptr)
    , m_hMemoryCounter(nullptr)
    , m_hDiskCounter(nullptr)
    , m_hNetworkCounter(nullptr)
{
    // Initialize update timer
    m_updateTimer = new QTimer(this);
    m_updateTimer->setSingleShot(false);
    m_updateTimer->setInterval(m_updateInterval);
    connect(m_updateTimer, &QTimer::timeout, this, &StatusMonitor::updateStatus);
    
    // Initialize performance counters
    initializePerformanceCounters();
    
    // Get system information
    updateSystemInfo();
    
    Logger::instance()->info("StatusMonitor initialized", "Monitor");
}

StatusMonitor::~StatusMonitor()
{
    stopMonitoring();
    cleanupPerformanceCounters();
}

void StatusMonitor::startMonitoring()
{
    QMutexLocker locker(&m_mutex);
    
    if (m_isMonitoring) {
        return;
    }
    
    m_isMonitoring = true;
    m_updateTimer->start();
    
    Logger::instance()->info("Status monitoring started", "Monitor");
    emit monitoringStarted();
    emit monitoringStateChanged(true);
}

void StatusMonitor::stopMonitoring()
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_isMonitoring) {
        return;
    }
    
    m_isMonitoring = false;
    m_updateTimer->stop();
    
    Logger::instance()->info("Status monitoring stopped", "Monitor");
    emit monitoringStopped();
    emit monitoringStateChanged(false);
}

bool StatusMonitor::isMonitoring() const
{
    QMutexLocker locker(&m_mutex);
    return m_isMonitoring;
}

void StatusMonitor::setUpdateInterval(int interval)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_updateInterval != interval) {
        m_updateInterval = interval;
        m_updateTimer->setInterval(interval);
        emit updateIntervalChanged(interval);
    }
}

int StatusMonitor::updateInterval() const
{
    QMutexLocker locker(&m_mutex);
    return m_updateInterval;
}

StatusMonitor::SystemInfo StatusMonitor::getSystemInfo() const
{
    QMutexLocker locker(&m_mutex);
    return m_systemInfo;
}

StatusMonitor::CpuInfo StatusMonitor::getCpuInfo() const
{
    QMutexLocker locker(&m_mutex);
    return m_cpuInfo;
}

StatusMonitor::MemoryInfo StatusMonitor::getMemoryInfo() const
{
    QMutexLocker locker(&m_mutex);
    return m_memoryInfo;
}

StatusMonitor::DiskInfo StatusMonitor::getDiskInfo() const
{
    QMutexLocker locker(&m_mutex);
    return m_diskInfo;
}

StatusMonitor::NetworkInfo StatusMonitor::getNetworkInfo() const
{
    QMutexLocker locker(&m_mutex);
    return m_networkInfo;
}

StatusMonitor::ProcessInfo StatusMonitor::getProcessInfo() const
{
    QMutexLocker locker(&m_mutex);
    return m_processInfo;
}

StatusMonitor::PerformanceInfo StatusMonitor::getPerformanceInfo() const
{
    QMutexLocker locker(&m_mutex);
    return m_performanceInfo;
}

StatusMonitor::SecurityInfo StatusMonitor::getSecurityInfo() const
{
    QMutexLocker locker(&m_mutex);
    return m_securityInfo;
}

QList<StatusMonitor::ProcessDetails> StatusMonitor::getRunningProcesses() const
{
    QMutexLocker locker(&m_mutex);
    return m_runningProcesses;
}

QList<StatusMonitor::ServiceDetails> StatusMonitor::getRunningServices() const
{
    QMutexLocker locker(&m_mutex);
    return m_runningServices;
}

QList<StatusMonitor::NetworkConnection> StatusMonitor::getNetworkConnections() const
{
    QMutexLocker locker(&m_mutex);
    return m_networkConnections;
}

StatusMonitor::StatusSummary StatusMonitor::getStatusSummary() const
{
    QMutexLocker locker(&m_mutex);
    
    StatusSummary summary;
    summary.overallStatus = calculateOverallStatus();
    summary.cpuUsage = m_cpuUsage;
    summary.memoryUsage = m_memoryUsage;
    summary.diskUsage = m_diskUsage;
    summary.networkUsage = m_networkUsage;
    summary.processCount = m_processCount;
    summary.activeConnections = m_networkConnections.size();
    summary.securityThreats = m_securityInfo.threatCount;
    summary.lastUpdate = QDateTime::currentDateTime();
    
    return summary;
}

void StatusMonitor::enableCpuMonitoring(bool enable)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_enableCpuMonitoring != enable) {
        m_enableCpuMonitoring = enable;
        emit cpuMonitoringChanged(enable);
    }
}

void StatusMonitor::enableMemoryMonitoring(bool enable)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_enableMemoryMonitoring != enable) {
        m_enableMemoryMonitoring = enable;
        emit memoryMonitoringChanged(enable);
    }
}

void StatusMonitor::enableDiskMonitoring(bool enable)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_enableDiskMonitoring != enable) {
        m_enableDiskMonitoring = enable;
        emit diskMonitoringChanged(enable);
    }
}

void StatusMonitor::enableNetworkMonitoring(bool enable)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_enableNetworkMonitoring != enable) {
        m_enableNetworkMonitoring = enable;
        emit networkMonitoringChanged(enable);
    }
}

void StatusMonitor::enableProcessMonitoring(bool enable)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_enableProcessMonitoring != enable) {
        m_enableProcessMonitoring = enable;
        emit processMonitoringChanged(enable);
    }
}

void StatusMonitor::enableSystemMonitoring(bool enable)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_enableSystemMonitoring != enable) {
        m_enableSystemMonitoring = enable;
        emit systemMonitoringChanged(enable);
    }
}

void StatusMonitor::enablePerformanceMonitoring(bool enable)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_enablePerformanceMonitoring != enable) {
        m_enablePerformanceMonitoring = enable;
        emit performanceMonitoringChanged(enable);
    }
}

void StatusMonitor::enableSecurityMonitoring(bool enable)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_enableSecurityMonitoring != enable) {
        m_enableSecurityMonitoring = enable;
        emit securityMonitoringChanged(enable);
    }
}

void StatusMonitor::updateStatus()
{
    if (!m_isMonitoring) {
        return;
    }
    
    try {
        // Update different components based on enabled monitoring
        if (m_enableCpuMonitoring) {
            updateCpuInfo();
        }
        
        if (m_enableMemoryMonitoring) {
            updateMemoryInfo();
        }
        
        if (m_enableDiskMonitoring) {
            updateDiskInfo();
        }
        
        if (m_enableNetworkMonitoring) {
            updateNetworkInfo();
        }
        
        if (m_enableProcessMonitoring) {
            updateProcessInfo();
        }
        
        if (m_enableSystemMonitoring) {
            updateSystemInfo();
        }
        
        if (m_enablePerformanceMonitoring) {
            updatePerformanceInfo();
        }
        
        if (m_enableSecurityMonitoring) {
            updateSecurityInfo();
        }
        
        // Emit update signals
        emit statusUpdated();
        emit cpuUsageChanged(m_cpuUsage);
        emit memoryUsageChanged(m_memoryUsage);
        emit diskUsageChanged(m_diskUsage);
        emit networkUsageChanged(m_networkUsage);
        
    } catch (...) {
        Logger::instance()->error("Error updating status", "Monitor");
    }
}

void StatusMonitor::updateSystemInfo()
{
    m_systemInfo.osName = QSysInfo::prettyProductName();
    m_systemInfo.osVersion = QSysInfo::productVersion();
    m_systemInfo.kernelType = QSysInfo::kernelType();
    m_systemInfo.kernelVersion = QSysInfo::kernelVersion();
    m_systemInfo.architecture = QSysInfo::currentCpuArchitecture();
    m_systemInfo.hostname = QSysInfo::machineHostName();
    m_systemInfo.uptime = GetTickCount64() / 1000; // Convert to seconds
    
    // Get system metrics
    m_systemInfo.screenWidth = GetSystemMetrics(SM_CXSCREEN);
    m_systemInfo.screenHeight = GetSystemMetrics(SM_CYSCREEN);
    m_systemInfo.processorCount = QThread::idealThreadCount();
    
    emit systemInfoUpdated(m_systemInfo);
}

void StatusMonitor::updateCpuInfo()
{
    if (m_hCpuCounter) {
        PDH_FMT_COUNTERVALUE counterValue;
        PDH_STATUS status = PdhCollectQueryData(m_hQuery);
        
        if (status == ERROR_SUCCESS) {
            status = PdhGetFormattedCounterValue(m_hCpuCounter, PDH_FMT_DOUBLE, nullptr, &counterValue);
            if (status == ERROR_SUCCESS) {
                m_cpuUsage = counterValue.doubleValue;
                m_cpuInfo.usage = m_cpuUsage;
            }
        }
    }
    
    // Get CPU frequency (placeholder)
    m_cpuInfo.frequency = 2400; // MHz
    m_cpuInfo.coreCount = QThread::idealThreadCount();
    m_cpuInfo.threadCount = QThread::idealThreadCount() * 2; // Assuming hyperthreading
    m_cpuInfo.temperature = 45.0; // Placeholder
    
    emit cpuInfoUpdated(m_cpuInfo);
}

void StatusMonitor::updateMemoryInfo()
{
    MEMORYSTATUSEX memStatus;
    memStatus.dwLength = sizeof(memStatus);
    
    if (GlobalMemoryStatusEx(&memStatus)) {
        m_memoryInfo.totalPhysical = memStatus.ullTotalPhys;
        m_memoryInfo.availablePhysical = memStatus.ullAvailPhys;
        m_memoryInfo.usedPhysical = m_memoryInfo.totalPhysical - m_memoryInfo.availablePhysical;
        m_memoryInfo.totalVirtual = memStatus.ullTotalVirtual;
        m_memoryInfo.availableVirtual = memStatus.ullAvailVirtual;
        m_memoryInfo.usedVirtual = m_memoryInfo.totalVirtual - m_memoryInfo.availableVirtual;
        m_memoryInfo.totalPageFile = memStatus.ullTotalPageFile;
        m_memoryInfo.availablePageFile = memStatus.ullAvailPageFile;
        m_memoryInfo.usedPageFile = m_memoryInfo.totalPageFile - m_memoryInfo.availablePageFile;
        
        m_memoryUsage = (double)m_memoryInfo.usedPhysical / m_memoryInfo.totalPhysical * 100.0;
        m_memoryInfo.usage = m_memoryUsage;
    }
    
    emit memoryInfoUpdated(m_memoryInfo);
}

void StatusMonitor::updateDiskInfo()
{
    QStorageInfo storage = QStorageInfo::root();
    
    m_diskInfo.totalSpace = storage.bytesTotal();
    m_diskInfo.freeSpace = storage.bytesFree();
    m_diskInfo.usedSpace = m_diskInfo.totalSpace - m_diskInfo.freeSpace;
    m_diskInfo.usage = (double)m_diskInfo.usedSpace / m_diskInfo.totalSpace * 100.0;
    m_diskInfo.readSpeed = 0; // Placeholder
    m_diskInfo.writeSpeed = 0; // Placeholder
    m_diskInfo.readOperations = 0; // Placeholder
    m_diskInfo.writeOperations = 0; // Placeholder
    
    m_diskUsage = m_diskInfo.usage;
    
    emit diskInfoUpdated(m_diskInfo);
}

void StatusMonitor::updateNetworkInfo()
{
    // Get network interface information
    QList<QNetworkInterface> interfaces = QNetworkInterface::allInterfaces();
    
    m_networkInfo.bytesReceived = 0; // Placeholder
    m_networkInfo.bytesSent = 0; // Placeholder
    m_networkInfo.packetsReceived = 0; // Placeholder
    m_networkInfo.packetsSent = 0; // Placeholder
    m_networkInfo.downloadSpeed = 0; // Placeholder
    m_networkInfo.uploadSpeed = 0; // Placeholder
    m_networkInfo.activeConnections = 0; // Placeholder
    m_networkInfo.usage = 0; // Placeholder
    
    m_networkUsage = m_networkInfo.usage;
    
    emit networkInfoUpdated(m_networkInfo);
}

void StatusMonitor::updateProcessInfo()
{
    // Get current process information
    HANDLE hProcess = GetCurrentProcess();
    PROCESS_MEMORY_COUNTERS_EX pmc;
    
    if (GetProcessMemoryInfo(hProcess, (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc))) {
        m_processInfo.memoryUsage = pmc.WorkingSetSize;
        m_processInfo.virtualMemoryUsage = pmc.PrivateUsage;
        m_processInfo.peakMemoryUsage = pmc.PeakWorkingSetSize;
    }
    
    // Get process count
    m_processCount = 0;
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnapshot != INVALID_HANDLE_VALUE) {
        PROCESSENTRY32 pe32;
        pe32.dwSize = sizeof(PROCESSENTRY32);
        
        if (Process32First(hSnapshot, &pe32)) {
            do {
                m_processCount++;
            } while (Process32Next(hSnapshot, &pe32));
        }
        
        CloseHandle(hSnapshot);
    }
    
    m_processInfo.processCount = m_processCount;
    m_processInfo.threadCount = m_threadCount;
    m_processInfo.handleCount = m_handleCount;
    m_processInfo.cpuUsage = 0; // Placeholder
    
    emit processInfoUpdated(m_processInfo);
}

void StatusMonitor::updatePerformanceInfo()
{
    // Update performance metrics
    m_performanceInfo.frameRate = 60; // Placeholder
    m_performanceInfo.frameTime = 16.67; // Placeholder
    m_performanceInfo.renderTime = 10.0; // Placeholder
    m_performanceInfo.updateTime = 5.0; // Placeholder
    m_performanceInfo.ioWaitTime = 1.0; // Placeholder
    m_performanceInfo.contextSwitches = 1000; // Placeholder
    m_performanceInfo.interrupts = 500; // Placeholder
    m_performanceInfo.systemCalls = 2000; // Placeholder
    
    emit performanceInfoUpdated(m_performanceInfo);
}

void StatusMonitor::updateSecurityInfo()
{
    // Update security information
    m_securityInfo.antivirusEnabled = true; // Placeholder
    m_securityInfo.firewallEnabled = true; // Placeholder
    m_securityInfo.realTimeProtection = true; // Placeholder
    m_securityInfo.threatCount = 0; // Placeholder
    m_securityInfo.lastScanTime = QDateTime::currentDateTime().addDays(-1); // Placeholder
    m_securityInfo.definitionsVersion = "1.0.0"; // Placeholder
    m_securityInfo.quarantinedItems = 0; // Placeholder
    m_securityInfo.securityLevel = SecurityLevel::High; // Placeholder
    
    emit securityInfoUpdated(m_securityInfo);
}

StatusMonitor::SystemStatus StatusMonitor::calculateOverallStatus() const
{
    // Calculate overall system status based on various metrics
    if (m_cpuUsage > 90 || m_memoryUsage > 95 || m_diskUsage > 95) {
        return SystemStatus::Critical;
    } else if (m_cpuUsage > 70 || m_memoryUsage > 80 || m_diskUsage > 80) {
        return SystemStatus::Warning;
    } else if (m_securityInfo.threatCount > 0) {
        return SystemStatus::Warning;
    } else {
        return SystemStatus::Normal;
    }
}

void StatusMonitor::initializePerformanceCounters()
{
    // Initialize PDH performance counters
    PDH_STATUS status = PdhOpenQuery(nullptr, 0, &m_hQuery);
    if (status != ERROR_SUCCESS) {
        Logger::instance()->error("Failed to open PDH query", "Monitor");
        return;
    }
    
    // Add CPU counter
    status = PdhAddEnglishCounter(m_hQuery, L"\\Processor(_Total)\\% Processor Time", 0, &m_hCpuCounter);
    if (status != ERROR_SUCCESS) {
        Logger::instance()->warning("Failed to add CPU counter", "Monitor");
    }
    
    // Add Memory counter
    status = PdhAddEnglishCounter(m_hQuery, L"\\Memory\\Available Bytes", 0, &m_hMemoryCounter);
    if (status != ERROR_SUCCESS) {
        Logger::instance()->warning("Failed to add Memory counter", "Monitor");
    }
    
    // Collect initial data
    PdhCollectQueryData(m_hQuery);
    Sleep(1000); // Wait for initial collection
}

void StatusMonitor::cleanupPerformanceCounters()
{
    if (m_hQuery) {
        PdhCloseQuery(m_hQuery);
        m_hQuery = nullptr;
    }
    
    m_hCpuCounter = nullptr;
    m_hMemoryCounter = nullptr;
    m_hDiskCounter = nullptr;
    m_hNetworkCounter = nullptr;
}

void StatusMonitor::refreshProcessList()
{
    QMutexLocker locker(&m_mutex);
    
    m_runningProcesses.clear();
    
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnapshot == INVALID_HANDLE_VALUE) {
        return;
    }
    
    PROCESSENTRY32W pe32;
    pe32.dwSize = sizeof(PROCESSENTRY32W);
    
    if (Process32FirstW(hSnapshot, &pe32)) {
        do {
            ProcessDetails process;
            process.processId = pe32.th32ProcessID;
            process.parentProcessId = pe32.th32ParentProcessID;
            process.name = QString::fromWCharArray(pe32.szExeFile);
            process.threadCount = pe32.cntThreads;
            process.priority = pe32.pcPriClassBase;
            
            // Get additional process information
            HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, pe32.th32ProcessID);
            if (hProcess) {
                PROCESS_MEMORY_COUNTERS_EX pmc;
                if (GetProcessMemoryInfo(hProcess, (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc))) {
                    process.memoryUsage = pmc.WorkingSetSize;
                    process.virtualMemoryUsage = pmc.PrivateUsage;
                }
                
                CloseHandle(hProcess);
            }
            
            m_runningProcesses.append(process);
            
        } while (Process32NextW(hSnapshot, &pe32));
    }
    
    CloseHandle(hSnapshot);
    
    emit processListUpdated(m_runningProcesses);
}

void StatusMonitor::refreshServiceList()
{
    QMutexLocker locker(&m_mutex);
    
    m_runningServices.clear();
    
    // Get Windows services information
    SC_HANDLE hSCManager = OpenSCManager(nullptr, nullptr, SC_MANAGER_ENUMERATE_SERVICE);
    if (!hSCManager) {
        return;
    }
    
    DWORD bytesNeeded = 0;
    DWORD servicesReturned = 0;
    DWORD resumeHandle = 0;
    
    // Get required buffer size
    EnumServicesStatusEx(hSCManager, SC_ENUM_PROCESS_INFO, SERVICE_WIN32,
                        SERVICE_STATE_ALL, nullptr, 0, &bytesNeeded,
                        &servicesReturned, &resumeHandle, nullptr);
    
    if (bytesNeeded > 0) {
        QByteArray buffer(bytesNeeded, 0);
        LPENUM_SERVICE_STATUS_PROCESS services = reinterpret_cast<LPENUM_SERVICE_STATUS_PROCESS>(buffer.data());
        
        if (EnumServicesStatusEx(hSCManager, SC_ENUM_PROCESS_INFO, SERVICE_WIN32,
                                SERVICE_STATE_ALL, reinterpret_cast<LPBYTE>(services),
                                bytesNeeded, &bytesNeeded, &servicesReturned,
                                &resumeHandle, nullptr)) {
            
            for (DWORD i = 0; i < servicesReturned; ++i) {
                ServiceDetails service;
                service.name = QString::fromWCharArray(services[i].lpServiceName);
                service.displayName = QString::fromWCharArray(services[i].lpDisplayName);
                service.processId = services[i].ServiceStatusProcess.dwProcessId;
                service.state = static_cast<ServiceState>(services[i].ServiceStatusProcess.dwCurrentState);
                service.startType = StartType::Automatic; // Placeholder
                
                m_runningServices.append(service);
            }
        }
    }
    
    CloseServiceHandle(hSCManager);
    
    emit serviceListUpdated(m_runningServices);
}

void StatusMonitor::refreshNetworkConnections()
{
    QMutexLocker locker(&m_mutex);
    
    m_networkConnections.clear();
    
    // Placeholder implementation
    // In a real implementation, you would use GetTcpTable2 or similar APIs
    
    emit networkConnectionsUpdated(m_networkConnections);
}

void StatusMonitor::exportStatusReport(const QString& filePath)
{
    // Export comprehensive status report
    QJsonObject report;
    
    // Add timestamp
    report["timestamp"] = QDateTime::currentDateTime().toString(Qt::ISODate);
    report["version"] = "1.0.0";
    
    // Add system information
    QJsonObject systemObj;
    systemObj["osName"] = m_systemInfo.osName;
    systemObj["osVersion"] = m_systemInfo.osVersion;
    systemObj["architecture"] = m_systemInfo.architecture;
    systemObj["hostname"] = m_systemInfo.hostname;
    systemObj["uptime"] = static_cast<qint64>(m_systemInfo.uptime);
    report["system"] = systemObj;
    
    // Add performance information
    QJsonObject perfObj;
    perfObj["cpuUsage"] = m_cpuUsage;
    perfObj["memoryUsage"] = m_memoryUsage;
    perfObj["diskUsage"] = m_diskUsage;
    perfObj["networkUsage"] = m_networkUsage;
    report["performance"] = perfObj;
    
    // Save to file
    QJsonDocument doc(report);
    QFile file(filePath);
    if (file.open(QIODevice::WriteOnly)) {
        file.write(doc.toJson());
        file.close();
        Logger::instance()->info(QString("Status report exported to %1").arg(filePath), "Monitor");
    } else {
        Logger::instance()->error(QString("Failed to export status report to %1").arg(filePath), "Monitor");
    }
}