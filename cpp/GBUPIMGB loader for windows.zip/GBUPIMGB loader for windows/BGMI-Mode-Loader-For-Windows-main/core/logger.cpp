#include "logger.h"
#include <QDateTime>
#include <QDir>
#include <QStandardPaths>
#include <QTextStream>
#include <QMutexLocker>
#include <iostream>

Logger::Logger(QObject *parent)
    : QObject(parent)
    , m_logLevel(LogLevel::Info)
    , m_maxFileSize(10 * 1024 * 1024) // 10MB
    , m_maxFiles(5)
    , m_enableConsole(true)
    , m_enableFile(true)
    , m_enableBuffer(true)
    , m_bufferSize(1000)
    , m_autoFlush(true)
    , m_flushInterval(5000) // 5 seconds
{
    // Initialize log directory
    QString appDataPath = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    m_logDirectory = QDir(appDataPath).absoluteFilePath("logs");
    
    // Create log directory if it doesn't exist
    QDir().mkpath(m_logDirectory);
    
    // Initialize current log file
    updateLogFile();
    
    // Setup flush timer
    m_flushTimer = new QTimer(this);
    m_flushTimer->setSingleShot(false);
    m_flushTimer->setInterval(m_flushInterval);
    connect(m_flushTimer, &QTimer::timeout, this, &Logger::flushBuffer);
    
    if (m_autoFlush) {
        m_flushTimer->start();
    }
    
    // Log startup message
    info("Logger initialized");
}

Logger::~Logger()
{
    flushBuffer();
    if (m_logFile.isOpen()) {
        m_logFile.close();
    }
}

Logger* Logger::instance()
{
    static Logger* s_instance = nullptr;
    if (!s_instance) {
        s_instance = new Logger();
    }
    return s_instance;
}

void Logger::setLogLevel(LogLevel level)
{
    QMutexLocker locker(&m_mutex);
    m_logLevel = level;
    emit logLevelChanged(level);
}

Logger::LogLevel Logger::logLevel() const
{
    QMutexLocker locker(&m_mutex);
    return m_logLevel;
}

void Logger::setLogDirectory(const QString& directory)
{
    QMutexLocker locker(&m_mutex);
    m_logDirectory = directory;
    QDir().mkpath(m_logDirectory);
    updateLogFile();
    emit logDirectoryChanged(directory);
}

QString Logger::logDirectory() const
{
    QMutexLocker locker(&m_mutex);
    return m_logDirectory;
}

void Logger::setMaxFileSize(qint64 size)
{
    QMutexLocker locker(&m_mutex);
    m_maxFileSize = size;
    emit maxFileSizeChanged(size);
}

qint64 Logger::maxFileSize() const
{
    QMutexLocker locker(&m_mutex);
    return m_maxFileSize;
}

void Logger::setMaxFiles(int count)
{
    QMutexLocker locker(&m_mutex);
    m_maxFiles = count;
    emit maxFilesChanged(count);
}

int Logger::maxFiles() const
{
    QMutexLocker locker(&m_mutex);
    return m_maxFiles;
}

void Logger::setEnableConsole(bool enable)
{
    QMutexLocker locker(&m_mutex);
    m_enableConsole = enable;
    emit enableConsoleChanged(enable);
}

bool Logger::enableConsole() const
{
    QMutexLocker locker(&m_mutex);
    return m_enableConsole;
}

void Logger::setEnableFile(bool enable)
{
    QMutexLocker locker(&m_mutex);
    m_enableFile = enable;
    emit enableFileChanged(enable);
}

bool Logger::enableFile() const
{
    QMutexLocker locker(&m_mutex);
    return m_enableFile;
}

void Logger::debug(const QString& message, const QString& category)
{
    log(LogLevel::Debug, message, category);
}

void Logger::info(const QString& message, const QString& category)
{
    log(LogLevel::Info, message, category);
}

void Logger::warning(const QString& message, const QString& category)
{
    log(LogLevel::Warning, message, category);
}

void Logger::error(const QString& message, const QString& category)
{
    log(LogLevel::Error, message, category);
}

void Logger::critical(const QString& message, const QString& category)
{
    log(LogLevel::Critical, message, category);
}

void Logger::log(LogLevel level, const QString& message, const QString& category)
{
    QMutexLocker locker(&m_mutex);
    
    // Check if we should log this level
    if (level < m_logLevel) {
        return;
    }
    
    // Create log entry
    LogEntry entry;
    entry.timestamp = QDateTime::currentDateTime();
    entry.level = level;
    entry.message = message;
    entry.category = category.isEmpty() ? "General" : category;
    entry.threadId = QThread::currentThreadId();
    
    // Format log message
    QString formattedMessage = formatLogEntry(entry);
    
    // Output to console
    if (m_enableConsole) {
        outputToConsole(formattedMessage, level);
    }
    
    // Add to buffer
    if (m_enableBuffer) {
        m_logBuffer.append(entry);
        
        // Trim buffer if too large
        while (m_logBuffer.size() > m_bufferSize) {
            m_logBuffer.removeFirst();
        }
    }
    
    // Write to file
    if (m_enableFile) {
        writeToFile(formattedMessage);
    }
    
    // Emit signal
    emit logMessage(entry);
    
    // Update statistics
    m_statistics.totalMessages++;
    switch (level) {
        case LogLevel::Debug: m_statistics.debugCount++; break;
        case LogLevel::Info: m_statistics.infoCount++; break;
        case LogLevel::Warning: m_statistics.warningCount++; break;
        case LogLevel::Error: m_statistics.errorCount++; break;
        case LogLevel::Critical: m_statistics.criticalCount++; break;
    }
    
    emit statisticsChanged(m_statistics);
}

QString Logger::formatLogEntry(const LogEntry& entry) const
{
    QString levelStr;
    switch (entry.level) {
        case LogLevel::Debug: levelStr = "DEBUG"; break;
        case LogLevel::Info: levelStr = "INFO"; break;
        case LogLevel::Warning: levelStr = "WARN"; break;
        case LogLevel::Error: levelStr = "ERROR"; break;
        case LogLevel::Critical: levelStr = "CRIT"; break;
    }
    
    return QString("[%1] [%2] [%3] %4")
        .arg(entry.timestamp.toString("yyyy-MM-dd hh:mm:ss.zzz"))
        .arg(levelStr)
        .arg(entry.category)
        .arg(entry.message);
}

void Logger::outputToConsole(const QString& message, LogLevel level)
{
    if (level >= LogLevel::Error) {
        std::cerr << message.toStdString() << std::endl;
    } else {
        std::cout << message.toStdString() << std::endl;
    }
}

void Logger::writeToFile(const QString& message)
{
    if (!m_logFile.isOpen()) {
        return;
    }
    
    // Check if we need to rotate the file
    if (m_logFile.size() > m_maxFileSize) {
        rotateLogFile();
    }
    
    QTextStream stream(&m_logFile);
    stream << message << Qt::endl;
    
    if (m_autoFlush) {
        stream.flush();
    }
}

void Logger::updateLogFile()
{
    if (m_logFile.isOpen()) {
        m_logFile.close();
    }
    
    QString timestamp = QDateTime::currentDateTime().toString("yyyyMMdd_hhmmss");
    QString filename = QString("ghostpulse_%1.log").arg(timestamp);
    QString filepath = QDir(m_logDirectory).absoluteFilePath(filename);
    
    m_logFile.setFileName(filepath);
    if (!m_logFile.open(QIODevice::WriteOnly | QIODevice::Append)) {
        // Fallback to console only if file can't be opened
        m_enableFile = false;
        std::cerr << "Failed to open log file: " << filepath.toStdString() << std::endl;
    }
}

void Logger::rotateLogFile()
{
    // Close current file
    if (m_logFile.isOpen()) {
        m_logFile.close();
    }
    
    // Clean up old files
    cleanupOldFiles();
    
    // Create new file
    updateLogFile();
}

void Logger::cleanupOldFiles()
{
    QDir logDir(m_logDirectory);
    QStringList filters;
    filters << "ghostpulse_*.log";
    
    QFileInfoList files = logDir.entryInfoList(filters, QDir::Files, QDir::Time | QDir::Reversed);
    
    // Remove excess files
    while (files.size() >= m_maxFiles) {
        QFile::remove(files.last().absoluteFilePath());
        files.removeLast();
    }
}

void Logger::flushBuffer()
{
    QMutexLocker locker(&m_mutex);
    
    if (m_logFile.isOpen()) {
        m_logFile.flush();
    }
    
    emit bufferFlushed();
}

void Logger::clearBuffer()
{
    QMutexLocker locker(&m_mutex);
    m_logBuffer.clear();
    emit bufferCleared();
}

QList<Logger::LogEntry> Logger::getBuffer() const
{
    QMutexLocker locker(&m_mutex);
    return m_logBuffer;
}

QList<Logger::LogEntry> Logger::getFilteredBuffer(LogLevel minLevel, const QString& category) const
{
    QMutexLocker locker(&m_mutex);
    
    QList<LogEntry> filtered;
    for (const LogEntry& entry : m_logBuffer) {
        if (entry.level >= minLevel) {
            if (category.isEmpty() || entry.category == category) {
                filtered.append(entry);
            }
        }
    }
    
    return filtered;
}

Logger::LogStatistics Logger::getStatistics() const
{
    QMutexLocker locker(&m_mutex);
    return m_statistics;
}

void Logger::resetStatistics()
{
    QMutexLocker locker(&m_mutex);
    m_statistics = LogStatistics();
    emit statisticsChanged(m_statistics);
}

QStringList Logger::getCategories() const
{
    QMutexLocker locker(&m_mutex);
    
    QStringList categories;
    for (const LogEntry& entry : m_logBuffer) {
        if (!categories.contains(entry.category)) {
            categories.append(entry.category);
        }
    }
    
    categories.sort();
    return categories;
}

bool Logger::exportLogs(const QString& filepath, LogLevel minLevel, const QString& category) const
{
    QFile file(filepath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        return false;
    }
    
    QTextStream stream(&file);
    
    QList<LogEntry> entries = getFilteredBuffer(minLevel, category);
    for (const LogEntry& entry : entries) {
        stream << formatLogEntry(entry) << Qt::endl;
    }
    
    return true;
}