#ifndef CONFIG_MANAGER_H
#define CONFIG_MANAGER_H

#include <QtCore/QObject>
#include <QtCore/QSettings>
#include <QtCore/QJsonObject>
#include <QtCore/QJsonDocument>
#include <QtCore/QJsonArray>
#include <QtCore/QString>
#include <QtCore/QStringList>
#include <QtCore/QVariant>
#include <QtCore/QMap>
#include <QtCore/QDateTime>
#include <QtCore/QFileSystemWatcher>
#include <QtCore/QTimer>
#include <QtCore/QMutex>
#include <memory>

// Forward declarations
class Logger;

enum class ConfigType {
    Application = 0,
    User = 1,
    Game = 2,
    Injection = 3,
    Memory = 4,
    Modules = 5,
    UI = 6,
    Security = 7,
    Performance = 8,
    Network = 9,
    Logging = 10,
    Custom = 11
};

enum class ConfigFormat {
    JSON = 0,
    INI = 1,
    XML = 2,
    Binary = 3,
    Registry = 4
};

enum class ConfigScope {
    Global = 0,
    User = 1,
    Session = 2,
    Temporary = 3
};

enum class ConfigSecurity {
    None = 0,
    Encrypted = 1,
    Obfuscated = 2,
    Compressed = 3,
    Signed = 4
};

enum class ValidationLevel {
    None = 0,
    Basic = 1,
    Strict = 2,
    Custom = 3
};

struct ConfigValue {
    QString key;
    QVariant value;
    QVariant defaultValue;
    QString description;
    QString category;
    
    ConfigType type = ConfigType::Application;
    ConfigScope scope = ConfigScope::Global;
    ValidationLevel validation = ValidationLevel::Basic;
    
    bool isRequired = false;
    bool isReadOnly = false;
    bool isEncrypted = false;
    bool isObfuscated = false;
    
    QVariant minValue;
    QVariant maxValue;
    QStringList allowedValues;
    QString validationRegex;
    
    QDateTime created;
    QDateTime lastModified;
    QString lastModifiedBy;
    
    QMap<QString, QVariant> metadata;
};

struct ConfigSection {
    QString name;
    QString description;
    QString category;
    ConfigType type = ConfigType::Application;
    
    QMap<QString, ConfigValue> values;
    QMap<QString, ConfigSection> subsections;
    
    bool isRequired = false;
    bool isReadOnly = false;
    bool isEncrypted = false;
    
    QDateTime created;
    QDateTime lastModified;
    QString version;
    
    QMap<QString, QVariant> metadata;
};

struct ConfigProfile {
    QString name;
    QString description;
    QString author;
    QString version;
    
    QMap<QString, ConfigSection> sections;
    QStringList dependencies;
    QStringList conflicts;
    
    bool isDefault = false;
    bool isReadOnly = false;
    bool isActive = false;
    
    QDateTime created;
    QDateTime lastModified;
    QDateTime lastUsed;
    
    QString filePath;
    ConfigFormat format = ConfigFormat::JSON;
    ConfigSecurity security = ConfigSecurity::None;
    
    QMap<QString, QVariant> metadata;
};

struct ConfigBackup {
    QString name;
    QString description;
    QString profileName;
    
    QJsonObject data;
    QString checksum;
    qint64 size;
    
    QDateTime created;
    QString createdBy;
    QString reason;
    
    QString filePath;
    bool isAutomatic = false;
    bool isCompressed = false;
    
    QMap<QString, QVariant> metadata;
};

struct ConfigValidationRule {
    QString name;
    QString description;
    QString key;
    QString category;
    
    ValidationLevel level = ValidationLevel::Basic;
    QString validationFunction;
    QString errorMessage;
    
    QVariant minValue;
    QVariant maxValue;
    QStringList allowedValues;
    QString regex;
    
    bool isRequired = false;
    bool isEnabled = true;
    
    QMap<QString, QVariant> parameters;
};

struct ConfigStatistics {
    int totalProfiles = 0;
    int totalSections = 0;
    int totalValues = 0;
    int totalBackups = 0;
    
    int loadedProfiles = 0;
    int activeProfiles = 0;
    int modifiedProfiles = 0;
    int errorProfiles = 0;
    
    qint64 totalSize = 0;
    qint64 memoryUsage = 0;
    qint64 diskUsage = 0;
    
    int loadOperations = 0;
    int saveOperations = 0;
    int validationOperations = 0;
    int backupOperations = 0;
    
    qint64 totalLoadTime = 0;
    qint64 totalSaveTime = 0;
    qint64 averageLoadTime = 0;
    qint64 averageSaveTime = 0;
    
    QDateTime lastReset;
    QDateTime lastUpdate;
    
    QMap<ConfigType, int> typeUsage;
    QMap<ConfigFormat, int> formatUsage;
    QMap<ConfigScope, int> scopeUsage;
    
    QStringList mostUsedProfiles;
    QStringList recentlyModified;
    QStringList errorMessages;
};

class ConfigManager : public QObject
{
    Q_OBJECT

public:
    explicit ConfigManager(QObject *parent = nullptr);
    ~ConfigManager();
    
    // Component integration
    void setLogger(Logger *logger);
    
    // Initialization
    bool initialize();
    void cleanup();
    bool isInitialized() const;
    
    // Profile management
    bool createProfile(const QString &name, const QString &description = "");
    bool loadProfile(const QString &name);
    bool saveProfile(const QString &name = "");
    bool deleteProfile(const QString &name);
    bool copyProfile(const QString &source, const QString &destination);
    bool renameProfile(const QString &oldName, const QString &newName);
    bool setActiveProfile(const QString &name);
    QString getActiveProfile() const;
    QStringList getProfileNames() const;
    ConfigProfile getProfile(const QString &name) const;
    bool hasProfile(const QString &name) const;
    
    // Section management
    bool createSection(const QString &sectionName, ConfigType type = ConfigType::Application);
    bool deleteSection(const QString &sectionName);
    bool renameSection(const QString &oldName, const QString &newName);
    bool copySection(const QString &source, const QString &destination);
    QStringList getSectionNames() const;
    QStringList getSectionNames(ConfigType type) const;
    ConfigSection getSection(const QString &name) const;
    bool hasSection(const QString &name) const;
    
    // Value management
    void setValue(const QString &key, const QVariant &value, ConfigType type = ConfigType::Application);
    QVariant getValue(const QString &key, const QVariant &defaultValue = QVariant()) const;
    void setDefaultValue(const QString &key, const QVariant &defaultValue);
    QVariant getDefaultValue(const QString &key) const;
    void removeValue(const QString &key);
    bool hasValue(const QString &key) const;
    QStringList getKeys() const;
    QStringList getKeys(const QString &section) const;
    QStringList getKeys(ConfigType type) const;
    
    // Batch operations
    void setValues(const QMap<QString, QVariant> &values, ConfigType type = ConfigType::Application);
    QMap<QString, QVariant> getValues(const QString &section = "") const;
    QMap<QString, QVariant> getValues(ConfigType type) const;
    void removeValues(const QStringList &keys);
    void clearSection(const QString &section);
    void clearType(ConfigType type);
    void clearAll();
    
    // File operations
    bool loadFromFile(const QString &filename, ConfigFormat format = ConfigFormat::JSON);
    bool saveToFile(const QString &filename, ConfigFormat format = ConfigFormat::JSON) const;
    bool importProfile(const QString &filename, const QString &profileName = "");
    bool exportProfile(const QString &profileName, const QString &filename) const;
    bool mergeFromFile(const QString &filename, bool overwrite = false);
    
    // Backup management
    QString createBackup(const QString &reason = "");
    bool restoreBackup(const QString &backupName);
    bool deleteBackup(const QString &backupName);
    QStringList getBackupNames() const;
    ConfigBackup getBackup(const QString &name) const;
    void setAutoBackup(bool enabled, int maxBackups = 10);
    bool isAutoBackupEnabled() const;
    void cleanupOldBackups(int maxAge = 30); // days
    
    // Validation
    void addValidationRule(const ConfigValidationRule &rule);
    void removeValidationRule(const QString &name);
    QList<ConfigValidationRule> getValidationRules() const;
    bool validateValue(const QString &key, const QVariant &value) const;
    bool validateSection(const QString &section) const;
    bool validateProfile(const QString &profile = "") const;
    QStringList getValidationErrors() const;
    void setValidationLevel(ValidationLevel level);
    ValidationLevel getValidationLevel() const;
    
    // Security
    void setEncryption(bool enabled, const QString &password = "");
    bool isEncryptionEnabled() const;
    void setObfuscation(bool enabled);
    bool isObfuscationEnabled() const;
    void setCompression(bool enabled);
    bool isCompressionEnabled() const;
    QString generateChecksum(const QString &profile = "") const;
    bool verifyChecksum(const QString &profile, const QString &checksum) const;
    
    // Monitoring
    void setFileWatching(bool enabled);
    bool isFileWatchingEnabled() const;
    void setAutoReload(bool enabled);
    bool isAutoReloadEnabled() const;
    void setAutoSave(bool enabled, int interval = 30000); // milliseconds
    bool isAutoSaveEnabled() const;
    
    // Templates and presets
    bool createTemplate(const QString &name, const QString &description = "");
    bool applyTemplate(const QString &name);
    bool deleteTemplate(const QString &name);
    QStringList getTemplateNames() const;
    bool saveAsTemplate(const QString &name, const QString &description = "");
    
    // Migration and versioning
    bool migrateFromVersion(const QString &fromVersion, const QString &toVersion);
    QString getCurrentVersion() const;
    void setVersion(const QString &version);
    bool isVersionCompatible(const QString &version) const;
    QStringList getSupportedVersions() const;
    
    // Statistics and monitoring
    ConfigStatistics getStatistics() const;
    void resetStatistics();
    QString getUsageReport() const;
    QString getPerformanceReport() const;
    qint64 getMemoryUsage() const;
    qint64 getDiskUsage() const;
    
    // Advanced features
    void setConfigPath(const QString &path);
    QString getConfigPath() const;
    void setConfigFormat(ConfigFormat format);
    ConfigFormat getConfigFormat() const;
    void setConfigSecurity(ConfigSecurity security);
    ConfigSecurity getConfigSecurity() const;
    
    // Utility functions
    static QString typeToString(ConfigType type);
    static ConfigType stringToType(const QString &str);
    static QString formatToString(ConfigFormat format);
    static ConfigFormat stringToFormat(const QString &str);
    static QString scopeToString(ConfigScope scope);
    static ConfigScope stringToScope(const QString &str);
    static QString securityToString(ConfigSecurity security);
    static ConfigSecurity stringToSecurity(const QString &str);
    static bool isValidKey(const QString &key);
    static QString normalizeKey(const QString &key);
    
public slots:
    // Profile slots
    void onProfileCreateRequested(const QString &name, const QString &description);
    void onProfileLoadRequested(const QString &name);
    void onProfileSaveRequested(const QString &name);
    void onProfileDeleteRequested(const QString &name);
    void onProfileCopyRequested(const QString &source, const QString &destination);
    void onProfileRenameRequested(const QString &oldName, const QString &newName);
    void onActiveProfileChangeRequested(const QString &name);
    
    // Value slots
    void onValueChangeRequested(const QString &key, const QVariant &value);
    void onValueRemoveRequested(const QString &key);
    void onValuesSetRequested(const QMap<QString, QVariant> &values);
    void onSectionClearRequested(const QString &section);
    void onTypeClearRequested(int type);
    void onAllClearRequested();
    
    // File operation slots
    void onLoadFromFileRequested(const QString &filename);
    void onSaveToFileRequested(const QString &filename);
    void onImportRequested(const QString &filename, const QString &profileName);
    void onExportRequested(const QString &profileName, const QString &filename);
    void onMergeRequested(const QString &filename, bool overwrite);
    
    // Backup slots
    void onBackupCreateRequested(const QString &reason);
    void onBackupRestoreRequested(const QString &backupName);
    void onBackupDeleteRequested(const QString &backupName);
    void onAutoBackupToggled(bool enabled);
    void onBackupCleanupRequested();
    
    // Validation slots
    void onValidationRequested(const QString &profile);
    void onValidationRuleAdded(const ConfigValidationRule &rule);
    void onValidationRuleRemoved(const QString &name);
    void onValidationLevelChanged(int level);
    
    // Security slots
    void onEncryptionToggled(bool enabled, const QString &password);
    void onObfuscationToggled(bool enabled);
    void onCompressionToggled(bool enabled);
    void onChecksumRequested(const QString &profile);
    void onChecksumVerificationRequested(const QString &profile, const QString &checksum);
    
    // Monitoring slots
    void onFileWatchingToggled(bool enabled);
    void onAutoReloadToggled(bool enabled);
    void onAutoSaveToggled(bool enabled, int interval);
    void onFileChanged(const QString &path);
    void onAutoSaveTimer();
    
    // Template slots
    void onTemplateCreateRequested(const QString &name, const QString &description);
    void onTemplateApplyRequested(const QString &name);
    void onTemplateDeleteRequested(const QString &name);
    void onSaveAsTemplateRequested(const QString &name, const QString &description);
    
    // Statistics slots
    void onStatisticsRequested();
    void onStatisticsReset();
    void onUsageReportRequested();
    void onPerformanceReportRequested();
    
signals:
    void profileCreated(const QString &name);
    void profileLoaded(const QString &name);
    void profileSaved(const QString &name);
    void profileDeleted(const QString &name);
    void profileRenamed(const QString &oldName, const QString &newName);
    void activeProfileChanged(const QString &name);
    
    void valueChanged(const QString &key, const QVariant &value, const QVariant &oldValue);
    void valueAdded(const QString &key, const QVariant &value);
    void valueRemoved(const QString &key);
    void sectionCleared(const QString &section);
    void typeCleared(ConfigType type);
    void allCleared();
    
    void fileLoaded(const QString &filename, bool success);
    void fileSaved(const QString &filename, bool success);
    void profileImported(const QString &filename, const QString &profileName, bool success);
    void profileExported(const QString &profileName, const QString &filename, bool success);
    void fileMerged(const QString &filename, bool success);
    
    void backupCreated(const QString &name, const QString &reason);
    void backupRestored(const QString &name, bool success);
    void backupDeleted(const QString &name);
    void autoBackupToggled(bool enabled);
    void backupsCleanedUp(int count);
    
    void validationCompleted(const QString &profile, bool success, const QStringList &errors);
    void validationRuleAdded(const QString &name);
    void validationRuleRemoved(const QString &name);
    void validationLevelChanged(ValidationLevel level);
    
    void encryptionToggled(bool enabled);
    void obfuscationToggled(bool enabled);
    void compressionToggled(bool enabled);
    void checksumGenerated(const QString &profile, const QString &checksum);
    void checksumVerified(const QString &profile, bool valid);
    
    void fileWatchingToggled(bool enabled);
    void autoReloadToggled(bool enabled);
    void autoSaveToggled(bool enabled, int interval);
    void fileChanged(const QString &path);
    void configReloaded(const QString &reason);
    void configAutoSaved();
    
    void templateCreated(const QString &name);
    void templateApplied(const QString &name, bool success);
    void templateDeleted(const QString &name);
    void savedAsTemplate(const QString &name, bool success);
    
    void statisticsUpdated(const ConfigStatistics &stats);
    void usageReportGenerated(const QString &report);
    void performanceReportGenerated(const QString &report);
    
    void error(const QString &message);
    void warning(const QString &message);
    void info(const QString &message);
    
private slots:
    void onFileSystemChanged(const QString &path);
    void onAutoSaveTimeout();
    void onStatisticsUpdateTimer();
    
private:
    // Core functionality
    bool loadProfileInternal(const QString &name);
    bool saveProfileInternal(const QString &name);
    bool validateProfileInternal(const QString &name) const;
    void updateStatistics(const QString &operation, qint64 duration = 0);
    
    // File operations
    QJsonObject profileToJson(const ConfigProfile &profile) const;
    ConfigProfile profileFromJson(const QJsonObject &json) const;
    QJsonObject sectionToJson(const ConfigSection &section) const;
    ConfigSection sectionFromJson(const QJsonObject &json) const;
    QJsonObject valueToJson(const ConfigValue &value) const;
    ConfigValue valueFromJson(const QJsonObject &json) const;
    
    // Security implementation
    QByteArray encryptData(const QByteArray &data, const QString &password) const;
    QByteArray decryptData(const QByteArray &data, const QString &password) const;
    QByteArray obfuscateData(const QByteArray &data) const;
    QByteArray deobfuscateData(const QByteArray &data) const;
    QByteArray compressData(const QByteArray &data) const;
    QByteArray decompressData(const QByteArray &data) const;
    QString calculateChecksum(const QByteArray &data) const;
    
    // Validation implementation
    bool validateValueInternal(const QString &key, const QVariant &value, const ConfigValidationRule &rule) const;
    QStringList validateSectionInternal(const ConfigSection &section) const;
    void addDefaultValidationRules();
    
    // Backup implementation
    QString generateBackupName() const;
    QString getBackupFilePath(const QString &name) const;
    bool saveBackupToFile(const ConfigBackup &backup) const;
    ConfigBackup loadBackupFromFile(const QString &name) const;
    void performAutoBackup(const QString &reason);
    
    // Template implementation
    QString getTemplateFilePath(const QString &name) const;
    bool saveTemplateToFile(const QString &name, const ConfigProfile &profile) const;
    ConfigProfile loadTemplateFromFile(const QString &name) const;
    
    // Migration implementation
    bool migrateProfile(ConfigProfile &profile, const QString &fromVersion, const QString &toVersion);
    void addMigrationRules();
    
    // Utility functions
    QString getProfileFilePath(const QString &name) const;
    QString getConfigDirectory() const;
    QString getBackupDirectory() const;
    QString getTemplateDirectory() const;
    bool createDirectoryIfNotExists(const QString &path) const;
    QString generateUniqueId() const;
    
    // Error handling
    void handleError(const QString &operation, const QString &error);
    void handleWarning(const QString &operation, const QString &warning);
    void logOperation(const QString &operation, bool success, qint64 duration = 0);
    
    // Core components
    Logger *m_logger;
    
    // Configuration storage
    QMap<QString, ConfigProfile> m_profiles;
    QString m_activeProfile;
    QMap<QString, ConfigBackup> m_backups;
    QMap<QString, ConfigProfile> m_templates;
    QList<ConfigValidationRule> m_validationRules;
    
    // Settings
    QString m_configPath;
    ConfigFormat m_configFormat;
    ConfigSecurity m_configSecurity;
    ValidationLevel m_validationLevel;
    
    // Security
    bool m_encryptionEnabled;
    QString m_encryptionPassword;
    bool m_obfuscationEnabled;
    bool m_compressionEnabled;
    
    // Monitoring
    QFileSystemWatcher *m_fileWatcher;
    bool m_fileWatchingEnabled;
    bool m_autoReloadEnabled;
    QTimer *m_autoSaveTimer;
    bool m_autoSaveEnabled;
    int m_autoSaveInterval;
    
    // Backup settings
    bool m_autoBackupEnabled;
    int m_maxBackups;
    
    // Statistics
    ConfigStatistics m_statistics;
    QTimer *m_statisticsTimer;
    
    // State
    bool m_initialized;
    QMutex m_mutex;
    QDateTime m_lastSave;
    QString m_version;
    
    // Constants
    static const QString DEFAULT_PROFILE_NAME;
    static const QString CONFIG_FILE_EXTENSION;
    static const QString BACKUP_FILE_EXTENSION;
    static const QString TEMPLATE_FILE_EXTENSION;
    static const int DEFAULT_AUTO_SAVE_INTERVAL = 30000; // 30 seconds
    static const int DEFAULT_MAX_BACKUPS = 10;
    static const int STATISTICS_UPDATE_INTERVAL = 60000; // 1 minute
};

#endif // CONFIG_MANAGER_H