#include "config_manager.h"
#include <QDir>
#include <QFile>
#include <QTextStream>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QSettings>
#include <QStandardPaths>
#include <QCryptographicHash>
#include <QDateTime>
#include <QDebug>

ConfigManager::ConfigManager(QObject *parent)
    : QObject(parent)
    , m_currentProfile("default")
    , m_autoSave(true)
    , m_autoReload(false)
    , m_encryptionEnabled(false)
    , m_compressionEnabled(false)
    , m_backupEnabled(true)
    , m_maxBackups(10)
    , m_validationLevel(ValidationLevel::Basic)
    , m_configFormat(ConfigFormat::JSON)
    , m_configScope(ConfigScope::User)
    , m_configSecurity(ConfigSecurity::None)
    , m_isDirty(false)
    , m_isLoading(false)
    , m_isSaving(false)
    , m_fileWatcher(new QFileSystemWatcher(this))
    , m_autoSaveTimer(new QTimer(this))
    , m_autoReloadTimer(new QTimer(this))
{
    // Initialize default config directory
    m_configDir = QStandardPaths::writableLocation(QStandardPaths::AppConfigLocation);
    QDir().mkpath(m_configDir);
    
    // Setup timers
    m_autoSaveTimer->setSingleShot(true);
    m_autoSaveTimer->setInterval(5000); // 5 seconds
    connect(m_autoSaveTimer, &QTimer::timeout, this, &ConfigManager::autoSave);
    
    m_autoReloadTimer->setSingleShot(true);
    m_autoReloadTimer->setInterval(1000); // 1 second
    connect(m_autoReloadTimer, &QTimer::timeout, this, &ConfigManager::autoReload);
    
    // Setup file watcher
    connect(m_fileWatcher, &QFileSystemWatcher::fileChanged,
            this, &ConfigManager::onFileChanged);
    connect(m_fileWatcher, &QFileSystemWatcher::directoryChanged,
            this, &ConfigManager::onDirectoryChanged);
    
    // Initialize default profile
    createProfile(m_currentProfile);
    
    emit initialized();
}

ConfigManager::~ConfigManager()
{
    if (m_autoSave && m_isDirty) {
        saveProfile(m_currentProfile);
    }
}

bool ConfigManager::createProfile(const QString& name)
{
    if (m_profiles.contains(name)) {
        return false;
    }
    
    ConfigProfile profile;
    profile.name = name;
    profile.created = QDateTime::currentDateTime();
    profile.modified = profile.created;
    profile.version = "1.0";
    profile.description = QString("Profile: %1").arg(name);
    
    m_profiles[name] = profile;
    
    emit profileCreated(name);
    return true;
}

bool ConfigManager::deleteProfile(const QString& name)
{
    if (!m_profiles.contains(name) || name == "default") {
        return false;
    }
    
    // Remove config file
    QString filePath = getProfileFilePath(name);
    QFile::remove(filePath);
    
    m_profiles.remove(name);
    
    // Switch to default if current profile was deleted
    if (m_currentProfile == name) {
        switchProfile("default");
    }
    
    emit profileDeleted(name);
    return true;
}

bool ConfigManager::switchProfile(const QString& name)
{
    if (!m_profiles.contains(name)) {
        return false;
    }
    
    // Save current profile if dirty
    if (m_autoSave && m_isDirty) {
        saveProfile(m_currentProfile);
    }
    
    QString oldProfile = m_currentProfile;
    m_currentProfile = name;
    
    // Load new profile
    loadProfile(name);
    
    emit profileSwitched(oldProfile, name);
    return true;
}

bool ConfigManager::loadProfile(const QString& name)
{
    if (!m_profiles.contains(name)) {
        return false;
    }
    
    m_isLoading = true;
    
    QString filePath = getProfileFilePath(name);
    if (!QFile::exists(filePath)) {
        // Create empty profile file
        saveProfile(name);
        m_isLoading = false;
        return true;
    }
    
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) {
        m_isLoading = false;
        emit errorOccurred(QString("Failed to open profile file: %1").arg(filePath));
        return false;
    }
    
    QByteArray data = file.readAll();
    file.close();
    
    // Decrypt if needed
    if (m_encryptionEnabled) {
        data = decryptData(data);
    }
    
    // Decompress if needed
    if (m_compressionEnabled) {
        data = qUncompress(data);
    }
    
    // Parse based on format
    bool success = false;
    switch (m_configFormat) {
        case ConfigFormat::JSON:
            success = loadFromJson(data, name);
            break;
        case ConfigFormat::XML:
            success = loadFromXml(data, name);
            break;
        case ConfigFormat::INI:
            success = loadFromIni(data, name);
            break;
        case ConfigFormat::Binary:
            success = loadFromBinary(data, name);
            break;
    }
    
    if (success) {
        m_profiles[name].modified = QDateTime::currentDateTime();
        m_isDirty = false;
        
        // Add to file watcher
        if (!m_fileWatcher->files().contains(filePath)) {
            m_fileWatcher->addPath(filePath);
        }
    }
    
    m_isLoading = false;
    
    if (success) {
        emit profileLoaded(name);
    } else {
        emit errorOccurred(QString("Failed to load profile: %1").arg(name));
    }
    
    return success;
}

bool ConfigManager::saveProfile(const QString& name)
{
    if (!m_profiles.contains(name)) {
        return false;
    }
    
    m_isSaving = true;
    
    // Create backup if enabled
    if (m_backupEnabled) {
        createBackup(name);
    }
    
    QByteArray data;
    
    // Serialize based on format
    switch (m_configFormat) {
        case ConfigFormat::JSON:
            data = saveToJson(name);
            break;
        case ConfigFormat::XML:
            data = saveToXml(name);
            break;
        case ConfigFormat::INI:
            data = saveToIni(name);
            break;
        case ConfigFormat::Binary:
            data = saveToBinary(name);
            break;
    }
    
    // Compress if needed
    if (m_compressionEnabled) {
        data = qCompress(data);
    }
    
    // Encrypt if needed
    if (m_encryptionEnabled) {
        data = encryptData(data);
    }
    
    QString filePath = getProfileFilePath(name);
    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly)) {
        m_isSaving = false;
        emit errorOccurred(QString("Failed to open profile file for writing: %1").arg(filePath));
        return false;
    }
    
    qint64 written = file.write(data);
    file.close();
    
    bool success = (written == data.size());
    
    if (success) {
        m_profiles[name].modified = QDateTime::currentDateTime();
        m_isDirty = false;
        
        // Update file watcher
        if (!m_fileWatcher->files().contains(filePath)) {
            m_fileWatcher->addPath(filePath);
        }
    }
    
    m_isSaving = false;
    
    if (success) {
        emit profileSaved(name);
    } else {
        emit errorOccurred(QString("Failed to save profile: %1").arg(name));
    }
    
    return success;
}

ConfigValue ConfigManager::getValue(const QString& section, const QString& key, const ConfigValue& defaultValue)
{
    if (!m_profiles.contains(m_currentProfile)) {
        return defaultValue;
    }
    
    const ConfigProfile& profile = m_profiles[m_currentProfile];
    
    if (!profile.sections.contains(section)) {
        return defaultValue;
    }
    
    const ConfigSection& configSection = profile.sections[section];
    
    if (!configSection.values.contains(key)) {
        return defaultValue;
    }
    
    return configSection.values[key];
}

void ConfigManager::setValue(const QString& section, const QString& key, const ConfigValue& value)
{
    if (!m_profiles.contains(m_currentProfile)) {
        createProfile(m_currentProfile);
    }
    
    ConfigProfile& profile = m_profiles[m_currentProfile];
    
    if (!profile.sections.contains(section)) {
        ConfigSection newSection;
        newSection.name = section;
        newSection.created = QDateTime::currentDateTime();
        profile.sections[section] = newSection;
    }
    
    ConfigSection& configSection = profile.sections[section];
    configSection.values[key] = value;
    configSection.modified = QDateTime::currentDateTime();
    
    m_isDirty = true;
    
    if (m_autoSave) {
        m_autoSaveTimer->start();
    }
    
    emit valueChanged(section, key, value);
}

QString ConfigManager::getProfileFilePath(const QString& name) const
{
    QString extension;
    switch (m_configFormat) {
        case ConfigFormat::JSON: extension = ".json"; break;
        case ConfigFormat::XML: extension = ".xml"; break;
        case ConfigFormat::INI: extension = ".ini"; break;
        case ConfigFormat::Binary: extension = ".dat"; break;
    }
    
    return QDir(m_configDir).filePath(name + extension);
}

bool ConfigManager::loadFromJson(const QByteArray& data, const QString& profileName)
{
    QJsonParseError error;
    QJsonDocument doc = QJsonDocument::fromJson(data, &error);
    
    if (error.error != QJsonParseError::NoError) {
        emit errorOccurred(QString("JSON parse error: %1").arg(error.errorString()));
        return false;
    }
    
    QJsonObject root = doc.object();
    ConfigProfile& profile = m_profiles[profileName];
    profile.sections.clear();
    
    for (auto it = root.begin(); it != root.end(); ++it) {
        QString sectionName = it.key();
        QJsonObject sectionObj = it.value().toObject();
        
        ConfigSection section;
        section.name = sectionName;
        section.created = QDateTime::currentDateTime();
        section.modified = section.created;
        
        for (auto valueIt = sectionObj.begin(); valueIt != sectionObj.end(); ++valueIt) {
            QString key = valueIt.key();
            QJsonValue jsonValue = valueIt.value();
            
            ConfigValue configValue;
            configValue.value = jsonValue.toVariant();
            configValue.type = getVariantTypeName(configValue.value.type());
            configValue.created = QDateTime::currentDateTime();
            configValue.modified = configValue.created;
            
            section.values[key] = configValue;
        }
        
        profile.sections[sectionName] = section;
    }
    
    return true;
}

QByteArray ConfigManager::saveToJson(const QString& profileName) const
{
    if (!m_profiles.contains(profileName)) {
        return QByteArray();
    }
    
    const ConfigProfile& profile = m_profiles[profileName];
    QJsonObject root;
    
    for (auto sectionIt = profile.sections.begin(); sectionIt != profile.sections.end(); ++sectionIt) {
        const QString& sectionName = sectionIt.key();
        const ConfigSection& section = sectionIt.value();
        
        QJsonObject sectionObj;
        
        for (auto valueIt = section.values.begin(); valueIt != section.values.end(); ++valueIt) {
            const QString& key = valueIt.key();
            const ConfigValue& configValue = valueIt.value();
            
            sectionObj[key] = QJsonValue::fromVariant(configValue.value);
        }
        
        root[sectionName] = sectionObj;
    }
    
    QJsonDocument doc(root);
    return doc.toJson();
}

bool ConfigManager::loadFromXml(const QByteArray& data, const QString& profileName)
{
    // Placeholder implementation
    Q_UNUSED(data)
    Q_UNUSED(profileName)
    return false;
}

QByteArray ConfigManager::saveToXml(const QString& profileName) const
{
    // Placeholder implementation
    Q_UNUSED(profileName)
    return QByteArray();
}

bool ConfigManager::loadFromIni(const QByteArray& data, const QString& profileName)
{
    // Placeholder implementation
    Q_UNUSED(data)
    Q_UNUSED(profileName)
    return false;
}

QByteArray ConfigManager::saveToIni(const QString& profileName) const
{
    // Placeholder implementation
    Q_UNUSED(profileName)
    return QByteArray();
}

bool ConfigManager::loadFromBinary(const QByteArray& data, const QString& profileName)
{
    // Placeholder implementation
    Q_UNUSED(data)
    Q_UNUSED(profileName)
    return false;
}

QByteArray ConfigManager::saveToBinary(const QString& profileName) const
{
    // Placeholder implementation
    Q_UNUSED(profileName)
    return QByteArray();
}

QByteArray ConfigManager::encryptData(const QByteArray& data) const
{
    // Simple XOR encryption for demonstration
    QByteArray encrypted = data;
    const char key = 0xAA;
    
    for (int i = 0; i < encrypted.size(); ++i) {
        encrypted[i] = encrypted[i] ^ key;
    }
    
    return encrypted;
}

QByteArray ConfigManager::decryptData(const QByteArray& data) const
{
    // XOR decryption (same as encryption for XOR)
    return encryptData(data);
}

void ConfigManager::createBackup(const QString& profileName)
{
    QString filePath = getProfileFilePath(profileName);
    if (!QFile::exists(filePath)) {
        return;
    }
    
    QString backupDir = QDir(m_configDir).filePath("backups");
    QDir().mkpath(backupDir);
    
    QString timestamp = QDateTime::currentDateTime().toString("yyyyMMdd_hhmmss");
    QString backupFileName = QString("%1_%2").arg(profileName, timestamp);
    QString backupPath = QDir(backupDir).filePath(backupFileName + getFileExtension());
    
    QFile::copy(filePath, backupPath);
    
    // Clean old backups
    cleanOldBackups(profileName);
}

void ConfigManager::cleanOldBackups(const QString& profileName)
{
    QString backupDir = QDir(m_configDir).filePath("backups");
    QDir dir(backupDir);
    
    QStringList filters;
    filters << profileName + "_*" + getFileExtension();
    
    QFileInfoList backups = dir.entryInfoList(filters, QDir::Files, QDir::Time | QDir::Reversed);
    
    // Remove excess backups
    for (int i = m_maxBackups; i < backups.size(); ++i) {
        QFile::remove(backups[i].absoluteFilePath());
    }
}

QString ConfigManager::getFileExtension() const
{
    switch (m_configFormat) {
        case ConfigFormat::JSON: return ".json";
        case ConfigFormat::XML: return ".xml";
        case ConfigFormat::INI: return ".ini";
        case ConfigFormat::Binary: return ".dat";
    }
    return ".json";
}

QString ConfigManager::getVariantTypeName(QVariant::Type type) const
{
    switch (type) {
        case QVariant::Bool: return "bool";
        case QVariant::Int: return "int";
        case QVariant::Double: return "double";
        case QVariant::String: return "string";
        case QVariant::StringList: return "stringlist";
        default: return "variant";
    }
}

void ConfigManager::onFileChanged(const QString& path)
{
    if (m_isSaving || m_isLoading) {
        return;
    }
    
    if (m_autoReload) {
        m_autoReloadTimer->start();
    }
    
    emit fileChanged(path);
}

void ConfigManager::onDirectoryChanged(const QString& path)
{
    emit directoryChanged(path);
}

void ConfigManager::autoSave()
{
    if (m_isDirty && !m_isSaving) {
        saveProfile(m_currentProfile);
    }
}

void ConfigManager::autoReload()
{
    if (!m_isLoading) {
        loadProfile(m_currentProfile);
    }
}