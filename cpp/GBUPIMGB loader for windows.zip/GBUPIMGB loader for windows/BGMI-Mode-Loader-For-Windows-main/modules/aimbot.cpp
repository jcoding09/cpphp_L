#include "aimbot.h"
#include "../core/logger.h"
#include "../core/memory_manager.h"
#include "../core/game_interface.h"
#include "../data/entity_manager.h"
#include <QTimer>
#include <QMutexLocker>
#include <QtMath>
#include <QVector3D>
#include <QMatrix4x4>

Aimbot::Aimbot(QObject *parent)
    : QObject(parent)
    , m_enabled(false)
    , m_fov(90.0f)
    , m_smoothness(5.0f)
    , m_targetBone(TargetBone::Head)
    , m_aimKey(Qt::Key_Alt)
    , m_autoShoot(false)
    , m_visibilityCheck(true)
    , m_teamCheck(true)
    , m_maxDistance(500.0f)
    , m_recoilControl(false)
    , m_prediction(false)
    , m_silent(false)
    , m_memoryManager(nullptr)
    , m_gameInterface(nullptr)
    , m_entityManager(nullptr)
    , m_logger(nullptr)
    , m_updateTimer(new QTimer(this))
    , m_currentTarget(nullptr)
    , m_isAiming(false)
    , m_lastShotTime(0)
    , m_shotCount(0)
    , m_hitCount(0)
{
    m_updateTimer->setSingleShot(false);
    connect(m_updateTimer, &QTimer::timeout, this, &Aimbot::update);
}

Aimbot::~Aimbot()
{
    stop();
}

void Aimbot::initialize(MemoryManager* memoryManager, GameInterface* gameInterface, 
                       EntityManager* entityManager, Logger* logger)
{
    m_memoryManager = memoryManager;
    m_gameInterface = gameInterface;
    m_entityManager = entityManager;
    m_logger = logger;
    
    if (m_logger) {
        m_logger->info("Aimbot initialized");
    }
}

void Aimbot::start()
{
    if (!m_memoryManager || !m_gameInterface || !m_entityManager) {
        if (m_logger) {
            m_logger->error("Aimbot: Required components not initialized");
        }
        return;
    }
    
    m_enabled = true;
    m_updateTimer->start(16); // ~60 FPS
    
    if (m_logger) {
        m_logger->info("Aimbot started");
    }
    
    emit statusChanged(true);
}

void Aimbot::stop()
{
    m_enabled = false;
    m_updateTimer->stop();
    m_currentTarget = nullptr;
    m_isAiming = false;
    
    if (m_logger) {
        m_logger->info("Aimbot stopped");
    }
    
    emit statusChanged(false);
}

void Aimbot::setEnabled(bool enabled)
{
    if (enabled) {
        start();
    } else {
        stop();
    }
}

void Aimbot::setFOV(float fov)
{
    QMutexLocker locker(&m_mutex);
    m_fov = qBound(1.0f, fov, 180.0f);
    emit settingsChanged();
}

void Aimbot::setSmoothness(float smoothness)
{
    QMutexLocker locker(&m_mutex);
    m_smoothness = qBound(0.1f, smoothness, 20.0f);
    emit settingsChanged();
}

void Aimbot::setTargetBone(TargetBone bone)
{
    QMutexLocker locker(&m_mutex);
    m_targetBone = bone;
    emit settingsChanged();
}

void Aimbot::setAimKey(Qt::Key key)
{
    QMutexLocker locker(&m_mutex);
    m_aimKey = key;
    emit settingsChanged();
}

void Aimbot::setAutoShoot(bool enabled)
{
    QMutexLocker locker(&m_mutex);
    m_autoShoot = enabled;
    emit settingsChanged();
}

void Aimbot::setVisibilityCheck(bool enabled)
{
    QMutexLocker locker(&m_mutex);
    m_visibilityCheck = enabled;
    emit settingsChanged();
}

void Aimbot::setTeamCheck(bool enabled)
{
    QMutexLocker locker(&m_mutex);
    m_teamCheck = enabled;
    emit settingsChanged();
}

void Aimbot::setMaxDistance(float distance)
{
    QMutexLocker locker(&m_mutex);
    m_maxDistance = qBound(50.0f, distance, 2000.0f);
    emit settingsChanged();
}

void Aimbot::setRecoilControl(bool enabled)
{
    QMutexLocker locker(&m_mutex);
    m_recoilControl = enabled;
    emit settingsChanged();
}

void Aimbot::setPrediction(bool enabled)
{
    QMutexLocker locker(&m_mutex);
    m_prediction = enabled;
    emit settingsChanged();
}

void Aimbot::setSilent(bool enabled)
{
    QMutexLocker locker(&m_mutex);
    m_silent = enabled;
    emit settingsChanged();
}

void Aimbot::update()
{
    if (!m_enabled || !m_gameInterface || !m_entityManager) {
        return;
    }
    
    QMutexLocker locker(&m_mutex);
    
    // Check if aim key is pressed (placeholder - would need actual input handling)
    bool aimKeyPressed = true; // Placeholder
    
    if (!aimKeyPressed && !m_autoShoot) {
        m_currentTarget = nullptr;
        m_isAiming = false;
        return;
    }
    
    // Get local player
    auto localPlayer = m_gameInterface->getLocalPlayer();
    if (!localPlayer.isValid) {
        return;
    }
    
    // Find best target
    Entity* bestTarget = findBestTarget(localPlayer);
    
    if (bestTarget) {
        m_currentTarget = bestTarget;
        aimAtTarget(localPlayer, *bestTarget);
        
        if (m_autoShoot && canShoot()) {
            shoot();
        }
    } else {
        m_currentTarget = nullptr;
        m_isAiming = false;
    }
}

Entity* Aimbot::findBestTarget(const PlayerInfo& localPlayer)
{
    auto entities = m_entityManager->getEntitiesByType(EntityType::Player);
    Entity* bestTarget = nullptr;
    float bestScore = std::numeric_limits<float>::max();
    
    for (auto& entity : entities) {
        if (!isValidTarget(localPlayer, entity)) {
            continue;
        }
        
        float distance = calculateDistance(localPlayer.position, entity.position);
        float fovAngle = calculateFOVAngle(localPlayer, entity);
        
        // Calculate score (lower is better)
        float score = (distance * 0.3f) + (fovAngle * 0.7f);
        
        if (score < bestScore) {
            bestScore = score;
            bestTarget = &entity;
        }
    }
    
    return bestTarget;
}

bool Aimbot::isValidTarget(const PlayerInfo& localPlayer, const Entity& target)
{
    // Check if target is valid
    if (!target.isValid || target.health <= 0) {
        return false;
    }
    
    // Check team
    if (m_teamCheck && target.teamId == localPlayer.teamId) {
        return false;
    }
    
    // Check distance
    float distance = calculateDistance(localPlayer.position, target.position);
    if (distance > m_maxDistance) {
        return false;
    }
    
    // Check FOV
    float fovAngle = calculateFOVAngle(localPlayer, target);
    if (fovAngle > m_fov) {
        return false;
    }
    
    // Check visibility
    if (m_visibilityCheck && !isVisible(localPlayer, target)) {
        return false;
    }
    
    return true;
}

float Aimbot::calculateDistance(const QVector3D& pos1, const QVector3D& pos2)
{
    return pos1.distanceToPoint(pos2);
}

float Aimbot::calculateFOVAngle(const PlayerInfo& localPlayer, const Entity& target)
{
    QVector3D targetPos = getTargetBonePosition(target);
    QVector3D direction = (targetPos - localPlayer.position).normalized();
    
    // Convert view angles to direction vector
    float pitch = qDegreesToRadians(localPlayer.viewAngles.x());
    float yaw = qDegreesToRadians(localPlayer.viewAngles.y());
    
    QVector3D viewDirection(
        qCos(pitch) * qCos(yaw),
        qCos(pitch) * qSin(yaw),
        -qSin(pitch)
    );
    
    float dotProduct = QVector3D::dotProduct(viewDirection, direction);
    float angle = qRadiansToDegrees(qAcos(qBound(-1.0f, dotProduct, 1.0f)));
    
    return angle;
}

QVector3D Aimbot::getTargetBonePosition(const Entity& target)
{
    // Placeholder bone offsets
    QVector3D offset;
    
    switch (m_targetBone) {
        case TargetBone::Head:
            offset = QVector3D(0, 0, 1.8f);
            break;
        case TargetBone::Chest:
            offset = QVector3D(0, 0, 1.4f);
            break;
        case TargetBone::Stomach:
            offset = QVector3D(0, 0, 1.0f);
            break;
        case TargetBone::Pelvis:
            offset = QVector3D(0, 0, 0.8f);
            break;
    }
    
    return target.position + offset;
}

bool Aimbot::isVisible(const PlayerInfo& localPlayer, const Entity& target)
{
    // Placeholder visibility check
    // In a real implementation, this would perform a raycast
    return true;
}

void Aimbot::aimAtTarget(const PlayerInfo& localPlayer, const Entity& target)
{
    QVector3D targetPos = getTargetBonePosition(target);
    
    if (m_prediction) {
        targetPos = predictTargetPosition(target, targetPos);
    }
    
    QVector2D targetAngles = calculateAimAngles(localPlayer.position, targetPos);
    QVector2D currentAngles = localPlayer.viewAngles;
    
    // Calculate angle difference
    QVector2D angleDiff = targetAngles - currentAngles;
    
    // Normalize angles
    angleDiff = normalizeAngles(angleDiff);
    
    // Apply smoothing
    QVector2D smoothedAngles = currentAngles + (angleDiff / m_smoothness);
    
    // Apply aim
    if (m_silent) {
        applySilentAim(smoothedAngles);
    } else {
        applyViewAngleAim(smoothedAngles);
    }
    
    m_isAiming = true;
    emit targetAcquired(target.id);
}

QVector3D Aimbot::predictTargetPosition(const Entity& target, const QVector3D& currentPos)
{
    // Simple prediction based on velocity
    float predictionTime = 0.1f; // 100ms prediction
    return currentPos + (target.velocity * predictionTime);
}

QVector2D Aimbot::calculateAimAngles(const QVector3D& from, const QVector3D& to)
{
    QVector3D direction = (to - from).normalized();
    
    float pitch = qRadiansToDegrees(qAsin(-direction.z()));
    float yaw = qRadiansToDegrees(qAtan2(direction.y(), direction.x()));
    
    return QVector2D(pitch, yaw);
}

QVector2D Aimbot::normalizeAngles(const QVector2D& angles)
{
    QVector2D normalized = angles;
    
    // Normalize pitch
    while (normalized.x() > 180.0f) normalized.setX(normalized.x() - 360.0f);
    while (normalized.x() < -180.0f) normalized.setX(normalized.x() + 360.0f);
    
    // Normalize yaw
    while (normalized.y() > 180.0f) normalized.setY(normalized.y() - 360.0f);
    while (normalized.y() < -180.0f) normalized.setY(normalized.y() + 360.0f);
    
    return normalized;
}

void Aimbot::applySilentAim(const QVector2D& angles)
{
    // Placeholder for silent aim implementation
    // This would modify bullet trajectory without changing view angles
    if (m_logger) {
        m_logger->debug(QString("Silent aim applied: pitch=%1, yaw=%2")
                       .arg(angles.x()).arg(angles.y()));
    }
}

void Aimbot::applyViewAngleAim(const QVector2D& angles)
{
    // Placeholder for view angle aim implementation
    // This would directly modify the player's view angles
    if (m_logger) {
        m_logger->debug(QString("View angle aim applied: pitch=%1, yaw=%2")
                       .arg(angles.x()).arg(angles.y()));
    }
}

bool Aimbot::canShoot()
{
    // Check shooting cooldown
    qint64 currentTime = QDateTime::currentMSecsSinceEpoch();
    if (currentTime - m_lastShotTime < 100) { // 100ms cooldown
        return false;
    }
    
    // Additional checks (ammo, weapon ready, etc.)
    return true;
}

void Aimbot::shoot()
{
    // Placeholder for shooting implementation
    m_lastShotTime = QDateTime::currentMSecsSinceEpoch();
    m_shotCount++;
    
    if (m_logger) {
        m_logger->debug("Auto-shoot triggered");
    }
    
    emit shotFired();
}

void Aimbot::applyRecoilControl()
{
    if (!m_recoilControl) {
        return;
    }
    
    // Placeholder for recoil control implementation
    if (m_logger) {
        m_logger->debug("Recoil control applied");
    }
}

AimbotStats Aimbot::getStats() const
{
    QMutexLocker locker(&m_mutex);
    
    AimbotStats stats;
    stats.enabled = m_enabled;
    stats.currentTarget = m_currentTarget ? m_currentTarget->id : 0;
    stats.isAiming = m_isAiming;
    stats.shotCount = m_shotCount;
    stats.hitCount = m_hitCount;
    stats.accuracy = m_shotCount > 0 ? (float)m_hitCount / m_shotCount * 100.0f : 0.0f;
    stats.fov = m_fov;
    stats.smoothness = m_smoothness;
    stats.targetBone = static_cast<int>(m_targetBone);
    
    return stats;
}

void Aimbot::resetStats()
{
    QMutexLocker locker(&m_mutex);
    m_shotCount = 0;
    m_hitCount = 0;
    
    if (m_logger) {
        m_logger->info("Aimbot stats reset");
    }
    
    emit statsReset();
}

void Aimbot::saveSettings(QSettings& settings)
{
    QMutexLocker locker(&m_mutex);
    
    settings.beginGroup("Aimbot");
    settings.setValue("enabled", m_enabled);
    settings.setValue("fov", m_fov);
    settings.setValue("smoothness", m_smoothness);
    settings.setValue("targetBone", static_cast<int>(m_targetBone));
    settings.setValue("aimKey", static_cast<int>(m_aimKey));
    settings.setValue("autoShoot", m_autoShoot);
    settings.setValue("visibilityCheck", m_visibilityCheck);
    settings.setValue("teamCheck", m_teamCheck);
    settings.setValue("maxDistance", m_maxDistance);
    settings.setValue("recoilControl", m_recoilControl);
    settings.setValue("prediction", m_prediction);
    settings.setValue("silent", m_silent);
    settings.endGroup();
}

void Aimbot::loadSettings(QSettings& settings)
{
    QMutexLocker locker(&m_mutex);
    
    settings.beginGroup("Aimbot");
    m_enabled = settings.value("enabled", false).toBool();
    m_fov = settings.value("fov", 90.0f).toFloat();
    m_smoothness = settings.value("smoothness", 5.0f).toFloat();
    m_targetBone = static_cast<TargetBone>(settings.value("targetBone", 0).toInt());
    m_aimKey = static_cast<Qt::Key>(settings.value("aimKey", Qt::Key_Alt).toInt());
    m_autoShoot = settings.value("autoShoot", false).toBool();
    m_visibilityCheck = settings.value("visibilityCheck", true).toBool();
    m_teamCheck = settings.value("teamCheck", true).toBool();
    m_maxDistance = settings.value("maxDistance", 500.0f).toFloat();
    m_recoilControl = settings.value("recoilControl", false).toBool();
    m_prediction = settings.value("prediction", false).toBool();
    m_silent = settings.value("silent", false).toBool();
    settings.endGroup();
    
    emit settingsChanged();
}