#ifndef RADAR_H
#define RADAR_H

#include <QtCore/QObject>
#include <QtCore/QTimer>
#include <QtCore/QSettings>
#include <QtCore/QDateTime>
#include <QtCore/QMutex>
#include <QtCore/QThread>
#include <QtGui/QVector3D>
#include <QtGui/QVector2D>
#include <QtGui/QColor>
#include <QtGui/QPixmap>
#include <QtGui/QPainter>
#include <QtGui/QFont>
#include <QtCore/QMap>
#include <QtCore/QList>
#include <memory>

// Forward declarations
class GameInterface;
class MemoryManager;
class Logger;

enum class RadarMode {
    Disabled = 0,
    Minimap = 1,
    Overlay = 2,
    Fullscreen = 3,
    Picture = 4,
    Compass = 5
};

enum class RadarStyle {
    Classic = 0,
    Modern = 1,
    Military = 2,
    Minimal = 3,
    Custom = 4
};

enum class RadarShape {
    Circle = 0,
    Square = 1,
    Rectangle = 2,
    Hexagon = 3
};

enum class EntityType {
    Unknown = 0,
    Player = 1,
    Enemy = 2,
    Teammate = 3,
    Bot = 4,
    Knocked = 5,
    Spectator = 6,
    Vehicle = 7,
    Weapon = 8,
    Armor = 9,
    Medical = 10,
    Ammo = 11,
    Attachment = 12,
    Throwable = 13,
    Airdrop = 14,
    DeathBox = 15,
    Building = 16,
    Cover = 17,
    Zone = 18,
    Waypoint = 19
};

enum class RadarZoom {
    VeryClose = 0,  // 50m
    Close = 1,      // 100m
    Medium = 2,     // 200m
    Far = 3,        // 500m
    VeryFar = 4,    // 1000m
    Auto = 5        // Dynamic
};

enum class CompassMode {
    None = 0,
    Simple = 1,
    Detailed = 2,
    Military = 3
};

struct RadarSettings {
    // Basic settings
    bool enabled = false;
    RadarMode mode = RadarMode::Overlay;
    RadarStyle style = RadarStyle::Modern;
    RadarShape shape = RadarShape::Circle;
    
    // Position and size
    QVector2D position = QVector2D(50, 50); // Top-left corner
    QVector2D size = QVector2D(200, 200);
    float scale = 1.0f;
    bool lockAspectRatio = true;
    bool draggable = true;
    bool resizable = true;
    
    // Zoom and range
    RadarZoom zoomLevel = RadarZoom::Medium;
    float customRange = 200.0f;
    float minRange = 25.0f;
    float maxRange = 2000.0f;
    bool autoZoom = false;
    float autoZoomSpeed = 2.0f;
    
    // Appearance
    QColor backgroundColor = QColor(0, 0, 0, 180);
    QColor borderColor = QColor(255, 255, 255, 255);
    QColor gridColor = QColor(128, 128, 128, 100);
    QColor centerColor = QColor(255, 255, 255, 255);
    float borderWidth = 2.0f;
    float opacity = 0.8f;
    bool showGrid = true;
    bool showBorder = true;
    bool showCenter = true;
    bool showBackground = true;
    
    // Player representation
    bool showSelf = true;
    QColor selfColor = QColor(255, 255, 255, 255);
    float selfSize = 6.0f;
    bool selfArrow = true;
    bool showSelfDirection = true;
    bool showSelfFOV = false;
    float selfFOVAngle = 90.0f;
    QColor selfFOVColor = QColor(255, 255, 255, 50);
    
    // Enemy settings
    bool showEnemies = true;
    QColor enemyColor = QColor(255, 0, 0, 255);
    float enemySize = 5.0f;
    bool enemyArrows = true;
    bool showEnemyDirection = true;
    bool showEnemyDistance = false;
    bool showEnemyHealth = false;
    bool showEnemyWeapon = false;
    bool showEnemyName = false;
    bool highlightLowHealth = true;
    float lowHealthThreshold = 30.0f;
    QColor lowHealthColor = QColor(255, 255, 0, 255);
    
    // Teammate settings
    bool showTeammates = true;
    QColor teammateColor = QColor(0, 255, 0, 255);
    float teammateSize = 5.0f;
    bool teammateArrows = true;
    bool showTeammateDirection = true;
    bool showTeammateDistance = false;
    bool showTeammateHealth = true;
    bool showTeammateWeapon = false;
    bool showTeammateName = true;
    
    // Bot settings
    bool showBots = true;
    QColor botColor = QColor(255, 165, 0, 255);
    float botSize = 4.0f;
    bool botArrows = false;
    bool showBotDirection = false;
    bool showBotDistance = false;
    bool showBotHealth = false;
    
    // Knocked player settings
    bool showKnocked = true;
    QColor knockedColor = QColor(255, 255, 0, 255);
    float knockedSize = 4.0f;
    bool knockedArrows = false;
    bool showKnockedDistance = false;
    bool knockedBlink = true;
    float knockedBlinkSpeed = 2.0f;
    
    // Vehicle settings
    bool showVehicles = true;
    QColor vehicleColor = QColor(255, 0, 255, 255);
    float vehicleSize = 8.0f;
    bool vehicleArrows = true;
    bool showVehicleDirection = true;
    bool showVehicleType = true;
    bool showVehicleHealth = false;
    bool showEmptyVehicles = true;
    QColor emptyVehicleColor = QColor(128, 0, 128, 255);
    
    // Item settings
    bool showItems = false;
    bool showWeapons = true;
    bool showArmor = true;
    bool showMedical = true;
    bool showAmmo = false;
    bool showAttachments = false;
    bool showThrowables = true;
    QColor weaponColor = QColor(255, 255, 0, 255);
    QColor armorColor = QColor(0, 255, 255, 255);
    QColor medicalColor = QColor(0, 255, 0, 255);
    QColor ammoColor = QColor(255, 128, 0, 255);
    QColor attachmentColor = QColor(128, 255, 128, 255);
    QColor throwableColor = QColor(255, 0, 128, 255);
    float itemSize = 3.0f;
    float itemRange = 100.0f;
    bool itemDistanceFilter = true;
    
    // Airdrop settings
    bool showAirdrops = true;
    QColor airdropColor = QColor(255, 255, 255, 255);
    float airdropSize = 10.0f;
    bool airdropBlink = true;
    float airdropBlinkSpeed = 1.0f;
    bool showAirdropDistance = true;
    
    // Death box settings
    bool showDeathBoxes = true;
    QColor deathBoxColor = QColor(128, 128, 128, 255);
    float deathBoxSize = 4.0f;
    bool showDeathBoxDistance = false;
    float deathBoxTimeout = 300.0f; // 5 minutes
    
    // Zone settings
    bool showZone = true;
    bool showSafeZone = true;
    bool showPlayZone = true;
    bool showRedZone = false;
    QColor safeZoneColor = QColor(255, 255, 255, 100);
    QColor playZoneColor = QColor(0, 0, 255, 100);
    QColor redZoneColor = QColor(255, 0, 0, 100);
    bool zoneAnimation = true;
    float zoneAnimationSpeed = 1.0f;
    
    // Compass settings
    CompassMode compassMode = CompassMode::Simple;
    bool showCompass = true;
    QVector2D compassPosition = QVector2D(400, 50);
    QVector2D compassSize = QVector2D(200, 30);
    QColor compassColor = QColor(255, 255, 255, 200);
    QColor compassTextColor = QColor(255, 255, 255, 255);
    bool showCompassDegrees = true;
    bool showCompassCardinals = true;
    bool showCompassMarks = true;
    
    // Text settings
    QFont textFont = QFont("Arial", 8);
    QColor textColor = QColor(255, 255, 255, 255);
    QColor textShadowColor = QColor(0, 0, 0, 128);
    bool textShadow = true;
    bool textOutline = false;
    QColor textOutlineColor = QColor(0, 0, 0, 255);
    float textOutlineWidth = 1.0f;
    
    // Distance settings
    bool showDistances = false;
    QString distanceUnit = "m";
    int distancePrecision = 0;
    float maxDistanceDisplay = 500.0f;
    bool distanceColorCoding = true;
    QColor nearDistanceColor = QColor(0, 255, 0, 255);
    QColor mediumDistanceColor = QColor(255, 255, 0, 255);
    QColor farDistanceColor = QColor(255, 0, 0, 255);
    float nearDistanceThreshold = 50.0f;
    float farDistanceThreshold = 200.0f;
    
    // Animation settings
    bool enableAnimations = true;
    bool smoothMovement = true;
    float smoothingFactor = 0.8f;
    bool fadeInOut = true;
    float fadeSpeed = 3.0f;
    bool pulseEffects = true;
    float pulseSpeed = 2.0f;
    bool rotationAnimation = true;
    float rotationSpeed = 1.0f;
    
    // Performance settings
    int updateRate = 30; // FPS
    bool useThreading = true;
    bool cullOffScreen = true;
    bool levelOfDetail = true;
    int maxDisplayedEntities = 200;
    bool adaptiveQuality = true;
    float performanceThreshold = 60.0f;
    
    // Interaction settings
    bool clickToMark = true;
    bool doubleClickToZoom = true;
    bool scrollToZoom = true;
    bool rightClickMenu = true;
    bool keyboardShortcuts = true;
    int toggleKey = 0x23; // End key
    int zoomInKey = 0x6B; // Numpad +
    int zoomOutKey = 0x6D; // Numpad -
    
    // Waypoint settings
    bool showWaypoints = true;
    QColor waypointColor = QColor(255, 255, 255, 255);
    float waypointSize = 6.0f;
    bool waypointNumbers = true;
    bool waypointLines = false;
    QColor waypointLineColor = QColor(255, 255, 255, 128);
    float waypointLineWidth = 1.0f;
    int maxWaypoints = 10;
    
    // Advanced features
    bool predictiveTracking = false;
    float predictionTime = 2.0f;
    QColor predictionColor = QColor(255, 255, 255, 128);
    bool showTrails = false;
    float trailLength = 5.0f;
    QColor trailColor = QColor(255, 255, 255, 100);
    bool heatmap = false;
    QColor heatmapColdColor = QColor(0, 0, 255, 100);
    QColor heatmapHotColor = QColor(255, 0, 0, 100);
    
    // Safety settings
    bool safeMode = true;
    bool hideFromScreenshots = true;
    bool hideFromRecording = true;
    bool disableOnAltTab = false;
    bool emergencyDisable = false;
    int emergencyKey = 0x23; // End key
    
    // Map settings
    bool useGameMap = false;
    QString customMapPath;
    float mapOpacity = 0.3f;
    bool mapRotation = true;
    bool mapZoom = true;
    QVector2D mapOffset = QVector2D(0, 0);
    float mapScale = 1.0f;
};

struct RadarEntity {
    quint32 entityId = 0;
    EntityType type = EntityType::Unknown;
    QString name;
    QString subType; // weapon type, vehicle type, etc.
    QVector3D position;
    QVector3D velocity;
    QVector2D radarPosition;
    float distance = 0.0f;
    float direction = 0.0f; // Angle in degrees
    float health = 100.0f;
    float maxHealth = 100.0f;
    bool isVisible = false;
    bool isAlive = true;
    bool isMoving = false;
    int teamId = 0;
    QString weaponName;
    QDateTime lastSeen;
    QDateTime firstSeen;
    QColor currentColor;
    float currentSize = 5.0f;
    float currentOpacity = 1.0f;
    bool shouldRender = true;
    float threatLevel = 0.0f;
    QList<QVector3D> trail;
    QVector3D predictedPosition;
    bool isInSafeZone = true;
    bool isInPlayZone = true;
    bool isInRedZone = false;
    float timeToZone = 0.0f;
    QMap<QString, QVariant> customData;
};

struct RadarZoneInfo {
    QVector3D center;
    float radius = 0.0f;
    QVector3D nextCenter;
    float nextRadius = 0.0f;
    float timeRemaining = 0.0f;
    float totalTime = 0.0f;
    bool isActive = false;
    bool isShrinking = false;
    int phaseNumber = 0;
    float damagePerSecond = 0.0f;
    QColor zoneColor;
};

struct RadarWaypoint {
    quint32 id = 0;
    QString name;
    QVector3D position;
    QVector2D radarPosition;
    QColor color = QColor(255, 255, 255, 255);
    float size = 6.0f;
    bool visible = true;
    QDateTime created;
    QString description;
    int priority = 0;
    bool temporary = false;
    float timeout = 0.0f;
};

struct RadarRenderData {
    QPixmap radarImage;
    QPixmap compassImage;
    QList<RadarEntity> entities;
    RadarZoneInfo safeZone;
    RadarZoneInfo playZone;
    RadarZoneInfo redZone;
    QList<RadarWaypoint> waypoints;
    QVector3D playerPosition;
    float playerDirection = 0.0f;
    float currentZoom = 200.0f;
    QDateTime timestamp;
    bool isValid = false;
    QMap<QString, int> entityCounts;
    float averageFPS = 60.0f;
};

class Radar : public QObject
{
    Q_OBJECT

public:
    explicit Radar(QObject *parent = nullptr);
    ~Radar();
    
    // Component integration
    void setGameInterface(GameInterface *gameInterface);
    void setMemoryManager(MemoryManager *memoryManager);
    void setLogger(Logger *logger);
    
    // Settings management
    void setSettings(const RadarSettings &settings);
    RadarSettings getSettings() const;
    void loadSettings();
    void saveSettings();
    void resetSettings();
    
    // Control methods
    void enable();
    void disable();
    void toggle();
    bool isEnabled() const;
    
    // Rendering
    QPixmap renderRadar();
    QPixmap renderCompass();
    void updateRadarImage();
    void updateCompassImage();
    
    // Entity management
    void updateEntities();
    void addEntity(const RadarEntity &entity);
    void removeEntity(quint32 entityId);
    void clearEntities();
    QList<RadarEntity> getVisibleEntities() const;
    
    // Zone management
    void updateZoneInfo();
    RadarZoneInfo getSafeZone() const;
    RadarZoneInfo getPlayZone() const;
    RadarZoneInfo getRedZone() const;
    
    // Waypoint management
    void addWaypoint(const RadarWaypoint &waypoint);
    void removeWaypoint(quint32 waypointId);
    void clearWaypoints();
    QList<RadarWaypoint> getWaypoints() const;
    
    // Coordinate conversion
    QVector2D worldToRadar(const QVector3D &worldPos);
    QVector3D radarToWorld(const QVector2D &radarPos);
    float calculateDistance(const QVector3D &pos1, const QVector3D &pos2);
    float calculateDirection(const QVector3D &from, const QVector3D &to);
    
    // Zoom and navigation
    void setZoom(float range);
    float getZoom() const;
    void zoomIn();
    void zoomOut();
    void resetZoom();
    void centerOnPlayer();
    void centerOnPosition(const QVector3D &position);
    
public slots:
    // Main update slots
    void update();
    void onGameUpdate();
    void onPlayerUpdate();
    void onEntityUpdate();
    void onZoneUpdate();
    
    // Settings slots
    void onSettingsChanged(const RadarSettings &settings);
    void onModeChanged(int mode);
    void onStyleChanged(int style);
    void onShapeChanged(int shape);
    void onZoomLevelChanged(int level);
    void onCompassModeChanged(int mode);
    
    // Appearance slots
    void onPositionChanged(const QVector2D &position);
    void onSizeChanged(const QVector2D &size);
    void onScaleChanged(float scale);
    void onOpacityChanged(float opacity);
    void onBackgroundColorChanged(const QColor &color);
    void onBorderColorChanged(const QColor &color);
    void onGridColorChanged(const QColor &color);
    void onBorderWidthChanged(float width);
    
    // Entity display slots
    void onShowEnemiesToggled(bool enabled);
    void onShowTeammatesToggled(bool enabled);
    void onShowBotsToggled(bool enabled);
    void onShowKnockedToggled(bool enabled);
    void onShowVehiclesToggled(bool enabled);
    void onShowItemsToggled(bool enabled);
    void onShowAirdropsToggled(bool enabled);
    void onShowDeathBoxesToggled(bool enabled);
    void onShowZoneToggled(bool enabled);
    void onShowCompassToggled(bool enabled);
    void onShowWaypointsToggled(bool enabled);
    
    // Color slots
    void onEnemyColorChanged(const QColor &color);
    void onTeammateColorChanged(const QColor &color);
    void onBotColorChanged(const QColor &color);
    void onKnockedColorChanged(const QColor &color);
    void onVehicleColorChanged(const QColor &color);
    void onWeaponColorChanged(const QColor &color);
    void onArmorColorChanged(const QColor &color);
    void onMedicalColorChanged(const QColor &color);
    void onAirdropColorChanged(const QColor &color);
    void onDeathBoxColorChanged(const QColor &color);
    void onSafeZoneColorChanged(const QColor &color);
    void onPlayZoneColorChanged(const QColor &color);
    void onRedZoneColorChanged(const QColor &color);
    
    // Size slots
    void onEnemySizeChanged(float size);
    void onTeammateSizeChanged(float size);
    void onBotSizeChanged(float size);
    void onKnockedSizeChanged(float size);
    void onVehicleSizeChanged(float size);
    void onItemSizeChanged(float size);
    void onAirdropSizeChanged(float size);
    void onDeathBoxSizeChanged(float size);
    
    // Feature toggle slots
    void onShowGridToggled(bool enabled);
    void onShowBorderToggled(bool enabled);
    void onShowCenterToggled(bool enabled);
    void onShowBackgroundToggled(bool enabled);
    void onShowSelfToggled(bool enabled);
    void onSelfArrowToggled(bool enabled);
    void onShowSelfDirectionToggled(bool enabled);
    void onShowSelfFOVToggled(bool enabled);
    void onEnemyArrowsToggled(bool enabled);
    void onShowEnemyDirectionToggled(bool enabled);
    void onShowEnemyDistanceToggled(bool enabled);
    void onShowEnemyHealthToggled(bool enabled);
    void onShowEnemyWeaponToggled(bool enabled);
    void onShowEnemyNameToggled(bool enabled);
    void onTeammateArrowsToggled(bool enabled);
    void onShowTeammateDirectionToggled(bool enabled);
    void onShowTeammateDistanceToggled(bool enabled);
    void onShowTeammateHealthToggled(bool enabled);
    void onShowTeammateWeaponToggled(bool enabled);
    void onShowTeammateNameToggled(bool enabled);
    void onVehicleArrowsToggled(bool enabled);
    void onShowVehicleDirectionToggled(bool enabled);
    void onShowVehicleTypeToggled(bool enabled);
    void onShowVehicleHealthToggled(bool enabled);
    void onShowEmptyVehiclesToggled(bool enabled);
    void onShowDistancesToggled(bool enabled);
    void onDistanceColorCodingToggled(bool enabled);
    void onEnableAnimationsToggled(bool enabled);
    void onSmoothMovementToggled(bool enabled);
    void onFadeInOutToggled(bool enabled);
    void onPulseEffectsToggled(bool enabled);
    void onRotationAnimationToggled(bool enabled);
    void onAutoZoomToggled(bool enabled);
    void onPredictiveTrackingToggled(bool enabled);
    void onShowTrailsToggled(bool enabled);
    void onHeatmapToggled(bool enabled);
    void onUseGameMapToggled(bool enabled);
    void onMapRotationToggled(bool enabled);
    void onMapZoomToggled(bool enabled);
    
    // Zoom and range slots
    void onCustomRangeChanged(float range);
    void onMinRangeChanged(float range);
    void onMaxRangeChanged(float range);
    void onAutoZoomSpeedChanged(float speed);
    void onItemRangeChanged(float range);
    void onMaxDistanceDisplayChanged(float distance);
    
    // Interaction slots
    void onRadarClicked(const QVector2D &position);
    void onRadarDoubleClicked(const QVector2D &position);
    void onRadarRightClicked(const QVector2D &position);
    void onRadarScrolled(float delta);
    void onRadarDragged(const QVector2D &delta);
    void onRadarResized(const QVector2D &newSize);
    
    // Waypoint slots
    void onWaypointAdded(const RadarWaypoint &waypoint);
    void onWaypointRemoved(quint32 waypointId);
    void onWaypointUpdated(const RadarWaypoint &waypoint);
    void onWaypointsCleared();
    
    // Safety slots
    void onEmergencyDisable();
    void onSafeModeToggled(bool enabled);
    void onHideFromScreenshotsToggled(bool enabled);
    void onHideFromRecordingToggled(bool enabled);
    
signals:
    void enabledChanged(bool enabled);
    void settingsChanged(const RadarSettings &settings);
    void radarImageUpdated(const QPixmap &image);
    void compassImageUpdated(const QPixmap &image);
    void entityAdded(const RadarEntity &entity);
    void entityRemoved(quint32 entityId);
    void entityUpdated(const RadarEntity &entity);
    void zoneUpdated(const RadarZoneInfo &zone);
    void waypointAdded(const RadarWaypoint &waypoint);
    void waypointRemoved(quint32 waypointId);
    void zoomChanged(float zoom);
    void positionChanged(const QVector2D &position);
    void sizeChanged(const QVector2D &size);
    void emergencyTriggered();
    void errorOccurred(const QString &error);
    
private slots:
    void updateTimer();
    void renderTimer();
    void entityScanTimer();
    void zoneUpdateTimer();
    void animationTimer();
    void safetyCheckTimer();
    
private:
    // Core rendering
    void renderRadarBackground(QPainter &painter);
    void renderRadarGrid(QPainter &painter);
    void renderRadarBorder(QPainter &painter);
    void renderRadarCenter(QPainter &painter);
    void renderRadarEntities(QPainter &painter);
    void renderRadarZones(QPainter &painter);
    void renderRadarWaypoints(QPainter &painter);
    void renderRadarSelf(QPainter &painter);
    void renderRadarMap(QPainter &painter);
    
    void renderCompassBackground(QPainter &painter);
    void renderCompassMarks(QPainter &painter);
    void renderCompassCardinals(QPainter &painter);
    void renderCompassDegrees(QPainter &painter);
    void renderCompassNeedle(QPainter &painter);
    
    // Entity rendering
    void renderEntity(QPainter &painter, const RadarEntity &entity);
    void renderEntityIcon(QPainter &painter, const RadarEntity &entity);
    void renderEntityArrow(QPainter &painter, const RadarEntity &entity);
    void renderEntityText(QPainter &painter, const RadarEntity &entity);
    void renderEntityHealth(QPainter &painter, const RadarEntity &entity);
    void renderEntityDistance(QPainter &painter, const RadarEntity &entity);
    void renderEntityTrail(QPainter &painter, const RadarEntity &entity);
    void renderEntityPrediction(QPainter &painter, const RadarEntity &entity);
    
    // Zone rendering
    void renderSafeZone(QPainter &painter);
    void renderPlayZone(QPainter &painter);
    void renderRedZone(QPainter &painter);
    void renderZoneTimer(QPainter &painter, const RadarZoneInfo &zone);
    
    // Waypoint rendering
    void renderWaypoint(QPainter &painter, const RadarWaypoint &waypoint);
    void renderWaypointLine(QPainter &painter, const RadarWaypoint &waypoint);
    void renderWaypointText(QPainter &painter, const RadarWaypoint &waypoint);
    
    // Entity processing
    QList<RadarEntity> scanForEntities();
    RadarEntity processEntity(quint32 entityId);
    void updateEntityData(RadarEntity &entity);
    void updateEntityPosition(RadarEntity &entity);
    void updateEntityVisibility(RadarEntity &entity);
    void updateEntityColors(RadarEntity &entity);
    void updateEntityTrail(RadarEntity &entity);
    void updateEntityPrediction(RadarEntity &entity);
    
    bool isValidEntity(const RadarEntity &entity);
    bool shouldDisplayEntity(const RadarEntity &entity);
    bool isEntityInRange(const RadarEntity &entity);
    bool isEntityOnScreen(const RadarEntity &entity);
    
    EntityType determineEntityType(quint32 entityId);
    QString getEntityName(const RadarEntity &entity);
    QString getEntitySubType(const RadarEntity &entity);
    QColor getEntityColor(const RadarEntity &entity);
    float getEntitySize(const RadarEntity &entity);
    float calculateThreatLevel(const RadarEntity &entity);
    
    // Zone processing
    void updateSafeZoneInfo();
    void updatePlayZoneInfo();
    void updateRedZoneInfo();
    bool isPositionInZone(const QVector3D &position, const RadarZoneInfo &zone);
    float calculateTimeToZone(const QVector3D &position, const RadarZoneInfo &zone);
    
    // Coordinate calculations
    QVector2D calculateRadarPosition(const QVector3D &worldPos);
    QVector3D calculateWorldPosition(const QVector2D &radarPos);
    float calculateRadarDistance(const QVector3D &worldPos);
    float calculateRadarDirection(const QVector3D &worldPos);
    
    QVector2D rotatePoint(const QVector2D &point, float angle);
    QVector2D scalePoint(const QVector2D &point, float scale);
    QVector2D translatePoint(const QVector2D &point, const QVector2D &offset);
    
    // Animation and effects
    void updateAnimations();
    void updateEntityAnimations();
    void updateZoneAnimations();
    void updateWaypointAnimations();
    
    float calculatePulseValue(float time, float speed);
    float calculateFadeValue(float time, float speed);
    QColor animateColor(const QColor &baseColor, float time, bool pulse = false);
    QColor interpolateColor(const QColor &color1, const QColor &color2, float factor);
    
    // Memory operations
    bool readPlayerPosition(QVector3D &position);
    bool readPlayerDirection(float &direction);
    bool readEntityList(QList<quint32> &entityIds);
    bool readEntityPosition(quint32 entityId, QVector3D &position);
    bool readEntityVelocity(quint32 entityId, QVector3D &velocity);
    bool readEntityHealth(quint32 entityId, float &health, float &maxHealth);
    bool readEntityTeam(quint32 entityId, int &teamId);
    bool readEntityType(quint32 entityId, EntityType &type);
    bool readEntityName(quint32 entityId, QString &name);
    bool readEntityWeapon(quint32 entityId, QString &weaponName);
    
    bool readZoneCenter(QVector3D &center);
    bool readZoneRadius(float &radius);
    bool readNextZoneCenter(QVector3D &center);
    bool readNextZoneRadius(float &radius);
    bool readZoneTimer(float &timeRemaining, float &totalTime);
    bool readZonePhase(int &phase);
    bool readZoneDamage(float &damagePerSecond);
    
    // Performance optimization
    void optimizeEntityProcessing();
    void cullDistantEntities();
    void sortEntitiesByPriority();
    void limitDisplayedEntities();
    void adaptQualitySettings();
    void updateLevelOfDetail();
    
    // Safety and detection
    void performSafetyChecks();
    void checkDetectionRisk();
    void handleScreenshotDetection();
    void handleRecordingDetection();
    void handleAltTabDetection();
    void emergencyShutdown();
    
    bool isScreenshotActive();
    bool isRecordingActive();
    bool isGameFocused();
    bool isDetectionRisky();
    
    // Statistics and logging
    void updatePerformanceMetrics();
    void logRadarStats();
    void logEntityStats();
    void logZoneStats();
    void logWaypointStats();
    
    // Utility functions
    QString formatEntityInfo(const RadarEntity &entity) const;
    QString formatZoneInfo(const RadarZoneInfo &zone) const;
    QString formatWaypointInfo(const RadarWaypoint &waypoint) const;
    QString formatRenderStats() const;
    QString formatSettings() const;
    
    QPixmap loadCustomMap(const QString &path);
    void saveRadarImage(const QPixmap &image, const QString &path);
    
    // Core components
    GameInterface *m_gameInterface;
    MemoryManager *m_memoryManager;
    Logger *m_logger;
    
    // Settings and configuration
    RadarSettings m_settings;
    QSettings *m_qsettings;
    
    // Entity management
    QList<RadarEntity> m_entities;
    QList<RadarEntity> m_visibleEntities;
    QMutex m_entityMutex;
    
    // Zone information
    RadarZoneInfo m_safeZone;
    RadarZoneInfo m_playZone;
    RadarZoneInfo m_redZone;
    
    // Waypoint management
    QList<RadarWaypoint> m_waypoints;
    quint32 m_nextWaypointId;
    
    // Rendering data
    RadarRenderData m_renderData;
    QPixmap m_radarImage;
    QPixmap m_compassImage;
    QPixmap m_customMap;
    
    // State variables
    bool m_enabled;
    QVector3D m_playerPosition;
    float m_playerDirection;
    float m_currentZoom;
    QVector2D m_radarCenter;
    QDateTime m_lastUpdateTime;
    
    // Performance tracking
    int m_frameCount;
    QDateTime m_lastFrameTime;
    float m_averageFPS;
    int m_entityCount;
    int m_visibleEntityCount;
    qint64 m_renderingTime;
    
    // Animation data
    QDateTime m_animationStartTime;
    float m_currentAnimationTime;
    QMap<quint32, float> m_entityAnimationOffsets;
    QMap<quint32, QVector3D> m_entityLastPositions;
    
    // Timers
    QTimer *m_updateTimer;
    QTimer *m_renderTimer;
    QTimer *m_entityScanTimer;
    QTimer *m_zoneUpdateTimer;
    QTimer *m_animationTimer;
    QTimer *m_safetyCheckTimer;
    
    // Threading
    QThread *m_processingThread;
    QMutex m_processingMutex;
    
    // Safety and detection
    QDateTime m_lastSafetyCheck;
    QDateTime m_lastDetectionCheck;
    bool m_screenshotDetected;
    bool m_recordingDetected;
    bool m_altTabDetected;
    
    // Constants
    static const float DEFAULT_RANGE;
    static const float MIN_RANGE;
    static const float MAX_RANGE;
    static const float DEFAULT_ENTITY_SIZE;
    static const float DEFAULT_OPACITY;
    static const float DEFAULT_BORDER_WIDTH;
    
    static const int UPDATE_INTERVAL = 33; // ~30 FPS
    static const int RENDER_INTERVAL = 16; // ~60 FPS
    static const int ENTITY_SCAN_INTERVAL = 50; // 20 FPS
    static const int ZONE_UPDATE_INTERVAL = 1000; // 1 FPS
    static const int ANIMATION_INTERVAL = 16; // ~60 FPS
    static const int SAFETY_CHECK_INTERVAL = 500; // 2 FPS
    
    static const int MAX_ENTITIES = 1000;
    static const int MAX_VISIBLE_ENTITIES = 200;
    static const int MAX_WAYPOINTS = 50;
    static const int MAX_TRAIL_POINTS = 20;
    static const float DETECTION_RISK_THRESHOLD;
    static const float EMERGENCY_COOLDOWN_TIME;
};

#endif // RADAR_H