#ifndef MISC_H
#define MISC_H

#include <QtCore/QObject>
#include <QtCore/QTimer>
#include <QtCore/QSettings>
#include <QtCore/QDateTime>
#include <QtCore/QMutex>
#include <QtCore/QThread>
#include <QtGui/QVector3D>
#include <QtGui/QVector2D>
#include <QtGui/QColor>
#include <QtCore/QMap>
#include <QtCore/QList>
#include <QtCore/QStringList>
#include <memory>

// Forward declarations
class GameInterface;
class MemoryManager;
class Logger;

enum class SpeedHackMode {
    Disabled = 0,
    Movement = 1,
    Animation = 2,
    Global = 3,
    Custom = 4
};

enum class NoRecoilMode {
    Disabled = 0,
    Basic = 1,
    Advanced = 2,
    Weapon_Specific = 3,
    Adaptive = 4
};

enum class NoSpreadMode {
    Disabled = 0,
    Basic = 1,
    Advanced = 2,
    Perfect = 3
};

enum class TeleportMode {
    Disabled = 0,
    Instant = 1,
    Smooth = 2,
    Safe = 3
};

enum class FlyMode {
    Disabled = 0,
    Basic = 1,
    Noclip = 2,
    Smooth = 3,
    Realistic = 4
};

enum class JumpMode {
    Disabled = 0,
    Super = 1,
    Infinite = 2,
    Custom = 3
};

enum class WeatherMode {
    Default = 0,
    Clear = 1,
    Sunny = 2,
    Cloudy = 3,
    Rainy = 4,
    Foggy = 5,
    Custom = 6
};

enum class TimeMode {
    Default = 0,
    Dawn = 1,
    Day = 2,
    Dusk = 3,
    Night = 4,
    Custom = 5
};

enum class CrosshairType {
    None = 0,
    Dot = 1,
    Cross = 2,
    Circle = 3,
    Square = 4,
    Custom = 5
};

enum class FOVMode {
    Default = 0,
    Wide = 1,
    Ultra_Wide = 2,
    Custom = 3
};

struct MiscSettings {
    // Speed modifications
    bool speedHackEnabled = false;
    SpeedHackMode speedHackMode = SpeedHackMode::Movement;
    float movementSpeedMultiplier = 1.5f;
    float animationSpeedMultiplier = 1.0f;
    float globalSpeedMultiplier = 1.0f;
    float customSpeedValue = 1.0f;
    bool speedHackSafe = true;
    float maxSafeSpeed = 2.0f;
    bool speedHackSmooth = true;
    float speedTransitionTime = 0.5f;
    
    // Recoil control
    bool noRecoilEnabled = false;
    NoRecoilMode noRecoilMode = NoRecoilMode::Basic;
    float recoilReductionPercent = 100.0f;
    bool weaponSpecificRecoil = false;
    bool adaptiveRecoil = false;
    float recoilSmoothness = 0.8f;
    bool horizontalRecoilOnly = false;
    bool verticalRecoilOnly = false;
    QMap<QString, float> weaponRecoilSettings;
    
    // Spread control
    bool noSpreadEnabled = false;
    NoSpreadMode noSpreadMode = NoSpreadMode::Basic;
    float spreadReductionPercent = 100.0f;
    bool perfectAccuracy = false;
    bool spreadCompensation = true;
    float spreadSmoothness = 0.9f;
    
    // Teleportation
    bool teleportEnabled = false;
    TeleportMode teleportMode = TeleportMode::Safe;
    QVector3D teleportTarget;
    bool teleportToMouse = false;
    bool teleportToWaypoint = false;
    bool teleportSafe = true;
    float teleportHeight = 2.0f;
    float teleportSpeed = 10.0f;
    bool teleportSmooth = true;
    float teleportSmoothTime = 1.0f;
    QList<QVector3D> teleportHistory;
    int maxTeleportHistory = 10;
    
    // Flight
    bool flyEnabled = false;
    FlyMode flyMode = FlyMode::Basic;
    float flySpeed = 5.0f;
    float flyAcceleration = 2.0f;
    float flyDeceleration = 3.0f;
    bool flyNoclip = false;
    bool flySmooth = true;
    float flySmoothness = 0.8f;
    bool flyRealistic = false;
    float flyGravity = 0.1f;
    bool flyCollision = true;
    
    // Jump modifications
    bool jumpHackEnabled = false;
    JumpMode jumpMode = JumpMode::Super;
    float jumpHeightMultiplier = 2.0f;
    bool infiniteJump = false;
    float customJumpHeight = 10.0f;
    bool jumpSafe = true;
    float maxSafeJumpHeight = 5.0f;
    bool jumpSmooth = true;
    float jumpSmoothness = 0.7f;
    
    // Instant actions
    bool instantHealEnabled = false;
    bool instantReloadEnabled = false;
    bool instantReviveEnabled = false;
    bool instantLootEnabled = false;
    bool instantRepairEnabled = false;
    bool instantCookingEnabled = false;
    float instantActionDelay = 0.1f;
    bool instantActionSafe = true;
    
    // Infinite resources
    bool infiniteAmmoEnabled = false;
    bool infiniteHealthEnabled = false;
    bool infiniteEnergyEnabled = false;
    bool infiniteFuelEnabled = false;
    bool infiniteOxygenEnabled = false;
    bool infiniteDurabilityEnabled = false;
    bool resourcesSafe = true;
    float resourcesUpdateRate = 1.0f;
    
    // Auto features
    bool autoHealEnabled = false;
    float autoHealThreshold = 50.0f;
    bool autoEnergyEnabled = false;
    float autoEnergyThreshold = 30.0f;
    bool autoLootEnabled = false;
    float autoLootRange = 5.0f;
    QStringList autoLootItems;
    bool autoReloadEnabled = false;
    float autoReloadThreshold = 10.0f;
    bool autoReviveEnabled = false;
    float autoReviveRange = 3.0f;
    
    // Weapon modifications
    bool noWeaponSwayEnabled = false;
    bool noWeaponBobEnabled = false;
    bool rapidFireEnabled = false;
    float rapidFireRate = 2.0f;
    bool weaponRangeEnabled = false;
    float weaponRangeMultiplier = 2.0f;
    bool weaponDamageEnabled = false;
    float weaponDamageMultiplier = 1.5f;
    bool weaponPenetrationEnabled = false;
    float weaponPenetrationMultiplier = 2.0f;
    
    // Vehicle modifications
    bool vehicleSpeedEnabled = false;
    float vehicleSpeedMultiplier = 2.0f;
    bool vehicleHealthEnabled = false;
    bool vehicleFuelEnabled = false;
    bool vehiclePhysicsEnabled = false;
    float vehicleGravityMultiplier = 1.0f;
    bool vehicleCollisionEnabled = false;
    bool vehicleFlipEnabled = false;
    
    // Environmental modifications
    bool weatherControlEnabled = false;
    WeatherMode weatherMode = WeatherMode::Clear;
    float customWeatherIntensity = 1.0f;
    bool timeControlEnabled = false;
    TimeMode timeMode = TimeMode::Day;
    float customTimeValue = 12.0f; // 24-hour format
    bool fogRemovalEnabled = false;
    bool shadowRemovalEnabled = false;
    bool grassRemovalEnabled = false;
    bool treeRemovalEnabled = false;
    
    // Visual enhancements
    bool customCrosshairEnabled = false;
    CrosshairType crosshairType = CrosshairType::Cross;
    QColor crosshairColor = QColor(255, 255, 255, 255);
    float crosshairSize = 10.0f;
    float crosshairThickness = 2.0f;
    bool crosshairOutline = true;
    QColor crosshairOutlineColor = QColor(0, 0, 0, 255);
    bool crosshairDynamic = false;
    
    bool fovModificationEnabled = false;
    FOVMode fovMode = FOVMode::Wide;
    float customFOV = 90.0f;
    float minFOV = 60.0f;
    float maxFOV = 120.0f;
    bool fovSmooth = true;
    float fovTransitionTime = 0.5f;
    
    bool brightnessEnabled = false;
    float brightnessMultiplier = 1.5f;
    bool contrastEnabled = false;
    float contrastMultiplier = 1.2f;
    bool saturationEnabled = false;
    float saturationMultiplier = 1.3f;
    bool gammaEnabled = false;
    float gammaValue = 1.0f;
    
    // UI modifications
    bool hideUIEnabled = false;
    bool hideHUDEnabled = false;
    bool hideMinimapEnabled = false;
    bool hideChatEnabled = false;
    bool hideKillFeedEnabled = false;
    bool hideSpectatorListEnabled = false;
    bool customUIScaleEnabled = false;
    float uiScaleMultiplier = 1.0f;
    
    // Performance optimizations
    bool performanceBoostEnabled = false;
    bool reducedEffectsEnabled = false;
    bool lowQualityTexturesEnabled = false;
    bool disableParticlesEnabled = false;
    bool disableShadowsEnabled = false;
    bool disableReflectionsEnabled = false;
    bool disablePostProcessingEnabled = false;
    int maxFPS = 144;
    bool fpsLimitEnabled = false;
    
    // Anti-detection features
    bool humanizationEnabled = true;
    float humanizationFactor = 0.8f;
    bool randomDelaysEnabled = true;
    float minRandomDelay = 0.05f;
    float maxRandomDelay = 0.2f;
    bool behaviorMimicEnabled = true;
    float behaviorVariation = 0.3f;
    bool safetyChecksEnabled = true;
    float safetyCheckInterval = 1.0f;
    
    // Hotkeys
    int speedHackToggleKey = 0x70; // F1
    int noRecoilToggleKey = 0x71; // F2
    int noSpreadToggleKey = 0x72; // F3
    int teleportKey = 0x73; // F4
    int flyToggleKey = 0x74; // F5
    int jumpHackToggleKey = 0x75; // F6
    int instantActionsToggleKey = 0x76; // F7
    int infiniteResourcesToggleKey = 0x77; // F8
    int autoFeaturesToggleKey = 0x78; // F9
    int weaponModsToggleKey = 0x79; // F10
    int vehicleModsToggleKey = 0x7A; // F11
    int environmentToggleKey = 0x7B; // F12
    
    // Advanced settings
    bool expertModeEnabled = false;
    bool debugModeEnabled = false;
    bool loggingEnabled = true;
    bool statisticsEnabled = true;
    bool backupSettingsEnabled = true;
    QString configurationProfile = "Default";
    QStringList availableProfiles;
    
    // Safety limits
    float maxSpeedLimit = 10.0f;
    float maxJumpLimit = 20.0f;
    float maxTeleportDistance = 1000.0f;
    float maxFlyHeight = 500.0f;
    int maxActionsPerSecond = 10;
    bool enforceLimits = true;
    bool warningSystemEnabled = true;
    
    // Timing settings
    int updateInterval = 16; // ~60 FPS
    int safetyCheckInterval_ms = 1000;
    int statisticsUpdateInterval = 5000;
    int backupInterval = 300000; // 5 minutes
    bool adaptiveTimingEnabled = true;
    
    // Compatibility settings
    bool gameVersionCheckEnabled = true;
    QString supportedGameVersion = "3.9";
    bool autoDisableOnUpdate = true;
    bool compatibilityModeEnabled = false;
    QStringList disabledFeatures;
};

struct MiscStatistics {
    // Usage statistics
    int totalActivations = 0;
    int speedHackUsage = 0;
    int noRecoilUsage = 0;
    int noSpreadUsage = 0;
    int teleportUsage = 0;
    int flyUsage = 0;
    int jumpHackUsage = 0;
    int instantActionsUsage = 0;
    int infiniteResourcesUsage = 0;
    int autoFeaturesUsage = 0;
    int weaponModsUsage = 0;
    int vehicleModsUsage = 0;
    int environmentModsUsage = 0;
    
    // Performance statistics
    float averageProcessingTime = 0.0f;
    float maxProcessingTime = 0.0f;
    float minProcessingTime = 999.0f;
    int totalProcessingCycles = 0;
    float averageFPS = 60.0f;
    int frameDrops = 0;
    
    // Safety statistics
    int safetyViolations = 0;
    int warningsIssued = 0;
    int emergencyDisables = 0;
    int detectionRisks = 0;
    QDateTime lastSafetyCheck;
    
    // Error statistics
    int totalErrors = 0;
    int memoryErrors = 0;
    int injectionErrors = 0;
    int gameInterfaceErrors = 0;
    QStringList recentErrors;
    
    // Session statistics
    QDateTime sessionStart;
    QDateTime lastActivity;
    int sessionDuration = 0; // seconds
    int featuresUsedThisSession = 0;
    
    // Historical data
    QMap<QString, int> dailyUsage;
    QMap<QString, float> performanceHistory;
    QList<QString> errorHistory;
};

class Misc : public QObject
{
    Q_OBJECT

public:
    explicit Misc(QObject *parent = nullptr);
    ~Misc();
    
    // Component integration
    void setGameInterface(GameInterface *gameInterface);
    void setMemoryManager(MemoryManager *memoryManager);
    void setLogger(Logger *logger);
    
    // Settings management
    void setSettings(const MiscSettings &settings);
    MiscSettings getSettings() const;
    void loadSettings();
    void saveSettings();
    void resetSettings();
    void loadProfile(const QString &profileName);
    void saveProfile(const QString &profileName);
    void deleteProfile(const QString &profileName);
    QStringList getAvailableProfiles() const;
    
    // Control methods
    void enable();
    void disable();
    void toggle();
    bool isEnabled() const;
    
    // Feature control
    void enableSpeedHack(bool enabled);
    void enableNoRecoil(bool enabled);
    void enableNoSpread(bool enabled);
    void enableTeleport(bool enabled);
    void enableFly(bool enabled);
    void enableJumpHack(bool enabled);
    void enableInstantActions(bool enabled);
    void enableInfiniteResources(bool enabled);
    void enableAutoFeatures(bool enabled);
    void enableWeaponMods(bool enabled);
    void enableVehicleMods(bool enabled);
    void enableEnvironmentMods(bool enabled);
    
    // Speed modifications
    void setMovementSpeed(float multiplier);
    void setAnimationSpeed(float multiplier);
    void setGlobalSpeed(float multiplier);
    float getCurrentSpeed() const;
    
    // Recoil and spread control
    void setRecoilReduction(float percent);
    void setSpreadReduction(float percent);
    void addWeaponRecoilSetting(const QString &weapon, float reduction);
    void removeWeaponRecoilSetting(const QString &weapon);
    
    // Teleportation
    void teleportToPosition(const QVector3D &position);
    void teleportToMouse();
    void teleportToWaypoint(int waypointIndex);
    void addTeleportHistory(const QVector3D &position);
    QList<QVector3D> getTeleportHistory() const;
    
    // Flight control
    void setFlySpeed(float speed);
    void setFlyMode(FlyMode mode);
    bool isFlyingEnabled() const;
    
    // Jump modifications
    void setJumpHeight(float multiplier);
    void setJumpMode(JumpMode mode);
    
    // Instant actions
    void performInstantHeal();
    void performInstantReload();
    void performInstantRevive();
    void performInstantLoot();
    void performInstantRepair();
    
    // Resource management
    void setInfiniteAmmo(bool enabled);
    void setInfiniteHealth(bool enabled);
    void setInfiniteEnergy(bool enabled);
    void setInfiniteFuel(bool enabled);
    void setInfiniteOxygen(bool enabled);
    void setInfiniteDurability(bool enabled);
    
    // Auto features
    void setAutoHeal(bool enabled, float threshold);
    void setAutoEnergy(bool enabled, float threshold);
    void setAutoLoot(bool enabled, float range);
    void setAutoReload(bool enabled, float threshold);
    void setAutoRevive(bool enabled, float range);
    
    // Weapon modifications
    void setRapidFire(bool enabled, float rate);
    void setWeaponRange(bool enabled, float multiplier);
    void setWeaponDamage(bool enabled, float multiplier);
    void setWeaponPenetration(bool enabled, float multiplier);
    
    // Vehicle modifications
    void setVehicleSpeed(bool enabled, float multiplier);
    void setVehicleHealth(bool enabled);
    void setVehicleFuel(bool enabled);
    void setVehiclePhysics(bool enabled, float gravity);
    
    // Environmental control
    void setWeather(WeatherMode mode, float intensity = 1.0f);
    void setTime(TimeMode mode, float customTime = 12.0f);
    void setFogRemoval(bool enabled);
    void setShadowRemoval(bool enabled);
    void setGrassRemoval(bool enabled);
    void setTreeRemoval(bool enabled);
    
    // Visual enhancements
    void setCrosshair(bool enabled, CrosshairType type, const QColor &color, float size);
    void setFOV(bool enabled, float fov);
    void setBrightness(bool enabled, float multiplier);
    void setContrast(bool enabled, float multiplier);
    void setSaturation(bool enabled, float multiplier);
    void setGamma(bool enabled, float value);
    
    // UI modifications
    void setHideUI(bool enabled);
    void setHideHUD(bool enabled);
    void setHideMinimap(bool enabled);
    void setHideChat(bool enabled);
    void setUIScale(bool enabled, float multiplier);
    
    // Performance optimizations
    void setPerformanceBoost(bool enabled);
    void setReducedEffects(bool enabled);
    void setLowQualityTextures(bool enabled);
    void setDisableParticles(bool enabled);
    void setDisableShadows(bool enabled);
    void setFPSLimit(bool enabled, int maxFPS);
    
    // Statistics
    MiscStatistics getStatistics() const;
    void resetStatistics();
    void updateStatistics();
    
public slots:
    // Main update slots
    void update();
    void onGameUpdate();
    void onPlayerUpdate();
    void onWeaponUpdate();
    void onVehicleUpdate();
    void onEnvironmentUpdate();
    
    // Settings slots
    void onSettingsChanged(const MiscSettings &settings);
    void onProfileChanged(const QString &profileName);
    void onExpertModeToggled(bool enabled);
    void onDebugModeToggled(bool enabled);
    void onSafetyChecksToggled(bool enabled);
    
    // Speed modification slots
    void onSpeedHackToggled(bool enabled);
    void onSpeedHackModeChanged(int mode);
    void onMovementSpeedChanged(float multiplier);
    void onAnimationSpeedChanged(float multiplier);
    void onGlobalSpeedChanged(float multiplier);
    void onCustomSpeedChanged(float value);
    void onSpeedHackSafeToggled(bool enabled);
    void onMaxSafeSpeedChanged(float speed);
    void onSpeedHackSmoothToggled(bool enabled);
    void onSpeedTransitionTimeChanged(float time);
    
    // Recoil control slots
    void onNoRecoilToggled(bool enabled);
    void onNoRecoilModeChanged(int mode);
    void onRecoilReductionChanged(float percent);
    void onWeaponSpecificRecoilToggled(bool enabled);
    void onAdaptiveRecoilToggled(bool enabled);
    void onRecoilSmoothnessChanged(float smoothness);
    void onHorizontalRecoilOnlyToggled(bool enabled);
    void onVerticalRecoilOnlyToggled(bool enabled);
    
    // Spread control slots
    void onNoSpreadToggled(bool enabled);
    void onNoSpreadModeChanged(int mode);
    void onSpreadReductionChanged(float percent);
    void onPerfectAccuracyToggled(bool enabled);
    void onSpreadCompensationToggled(bool enabled);
    void onSpreadSmoothnessChanged(float smoothness);
    
    // Teleportation slots
    void onTeleportToggled(bool enabled);
    void onTeleportModeChanged(int mode);
    void onTeleportToMouseToggled(bool enabled);
    void onTeleportToWaypointToggled(bool enabled);
    void onTeleportSafeToggled(bool enabled);
    void onTeleportHeightChanged(float height);
    void onTeleportSpeedChanged(float speed);
    void onTeleportSmoothToggled(bool enabled);
    void onTeleportSmoothTimeChanged(float time);
    void onTeleportRequested(const QVector3D &position);
    void onTeleportToMouseRequested();
    void onTeleportToWaypointRequested(int index);
    
    // Flight slots
    void onFlyToggled(bool enabled);
    void onFlyModeChanged(int mode);
    void onFlySpeedChanged(float speed);
    void onFlyAccelerationChanged(float acceleration);
    void onFlyDecelerationChanged(float deceleration);
    void onFlyNoclipToggled(bool enabled);
    void onFlySmoothToggled(bool enabled);
    void onFlySmoothnessChanged(float smoothness);
    void onFlyRealisticToggled(bool enabled);
    void onFlyGravityChanged(float gravity);
    void onFlyCollisionToggled(bool enabled);
    
    // Jump modification slots
    void onJumpHackToggled(bool enabled);
    void onJumpModeChanged(int mode);
    void onJumpHeightMultiplierChanged(float multiplier);
    void onInfiniteJumpToggled(bool enabled);
    void onCustomJumpHeightChanged(float height);
    void onJumpSafeToggled(bool enabled);
    void onMaxSafeJumpHeightChanged(float height);
    void onJumpSmoothToggled(bool enabled);
    void onJumpSmoothnessChanged(float smoothness);
    
    // Instant action slots
    void onInstantHealToggled(bool enabled);
    void onInstantReloadToggled(bool enabled);
    void onInstantReviveToggled(bool enabled);
    void onInstantLootToggled(bool enabled);
    void onInstantRepairToggled(bool enabled);
    void onInstantCookingToggled(bool enabled);
    void onInstantActionDelayChanged(float delay);
    void onInstantActionSafeToggled(bool enabled);
    void onInstantHealRequested();
    void onInstantReloadRequested();
    void onInstantReviveRequested();
    void onInstantLootRequested();
    void onInstantRepairRequested();
    
    // Infinite resource slots
    void onInfiniteAmmoToggled(bool enabled);
    void onInfiniteHealthToggled(bool enabled);
    void onInfiniteEnergyToggled(bool enabled);
    void onInfiniteFuelToggled(bool enabled);
    void onInfiniteOxygenToggled(bool enabled);
    void onInfiniteDurabilityToggled(bool enabled);
    void onResourcesSafeToggled(bool enabled);
    void onResourcesUpdateRateChanged(float rate);
    
    // Auto feature slots
    void onAutoHealToggled(bool enabled);
    void onAutoHealThresholdChanged(float threshold);
    void onAutoEnergyToggled(bool enabled);
    void onAutoEnergyThresholdChanged(float threshold);
    void onAutoLootToggled(bool enabled);
    void onAutoLootRangeChanged(float range);
    void onAutoLootItemsChanged(const QStringList &items);
    void onAutoReloadToggled(bool enabled);
    void onAutoReloadThresholdChanged(float threshold);
    void onAutoReviveToggled(bool enabled);
    void onAutoReviveRangeChanged(float range);
    
    // Weapon modification slots
    void onNoWeaponSwayToggled(bool enabled);
    void onNoWeaponBobToggled(bool enabled);
    void onRapidFireToggled(bool enabled);
    void onRapidFireRateChanged(float rate);
    void onWeaponRangeToggled(bool enabled);
    void onWeaponRangeMultiplierChanged(float multiplier);
    void onWeaponDamageToggled(bool enabled);
    void onWeaponDamageMultiplierChanged(float multiplier);
    void onWeaponPenetrationToggled(bool enabled);
    void onWeaponPenetrationMultiplierChanged(float multiplier);
    
    // Vehicle modification slots
    void onVehicleSpeedToggled(bool enabled);
    void onVehicleSpeedMultiplierChanged(float multiplier);
    void onVehicleHealthToggled(bool enabled);
    void onVehicleFuelToggled(bool enabled);
    void onVehiclePhysicsToggled(bool enabled);
    void onVehicleGravityMultiplierChanged(float multiplier);
    void onVehicleCollisionToggled(bool enabled);
    void onVehicleFlipToggled(bool enabled);
    
    // Environmental modification slots
    void onWeatherControlToggled(bool enabled);
    void onWeatherModeChanged(int mode);
    void onCustomWeatherIntensityChanged(float intensity);
    void onTimeControlToggled(bool enabled);
    void onTimeModeChanged(int mode);
    void onCustomTimeValueChanged(float time);
    void onFogRemovalToggled(bool enabled);
    void onShadowRemovalToggled(bool enabled);
    void onGrassRemovalToggled(bool enabled);
    void onTreeRemovalToggled(bool enabled);
    
    // Visual enhancement slots
    void onCustomCrosshairToggled(bool enabled);
    void onCrosshairTypeChanged(int type);
    void onCrosshairColorChanged(const QColor &color);
    void onCrosshairSizeChanged(float size);
    void onCrosshairThicknessChanged(float thickness);
    void onCrosshairOutlineToggled(bool enabled);
    void onCrosshairOutlineColorChanged(const QColor &color);
    void onCrosshairDynamicToggled(bool enabled);
    
    void onFOVModificationToggled(bool enabled);
    void onFOVModeChanged(int mode);
    void onCustomFOVChanged(float fov);
    void onMinFOVChanged(float fov);
    void onMaxFOVChanged(float fov);
    void onFOVSmoothToggled(bool enabled);
    void onFOVTransitionTimeChanged(float time);
    
    void onBrightnessToggled(bool enabled);
    void onBrightnessMultiplierChanged(float multiplier);
    void onContrastToggled(bool enabled);
    void onContrastMultiplierChanged(float multiplier);
    void onSaturationToggled(bool enabled);
    void onSaturationMultiplierChanged(float multiplier);
    void onGammaToggled(bool enabled);
    void onGammaValueChanged(float value);
    
    // UI modification slots
    void onHideUIToggled(bool enabled);
    void onHideHUDToggled(bool enabled);
    void onHideMinimapToggled(bool enabled);
    void onHideChatToggled(bool enabled);
    void onHideKillFeedToggled(bool enabled);
    void onHideSpectatorListToggled(bool enabled);
    void onCustomUIScaleToggled(bool enabled);
    void onUIScaleMultiplierChanged(float multiplier);
    
    // Performance optimization slots
    void onPerformanceBoostToggled(bool enabled);
    void onReducedEffectsToggled(bool enabled);
    void onLowQualityTexturesToggled(bool enabled);
    void onDisableParticlesToggled(bool enabled);
    void onDisableShadowsToggled(bool enabled);
    void onDisableReflectionsToggled(bool enabled);
    void onDisablePostProcessingToggled(bool enabled);
    void onMaxFPSChanged(int fps);
    void onFPSLimitToggled(bool enabled);
    
    // Anti-detection slots
    void onHumanizationToggled(bool enabled);
    void onHumanizationFactorChanged(float factor);
    void onRandomDelaysToggled(bool enabled);
    void onMinRandomDelayChanged(float delay);
    void onMaxRandomDelayChanged(float delay);
    void onBehaviorMimicToggled(bool enabled);
    void onBehaviorVariationChanged(float variation);
    
    // Hotkey slots
    void onSpeedHackHotkeyPressed();
    void onNoRecoilHotkeyPressed();
    void onNoSpreadHotkeyPressed();
    void onTeleportHotkeyPressed();
    void onFlyHotkeyPressed();
    void onJumpHackHotkeyPressed();
    void onInstantActionsHotkeyPressed();
    void onInfiniteResourcesHotkeyPressed();
    void onAutoFeaturesHotkeyPressed();
    void onWeaponModsHotkeyPressed();
    void onVehicleModsHotkeyPressed();
    void onEnvironmentHotkeyPressed();
    
    // Safety slots
    void onSafetyViolation(const QString &violation);
    void onWarningIssued(const QString &warning);
    void onEmergencyDisable();
    void onDetectionRisk(const QString &risk);
    void onSafetyCheckTimer();
    
signals:
    void enabledChanged(bool enabled);
    void settingsChanged(const MiscSettings &settings);
    void profileChanged(const QString &profileName);
    void featureToggled(const QString &feature, bool enabled);
    void speedChanged(float speed);
    void teleportPerformed(const QVector3D &position);
    void flyModeChanged(bool enabled);
    void instantActionPerformed(const QString &action);
    void resourceModified(const QString &resource, bool infinite);
    void weaponModified(const QString &modification, bool enabled);
    void vehicleModified(const QString &modification, bool enabled);
    void environmentModified(const QString &modification, bool enabled);
    void visualModified(const QString &modification, bool enabled);
    void performanceModified(const QString &modification, bool enabled);
    void safetyViolation(const QString &violation);
    void warningIssued(const QString &warning);
    void emergencyTriggered();
    void detectionRisk(const QString &risk);
    void statisticsUpdated(const MiscStatistics &stats);
    void errorOccurred(const QString &error);
    
private slots:
    void updateTimer();
    void safetyCheckTimer();
    void statisticsTimer();
    void backupTimer();
    void humanizationTimer();
    
private:
    // Core functionality
    void applySpeedModifications();
    void applyRecoilControl();
    void applySpreadControl();
    void applyTeleportation();
    void applyFlightControl();
    void applyJumpModifications();
    void applyInstantActions();
    void applyInfiniteResources();
    void applyAutoFeatures();
    void applyWeaponModifications();
    void applyVehicleModifications();
    void applyEnvironmentalModifications();
    void applyVisualEnhancements();
    void applyUIModifications();
    void applyPerformanceOptimizations();
    
    // Speed control implementation
    void setPlayerSpeed(float multiplier);
    void setAnimationSpeed(float multiplier);
    void setGameSpeed(float multiplier);
    bool isSpeedSafe(float speed);
    void smoothSpeedTransition(float targetSpeed);
    
    // Recoil control implementation
    void reduceRecoil(float percent);
    void applyWeaponSpecificRecoil(const QString &weapon);
    void adaptiveRecoilControl();
    QVector2D calculateRecoilCompensation();
    
    // Spread control implementation
    void reduceSpread(float percent);
    void applyPerfectAccuracy();
    void compensateSpread();
    
    // Teleportation implementation
    bool teleportToPosition(const QVector3D &position, bool safe);
    bool isTeleportSafe(const QVector3D &position);
    QVector3D findSafeTeleportPosition(const QVector3D &target);
    void smoothTeleport(const QVector3D &target);
    
    // Flight implementation
    void updateFlightMovement();
    void applyFlightPhysics();
    void handleFlightCollision();
    bool isFlightPositionSafe(const QVector3D &position);
    
    // Jump implementation
    void modifyJumpHeight(float multiplier);
    void enableInfiniteJump();
    bool isJumpSafe(float height);
    
    // Instant action implementation
    void performInstantAction(const QString &action);
    bool canPerformInstantAction(const QString &action);
    void addActionDelay(float delay);
    
    // Resource management implementation
    void setResourceValue(const QString &resource, float value);
    void maintainInfiniteResource(const QString &resource);
    bool isResourceModificationSafe(const QString &resource);
    
    // Auto feature implementation
    void checkAutoHeal();
    void checkAutoEnergy();
    void checkAutoLoot();
    void checkAutoReload();
    void checkAutoRevive();
    bool shouldPerformAutoAction(const QString &action);
    
    // Weapon modification implementation
    void modifyWeaponProperty(const QString &property, float value);
    void removeWeaponSway();
    void removeWeaponBob();
    void setRapidFireRate(float rate);
    void modifyWeaponRange(float multiplier);
    void modifyWeaponDamage(float multiplier);
    void modifyWeaponPenetration(float multiplier);
    
    // Vehicle modification implementation
    void modifyVehicleProperty(const QString &property, float value);
    void setVehicleSpeedMultiplier(float multiplier);
    void setVehicleInfiniteHealth();
    void setVehicleInfiniteFuel();
    void modifyVehiclePhysics(float gravity);
    void disableVehicleCollision();
    
    // Environmental modification implementation
    void setWeatherType(WeatherMode mode, float intensity);
    void setTimeOfDay(TimeMode mode, float time);
    void removeEnvironmentalElement(const QString &element);
    void modifyEnvironmentalProperty(const QString &property, float value);
    
    // Visual enhancement implementation
    void drawCustomCrosshair();
    void modifyFOV(float fov);
    void adjustBrightness(float multiplier);
    void adjustContrast(float multiplier);
    void adjustSaturation(float multiplier);
    void adjustGamma(float value);
    
    // UI modification implementation
    void hideUIElement(const QString &element);
    void showUIElement(const QString &element);
    void scaleUIElement(const QString &element, float scale);
    
    // Performance optimization implementation
    void optimizePerformance();
    void reduceGraphicalEffects();
    void setTextureQuality(bool lowQuality);
    void toggleGraphicalFeature(const QString &feature, bool enabled);
    void limitFrameRate(int maxFPS);
    
    // Memory operations
    bool readPlayerSpeed(float &speed);
    bool writePlayerSpeed(float speed);
    bool readRecoilPattern(QVector2D &pattern);
    bool writeRecoilPattern(const QVector2D &pattern);
    bool readSpreadValue(float &spread);
    bool writeSpreadValue(float spread);
    bool readPlayerPosition(QVector3D &position);
    bool writePlayerPosition(const QVector3D &position);
    bool readPlayerVelocity(QVector3D &velocity);
    bool writePlayerVelocity(const QVector3D &velocity);
    bool readJumpHeight(float &height);
    bool writeJumpHeight(float height);
    bool readResourceValue(const QString &resource, float &value);
    bool writeResourceValue(const QString &resource, float value);
    bool readWeaponProperty(const QString &property, float &value);
    bool writeWeaponProperty(const QString &property, float value);
    bool readVehicleProperty(const QString &property, float &value);
    bool writeVehicleProperty(const QString &property, float value);
    bool readEnvironmentalProperty(const QString &property, float &value);
    bool writeEnvironmentalProperty(const QString &property, float value);
    bool readVisualProperty(const QString &property, float &value);
    bool writeVisualProperty(const QString &property, float value);
    
    // Safety and detection
    void performSafetyChecks();
    void checkFeatureLimits();
    void checkDetectionRisk();
    void issueWarning(const QString &warning);
    void handleSafetyViolation(const QString &violation);
    void emergencyShutdown();
    bool isFeatureSafe(const QString &feature);
    bool isValueWithinLimits(const QString &property, float value);
    float calculateDetectionRisk();
    
    // Humanization and anti-detection
    void applyHumanization();
    void addRandomDelay();
    void mimicHumanBehavior();
    void varyBehaviorPattern();
    float generateRandomDelay();
    QVector2D generateHumanLikeMovement();
    
    // Statistics and logging
    void updateUsageStatistics(const QString &feature);
    void updatePerformanceStatistics();
    void updateSafetyStatistics();
    void updateErrorStatistics(const QString &error);
    void logFeatureUsage(const QString &feature);
    void logPerformanceMetrics();
    void logSafetyEvent(const QString &event);
    void logError(const QString &error);
    
    // Configuration management
    void loadConfiguration();
    void saveConfiguration();
    void backupConfiguration();
    void restoreConfiguration();
    void validateConfiguration();
    void migrateConfiguration();
    
    // Utility functions
    QString formatFeatureInfo(const QString &feature) const;
    QString formatStatistics() const;
    QString formatSettings() const;
    QString formatSafetyReport() const;
    float clampValue(float value, float min, float max);
    bool isGameVersionSupported();
    void checkGameCompatibility();
    
    // Core components
    GameInterface *m_gameInterface;
    MemoryManager *m_memoryManager;
    Logger *m_logger;
    
    // Settings and configuration
    MiscSettings m_settings;
    QSettings *m_qsettings;
    
    // Statistics
    MiscStatistics m_statistics;
    
    // State variables
    bool m_enabled;
    QDateTime m_lastUpdateTime;
    QDateTime m_lastSafetyCheck;
    QDateTime m_sessionStartTime;
    
    // Feature states
    bool m_speedHackActive;
    bool m_noRecoilActive;
    bool m_noSpreadActive;
    bool m_teleportActive;
    bool m_flyActive;
    bool m_jumpHackActive;
    bool m_instantActionsActive;
    bool m_infiniteResourcesActive;
    bool m_autoFeaturesActive;
    bool m_weaponModsActive;
    bool m_vehicleModsActive;
    bool m_environmentModsActive;
    
    // Current values
    float m_currentSpeed;
    QVector2D m_currentRecoilPattern;
    float m_currentSpread;
    QVector3D m_currentPosition;
    QVector3D m_currentVelocity;
    float m_currentJumpHeight;
    float m_currentFOV;
    
    // Safety tracking
    int m_safetyViolationCount;
    int m_warningCount;
    QDateTime m_lastWarning;
    QDateTime m_lastViolation;
    bool m_emergencyMode;
    
    // Performance tracking
    QDateTime m_lastPerformanceUpdate;
    float m_averageProcessingTime;
    int m_frameCount;
    QDateTime m_lastFrameTime;
    
    // Humanization data
    QDateTime m_lastHumanizationUpdate;
    QVector2D m_lastMouseMovement;
    float m_behaviorVariationOffset;
    
    // Timers
    QTimer *m_updateTimer;
    QTimer *m_safetyCheckTimer;
    QTimer *m_statisticsTimer;
    QTimer *m_backupTimer;
    QTimer *m_humanizationTimer;
    
    // Threading
    QThread *m_processingThread;
    QMutex m_processingMutex;
    
    // Constants
    static const float DEFAULT_SPEED_MULTIPLIER;
    static const float DEFAULT_RECOIL_REDUCTION;
    static const float DEFAULT_SPREAD_REDUCTION;
    static const float DEFAULT_JUMP_MULTIPLIER;
    static const float DEFAULT_FLY_SPEED;
    static const float DEFAULT_TELEPORT_HEIGHT;
    static const float DEFAULT_FOV;
    
    static const float MAX_SAFE_SPEED;
    static const float MAX_SAFE_JUMP;
    static const float MAX_SAFE_TELEPORT_DISTANCE;
    static const float MAX_SAFE_FLY_HEIGHT;
    static const float DETECTION_RISK_THRESHOLD;
    
    static const int UPDATE_INTERVAL = 16; // ~60 FPS
    static const int SAFETY_CHECK_INTERVAL = 1000; // 1 second
    static const int STATISTICS_INTERVAL = 5000; // 5 seconds
    static const int BACKUP_INTERVAL = 300000; // 5 minutes
    static const int HUMANIZATION_INTERVAL = 100; // 10 FPS
};

#endif // MISC_H