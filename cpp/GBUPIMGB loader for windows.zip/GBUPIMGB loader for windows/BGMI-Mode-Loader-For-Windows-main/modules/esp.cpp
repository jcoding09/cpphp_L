#include "esp.h"
#include "../core/logger.h"
#include "../core/memory_manager.h"
#include "../core/game_interface.h"
#include "../data/entity_manager.h"
#include <QTimer>
#include <QMutexLocker>
#include <QPainter>
#include <QFont>
#include <QFontMetrics>
#include <QtMath>
#include <QOpenGLWidget>
#include <QMatrix4x4>

ESP::ESP(QObject *parent)
    : QObject(parent)
    , m_enabled(false)
    , m_showPlayers(true)
    , m_showEnemies(true)
    , m_showTeammates(false)
    , m_showItems(true)
    , m_showVehicles(true)
    , m_showDistance(true)
    , m_showHealth(true)
    , m_showName(true)
    , m_showWeapon(true)
    , m_showBones(false)
    , m_showBoxes(true)
    , m_showLines(false)
    , m_maxDistance(500.0f)
    , m_boxType(BoxType::TwoD)
    , m_lineType(LineType::Bottom)
    , m_playerColor(QColor(255, 0, 0))
    , m_teammateColor(QColor(0, 255, 0))
    , m_itemColor(QColor(255, 255, 0))
    , m_vehicleColor(QColor(0, 0, 255))
    , m_fontSize(12)
    , m_lineWidth(2)
    , m_memoryManager(nullptr)
    , m_gameInterface(nullptr)
    , m_entityManager(nullptr)
    , m_logger(nullptr)
    , m_updateTimer(new QTimer(this))
    , m_renderWidget(nullptr)
    , m_viewMatrix(QMatrix4x4())
    , m_projectionMatrix(QMatrix4x4())
    , m_screenWidth(1920)
    , m_screenHeight(1080)
{
    m_updateTimer->setSingleShot(false);
    connect(m_updateTimer, &QTimer::timeout, this, &ESP::update);
}

ESP::~ESP()
{
    stop();
}

void ESP::initialize(MemoryManager* memoryManager, GameInterface* gameInterface,
                    EntityManager* entityManager, Logger* logger)
{
    m_memoryManager = memoryManager;
    m_gameInterface = gameInterface;
    m_entityManager = entityManager;
    m_logger = logger;
    
    if (m_logger) {
        m_logger->info("ESP initialized");
    }
}

void ESP::start()
{
    if (!m_memoryManager || !m_gameInterface || !m_entityManager) {
        if (m_logger) {
            m_logger->error("ESP: Required components not initialized");
        }
        return;
    }
    
    m_enabled = true;
    m_updateTimer->start(16); // ~60 FPS
    
    if (m_logger) {
        m_logger->info("ESP started");
    }
    
    emit statusChanged(true);
}

void ESP::stop()
{
    m_enabled = false;
    m_updateTimer->stop();
    
    if (m_logger) {
        m_logger->info("ESP stopped");
    }
    
    emit statusChanged(false);
}

void ESP::setEnabled(bool enabled)
{
    if (enabled) {
        start();
    } else {
        stop();
    }
}

void ESP::setShowPlayers(bool show)
{
    QMutexLocker locker(&m_mutex);
    m_showPlayers = show;
    emit settingsChanged();
}

void ESP::setShowEnemies(bool show)
{
    QMutexLocker locker(&m_mutex);
    m_showEnemies = show;
    emit settingsChanged();
}

void ESP::setShowTeammates(bool show)
{
    QMutexLocker locker(&m_mutex);
    m_showTeammates = show;
    emit settingsChanged();
}

void ESP::setShowItems(bool show)
{
    QMutexLocker locker(&m_mutex);
    m_showItems = show;
    emit settingsChanged();
}

void ESP::setShowVehicles(bool show)
{
    QMutexLocker locker(&m_mutex);
    m_showVehicles = show;
    emit settingsChanged();
}

void ESP::setShowDistance(bool show)
{
    QMutexLocker locker(&m_mutex);
    m_showDistance = show;
    emit settingsChanged();
}

void ESP::setShowHealth(bool show)
{
    QMutexLocker locker(&m_mutex);
    m_showHealth = show;
    emit settingsChanged();
}

void ESP::setShowName(bool show)
{
    QMutexLocker locker(&m_mutex);
    m_showName = show;
    emit settingsChanged();
}

void ESP::setShowWeapon(bool show)
{
    QMutexLocker locker(&m_mutex);
    m_showWeapon = show;
    emit settingsChanged();
}

void ESP::setShowBones(bool show)
{
    QMutexLocker locker(&m_mutex);
    m_showBones = show;
    emit settingsChanged();
}

void ESP::setShowBoxes(bool show)
{
    QMutexLocker locker(&m_mutex);
    m_showBoxes = show;
    emit settingsChanged();
}

void ESP::setShowLines(bool show)
{
    QMutexLocker locker(&m_mutex);
    m_showLines = show;
    emit settingsChanged();
}

void ESP::setMaxDistance(float distance)
{
    QMutexLocker locker(&m_mutex);
    m_maxDistance = qBound(50.0f, distance, 2000.0f);
    emit settingsChanged();
}

void ESP::setBoxType(BoxType type)
{
    QMutexLocker locker(&m_mutex);
    m_boxType = type;
    emit settingsChanged();
}

void ESP::setLineType(LineType type)
{
    QMutexLocker locker(&m_mutex);
    m_lineType = type;
    emit settingsChanged();
}

void ESP::setPlayerColor(const QColor& color)
{
    QMutexLocker locker(&m_mutex);
    m_playerColor = color;
    emit settingsChanged();
}

void ESP::setTeammateColor(const QColor& color)
{
    QMutexLocker locker(&m_mutex);
    m_teammateColor = color;
    emit settingsChanged();
}

void ESP::setItemColor(const QColor& color)
{
    QMutexLocker locker(&m_mutex);
    m_itemColor = color;
    emit settingsChanged();
}

void ESP::setVehicleColor(const QColor& color)
{
    QMutexLocker locker(&m_mutex);
    m_vehicleColor = color;
    emit settingsChanged();
}

void ESP::setFontSize(int size)
{
    QMutexLocker locker(&m_mutex);
    m_fontSize = qBound(8, size, 24);
    emit settingsChanged();
}

void ESP::setLineWidth(int width)
{
    QMutexLocker locker(&m_mutex);
    m_lineWidth = qBound(1, width, 5);
    emit settingsChanged();
}

void ESP::setRenderWidget(QWidget* widget)
{
    m_renderWidget = widget;
    if (widget) {
        m_screenWidth = widget->width();
        m_screenHeight = widget->height();
    }
}

void ESP::update()
{
    if (!m_enabled || !m_gameInterface || !m_entityManager) {
        return;
    }
    
    QMutexLocker locker(&m_mutex);
    
    // Update view and projection matrices
    updateMatrices();
    
    // Clear previous render data
    m_renderData.clear();
    
    // Get local player
    auto localPlayer = m_gameInterface->getLocalPlayer();
    if (!localPlayer.isValid) {
        return;
    }
    
    // Process players
    if (m_showPlayers) {
        processPlayers(localPlayer);
    }
    
    // Process items
    if (m_showItems) {
        processItems(localPlayer);
    }
    
    // Process vehicles
    if (m_showVehicles) {
        processVehicles(localPlayer);
    }
    
    // Trigger render update
    emit renderDataUpdated();
}

void ESP::updateMatrices()
{
    // Placeholder for matrix updates
    // In a real implementation, these would be read from game memory
    m_viewMatrix.setToIdentity();
    m_projectionMatrix.setToIdentity();
    m_projectionMatrix.perspective(90.0f, (float)m_screenWidth / m_screenHeight, 0.1f, 1000.0f);
}

void ESP::processPlayers(const PlayerInfo& localPlayer)
{
    auto players = m_entityManager->getEntitiesByType(EntityType::Player);
    
    for (const auto& player : players) {
        if (!player.isValid || player.health <= 0) {
            continue;
        }
        
        // Skip self
        if (player.id == localPlayer.id) {
            continue;
        }
        
        // Check team
        bool isTeammate = (player.teamId == localPlayer.teamId);
        if (isTeammate && !m_showTeammates) {
            continue;
        }
        if (!isTeammate && !m_showEnemies) {
            continue;
        }
        
        // Check distance
        float distance = calculateDistance(localPlayer.position, player.position);
        if (distance > m_maxDistance) {
            continue;
        }
        
        // World to screen conversion
        QVector2D screenPos;
        if (!worldToScreen(player.position, screenPos)) {
            continue;
        }
        
        // Create render data
        ESPRenderData renderData;
        renderData.entityId = player.id;
        renderData.entityType = EntityType::Player;
        renderData.screenPosition = screenPos;
        renderData.worldPosition = player.position;
        renderData.distance = distance;
        renderData.isTeammate = isTeammate;
        renderData.health = player.health;
        renderData.maxHealth = player.maxHealth;
        renderData.name = player.name;
        renderData.weapon = player.currentWeapon;
        renderData.color = isTeammate ? m_teammateColor : m_playerColor;
        
        // Calculate bounding box
        if (m_showBoxes) {
            calculateBoundingBox(player, renderData);
        }
        
        // Calculate bone positions
        if (m_showBones) {
            calculateBonePositions(player, renderData);
        }
        
        m_renderData.append(renderData);
    }
}

void ESP::processItems(const PlayerInfo& localPlayer)
{
    auto items = m_entityManager->getEntitiesByType(EntityType::Item);
    
    for (const auto& item : items) {
        if (!item.isValid) {
            continue;
        }
        
        // Check distance
        float distance = calculateDistance(localPlayer.position, item.position);
        if (distance > m_maxDistance) {
            continue;
        }
        
        // World to screen conversion
        QVector2D screenPos;
        if (!worldToScreen(item.position, screenPos)) {
            continue;
        }
        
        // Create render data
        ESPRenderData renderData;
        renderData.entityId = item.id;
        renderData.entityType = EntityType::Item;
        renderData.screenPosition = screenPos;
        renderData.worldPosition = item.position;
        renderData.distance = distance;
        renderData.name = item.name;
        renderData.color = m_itemColor;
        
        m_renderData.append(renderData);
    }
}

void ESP::processVehicles(const PlayerInfo& localPlayer)
{
    auto vehicles = m_entityManager->getEntitiesByType(EntityType::Vehicle);
    
    for (const auto& vehicle : vehicles) {
        if (!vehicle.isValid) {
            continue;
        }
        
        // Check distance
        float distance = calculateDistance(localPlayer.position, vehicle.position);
        if (distance > m_maxDistance) {
            continue;
        }
        
        // World to screen conversion
        QVector2D screenPos;
        if (!worldToScreen(vehicle.position, screenPos)) {
            continue;
        }
        
        // Create render data
        ESPRenderData renderData;
        renderData.entityId = vehicle.id;
        renderData.entityType = EntityType::Vehicle;
        renderData.screenPosition = screenPos;
        renderData.worldPosition = vehicle.position;
        renderData.distance = distance;
        renderData.name = vehicle.name;
        renderData.health = vehicle.health;
        renderData.maxHealth = vehicle.maxHealth;
        renderData.color = m_vehicleColor;
        
        m_renderData.append(renderData);
    }
}

float ESP::calculateDistance(const QVector3D& pos1, const QVector3D& pos2)
{
    return pos1.distanceToPoint(pos2);
}

bool ESP::worldToScreen(const QVector3D& worldPos, QVector2D& screenPos)
{
    // Transform world position to screen coordinates
    QVector4D clipCoords = m_projectionMatrix * m_viewMatrix * QVector4D(worldPos, 1.0f);
    
    if (clipCoords.w() <= 0.0f) {
        return false; // Behind camera
    }
    
    // Perspective divide
    QVector3D ndc = clipCoords.toVector3D() / clipCoords.w();
    
    // Convert to screen coordinates
    screenPos.setX((ndc.x() + 1.0f) * 0.5f * m_screenWidth);
    screenPos.setY((1.0f - ndc.y()) * 0.5f * m_screenHeight);
    
    return (screenPos.x() >= 0 && screenPos.x() <= m_screenWidth &&
            screenPos.y() >= 0 && screenPos.y() <= m_screenHeight);
}

void ESP::calculateBoundingBox(const Entity& entity, ESPRenderData& renderData)
{
    // Calculate 2D or 3D bounding box based on box type
    if (m_boxType == BoxType::TwoD) {
        // Simple 2D box around screen position
        float boxWidth = 60.0f / (renderData.distance * 0.01f + 1.0f);
        float boxHeight = 80.0f / (renderData.distance * 0.01f + 1.0f);
        
        renderData.boundingBox = QRectF(
            renderData.screenPosition.x() - boxWidth / 2,
            renderData.screenPosition.y() - boxHeight / 2,
            boxWidth,
            boxHeight
        );
    } else {
        // 3D box calculation (placeholder)
        renderData.boundingBox = QRectF(
            renderData.screenPosition.x() - 30,
            renderData.screenPosition.y() - 40,
            60,
            80
        );
    }
}

void ESP::calculateBonePositions(const Entity& entity, ESPRenderData& renderData)
{
    // Placeholder bone positions
    QVector<QVector3D> bonePositions = {
        entity.position + QVector3D(0, 0, 1.8f), // Head
        entity.position + QVector3D(0, 0, 1.6f), // Neck
        entity.position + QVector3D(0, 0, 1.4f), // Chest
        entity.position + QVector3D(0, 0, 1.0f), // Stomach
        entity.position + QVector3D(0, 0, 0.8f), // Pelvis
        entity.position + QVector3D(-0.3f, 0, 1.4f), // Left shoulder
        entity.position + QVector3D(0.3f, 0, 1.4f),  // Right shoulder
        entity.position + QVector3D(-0.3f, 0, 0.8f), // Left hand
        entity.position + QVector3D(0.3f, 0, 0.8f),  // Right hand
        entity.position + QVector3D(-0.2f, 0, 0.0f), // Left foot
        entity.position + QVector3D(0.2f, 0, 0.0f)   // Right foot
    };
    
    // Convert to screen coordinates
    for (const auto& bonePos : bonePositions) {
        QVector2D screenPos;
        if (worldToScreen(bonePos, screenPos)) {
            renderData.bonePositions.append(screenPos);
        }
    }
}

void ESP::render(QPainter& painter)
{
    if (!m_enabled || m_renderData.isEmpty()) {
        return;
    }
    
    QMutexLocker locker(&m_mutex);
    
    // Set up painter
    painter.setRenderHint(QPainter::Antialiasing, true);
    QFont font = painter.font();
    font.setPointSize(m_fontSize);
    painter.setFont(font);
    
    // Render each entity
    for (const auto& data : m_renderData) {
        renderEntity(painter, data);
    }
}

void ESP::renderEntity(QPainter& painter, const ESPRenderData& data)
{
    painter.setPen(QPen(data.color, m_lineWidth));
    painter.setBrush(Qt::NoBrush);
    
    // Draw bounding box
    if (m_showBoxes && !data.boundingBox.isEmpty()) {
        painter.drawRect(data.boundingBox);
    }
    
    // Draw lines
    if (m_showLines) {
        QPointF lineStart;
        switch (m_lineType) {
            case LineType::Top:
                lineStart = QPointF(m_screenWidth / 2, 0);
                break;
            case LineType::Center:
                lineStart = QPointF(m_screenWidth / 2, m_screenHeight / 2);
                break;
            case LineType::Bottom:
                lineStart = QPointF(m_screenWidth / 2, m_screenHeight);
                break;
        }
        painter.drawLine(lineStart, data.screenPosition.toPointF());
    }
    
    // Draw bones
    if (m_showBones && !data.bonePositions.isEmpty()) {
        renderBones(painter, data);
    }
    
    // Draw text information
    renderText(painter, data);
}

void ESP::renderBones(QPainter& painter, const ESPRenderData& data)
{
    if (data.bonePositions.size() < 11) {
        return;
    }
    
    painter.setPen(QPen(data.color, 1));
    
    // Draw bone connections
    QVector<QPair<int, int>> connections = {
        {0, 1}, // Head to neck
        {1, 2}, // Neck to chest
        {2, 3}, // Chest to stomach
        {3, 4}, // Stomach to pelvis
        {2, 5}, // Chest to left shoulder
        {2, 6}, // Chest to right shoulder
        {5, 7}, // Left shoulder to left hand
        {6, 8}, // Right shoulder to right hand
        {4, 9}, // Pelvis to left foot
        {4, 10} // Pelvis to right foot
    };
    
    for (const auto& connection : connections) {
        if (connection.first < data.bonePositions.size() &&
            connection.second < data.bonePositions.size()) {
            painter.drawLine(
                data.bonePositions[connection.first].toPointF(),
                data.bonePositions[connection.second].toPointF()
            );
        }
    }
}

void ESP::renderText(QPainter& painter, const ESPRenderData& data)
{
    QStringList textLines;
    
    // Add name
    if (m_showName && !data.name.isEmpty()) {
        textLines.append(data.name);
    }
    
    // Add distance
    if (m_showDistance) {
        textLines.append(QString("%1m").arg(qRound(data.distance)));
    }
    
    // Add health
    if (m_showHealth && data.entityType == EntityType::Player) {
        textLines.append(QString("HP: %1/%2").arg(data.health).arg(data.maxHealth));
    }
    
    // Add weapon
    if (m_showWeapon && !data.weapon.isEmpty()) {
        textLines.append(data.weapon);
    }
    
    // Render text
    if (!textLines.isEmpty()) {
        painter.setPen(QPen(data.color));
        QFontMetrics metrics(painter.font());
        
        QPointF textPos = data.screenPosition.toPointF();
        textPos.setY(textPos.y() - 10); // Offset above entity
        
        for (const QString& line : textLines) {
            QRect textRect = metrics.boundingRect(line);
            textPos.setX(data.screenPosition.x() - textRect.width() / 2);
            
            // Draw text background
            painter.fillRect(QRectF(textPos, textRect.size()), QColor(0, 0, 0, 128));
            
            // Draw text
            painter.drawText(textPos, line);
            
            textPos.setY(textPos.y() - textRect.height() - 2);
        }
    }
}

ESPStats ESP::getStats() const
{
    QMutexLocker locker(&m_mutex);
    
    ESPStats stats;
    stats.enabled = m_enabled;
    stats.entitiesRendered = m_renderData.size();
    stats.playersVisible = 0;
    stats.itemsVisible = 0;
    stats.vehiclesVisible = 0;
    
    for (const auto& data : m_renderData) {
        switch (data.entityType) {
            case EntityType::Player:
                stats.playersVisible++;
                break;
            case EntityType::Item:
                stats.itemsVisible++;
                break;
            case EntityType::Vehicle:
                stats.vehiclesVisible++;
                break;
            default:
                break;
        }
    }
    
    stats.maxDistance = m_maxDistance;
    stats.boxType = static_cast<int>(m_boxType);
    stats.lineType = static_cast<int>(m_lineType);
    
    return stats;
}

void ESP::saveSettings(QSettings& settings)
{
    QMutexLocker locker(&m_mutex);
    
    settings.beginGroup("ESP");
    settings.setValue("enabled", m_enabled);
    settings.setValue("showPlayers", m_showPlayers);
    settings.setValue("showEnemies", m_showEnemies);
    settings.setValue("showTeammates", m_showTeammates);
    settings.setValue("showItems", m_showItems);
    settings.setValue("showVehicles", m_showVehicles);
    settings.setValue("showDistance", m_showDistance);
    settings.setValue("showHealth", m_showHealth);
    settings.setValue("showName", m_showName);
    settings.setValue("showWeapon", m_showWeapon);
    settings.setValue("showBones", m_showBones);
    settings.setValue("showBoxes", m_showBoxes);
    settings.setValue("showLines", m_showLines);
    settings.setValue("maxDistance", m_maxDistance);
    settings.setValue("boxType", static_cast<int>(m_boxType));
    settings.setValue("lineType", static_cast<int>(m_lineType));
    settings.setValue("playerColor", m_playerColor.name());
    settings.setValue("teammateColor", m_teammateColor.name());
    settings.setValue("itemColor", m_itemColor.name());
    settings.setValue("vehicleColor", m_vehicleColor.name());
    settings.setValue("fontSize", m_fontSize);
    settings.setValue("lineWidth", m_lineWidth);
    settings.endGroup();
}

void ESP::loadSettings(QSettings& settings)
{
    QMutexLocker locker(&m_mutex);
    
    settings.beginGroup("ESP");
    m_enabled = settings.value("enabled", false).toBool();
    m_showPlayers = settings.value("showPlayers", true).toBool();
    m_showEnemies = settings.value("showEnemies", true).toBool();
    m_showTeammates = settings.value("showTeammates", false).toBool();
    m_showItems = settings.value("showItems", true).toBool();
    m_showVehicles = settings.value("showVehicles", true).toBool();
    m_showDistance = settings.value("showDistance", true).toBool();
    m_showHealth = settings.value("showHealth", true).toBool();
    m_showName = settings.value("showName", true).toBool();
    m_showWeapon = settings.value("showWeapon", true).toBool();
    m_showBones = settings.value("showBones", false).toBool();
    m_showBoxes = settings.value("showBoxes", true).toBool();
    m_showLines = settings.value("showLines", false).toBool();
    m_maxDistance = settings.value("maxDistance", 500.0f).toFloat();
    m_boxType = static_cast<BoxType>(settings.value("boxType", 0).toInt());
    m_lineType = static_cast<LineType>(settings.value("lineType", 2).toInt());
    m_playerColor = QColor(settings.value("playerColor", "#ff0000").toString());
    m_teammateColor = QColor(settings.value("teammateColor", "#00ff00").toString());
    m_itemColor = QColor(settings.value("itemColor", "#ffff00").toString());
    m_vehicleColor = QColor(settings.value("vehicleColor", "#0000ff").toString());
    m_fontSize = settings.value("fontSize", 12).toInt();
    m_lineWidth = settings.value("lineWidth", 2).toInt();
    settings.endGroup();
    
    emit settingsChanged();
}