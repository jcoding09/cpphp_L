#ifndef ESP_H
#define ESP_H

#include <QtCore/QObject>
#include <QtCore/QTimer>
#include <QtCore/QSettings>
#include <QtCore/QDateTime>
#include <QtCore/QMutex>
#include <QtCore/QThread>
#include <QtGui/QVector3D>
#include <QtGui/QVector2D>
#include <QtGui/QColor>
#include <QtGui/QFont>
#include <QtGui/QPainter>
#include <QtGui/QPixmap>
#include <QtWidgets/QWidget>
#include <memory>

// Forward declarations
class GameInterface;
class MemoryManager;
class Logger;

enum class ESPMode {
    Disabled = 0,
    Basic = 1,
    Advanced = 2,
    Full = 3,
    Minimal = 4
};

enum class ESPBoxType {
    None = 0,
    Box2D = 1,
    Box3D = 2,
    Corner = 3,
    Filled = 4,
    Rounded = 5
};

enum class ESPLineType {
    None = 0,
    Top = 1,
    Center = 2,
    Bottom = 3,
    Crosshair = 4
};

enum class ESPTextPosition {
    None = 0,
    Top = 1,
    Bottom = 2,
    Left = 3,
    Right = 4,
    Center = 5
};

enum class ESPHealthBarType {
    None = 0,
    Horizontal = 1,
    Vertical = 2,
    Circular = 3,
    Gradient = 4
};

enum class ESPDistanceUnit {
    Meters = 0,
    Feet = 1,
    Units = 2
};

struct ESPSettings {
    // Basic settings
    bool enabled = false;
    ESPMode mode = ESPMode::Basic;
    float maxDistance = 500.0f;
    float minDistance = 10.0f;
    bool showOnlyVisible = false;
    bool showThroughWalls = true;
    
    // Player ESP
    bool showPlayers = true;
    bool showEnemies = true;
    bool showTeammates = false;
    bool showKnocked = true;
    bool showBots = true;
    bool showSpectators = false;
    
    // Box settings
    ESPBoxType boxType = ESPBoxType::Box2D;
    QColor enemyBoxColor = QColor(255, 0, 0, 180);
    QColor teammateBoxColor = QColor(0, 255, 0, 180);
    QColor knockedBoxColor = QColor(255, 255, 0, 180);
    QColor botBoxColor = QColor(255, 165, 0, 180);
    float boxThickness = 2.0f;
    bool boxFilled = false;
    float boxFillOpacity = 0.3f;
    
    // Line settings
    ESPLineType lineType = ESPLineType::Bottom;
    QColor lineColor = QColor(255, 255, 255, 200);
    float lineThickness = 1.5f;
    bool dynamicLineColor = true;
    
    // Text settings
    bool showNames = true;
    bool showDistance = true;
    bool showHealth = true;
    bool showArmor = false;
    bool showWeapon = true;
    bool showKills = false;
    bool showTeamId = false;
    ESPTextPosition textPosition = ESPTextPosition::Top;
    QFont textFont = QFont("Arial", 10);
    QColor textColor = QColor(255, 255, 255, 255);
    QColor textOutlineColor = QColor(0, 0, 0, 255);
    bool textOutline = true;
    float textOutlineThickness = 1.0f;
    ESPDistanceUnit distanceUnit = ESPDistanceUnit::Meters;
    
    // Health bar settings
    ESPHealthBarType healthBarType = ESPHealthBarType::Vertical;
    QColor healthBarColorHigh = QColor(0, 255, 0, 255);
    QColor healthBarColorMid = QColor(255, 255, 0, 255);
    QColor healthBarColorLow = QColor(255, 0, 0, 255);
    QColor healthBarBackground = QColor(0, 0, 0, 128);
    float healthBarWidth = 4.0f;
    float healthBarHeight = 50.0f;
    bool healthBarBorder = true;
    bool showArmorBar = false;
    QColor armorBarColor = QColor(0, 0, 255, 255);
    
    // Skeleton settings
    bool showSkeleton = false;
    QColor skeletonColor = QColor(255, 255, 255, 200);
    float skeletonThickness = 1.5f;
    bool skeletonJoints = true;
    float jointSize = 3.0f;
    
    // Head dot settings
    bool showHeadDot = true;
    QColor headDotColor = QColor(255, 0, 0, 255);
    float headDotSize = 4.0f;
    bool headDotFilled = true;
    
    // Glow settings
    bool enableGlow = false;
    QColor glowColor = QColor(255, 255, 255, 100);
    float glowRadius = 10.0f;
    float glowIntensity = 0.5f;
    
    // Item ESP
    bool showItems = false;
    bool showWeapons = true;
    bool showArmor = true;
    bool showMedical = true;
    bool showAmmo = false;
    bool showAttachments = false;
    bool showVehicles = true;
    bool showAirdrops = true;
    bool showGrenades = false;
    float itemMaxDistance = 200.0f;
    QColor weaponColor = QColor(255, 255, 0, 255);
    QColor armorColor = QColor(0, 255, 255, 255);
    QColor medicalColor = QColor(0, 255, 0, 255);
    QColor ammoColor = QColor(255, 165, 0, 255);
    QColor vehicleColor = QColor(255, 0, 255, 255);
    QColor airdropColor = QColor(255, 255, 255, 255);
    
    // Radar settings
    bool showRadar = false;
    QVector2D radarPosition = QVector2D(50, 50);
    float radarSize = 150.0f;
    float radarRange = 200.0f;
    QColor radarBackground = QColor(0, 0, 0, 128);
    QColor radarBorder = QColor(255, 255, 255, 255);
    bool radarRotate = true;
    float radarOpacity = 0.8f;
    
    // Warning settings
    bool showWarnings = true;
    bool warnLowHealth = true;
    float lowHealthThreshold = 30.0f;
    bool warnEnemyNear = true;
    float enemyNearDistance = 50.0f;
    bool warnBeingAimed = false;
    QColor warningColor = QColor(255, 0, 0, 255);
    
    // Performance settings
    int updateRate = 60; // FPS
    bool useThreading = true;
    bool optimizeForDistance = true;
    bool cullOffScreen = true;
    int maxVisibleEntities = 100;
    
    // Advanced settings
    bool predictMovement = false;
    float predictionTime = 0.1f;
    bool showVelocity = false;
    bool showViewAngles = false;
    bool showBoneConnections = false;
    bool showHitboxes = false;
    bool showAimPrediction = false;
    
    // Customization
    bool customColors = false;
    QMap<QString, QColor> weaponColors;
    QMap<QString, QColor> playerColors;
    bool fadeWithDistance = true;
    float fadeStartDistance = 300.0f;
    float fadeEndDistance = 500.0f;
};

struct ESPEntity {
    quint32 entityId = 0;
    QString name;
    QString type; // "player", "item", "vehicle", etc.
    QVector3D position;
    QVector3D velocity;
    QVector2D screenPosition;
    QVector2D headScreenPosition;
    float distance = 0.0f;
    float health = 100.0f;
    float maxHealth = 100.0f;
    float armor = 0.0f;
    float maxArmor = 100.0f;
    bool isVisible = false;
    bool isEnemy = false;
    bool isTeammate = false;
    bool isKnocked = false;
    bool isBot = false;
    bool isSpectator = false;
    QString weaponName;
    int teamId = 0;
    int kills = 0;
    QDateTime lastSeen;
    QVector3D predictedPosition;
    QVector2D viewAngles;
    QList<QVector3D> bonePositions;
    QList<QVector2D> screenBonePositions;
    QColor customColor;
    bool isOnScreen = false;
    float screenDistance = 0.0f;
    QRectF boundingBox;
};

struct ESPDrawData {
    QList<ESPEntity> entities;
    QVector2D screenCenter;
    QVector2D screenSize;
    QMatrix4x4 viewMatrix;
    QMatrix4x4 projectionMatrix;
    QVector3D cameraPosition;
    QVector2D cameraAngles;
    float fov = 90.0f;
    QDateTime timestamp;
};

struct RadarData {
    QVector2D position;
    float size;
    float range;
    QVector3D playerPosition;
    QVector2D playerAngles;
    QList<ESPEntity> entities;
    bool rotate;
    float opacity;
};

class ESP : public QObject
{
    Q_OBJECT

public:
    explicit ESP(QObject *parent = nullptr);
    ~ESP();
    
    // Component integration
    void setGameInterface(GameInterface *gameInterface);
    void setMemoryManager(MemoryManager *memoryManager);
    void setLogger(Logger *logger);
    
    // Settings management
    void setSettings(const ESPSettings &settings);
    ESPSettings getSettings() const;
    void loadSettings();
    void saveSettings();
    void resetSettings();
    
    // Control methods
    void enable();
    void disable();
    void toggle();
    bool isEnabled() const;
    
    // Rendering methods
    void render(QPainter *painter, const QSize &screenSize);
    void renderOverlay(QWidget *overlay);
    QPixmap generateOverlay(const QSize &size);
    
    // Entity management
    void updateEntities();
    void addEntity(const ESPEntity &entity);
    void removeEntity(quint32 entityId);
    void clearEntities();
    QList<ESPEntity> getVisibleEntities() const;
    
    // Drawing functions
    void drawPlayerESP(QPainter *painter, const ESPEntity &entity);
    void drawItemESP(QPainter *painter, const ESPEntity &entity);
    void drawVehicleESP(QPainter *painter, const ESPEntity &entity);
    void drawRadar(QPainter *painter, const RadarData &radarData);
    
    // Utility methods
    QVector2D worldToScreen(const QVector3D &worldPos);
    bool isOnScreen(const QVector2D &screenPos, const QSize &screenSize);
    float calculateDistance(const QVector3D &pos1, const QVector3D &pos2);
    QColor getEntityColor(const ESPEntity &entity);
    
public slots:
    // Main update slots
    void update();
    void onGameUpdate();
    void onPlayerUpdate();
    void onEntityUpdate();
    
    // Settings slots
    void onSettingsChanged(const ESPSettings &settings);
    void onModeChanged(int mode);
    void onMaxDistanceChanged(float distance);
    void onBoxTypeChanged(int type);
    void onLineTypeChanged(int type);
    void onTextPositionChanged(int position);
    void onHealthBarTypeChanged(int type);
    
    // Color slots
    void onEnemyColorChanged(const QColor &color);
    void onTeammateColorChanged(const QColor &color);
    void onKnockedColorChanged(const QColor &color);
    void onBotColorChanged(const QColor &color);
    void onTextColorChanged(const QColor &color);
    
    // Feature toggle slots
    void onShowPlayersToggled(bool enabled);
    void onShowEnemiesToggled(bool enabled);
    void onShowTeammatesToggled(bool enabled);
    void onShowKnockedToggled(bool enabled);
    void onShowBotsToggled(bool enabled);
    void onShowNamesToggled(bool enabled);
    void onShowDistanceToggled(bool enabled);
    void onShowHealthToggled(bool enabled);
    void onShowWeaponToggled(bool enabled);
    void onShowSkeletonToggled(bool enabled);
    void onShowHeadDotToggled(bool enabled);
    void onShowItemsToggled(bool enabled);
    void onShowRadarToggled(bool enabled);
    void onShowWarningsToggled(bool enabled);
    
    // Advanced feature slots
    void onGlowToggled(bool enabled);
    void onPredictionToggled(bool enabled);
    void onFadeWithDistanceToggled(bool enabled);
    
signals:
    void enabledChanged(bool enabled);
    void settingsChanged(const ESPSettings &settings);
    void entityAdded(const ESPEntity &entity);
    void entityRemoved(quint32 entityId);
    void entityUpdated(const ESPEntity &entity);
    void renderRequested();
    void warningTriggered(const QString &warning, const ESPEntity &entity);
    void errorOccurred(const QString &error);
    
private slots:
    void updateTimer();
    void renderTimer();
    void entityScanTimer();
    void performanceTimer();
    
private:
    // Core rendering functions
    void renderEntities(QPainter *painter);
    void renderWarnings(QPainter *painter);
    void renderCrosshair(QPainter *painter);
    void renderDebugInfo(QPainter *painter);
    
    // Entity drawing functions
    void drawBox(QPainter *painter, const ESPEntity &entity);
    void drawLine(QPainter *painter, const ESPEntity &entity);
    void drawText(QPainter *painter, const ESPEntity &entity);
    void drawHealthBar(QPainter *painter, const ESPEntity &entity);
    void drawSkeleton(QPainter *painter, const ESPEntity &entity);
    void drawHeadDot(QPainter *painter, const ESPEntity &entity);
    void drawGlow(QPainter *painter, const ESPEntity &entity);
    void drawPrediction(QPainter *painter, const ESPEntity &entity);
    
    // Box drawing variants
    void draw2DBox(QPainter *painter, const QRectF &box, const QColor &color, float thickness, bool filled);
    void draw3DBox(QPainter *painter, const ESPEntity &entity, const QColor &color, float thickness);
    void drawCornerBox(QPainter *painter, const QRectF &box, const QColor &color, float thickness);
    void drawRoundedBox(QPainter *painter, const QRectF &box, const QColor &color, float thickness, bool filled);
    
    // Health bar variants
    void drawHorizontalHealthBar(QPainter *painter, const ESPEntity &entity, const QRectF &area);
    void drawVerticalHealthBar(QPainter *painter, const ESPEntity &entity, const QRectF &area);
    void drawCircularHealthBar(QPainter *painter, const ESPEntity &entity, const QPointF &center, float radius);
    void drawGradientHealthBar(QPainter *painter, const ESPEntity &entity, const QRectF &area);
    
    // Text rendering
    void drawOutlinedText(QPainter *painter, const QString &text, const QPointF &position, const QFont &font, const QColor &textColor, const QColor &outlineColor, float outlineThickness);
    QString formatEntityText(const ESPEntity &entity);
    QString formatDistance(float distance, ESPDistanceUnit unit);
    QString formatHealth(float health, float maxHealth);
    
    // Radar functions
    void updateRadarData();
    void drawRadarBackground(QPainter *painter, const RadarData &radar);
    void drawRadarEntities(QPainter *painter, const RadarData &radar);
    void drawRadarPlayer(QPainter *painter, const RadarData &radar);
    QVector2D worldToRadar(const QVector3D &worldPos, const RadarData &radar);
    
    // Entity management
    ESPEntity scanEntity(quint32 entityId);
    void updateEntityData(ESPEntity &entity);
    void updateEntityScreenPosition(ESPEntity &entity);
    void updateEntityBones(ESPEntity &entity);
    void updateEntityPrediction(ESPEntity &entity);
    void updateEntityVisibility(ESPEntity &entity);
    
    QList<ESPEntity> scanForPlayers();
    QList<ESPEntity> scanForItems();
    QList<ESPEntity> scanForVehicles();
    
    bool isValidEntity(const ESPEntity &entity);
    bool shouldShowEntity(const ESPEntity &entity);
    bool isEntityInRange(const ESPEntity &entity);
    
    // Calculation functions
    QRectF calculateBoundingBox(const ESPEntity &entity);
    QVector3D calculatePredictedPosition(const ESPEntity &entity);
    float calculateScreenDistance(const ESPEntity &entity);
    float calculateFadeAlpha(const ESPEntity &entity);
    
    // Color management
    QColor getBoxColor(const ESPEntity &entity);
    QColor getTextColor(const ESPEntity &entity);
    QColor getHealthBarColor(float healthPercent);
    QColor applyDistanceFade(const QColor &color, const ESPEntity &entity);
    QColor blendColors(const QColor &color1, const QColor &color2, float factor);
    
    // Performance optimization
    void optimizeEntityList();
    void cullOffScreenEntities();
    void sortEntitiesByDistance();
    void limitVisibleEntities();
    
    // Memory operations
    bool readEntityList(QList<quint32> &entityIds);
    bool readEntityPosition(quint32 entityId, QVector3D &position);
    bool readEntityHealth(quint32 entityId, float &health, float &maxHealth);
    bool readEntityTeam(quint32 entityId, int &teamId);
    bool readEntityName(quint32 entityId, QString &name);
    bool readEntityWeapon(quint32 entityId, QString &weaponName);
    bool readEntityBones(quint32 entityId, QList<QVector3D> &bones);
    bool readEntityVelocity(quint32 entityId, QVector3D &velocity);
    bool readEntityViewAngles(quint32 entityId, QVector2D &angles);
    
    bool readPlayerPosition(QVector3D &position);
    bool readPlayerAngles(QVector2D &angles);
    bool readViewMatrix(QMatrix4x4 &matrix);
    bool readProjectionMatrix(QMatrix4x4 &matrix);
    bool readCameraFOV(float &fov);
    
    // Validation and safety
    bool validateEntity(const ESPEntity &entity);
    bool validateScreenPosition(const QVector2D &screenPos);
    bool isRenderingSafe();
    
    void performSafetyChecks();
    void handleRenderingError(const QString &error);
    
    // Warning system
    void checkWarnings();
    void checkLowHealth();
    void checkEnemyNear();
    void checkBeingAimed();
    void triggerWarning(const QString &warning, const ESPEntity &entity);
    
    // Statistics and logging
    void updatePerformanceMetrics();
    void logRenderingStats();
    void logEntityStats();
    
    // Utility functions
    QString formatEntityInfo(const ESPEntity &entity) const;
    QString formatRenderStats() const;
    QString formatSettings() const;
    
    // Core components
    GameInterface *m_gameInterface;
    MemoryManager *m_memoryManager;
    Logger *m_logger;
    
    // Settings and configuration
    ESPSettings m_settings;
    QSettings *m_qsettings;
    
    // Entity management
    QList<ESPEntity> m_entities;
    QList<ESPEntity> m_visibleEntities;
    QMutex m_entityMutex;
    
    // Rendering data
    ESPDrawData m_drawData;
    RadarData m_radarData;
    QSize m_screenSize;
    QVector2D m_screenCenter;
    
    // Performance tracking
    int m_frameCount;
    QDateTime m_lastFrameTime;
    float m_averageFPS;
    int m_entityCount;
    int m_visibleEntityCount;
    qint64 m_renderTime;
    
    // State variables
    bool m_enabled;
    bool m_rendering;
    QDateTime m_lastUpdateTime;
    QDateTime m_lastRenderTime;
    
    // Timers
    QTimer *m_updateTimer;
    QTimer *m_renderTimer;
    QTimer *m_entityScanTimer;
    QTimer *m_performanceTimer;
    
    // Threading
    QThread *m_renderThread;
    QMutex m_renderMutex;
    
    // Warning system
    QDateTime m_lastWarningTime;
    QMap<QString, QDateTime> m_warningCooldowns;
    
    // Constants
    static const float DEFAULT_MAX_DISTANCE;
    static const float DEFAULT_MIN_DISTANCE;
    static const float DEFAULT_BOX_THICKNESS;
    static const float DEFAULT_LINE_THICKNESS;
    static const float DEFAULT_HEALTH_BAR_WIDTH;
    static const float DEFAULT_HEALTH_BAR_HEIGHT;
    static const float DEFAULT_HEAD_DOT_SIZE;
    static const float DEFAULT_RADAR_SIZE;
    static const float DEFAULT_RADAR_RANGE;
    
    static const int UPDATE_INTERVAL = 16; // ~60 FPS
    static const int RENDER_INTERVAL = 16; // ~60 FPS
    static const int ENTITY_SCAN_INTERVAL = 100; // 10 FPS
    static const int PERFORMANCE_INTERVAL = 1000; // 1 second
    
    static const int MAX_ENTITIES = 1000;
    static const int MAX_VISIBLE_ENTITIES = 100;
    static const float MAX_RENDER_DISTANCE;
    static const float WARNING_COOLDOWN_TIME;
};

#endif // ESP_H