#ifndef WALLHACK_H
#define WALLHACK_H

#include <QtCore/QObject>
#include <QtCore/QTimer>
#include <QtCore/QSettings>
#include <QtCore/QDateTime>
#include <QtCore/QMutex>
#include <QtCore/QThread>
#include <QtGui/QVector3D>
#include <QtGui/QVector2D>
#include <QtGui/QColor>
#include <QtCore/QMap>
#include <memory>

// Forward declarations
class GameInterface;
class MemoryManager;
class Logger;

enum class WallhackMode {
    Disabled = 0,
    Basic = 1,
    Advanced = 2,
    Chams = 3,
    Wireframe = 4,
    Glow = 5,
    XRay = 6
};

enum class WallhackType {
    None = 0,
    PlayerWalls = 1,
    ItemWalls = 2,
    VehicleWalls = 3,
    AllWalls = 4,
    TerrainOnly = 5,
    BuildingsOnly = 6
};

enum class ChamType {
    None = 0,
    Flat = 1,
    Textured = 2,
    Wireframe = 3,
    Glass = 4,
    Metallic = 5,
    Glow = 6,
    Pulse = 7
};

enum class GlowType {
    None = 0,
    Outline = 1,
    Full = 2,
    Rim = 3,
    Pulse = 4,
    Rainbow = 5
};

enum class VisibilityMode {
    Always = 0,
    WhenHidden = 1,
    WhenVisible = 2,
    Distance = 3,
    Health = 4,
    Threat = 5
};

struct WallhackSettings {
    // Basic settings
    bool enabled = false;
    WallhackMode mode = WallhackMode::Basic;
    WallhackType wallType = WallhackType::PlayerWalls;
    float maxDistance = 500.0f;
    float minDistance = 10.0f;
    bool affectEnemies = true;
    bool affectTeammates = false;
    bool affectItems = false;
    bool affectVehicles = false;
    
    // Player wallhack
    bool enablePlayerWallhack = true;
    bool showEnemiesThroughWalls = true;
    bool showTeammatesThroughWalls = false;
    bool showKnockedThroughWalls = true;
    bool showBotsThroughWalls = true;
    bool showSpectatorsThroughWalls = false;
    
    // Chams settings
    ChamType chamType = ChamType::Flat;
    QColor enemyChamColor = QColor(255, 0, 0, 180);
    QColor teammateChamColor = QColor(0, 255, 0, 180);
    QColor knockedChamColor = QColor(255, 255, 0, 180);
    QColor botChamColor = QColor(255, 165, 0, 180);
    QColor visibleChamColor = QColor(0, 255, 255, 180);
    QColor hiddenChamColor = QColor(255, 0, 255, 180);
    float chamOpacity = 0.7f;
    bool chamTwoTone = true;
    bool chamIgnoreZ = true;
    bool chamWireframe = false;
    float chamWireframeThickness = 1.0f;
    
    // Glow settings
    GlowType glowType = GlowType::Outline;
    QColor enemyGlowColor = QColor(255, 0, 0, 255);
    QColor teammateGlowColor = QColor(0, 255, 0, 255);
    QColor knockedGlowColor = QColor(255, 255, 0, 255);
    QColor botGlowColor = QColor(255, 165, 0, 255);
    float glowIntensity = 1.0f;
    float glowRadius = 5.0f;
    bool glowPulse = false;
    float glowPulseSpeed = 2.0f;
    bool glowRainbow = false;
    float glowRainbowSpeed = 1.0f;
    
    // Visibility settings
    VisibilityMode visibilityMode = VisibilityMode::Always;
    bool enhanceVisibility = true;
    float visibilityBoost = 2.0f;
    bool removeSmoke = false;
    bool removeFog = false;
    bool removeFlash = false;
    bool removeGrass = false;
    bool removeTrees = false;
    bool removeBuildings = false;
    
    // Wall removal
    bool removeWalls = false;
    bool removePlayerWalls = false;
    bool removeItemWalls = false;
    bool removeVehicleWalls = false;
    bool removeTerrainWalls = false;
    bool removeBuildingWalls = false;
    float wallRemovalDistance = 100.0f;
    
    // Item wallhack
    bool enableItemWallhack = false;
    bool showWeaponsThroughWalls = true;
    bool showArmorThroughWalls = true;
    bool showMedicalThroughWalls = true;
    bool showAmmoThroughWalls = false;
    bool showAttachmentsThroughWalls = false;
    bool showVehiclesThroughWalls = true;
    bool showAirdropsThroughWalls = true;
    float itemWallhackDistance = 200.0f;
    QColor weaponWallColor = QColor(255, 255, 0, 200);
    QColor armorWallColor = QColor(0, 255, 255, 200);
    QColor medicalWallColor = QColor(0, 255, 0, 200);
    QColor vehicleWallColor = QColor(255, 0, 255, 200);
    QColor airdropWallColor = QColor(255, 255, 255, 200);
    
    // Advanced features
    bool xrayVision = false;
    float xrayIntensity = 0.5f;
    bool thermalVision = false;
    QColor thermalColdColor = QColor(0, 0, 255, 255);
    QColor thermalHotColor = QColor(255, 0, 0, 255);
    bool nightVision = false;
    float nightVisionBrightness = 2.0f;
    QColor nightVisionTint = QColor(0, 255, 0, 100);
    
    // Shader modifications
    bool modifyShaders = false;
    bool disableDepthTest = false;
    bool disableAlphaTest = false;
    bool disableCulling = false;
    bool wireframeMode = false;
    float wireframeThickness = 1.0f;
    QColor wireframeColor = QColor(255, 255, 255, 255);
    
    // Performance settings
    int updateRate = 60; // FPS
    bool useThreading = true;
    bool optimizeForDistance = true;
    bool cullOffScreen = true;
    int maxProcessedEntities = 100;
    bool adaptiveQuality = true;
    
    // Safety settings
    bool safeMode = true;
    bool hideFromScreenshots = true;
    bool hideFromRecording = true;
    bool disableOnAltTab = false;
    bool emergencyDisable = false;
    int emergencyKey = 0x23; // End key
    
    // Customization
    bool customMaterials = false;
    QMap<QString, QColor> customPlayerColors;
    QMap<QString, QColor> customItemColors;
    bool animatedEffects = true;
    float animationSpeed = 1.0f;
    bool distanceFading = true;
    float fadeStartDistance = 300.0f;
    float fadeEndDistance = 500.0f;
};

struct WallhackEntity {
    quint32 entityId = 0;
    QString name;
    QString type; // "player", "item", "vehicle", etc.
    QVector3D position;
    QVector3D velocity;
    float distance = 0.0f;
    float health = 100.0f;
    bool isVisible = false;
    bool isEnemy = false;
    bool isTeammate = false;
    bool isKnocked = false;
    bool isBot = false;
    bool isBehindWall = false;
    QString weaponName;
    int teamId = 0;
    QDateTime lastSeen;
    QColor currentColor;
    float currentOpacity = 1.0f;
    bool shouldRender = false;
    float threatLevel = 0.0f;
    QVector3D boundingBoxMin;
    QVector3D boundingBoxMax;
    quint32 modelHandle = 0;
    quint32 materialHandle = 0;
    QList<quint32> meshHandles;
};

struct WallhackRenderData {
    QList<WallhackEntity> entities;
    QVector3D cameraPosition;
    QVector2D cameraAngles;
    QMatrix4x4 viewMatrix;
    QMatrix4x4 projectionMatrix;
    float fov = 90.0f;
    QDateTime timestamp;
    bool isValid = false;
};

struct ShaderData {
    quint32 shaderId = 0;
    QString shaderName;
    QString originalCode;
    QString modifiedCode;
    bool isModified = false;
    QDateTime modificationTime;
    QMap<QString, float> parameters;
};

class Wallhack : public QObject
{
    Q_OBJECT

public:
    explicit Wallhack(QObject *parent = nullptr);
    ~Wallhack();
    
    // Component integration
    void setGameInterface(GameInterface *gameInterface);
    void setMemoryManager(MemoryManager *memoryManager);
    void setLogger(Logger *logger);
    
    // Settings management
    void setSettings(const WallhackSettings &settings);
    WallhackSettings getSettings() const;
    void loadSettings();
    void saveSettings();
    void resetSettings();
    
    // Control methods
    void enable();
    void disable();
    void toggle();
    bool isEnabled() const;
    
    void enableChams();
    void disableChams();
    void toggleChams();
    bool isChamsEnabled() const;
    
    void enableGlow();
    void disableGlow();
    void toggleGlow();
    bool isGlowEnabled() const;
    
    // Entity management
    void updateEntities();
    void addEntity(const WallhackEntity &entity);
    void removeEntity(quint32 entityId);
    void clearEntities();
    QList<WallhackEntity> getProcessedEntities() const;
    
    // Rendering control
    void applyWallhack();
    void removeWallhack();
    void updateRenderStates();
    void processEntityRendering(const WallhackEntity &entity);
    
    // Shader management
    void modifyShaders();
    void restoreShaders();
    void updateShaderParameters();
    
    // Visibility enhancement
    void enhanceVisibility();
    void removeEnvironmentalEffects();
    void modifyRenderingPipeline();
    
public slots:
    // Main update slots
    void update();
    void onGameUpdate();
    void onPlayerUpdate();
    void onEntityUpdate();
    void onRenderUpdate();
    
    // Settings slots
    void onSettingsChanged(const WallhackSettings &settings);
    void onModeChanged(int mode);
    void onWallTypeChanged(int type);
    void onChamTypeChanged(int type);
    void onGlowTypeChanged(int type);
    void onVisibilityModeChanged(int mode);
    void onMaxDistanceChanged(float distance);
    
    // Color slots
    void onEnemyChamColorChanged(const QColor &color);
    void onTeammateChamColorChanged(const QColor &color);
    void onKnockedChamColorChanged(const QColor &color);
    void onBotChamColorChanged(const QColor &color);
    void onEnemyGlowColorChanged(const QColor &color);
    void onTeammateGlowColorChanged(const QColor &color);
    
    // Feature toggle slots
    void onPlayerWallhackToggled(bool enabled);
    void onItemWallhackToggled(bool enabled);
    void onVehicleWallhackToggled(bool enabled);
    void onEnemiesToggled(bool enabled);
    void onTeammatesToggled(bool enabled);
    void onKnockedToggled(bool enabled);
    void onBotsToggled(bool enabled);
    void onChamTwoToneToggled(bool enabled);
    void onChamIgnoreZToggled(bool enabled);
    void onGlowPulseToggled(bool enabled);
    void onGlowRainbowToggled(bool enabled);
    void onRemoveSmokeToggled(bool enabled);
    void onRemoveFogToggled(bool enabled);
    void onRemoveFlashToggled(bool enabled);
    void onXRayVisionToggled(bool enabled);
    void onThermalVisionToggled(bool enabled);
    void onNightVisionToggled(bool enabled);
    void onWireframeModeToggled(bool enabled);
    
    // Advanced feature slots
    void onChamOpacityChanged(float opacity);
    void onGlowIntensityChanged(float intensity);
    void onGlowRadiusChanged(float radius);
    void onVisibilityBoostChanged(float boost);
    void onXRayIntensityChanged(float intensity);
    void onNightVisionBrightnessChanged(float brightness);
    void onWireframeThicknessChanged(float thickness);
    
    // Safety slots
    void onEmergencyDisable();
    void onSafeModeToggled(bool enabled);
    void onHideFromScreenshotsToggled(bool enabled);
    void onHideFromRecordingToggled(bool enabled);
    
signals:
    void enabledChanged(bool enabled);
    void chamsEnabledChanged(bool enabled);
    void glowEnabledChanged(bool enabled);
    void settingsChanged(const WallhackSettings &settings);
    void entityAdded(const WallhackEntity &entity);
    void entityRemoved(quint32 entityId);
    void entityUpdated(const WallhackEntity &entity);
    void renderStateChanged();
    void shaderModified(const QString &shaderName);
    void visibilityEnhanced();
    void emergencyTriggered();
    void errorOccurred(const QString &error);
    
private slots:
    void updateTimer();
    void renderTimer();
    void entityScanTimer();
    void shaderUpdateTimer();
    void safetyCheckTimer();
    
private:
    // Core functionality
    void performWallhack();
    void performChams();
    void performGlow();
    void performXRay();
    void performThermal();
    void performNightVision();
    void performWireframe();
    
    void applyEntityWallhack(const WallhackEntity &entity);
    void removeEntityWallhack(const WallhackEntity &entity);
    void updateEntityRenderState(WallhackEntity &entity);
    
    // Entity processing
    QList<WallhackEntity> scanForEntities();
    WallhackEntity processEntity(quint32 entityId);
    void updateEntityData(WallhackEntity &entity);
    void updateEntityVisibility(WallhackEntity &entity);
    void updateEntityColors(WallhackEntity &entity);
    
    bool isValidEntity(const WallhackEntity &entity);
    bool shouldProcessEntity(const WallhackEntity &entity);
    bool isEntityInRange(const WallhackEntity &entity);
    bool isEntityBehindWall(const WallhackEntity &entity);
    
    // Rendering modifications
    void modifyEntityRendering(const WallhackEntity &entity);
    void restoreEntityRendering(const WallhackEntity &entity);
    void setEntityRenderState(quint32 entityId, bool throughWalls);
    void setEntityMaterial(quint32 entityId, const QColor &color, float opacity);
    void setEntityGlow(quint32 entityId, const QColor &color, float intensity, float radius);
    
    // Shader operations
    void hookRenderingFunctions();
    void unhookRenderingFunctions();
    void modifyDepthTest(bool disable);
    void modifyAlphaTest(bool disable);
    void modifyCulling(bool disable);
    void modifyWireframe(bool enable, float thickness, const QColor &color);
    
    QList<ShaderData> getActiveShaders();
    void modifyShader(ShaderData &shader);
    void restoreShader(const ShaderData &shader);
    QString generateChamShader(ChamType type, const QColor &color, float opacity);
    QString generateGlowShader(GlowType type, const QColor &color, float intensity);
    QString generateXRayShader(float intensity);
    QString generateThermalShader(const QColor &coldColor, const QColor &hotColor);
    QString generateNightVisionShader(float brightness, const QColor &tint);
    
    // Environment modifications
    void removeSmokeEffects();
    void removeFogEffects();
    void removeFlashEffects();
    void removeGrassRendering();
    void removeTreeRendering();
    void removeBuildingWalls();
    
    void restoreSmokeEffects();
    void restoreFogEffects();
    void restoreFlashEffects();
    void restoreGrassRendering();
    void restoreTreeRendering();
    void restoreBuildingWalls();
    
    // Color calculations
    QColor getEntityChamColor(const WallhackEntity &entity);
    QColor getEntityGlowColor(const WallhackEntity &entity);
    QColor calculateThermalColor(const WallhackEntity &entity);
    QColor applyDistanceFading(const QColor &color, const WallhackEntity &entity);
    QColor animateColor(const QColor &baseColor, float time, bool rainbow = false);
    
    // Memory operations
    bool readEntityList(QList<quint32> &entityIds);
    bool readEntityPosition(quint32 entityId, QVector3D &position);
    bool readEntityHealth(quint32 entityId, float &health);
    bool readEntityTeam(quint32 entityId, int &teamId);
    bool readEntityModel(quint32 entityId, quint32 &modelHandle);
    bool readEntityMaterial(quint32 entityId, quint32 &materialHandle);
    bool readEntityMeshes(quint32 entityId, QList<quint32> &meshHandles);
    bool readEntityBoundingBox(quint32 entityId, QVector3D &min, QVector3D &max);
    
    bool writeEntityRenderFlags(quint32 entityId, quint32 flags);
    bool writeEntityMaterial(quint32 entityId, quint32 materialHandle);
    bool writeEntityShader(quint32 entityId, quint32 shaderHandle);
    bool writeRenderState(quint32 state, quint32 value);
    
    bool readPlayerPosition(QVector3D &position);
    bool readPlayerAngles(QVector2D &angles);
    bool readViewMatrix(QMatrix4x4 &matrix);
    bool readProjectionMatrix(QMatrix4x4 &matrix);
    
    // Visibility calculations
    bool isPositionVisible(const QVector3D &position);
    bool isEntityVisible(const WallhackEntity &entity);
    bool raycastToEntity(const QVector3D &start, const QVector3D &end);
    float calculateVisibilityFactor(const WallhackEntity &entity);
    
    // Performance optimization
    void optimizeEntityProcessing();
    void cullDistantEntities();
    void sortEntitiesByPriority();
    void limitProcessedEntities();
    void adaptQualitySettings();
    
    // Safety and detection
    void performSafetyChecks();
    void checkDetectionRisk();
    void handleScreenshotDetection();
    void handleRecordingDetection();
    void handleAltTabDetection();
    void emergencyShutdown();
    
    bool isScreenshotActive();
    bool isRecordingActive();
    bool isGameFocused();
    bool isDetectionRisky();
    
    // Statistics and logging
    void updatePerformanceMetrics();
    void logWallhackStats();
    void logEntityStats();
    void logShaderModifications();
    
    // Utility functions
    QString formatEntityInfo(const WallhackEntity &entity) const;
    QString formatRenderStats() const;
    QString formatShaderInfo(const ShaderData &shader) const;
    QString formatSettings() const;
    
    float calculateDistance(const QVector3D &pos1, const QVector3D &pos2);
    float calculateThreatLevel(const WallhackEntity &entity);
    
    // Core components
    GameInterface *m_gameInterface;
    MemoryManager *m_memoryManager;
    Logger *m_logger;
    
    // Settings and configuration
    WallhackSettings m_settings;
    QSettings *m_qsettings;
    
    // Entity management
    QList<WallhackEntity> m_entities;
    QList<WallhackEntity> m_processedEntities;
    QMutex m_entityMutex;
    
    // Rendering data
    WallhackRenderData m_renderData;
    QList<ShaderData> m_modifiedShaders;
    QMap<quint32, quint32> m_originalMaterials;
    QMap<quint32, quint32> m_originalRenderStates;
    
    // State variables
    bool m_enabled;
    bool m_chamsEnabled;
    bool m_glowEnabled;
    bool m_xrayEnabled;
    bool m_thermalEnabled;
    bool m_nightVisionEnabled;
    bool m_wireframeEnabled;
    bool m_shadersModified;
    bool m_environmentModified;
    bool m_emergencyMode;
    QDateTime m_lastUpdateTime;
    
    // Performance tracking
    int m_frameCount;
    QDateTime m_lastFrameTime;
    float m_averageFPS;
    int m_entityCount;
    int m_processedEntityCount;
    qint64 m_processingTime;
    
    // Timers
    QTimer *m_updateTimer;
    QTimer *m_renderTimer;
    QTimer *m_entityScanTimer;
    QTimer *m_shaderUpdateTimer;
    QTimer *m_safetyCheckTimer;
    
    // Threading
    QThread *m_processingThread;
    QMutex m_processingMutex;
    
    // Safety and detection
    QDateTime m_lastSafetyCheck;
    QDateTime m_lastDetectionCheck;
    bool m_screenshotDetected;
    bool m_recordingDetected;
    bool m_altTabDetected;
    
    // Animation data
    QDateTime m_animationStartTime;
    float m_currentAnimationTime;
    QMap<quint32, float> m_entityAnimationOffsets;
    
    // Constants
    static const float DEFAULT_MAX_DISTANCE;
    static const float DEFAULT_MIN_DISTANCE;
    static const float DEFAULT_CHAM_OPACITY;
    static const float DEFAULT_GLOW_INTENSITY;
    static const float DEFAULT_GLOW_RADIUS;
    static const float DEFAULT_VISIBILITY_BOOST;
    static const float DEFAULT_XRAY_INTENSITY;
    static const float DEFAULT_NIGHT_VISION_BRIGHTNESS;
    static const float DEFAULT_WIREFRAME_THICKNESS;
    
    static const int UPDATE_INTERVAL = 16; // ~60 FPS
    static const int RENDER_INTERVAL = 8; // ~120 FPS
    static const int ENTITY_SCAN_INTERVAL = 50; // 20 FPS
    static const int SHADER_UPDATE_INTERVAL = 100; // 10 FPS
    static const int SAFETY_CHECK_INTERVAL = 500; // 2 FPS
    
    static const int MAX_ENTITIES = 1000;
    static const int MAX_PROCESSED_ENTITIES = 100;
    static const float MAX_PROCESSING_DISTANCE;
    static const float DETECTION_RISK_THRESHOLD;
    static const float EMERGENCY_COOLDOWN_TIME;
};

#endif // WALLHACK_H