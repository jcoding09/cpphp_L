#ifndef AIMBOT_H
#define AIMBOT_H

#include <QtCore/QObject>
#include <QtCore/QTimer>
#include <QtCore/QSettings>
#include <QtCore/QDateTime>
#include <QtCore/QMutex>
#include <QtCore/QThread>
#include <QtGui/QVector3D>
#include <QtGui/QVector2D>
#include <QtGui/QMatrix4x4>
#include <memory>


class GameInterface;
class MemoryManager;
class Logger;

enum class AimbotMode {
    Disabled = 0,
    Legit = 1,
    Rage = 2,
    Silent = 3,
    Trigger = 4
};

enum class AimbotTarget {
    Head = 0,
    Neck = 1,
    Chest = 2,
    Body = 3,
    Legs = 4,
    Nearest = 5,
    HighestHP = 6,
    LowestHP = 7
};

enum class AimbotSmoothing {
    None = 0,
    Linear = 1,
    Smooth = 2,
    Bezier = 3,
    Humanized = 4
};

enum class AimbotTrigger {
    Manual = 0,
    AutoFire = 1,
    OnSight = 2,
    OnAim = 3,
    KeyBind = 4
};

struct AimbotSettings {
    // Basic settings
    bool enabled = false;
    AimbotMode mode = AimbotMode::Legit;
    AimbotTarget targetBone = AimbotTarget::Head;
    AimbotSmoothing smoothingType = AimbotSmoothing::Smooth;
    AimbotTrigger triggerMode = AimbotTrigger::Manual;
    
    // Aim settings
    float aimFOV = 90.0f;
    float aimSpeed = 5.0f;
    float smoothness = 2.0f;
    float recoilControl = 0.8f;
    float predictionTime = 0.1f;
    
    // Target selection
    bool prioritizeVisible = true;
    bool prioritizeDistance = false;
    bool prioritizeHealth = false;
    bool prioritizeThreat = false;
    float maxDistance = 500.0f;
    float minDistance = 10.0f;
    
    // Filtering
    bool targetEnemies = true;
    bool targetTeammates = false;
    bool targetKnocked = false;
    bool targetBots = true;
    bool ignoreWalls = false;
    bool ignoreSmokeGrenades = false;
    
    // Trigger settings
    bool autoFire = false;
    float autoFireDelay = 0.05f;
    bool burstFire = false;
    int burstCount = 3;
    float burstDelay = 0.1f;
    
    // Advanced settings
    bool aimAssist = true;
    bool magneticAim = false;
    bool silentAim = false;
    bool noRecoil = false;
    bool noSpread = false;
    bool instantHit = false;
    
    // Humanization
    bool humanizeMovement = true;
    float humanizationFactor = 0.3f;
    bool randomizeAimSpeed = true;
    float aimSpeedVariation = 0.2f;
    bool addMissChance = false;
    float missChancePercent = 5.0f;
    
    // Keybinds
    int aimKey = 0x02; // Right mouse button
    int triggerKey = 0x01; // Left mouse button
    int toggleKey = 0x74; // F5
    int panicKey = 0x23; // End
    
    // Weapon specific
    bool weaponSpecificSettings = false;
    QMap<QString, float> weaponAimSpeeds;
    QMap<QString, float> weaponRecoilControls;
    QMap<QString, float> weaponFOVs;
};

struct TargetInfo {
    quint32 entityId = 0;
    QVector3D position;
    QVector3D velocity;
    QVector3D headPosition;
    QVector3D chestPosition;
    QVector2D screenPosition;
    float distance = 0.0f;
    float health = 100.0f;
    float armor = 0.0f;
    bool isVisible = false;
    bool isEnemy = false;
    bool isKnocked = false;
    bool isBot = false;
    QString weaponName;
    float threatLevel = 0.0f;
    QDateTime lastSeen;
    QVector3D predictedPosition;
};

struct AimData {
    QVector2D currentAngles;
    QVector2D targetAngles;
    QVector2D deltaAngles;
    QVector2D smoothedAngles;
    float aimProgress = 0.0f;
    bool isAiming = false;
    bool hasTarget = false;
    QDateTime aimStartTime;
    qint64 aimDuration = 0;
};

struct RecoilPattern {
    QString weaponName;
    QList<QVector2D> pattern;
    float fireRate = 0.0f;
    int patternLength = 0;
    float recoilScale = 1.0f;
    bool isAutomatic = true;
};

class Aimbot : public QObject
{
    Q_OBJECT

public:
    explicit Aimbot(QObject *parent = nullptr);
    ~Aimbot();
    
    // Component integration
    void setGameInterface(GameInterface *gameInterface);
    void setMemoryManager(MemoryManager *memoryManager);
    void setLogger(Logger *logger);
    
    // Settings management
    void setSettings(const AimbotSettings &settings);
    AimbotSettings getSettings() const;
    void loadSettings();
    void saveSettings();
    void resetSettings();
    
    // Control methods
    void enable();
    void disable();
    void toggle();
    bool isEnabled() const;
    
    void startAiming();
    void stopAiming();
    bool isAiming() const;
    
    // Target management
    void updateTargets();
    void selectBestTarget();
    void clearTarget();
    TargetInfo getCurrentTarget() const;
    QList<TargetInfo> getAvailableTargets() const;
    
    // Aim calculation
    QVector2D calculateAimAngles(const TargetInfo &target);
    QVector2D calculatePredictedPosition(const TargetInfo &target);
    QVector2D applySmoothingToAngles(const QVector2D &currentAngles, const QVector2D &targetAngles);
    
    // Recoil control
    void updateRecoilPattern();
    QVector2D calculateRecoilCompensation();
    void resetRecoilPattern();
    
    // Weapon handling
    void updateCurrentWeapon();
    QString getCurrentWeaponName() const;
    RecoilPattern getCurrentRecoilPattern() const;
    
    // Statistics
    int getHitCount() const;
    int getShotCount() const;
    float getAccuracy() const;
    qint64 getTotalAimTime() const;
    
public slots:
    // Main update slots
    void update();
    void onGameUpdate();
    void onPlayerUpdate();
    void onWeaponUpdate();
    
    // Input handling slots
    void onAimKeyPressed();
    void onAimKeyReleased();
    void onTriggerKeyPressed();
    void onTriggerKeyReleased();
    void onToggleKeyPressed();
    void onPanicKeyPressed();
    
    // Settings slots
    void onSettingsChanged(const AimbotSettings &settings);
    void onModeChanged(int mode);
    void onTargetBoneChanged(int bone);
    void onSmoothingChanged(int smoothing);
    void onTriggerModeChanged(int trigger);
    void onAimFOVChanged(float fov);
    void onAimSpeedChanged(float speed);
    void onSmoothnessChanged(float smoothness);
    void onRecoilControlChanged(float control);
    
    // Target filtering slots
    void onTargetFilterChanged();
    void onMaxDistanceChanged(float distance);
    void onMinDistanceChanged(float distance);
    
    // Advanced feature slots
    void onAutoFireToggled(bool enabled);
    void onSilentAimToggled(bool enabled);
    void onNoRecoilToggled(bool enabled);
    void onHumanizationToggled(bool enabled);
    
signals:
    void enabledChanged(bool enabled);
    void aimingChanged(bool aiming);
    void targetChanged(const TargetInfo &target);
    void targetLost();
    void shotFired();
    void hitRegistered(const TargetInfo &target);
    void missRegistered(const TargetInfo &target);
    void accuracyChanged(float accuracy);
    void settingsChanged(const AimbotSettings &settings);
    void weaponChanged(const QString &weaponName);
    void recoilPatternChanged(const RecoilPattern &pattern);
    void errorOccurred(const QString &error);
    
private slots:
    void updateTimer();
    void aimTimer();
    void recoilTimer();
    void targetScanTimer();
    void statisticsTimer();
    
private:
    // Core functionality
    void performAiming();
    void performTargetSelection();
    void performRecoilControl();
    void performTriggerBot();
    void performSilentAim();
    
    void executeAimMovement(const QVector2D &angles);
    void executeTriggerAction();
    void executeRecoilCompensation(const QVector2D &compensation);
    
    // Target analysis
    QList<TargetInfo> scanForTargets();
    TargetInfo analyzeTarget(quint32 entityId);
    bool isValidTarget(const TargetInfo &target);
    bool isTargetVisible(const TargetInfo &target);
    float calculateTargetPriority(const TargetInfo &target);
    float calculateThreatLevel(const TargetInfo &target);
    
    void updateTargetPrediction(TargetInfo &target);
    void updateTargetVisibility(TargetInfo &target);
    
    // Aim calculations
    QVector2D worldToScreen(const QVector3D &worldPos);
    QVector3D screenToWorld(const QVector2D &screenPos, float depth);
    QVector2D calculateAnglesFromPosition(const QVector3D &position);
    QVector3D calculatePositionFromAngles(const QVector2D &angles);
    
    float calculateDistance(const QVector3D &pos1, const QVector3D &pos2);
    float calculateAngleDifference(const QVector2D &angle1, const QVector2D &angle2);
    QVector2D normalizeAngles(const QVector2D &angles);
    
    // Smoothing algorithms
    QVector2D linearSmoothing(const QVector2D &current, const QVector2D &target, float factor);
    QVector2D smoothSmoothing(const QVector2D &current, const QVector2D &target, float factor);
    QVector2D bezierSmoothing(const QVector2D &current, const QVector2D &target, float factor);
    QVector2D humanizedSmoothing(const QVector2D &current, const QVector2D &target, float factor);
    
    // Humanization
    void applyHumanization();
    float generateRandomFactor();
    QVector2D addHumanNoise(const QVector2D &angles);
    void simulateHumanReactionTime();
    bool shouldMissShot();
    
    // Weapon management
    void loadRecoilPatterns();
    void saveRecoilPatterns();
    RecoilPattern loadWeaponRecoilPattern(const QString &weaponName);
    void updateWeaponSpecificSettings();
    
    // Memory operations
    bool readPlayerAngles(QVector2D &angles);
    bool writePlayerAngles(const QVector2D &angles);
    bool readPlayerPosition(QVector3D &position);
    bool readEntityPosition(quint32 entityId, QVector3D &position);
    bool readEntityHealth(quint32 entityId, float &health);
    bool readEntityTeam(quint32 entityId, int &team);
    bool readWeaponInfo(QString &weaponName, float &fireRate);
    
    bool isKeyPressed(int keyCode);
    void simulateMouseMovement(const QVector2D &delta);
    void simulateMouseClick(int button);
    
    // Validation and safety
    bool validateTarget(const TargetInfo &target);
    bool validateAimAngles(const QVector2D &angles);
    bool isAngleSafe(const QVector2D &angles);
    bool isMovementSafe(const QVector2D &delta);
    
    void performSafetyChecks();
    void handleDetectionRisk();
    void emergencyStop();
    
    // Statistics and logging
    void updateStatistics();
    void logAimEvent(const QString &event, const TargetInfo &target = TargetInfo());
    void logPerformanceMetrics();
    
    // Utility functions
    QString formatTargetInfo(const TargetInfo &target) const;
    QString formatAimData(const AimData &data) const;
    QString formatSettings() const;
    
    // Core components
    GameInterface *m_gameInterface;
    MemoryManager *m_memoryManager;
    Logger *m_logger;
    
    // Settings and configuration
    AimbotSettings m_settings;
    QSettings *m_qsettings;
    
    // Target management
    QList<TargetInfo> m_availableTargets;
    TargetInfo m_currentTarget;
    bool m_hasTarget;
    QMutex m_targetMutex;
    
    // Aim data
    AimData m_aimData;
    QVector2D m_lastAngles;
    QVector2D m_targetAngles;
    QVector2D m_smoothedAngles;
    
    // Recoil control
    QMap<QString, RecoilPattern> m_recoilPatterns;
    RecoilPattern m_currentRecoilPattern;
    int m_currentRecoilIndex;
    QDateTime m_lastShotTime;
    QVector2D m_recoilCompensation;
    
    // Weapon information
    QString m_currentWeapon;
    float m_currentFireRate;
    bool m_isAutomatic;
    
    // State variables
    bool m_enabled;
    bool m_isAiming;
    bool m_isFiring;
    bool m_panicMode;
    QDateTime m_aimStartTime;
    QDateTime m_lastUpdateTime;
    
    // Statistics
    int m_hitCount;
    int m_shotCount;
    qint64 m_totalAimTime;
    QDateTime m_sessionStartTime;
    
    // Timers
    QTimer *m_updateTimer;
    QTimer *m_aimTimer;
    QTimer *m_recoilTimer;
    QTimer *m_targetScanTimer;
    QTimer *m_statisticsTimer;
    
    // Threading
    QThread *m_aimThread;
    QMutex m_aimMutex;
    
    // Humanization data
    QList<float> m_humanFactors;
    QDateTime m_lastHumanUpdate;
    float m_currentHumanFactor;
    
    // Constants
    static const float DEFAULT_AIM_FOV;
    static const float DEFAULT_AIM_SPEED;
    static const float DEFAULT_SMOOTHNESS;
    static const float DEFAULT_RECOIL_CONTROL;
    static const float DEFAULT_PREDICTION_TIME;
    static const float DEFAULT_MAX_DISTANCE;
    static const float DEFAULT_MIN_DISTANCE;
    
    static const int UPDATE_INTERVAL = 16; // ~60 FPS
    static const int AIM_INTERVAL = 8; // ~120 FPS
    static const int RECOIL_INTERVAL = 5; // ~200 FPS
    static const int TARGET_SCAN_INTERVAL = 50; // 20 FPS
    static const int STATISTICS_INTERVAL = 1000; // 1 second
    
    static const float MAX_AIM_ANGLE_DELTA;
    static const float MAX_MOUSE_MOVEMENT;
    static const float HUMANIZATION_NOISE_SCALE;
};

#endif // AIMBOT_H