#include "wallhack.h"
#include "../core/logger.h"
#include "../core/memory_manager.h"
#include "../core/game_interface.h"
#include "../data/entity_manager.h"
#include <QTimer>
#include <QMutexLocker>
#include <QSettings>
#include <QtMath>

Wallhack::Wallhack(QObject *parent)
    : QObject(parent)
    , m_enabled(false)
    , m_enablePlayers(true)
    , m_enableEnemies(true)
    , m_enableTeammates(false)
    , m_enableItems(true)
    , m_enableVehicles(true)
    , m_enableWeapons(true)
    , m_enableGrenades(true)
    , m_enableSupplies(true)
    , m_maxDistance(1000.0f)
    , m_transparency(0.7f)
    , m_glowIntensity(1.0f)
    , m_outlineWidth(2.0f)
    , m_playerColor(QColor(255, 0, 0))
    , m_teammateColor(QColor(0, 255, 0))
    , m_itemColor(QColor(255, 255, 0))
    , m_vehicleColor(QColor(0, 0, 255))
    , m_weaponColor(QColor(255, 165, 0))
    , m_grenadeColor(QColor(255, 0, 255))
    , m_supplyColor(QColor(0, 255, 255))
    , m_renderMode(RenderMode::Glow)
    , m_filterMode(FilterMode::Distance)
    , m_memoryManager(nullptr)
    , m_gameInterface(nullptr)
    , m_entityManager(nullptr)
    , m_logger(nullptr)
    , m_updateTimer(new QTimer(this))
    , m_entitiesProcessed(0)
    , m_entitiesVisible(0)
    , m_lastUpdateTime(QDateTime::currentMSecsSinceEpoch())
    , m_averageUpdateTime(16.0)
{
    m_updateTimer->setSingleShot(false);
    connect(m_updateTimer, &QTimer::timeout, this, &Wallhack::update);
}

Wallhack::~Wallhack()
{
    stop();
}

void Wallhack::initialize(MemoryManager* memoryManager, GameInterface* gameInterface,
                          EntityManager* entityManager, Logger* logger)
{
    m_memoryManager = memoryManager;
    m_gameInterface = gameInterface;
    m_entityManager = entityManager;
    m_logger = logger;
    
    if (m_logger) {
        m_logger->info("Wallhack initialized");
    }
}

void Wallhack::start()
{
    if (!m_memoryManager || !m_gameInterface || !m_entityManager) {
        if (m_logger) {
            m_logger->error("Wallhack: Required components not initialized");
        }
        return;
    }
    
    m_enabled = true;
    m_updateTimer->start(16); // ~60 FPS
    
    if (m_logger) {
        m_logger->info("Wallhack started");
    }
    
    emit statusChanged(true);
}

void Wallhack::stop()
{
    if (m_enabled) {
        // Restore original rendering states
        restoreOriginalStates();
    }
    
    m_enabled = false;
    m_updateTimer->stop();
    
    if (m_logger) {
        m_logger->info("Wallhack stopped");
    }
    
    emit statusChanged(false);
}

void Wallhack::setEnabled(bool enabled)
{
    if (enabled) {
        start();
    } else {
        stop();
    }
}

void Wallhack::setEnablePlayers(bool enable)
{
    QMutexLocker locker(&m_mutex);
    m_enablePlayers = enable;
    emit settingsChanged();
}

void Wallhack::setEnableEnemies(bool enable)
{
    QMutexLocker locker(&m_mutex);
    m_enableEnemies = enable;
    emit settingsChanged();
}

void Wallhack::setEnableTeammates(bool enable)
{
    QMutexLocker locker(&m_mutex);
    m_enableTeammates = enable;
    emit settingsChanged();
}

void Wallhack::setEnableItems(bool enable)
{
    QMutexLocker locker(&m_mutex);
    m_enableItems = enable;
    emit settingsChanged();
}

void Wallhack::setEnableVehicles(bool enable)
{
    QMutexLocker locker(&m_mutex);
    m_enableVehicles = enable;
    emit settingsChanged();
}

void Wallhack::setEnableWeapons(bool enable)
{
    QMutexLocker locker(&m_mutex);
    m_enableWeapons = enable;
    emit settingsChanged();
}

void Wallhack::setEnableGrenades(bool enable)
{
    QMutexLocker locker(&m_mutex);
    m_enableGrenades = enable;
    emit settingsChanged();
}

void Wallhack::setEnableSupplies(bool enable)
{
    QMutexLocker locker(&m_mutex);
    m_enableSupplies = enable;
    emit settingsChanged();
}

void Wallhack::setMaxDistance(float distance)
{
    QMutexLocker locker(&m_mutex);
    m_maxDistance = qBound(100.0f, distance, 5000.0f);
    emit settingsChanged();
}

void Wallhack::setTransparency(float transparency)
{
    QMutexLocker locker(&m_mutex);
    m_transparency = qBound(0.1f, transparency, 1.0f);
    emit settingsChanged();
}

void Wallhack::setGlowIntensity(float intensity)
{
    QMutexLocker locker(&m_mutex);
    m_glowIntensity = qBound(0.1f, intensity, 5.0f);
    emit settingsChanged();
}

void Wallhack::setOutlineWidth(float width)
{
    QMutexLocker locker(&m_mutex);
    m_outlineWidth = qBound(1.0f, width, 10.0f);
    emit settingsChanged();
}

void Wallhack::setPlayerColor(const QColor& color)
{
    QMutexLocker locker(&m_mutex);
    m_playerColor = color;
    emit settingsChanged();
}

void Wallhack::setTeammateColor(const QColor& color)
{
    QMutexLocker locker(&m_mutex);
    m_teammateColor = color;
    emit settingsChanged();
}

void Wallhack::setItemColor(const QColor& color)
{
    QMutexLocker locker(&m_mutex);
    m_itemColor = color;
    emit settingsChanged();
}

void Wallhack::setVehicleColor(const QColor& color)
{
    QMutexLocker locker(&m_mutex);
    m_vehicleColor = color;
    emit settingsChanged();
}

void Wallhack::setWeaponColor(const QColor& color)
{
    QMutexLocker locker(&m_mutex);
    m_weaponColor = color;
    emit settingsChanged();
}

void Wallhack::setGrenadeColor(const QColor& color)
{
    QMutexLocker locker(&m_mutex);
    m_grenadeColor = color;
    emit settingsChanged();
}

void Wallhack::setSupplyColor(const QColor& color)
{
    QMutexLocker locker(&m_mutex);
    m_supplyColor = color;
    emit settingsChanged();
}

void Wallhack::setRenderMode(RenderMode mode)
{
    QMutexLocker locker(&m_mutex);
    m_renderMode = mode;
    emit settingsChanged();
}

void Wallhack::setFilterMode(FilterMode mode)
{
    QMutexLocker locker(&m_mutex);
    m_filterMode = mode;
    emit settingsChanged();
}

void Wallhack::update()
{
    if (!m_enabled || !m_gameInterface || !m_entityManager) {
        return;
    }
    
    qint64 startTime = QDateTime::currentMSecsSinceEpoch();
    
    QMutexLocker locker(&m_mutex);
    
    // Get local player
    auto localPlayer = m_gameInterface->getLocalPlayer();
    if (!localPlayer.isValid) {
        return;
    }
    
    m_entitiesProcessed = 0;
    m_entitiesVisible = 0;
    
    // Process different entity types
    if (m_enablePlayers) {
        processPlayers(localPlayer);
    }
    
    if (m_enableItems) {
        processItems(localPlayer);
    }
    
    if (m_enableVehicles) {
        processVehicles(localPlayer);
    }
    
    if (m_enableWeapons) {
        processWeapons(localPlayer);
    }
    
    if (m_enableGrenades) {
        processGrenades(localPlayer);
    }
    
    if (m_enableSupplies) {
        processSupplies(localPlayer);
    }
    
    // Update performance metrics
    qint64 endTime = QDateTime::currentMSecsSinceEpoch();
    double updateTime = endTime - startTime;
    m_averageUpdateTime = (m_averageUpdateTime * 0.9) + (updateTime * 0.1);
    m_lastUpdateTime = endTime;
    
    emit dataUpdated();
}

void Wallhack::processPlayers(const PlayerInfo& localPlayer)
{
    auto players = m_entityManager->getEntitiesByType(EntityType::Player);
    
    for (const auto& player : players) {
        if (!player.isValid || player.health <= 0) {
            continue;
        }
        
        // Skip self
        if (player.id == localPlayer.id) {
            continue;
        }
        
        m_entitiesProcessed++;
        
        // Check team
        bool isTeammate = (player.teamId == localPlayer.teamId);
        if (isTeammate && !m_enableTeammates) {
            continue;
        }
        if (!isTeammate && !m_enableEnemies) {
            continue;
        }
        
        // Apply filters
        if (!shouldRenderEntity(player, localPlayer)) {
            continue;
        }
        
        // Apply wallhack effect
        QColor color = isTeammate ? m_teammateColor : m_playerColor;
        applyWallhackEffect(player, color);
        
        m_entitiesVisible++;
    }
}

void Wallhack::processItems(const PlayerInfo& localPlayer)
{
    auto items = m_entityManager->getEntitiesByType(EntityType::Item);
    
    for (const auto& item : items) {
        if (!item.isValid) {
            continue;
        }
        
        m_entitiesProcessed++;
        
        // Apply filters
        if (!shouldRenderEntity(item, localPlayer)) {
            continue;
        }
        
        // Apply wallhack effect
        applyWallhackEffect(item, m_itemColor);
        
        m_entitiesVisible++;
    }
}

void Wallhack::processVehicles(const PlayerInfo& localPlayer)
{
    auto vehicles = m_entityManager->getEntitiesByType(EntityType::Vehicle);
    
    for (const auto& vehicle : vehicles) {
        if (!vehicle.isValid) {
            continue;
        }
        
        m_entitiesProcessed++;
        
        // Apply filters
        if (!shouldRenderEntity(vehicle, localPlayer)) {
            continue;
        }
        
        // Apply wallhack effect
        applyWallhackEffect(vehicle, m_vehicleColor);
        
        m_entitiesVisible++;
    }
}

void Wallhack::processWeapons(const PlayerInfo& localPlayer)
{
    auto weapons = m_entityManager->getEntitiesByType(EntityType::Weapon);
    
    for (const auto& weapon : weapons) {
        if (!weapon.isValid) {
            continue;
        }
        
        m_entitiesProcessed++;
        
        // Apply filters
        if (!shouldRenderEntity(weapon, localPlayer)) {
            continue;
        }
        
        // Apply wallhack effect
        applyWallhackEffect(weapon, m_weaponColor);
        
        m_entitiesVisible++;
    }
}

void Wallhack::processGrenades(const PlayerInfo& localPlayer)
{
    auto grenades = m_entityManager->getEntitiesByType(EntityType::Grenade);
    
    for (const auto& grenade : grenades) {
        if (!grenade.isValid) {
            continue;
        }
        
        m_entitiesProcessed++;
        
        // Apply filters
        if (!shouldRenderEntity(grenade, localPlayer)) {
            continue;
        }
        
        // Apply wallhack effect
        applyWallhackEffect(grenade, m_grenadeColor);
        
        m_entitiesVisible++;
    }
}

void Wallhack::processSupplies(const PlayerInfo& localPlayer)
{
    auto supplies = m_entityManager->getEntitiesByType(EntityType::Supply);
    
    for (const auto& supply : supplies) {
        if (!supply.isValid) {
            continue;
        }
        
        m_entitiesProcessed++;
        
        // Apply filters
        if (!shouldRenderEntity(supply, localPlayer)) {
            continue;
        }
        
        // Apply wallhack effect
        applyWallhackEffect(supply, m_supplyColor);
        
        m_entitiesVisible++;
    }
}

bool Wallhack::shouldRenderEntity(const Entity& entity, const PlayerInfo& localPlayer)
{
    switch (m_filterMode) {
        case FilterMode::Distance: {
            float distance = localPlayer.position.distanceToPoint(entity.position);
            return distance <= m_maxDistance;
        }
        case FilterMode::LineOfSight: {
            // Check if entity is behind walls (simplified)
            return !hasLineOfSight(localPlayer.position, entity.position);
        }
        case FilterMode::Health: {
            // Only show entities with health (for players/vehicles)
            return entity.health > 0;
        }
        case FilterMode::Custom: {
            // Custom filtering logic
            return applyCustomFilter(entity, localPlayer);
        }
        default:
            return true;
    }
}

bool Wallhack::hasLineOfSight(const QVector3D& from, const QVector3D& to)
{
    // Placeholder for line of sight calculation
    // In a real implementation, this would perform ray casting
    Q_UNUSED(from)
    Q_UNUSED(to)
    return false; // Assume no line of sight for wallhack purposes
}

bool Wallhack::applyCustomFilter(const Entity& entity, const PlayerInfo& localPlayer)
{
    // Custom filtering logic based on entity properties
    Q_UNUSED(localPlayer)
    
    // Example: Filter by entity name or specific properties
    if (entity.name.contains("rare", Qt::CaseInsensitive)) {
        return true;
    }
    
    // Filter by health percentage for players
    if (entity.type == EntityType::Player && entity.maxHealth > 0) {
        float healthPercent = (float)entity.health / entity.maxHealth;
        return healthPercent < 0.5f; // Show low health players
    }
    
    return true;
}

void Wallhack::applyWallhackEffect(const Entity& entity, const QColor& color)
{
    if (!m_memoryManager) {
        return;
    }
    
    // Get entity render object address
    uintptr_t renderObjectAddr = getRenderObjectAddress(entity);
    if (renderObjectAddr == 0) {
        return;
    }
    
    switch (m_renderMode) {
        case RenderMode::Glow:
            applyGlowEffect(renderObjectAddr, color);
            break;
        case RenderMode::Outline:
            applyOutlineEffect(renderObjectAddr, color);
            break;
        case RenderMode::Wireframe:
            applyWireframeEffect(renderObjectAddr, color);
            break;
        case RenderMode::Transparent:
            applyTransparentEffect(renderObjectAddr, color);
            break;
        case RenderMode::Highlight:
            applyHighlightEffect(renderObjectAddr, color);
            break;
    }
}

uintptr_t Wallhack::getRenderObjectAddress(const Entity& entity)
{
    // Placeholder for getting render object address from entity
    // In a real implementation, this would read from game memory
    Q_UNUSED(entity)
    return 0x12345678; // Dummy address
}

void Wallhack::applyGlowEffect(uintptr_t renderObjectAddr, const QColor& color)
{
    if (!m_memoryManager) {
        return;
    }
    
    // Placeholder offsets for glow effect
    const uintptr_t GLOW_ENABLED_OFFSET = 0x50;
    const uintptr_t GLOW_COLOR_OFFSET = 0x54;
    const uintptr_t GLOW_INTENSITY_OFFSET = 0x64;
    
    try {
        // Enable glow
        m_memoryManager->writeMemory(renderObjectAddr + GLOW_ENABLED_OFFSET, true);
        
        // Set glow color (RGBA)
        float colorArray[4] = {
            color.redF(),
            color.greenF(),
            color.blueF(),
            m_transparency
        };
        m_memoryManager->writeMemory(renderObjectAddr + GLOW_COLOR_OFFSET, colorArray, sizeof(colorArray));
        
        // Set glow intensity
        m_memoryManager->writeMemory(renderObjectAddr + GLOW_INTENSITY_OFFSET, m_glowIntensity);
        
    } catch (const std::exception& e) {
        if (m_logger) {
            m_logger->warning(QString("Failed to apply glow effect: %1").arg(e.what()));
        }
    }
}

void Wallhack::applyOutlineEffect(uintptr_t renderObjectAddr, const QColor& color)
{
    if (!m_memoryManager) {
        return;
    }
    
    // Placeholder offsets for outline effect
    const uintptr_t OUTLINE_ENABLED_OFFSET = 0x70;
    const uintptr_t OUTLINE_COLOR_OFFSET = 0x74;
    const uintptr_t OUTLINE_WIDTH_OFFSET = 0x84;
    
    try {
        // Enable outline
        m_memoryManager->writeMemory(renderObjectAddr + OUTLINE_ENABLED_OFFSET, true);
        
        // Set outline color
        uint32_t colorValue = (color.alpha() << 24) | (color.red() << 16) | 
                             (color.green() << 8) | color.blue();
        m_memoryManager->writeMemory(renderObjectAddr + OUTLINE_COLOR_OFFSET, colorValue);
        
        // Set outline width
        m_memoryManager->writeMemory(renderObjectAddr + OUTLINE_WIDTH_OFFSET, m_outlineWidth);
        
    } catch (const std::exception& e) {
        if (m_logger) {
            m_logger->warning(QString("Failed to apply outline effect: %1").arg(e.what()));
        }
    }
}

void Wallhack::applyWireframeEffect(uintptr_t renderObjectAddr, const QColor& color)
{
    if (!m_memoryManager) {
        return;
    }
    
    // Placeholder offsets for wireframe effect
    const uintptr_t WIREFRAME_ENABLED_OFFSET = 0x90;
    const uintptr_t WIREFRAME_COLOR_OFFSET = 0x94;
    
    try {
        // Enable wireframe
        m_memoryManager->writeMemory(renderObjectAddr + WIREFRAME_ENABLED_OFFSET, true);
        
        // Set wireframe color
        uint32_t colorValue = (color.alpha() << 24) | (color.red() << 16) | 
                             (color.green() << 8) | color.blue();
        m_memoryManager->writeMemory(renderObjectAddr + WIREFRAME_COLOR_OFFSET, colorValue);
        
    } catch (const std::exception& e) {
        if (m_logger) {
            m_logger->warning(QString("Failed to apply wireframe effect: %1").arg(e.what()));
        }
    }
}

void Wallhack::applyTransparentEffect(uintptr_t renderObjectAddr, const QColor& color)
{
    if (!m_memoryManager) {
        return;
    }
    
    // Placeholder offsets for transparency effect
    const uintptr_t TRANSPARENCY_OFFSET = 0xA0;
    const uintptr_t BLEND_MODE_OFFSET = 0xA4;
    
    try {
        // Set transparency
        m_memoryManager->writeMemory(renderObjectAddr + TRANSPARENCY_OFFSET, m_transparency);
        
        // Set blend mode for transparency
        uint32_t blendMode = 1; // Alpha blending
        m_memoryManager->writeMemory(renderObjectAddr + BLEND_MODE_OFFSET, blendMode);
        
    } catch (const std::exception& e) {
        if (m_logger) {
            m_logger->warning(QString("Failed to apply transparent effect: %1").arg(e.what()));
        }
    }
}

void Wallhack::applyHighlightEffect(uintptr_t renderObjectAddr, const QColor& color)
{
    if (!m_memoryManager) {
        return;
    }
    
    // Placeholder offsets for highlight effect
    const uintptr_t HIGHLIGHT_ENABLED_OFFSET = 0xB0;
    const uintptr_t HIGHLIGHT_COLOR_OFFSET = 0xB4;
    const uintptr_t HIGHLIGHT_INTENSITY_OFFSET = 0xC4;
    
    try {
        // Enable highlight
        m_memoryManager->writeMemory(renderObjectAddr + HIGHLIGHT_ENABLED_OFFSET, true);
        
        // Set highlight color
        float colorArray[3] = {
            color.redF(),
            color.greenF(),
            color.blueF()
        };
        m_memoryManager->writeMemory(renderObjectAddr + HIGHLIGHT_COLOR_OFFSET, colorArray, sizeof(colorArray));
        
        // Set highlight intensity
        float intensity = m_glowIntensity * 0.8f;
        m_memoryManager->writeMemory(renderObjectAddr + HIGHLIGHT_INTENSITY_OFFSET, intensity);
        
    } catch (const std::exception& e) {
        if (m_logger) {
            m_logger->warning(QString("Failed to apply highlight effect: %1").arg(e.what()));
        }
    }
}

void Wallhack::restoreOriginalStates()
{
    if (!m_memoryManager) {
        return;
    }
    
    // Restore original rendering states for all processed entities
    // This would typically involve reading from a backup of original values
    
    if (m_logger) {
        m_logger->info("Wallhack: Restored original rendering states");
    }
}

WallhackStats Wallhack::getStats() const
{
    QMutexLocker locker(&m_mutex);
    
    WallhackStats stats;
    stats.enabled = m_enabled;
    stats.entitiesProcessed = m_entitiesProcessed;
    stats.entitiesVisible = m_entitiesVisible;
    stats.maxDistance = m_maxDistance;
    stats.transparency = m_transparency;
    stats.glowIntensity = m_glowIntensity;
    stats.outlineWidth = m_outlineWidth;
    stats.renderMode = static_cast<int>(m_renderMode);
    stats.filterMode = static_cast<int>(m_filterMode);
    stats.averageUpdateTime = m_averageUpdateTime;
    stats.lastUpdateTime = m_lastUpdateTime;
    
    return stats;
}

void Wallhack::saveSettings(QSettings& settings)
{
    QMutexLocker locker(&m_mutex);
    
    settings.beginGroup("Wallhack");
    settings.setValue("enabled", m_enabled);
    settings.setValue("enablePlayers", m_enablePlayers);
    settings.setValue("enableEnemies", m_enableEnemies);
    settings.setValue("enableTeammates", m_enableTeammates);
    settings.setValue("enableItems", m_enableItems);
    settings.setValue("enableVehicles", m_enableVehicles);
    settings.setValue("enableWeapons", m_enableWeapons);
    settings.setValue("enableGrenades", m_enableGrenades);
    settings.setValue("enableSupplies", m_enableSupplies);
    settings.setValue("maxDistance", m_maxDistance);
    settings.setValue("transparency", m_transparency);
    settings.setValue("glowIntensity", m_glowIntensity);
    settings.setValue("outlineWidth", m_outlineWidth);
    settings.setValue("playerColor", m_playerColor.name());
    settings.setValue("teammateColor", m_teammateColor.name());
    settings.setValue("itemColor", m_itemColor.name());
    settings.setValue("vehicleColor", m_vehicleColor.name());
    settings.setValue("weaponColor", m_weaponColor.name());
    settings.setValue("grenadeColor", m_grenadeColor.name());
    settings.setValue("supplyColor", m_supplyColor.name());
    settings.setValue("renderMode", static_cast<int>(m_renderMode));
    settings.setValue("filterMode", static_cast<int>(m_filterMode));
    settings.endGroup();
}

void Wallhack::loadSettings(QSettings& settings)
{
    QMutexLocker locker(&m_mutex);
    
    settings.beginGroup("Wallhack");
    m_enabled = settings.value("enabled", false).toBool();
    m_enablePlayers = settings.value("enablePlayers", true).toBool();
    m_enableEnemies = settings.value("enableEnemies", true).toBool();
    m_enableTeammates = settings.value("enableTeammates", false).toBool();
    m_enableItems = settings.value("enableItems", true).toBool();
    m_enableVehicles = settings.value("enableVehicles", true).toBool();
    m_enableWeapons = settings.value("enableWeapons", true).toBool();
    m_enableGrenades = settings.value("enableGrenades", true).toBool();
    m_enableSupplies = settings.value("enableSupplies", true).toBool();
    m_maxDistance = settings.value("maxDistance", 1000.0f).toFloat();
    m_transparency = settings.value("transparency", 0.7f).toFloat();
    m_glowIntensity = settings.value("glowIntensity", 1.0f).toFloat();
    m_outlineWidth = settings.value("outlineWidth", 2.0f).toFloat();
    m_playerColor = QColor(settings.value("playerColor", "#ff0000").toString());
    m_teammateColor = QColor(settings.value("teammateColor", "#00ff00").toString());
    m_itemColor = QColor(settings.value("itemColor", "#ffff00").toString());
    m_vehicleColor = QColor(settings.value("vehicleColor", "#0000ff").toString());
    m_weaponColor = QColor(settings.value("weaponColor", "#ffa500").toString());
    m_grenadeColor = QColor(settings.value("grenadeColor", "#ff00ff").toString());
    m_supplyColor = QColor(settings.value("supplyColor", "#00ffff").toString());
    m_renderMode = static_cast<RenderMode>(settings.value("renderMode", 0).toInt());
    m_filterMode = static_cast<FilterMode>(settings.value("filterMode", 0).toInt());
    settings.endGroup();
    
    emit settingsChanged();
}