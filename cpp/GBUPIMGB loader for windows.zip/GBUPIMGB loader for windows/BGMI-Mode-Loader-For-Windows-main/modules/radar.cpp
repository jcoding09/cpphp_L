#include "radar.h"
#include "../core/game_interface.h"
#include "../core/memory_manager.h"
#include "../core/logger.h"
#include <QtCore/QStandardPaths>
#include <QtCore/QDir>
#include <QtCore/QJsonDocument>
#include <QtCore/QJsonObject>
#include <QtCore/QMutexLocker>
#include <QtGui/QPainter>
#include <QtGui/QPen>
#include <QtGui/QBrush>
#include <QtCore/QThread>
#include <QtCore/QCoreApplication>
#include <cmath>

// Constants
const float Radar::DEFAULT_RANGE = 200.0f;
const float Radar::MIN_RANGE = 25.0f;
const float Radar::MAX_RANGE = 2000.0f;
const float Radar::DEFAULT_ENTITY_SIZE = 5.0f;
const float Radar::DEFAULT_OPACITY = 0.8f;
const float Radar::DEFAULT_BORDER_WIDTH = 2.0f;
const float Radar::DETECTION_RISK_THRESHOLD = 0.7f;
const float Radar::EMERGENCY_COOLDOWN_TIME = 5.0f;

Radar::Radar(QObject *parent)
    : QObject(parent)
    , m_gameInterface(nullptr)
    , m_memoryManager(nullptr)
    , m_logger(nullptr)
    , m_qsettings(nullptr)
    , m_enabled(false)
    , m_playerDirection(0.0f)
    , m_currentZoom(DEFAULT_RANGE)
    , m_radarCenter(QVector2D(0, 0))
    , m_frameCount(0)
    , m_averageFPS(60.0f)
    , m_entityCount(0)
    , m_visibleEntityCount(0)
    , m_renderingTime(0)
    , m_currentAnimationTime(0.0f)
    , m_nextWaypointId(1)
    , m_screenshotDetected(false)
    , m_recordingDetected(false)
    , m_altTabDetected(false)
    , m_updateTimer(new QTimer(this))
    , m_renderTimer(new QTimer(this))
    , m_entityScanTimer(new QTimer(this))
    , m_zoneUpdateTimer(new QTimer(this))
    , m_animationTimer(new QTimer(this))
    , m_safetyCheckTimer(new QTimer(this))
    , m_processingThread(nullptr)
{
    // Initialize timers
    m_updateTimer->setInterval(UPDATE_INTERVAL);
    m_renderTimer->setInterval(RENDER_INTERVAL);
    m_entityScanTimer->setInterval(ENTITY_SCAN_INTERVAL);
    m_zoneUpdateTimer->setInterval(ZONE_UPDATE_INTERVAL);
    m_animationTimer->setInterval(ANIMATION_INTERVAL);
    m_safetyCheckTimer->setInterval(SAFETY_CHECK_INTERVAL);
    
    // Connect timer signals
    connect(m_updateTimer, &QTimer::timeout, this, &Radar::updateTimer);
    connect(m_renderTimer, &QTimer::timeout, this, &Radar::renderTimer);
    connect(m_entityScanTimer, &QTimer::timeout, this, &Radar::entityScanTimer);
    connect(m_zoneUpdateTimer, &QTimer::timeout, this, &Radar::zoneUpdateTimer);
    connect(m_animationTimer, &QTimer::timeout, this, &Radar::animationTimer);
    connect(m_safetyCheckTimer, &QTimer::timeout, this, &Radar::safetyCheckTimer);
    
    // Initialize settings
    m_qsettings = new QSettings("PUBGLoader", "Radar", this);
    
    // Initialize timestamps
    m_lastUpdateTime = QDateTime::currentDateTime();
    m_lastFrameTime = QDateTime::currentDateTime();
    m_animationStartTime = QDateTime::currentDateTime();
    m_lastSafetyCheck = QDateTime::currentDateTime();
    m_lastDetectionCheck = QDateTime::currentDateTime();
    
    // Initialize radar images
    m_radarImage = QPixmap(m_settings.size.x(), m_settings.size.y());
    m_compassImage = QPixmap(m_settings.compassSize.x(), m_settings.compassSize.y());
    
    // Load settings
    loadSettings();
}

Radar::~Radar()
{
    if (m_enabled) {
        disable();
    }
    
    if (m_processingThread && m_processingThread->isRunning()) {
        m_processingThread->quit();
        m_processingThread->wait(3000);
    }
}

void Radar::setGameInterface(GameInterface *gameInterface)
{
    m_gameInterface = gameInterface;
}

void Radar::setMemoryManager(MemoryManager *memoryManager)
{
    m_memoryManager = memoryManager;
}

void Radar::setLogger(Logger *logger)
{
    m_logger = logger;
}

void Radar::setSettings(const RadarSettings &settings)
{
    m_settings = settings;
    
    // Update timer intervals based on settings
    if (m_settings.updateRate > 0) {
        int interval = 1000 / m_settings.updateRate;
        m_updateTimer->setInterval(interval);
        m_renderTimer->setInterval(interval);
    }
    
    // Resize radar images if needed
    if (m_radarImage.size() != QSize(m_settings.size.x(), m_settings.size.y())) {
        m_radarImage = QPixmap(m_settings.size.x(), m_settings.size.y());
    }
    
    if (m_compassImage.size() != QSize(m_settings.compassSize.x(), m_settings.compassSize.y())) {
        m_compassImage = QPixmap(m_settings.compassSize.x(), m_settings.compassSize.y());
    }
    
    emit settingsChanged(m_settings);
    
    if (m_logger) {
        m_logger->log(Logger::Info, "Radar settings updated");
    }
}

RadarSettings Radar::getSettings() const
{
    return m_settings;
}

void Radar::enable()
{
    if (m_enabled) {
        return;
    }
    
    m_enabled = true;
    
    // Start timers
    m_updateTimer->start();
    m_renderTimer->start();
    m_entityScanTimer->start();
    m_zoneUpdateTimer->start();
    
    if (m_settings.enableAnimations) {
        m_animationTimer->start();
    }
    
    if (m_settings.safeMode) {
        m_safetyCheckTimer->start();
    }
    
    // Initialize threading if enabled
    if (m_settings.useThreading && !m_processingThread) {
        m_processingThread = new QThread(this);
        m_processingThread->start();
    }
    
    emit enabledChanged(true);
    
    if (m_logger) {
        m_logger->log(Logger::Info, "Radar enabled");
    }
}

void Radar::disable()
{
    if (!m_enabled) {
        return;
    }
    
    m_enabled = false;
    
    // Stop timers
    m_updateTimer->stop();
    m_renderTimer->stop();
    m_entityScanTimer->stop();
    m_zoneUpdateTimer->stop();
    m_animationTimer->stop();
    m_safetyCheckTimer->stop();
    
    // Clear data
    clearEntities();
    clearWaypoints();
    
    emit enabledChanged(false);
    
    if (m_logger) {
        m_logger->log(Logger::Info, "Radar disabled");
    }
}

void Radar::toggle()
{
    if (m_enabled) {
        disable();
    } else {
        enable();
    }
}

bool Radar::isEnabled() const
{
    return m_enabled;
}

QPixmap Radar::renderRadar()
{
    if (!m_enabled || m_settings.mode == RadarMode::Disabled) {
        return QPixmap();
    }
    
    QDateTime startTime = QDateTime::currentDateTime();
    
    // Create radar image
    QPixmap radarPixmap(m_settings.size.x(), m_settings.size.y());
    radarPixmap.fill(Qt::transparent);
    
    QPainter painter(&radarPixmap);
    painter.setRenderHint(QPainter::Antialiasing, true);
    painter.setRenderHint(QPainter::SmoothPixmapTransform, true);
    
    // Render radar components
    if (m_settings.showBackground) {
        renderRadarBackground(painter);
    }
    
    if (m_settings.useGameMap && !m_customMap.isNull()) {
        renderRadarMap(painter);
    }
    
    if (m_settings.showGrid) {
        renderRadarGrid(painter);
    }
    
    if (m_settings.showZone) {
        renderRadarZones(painter);
    }
    
    renderRadarEntities(painter);
    
    if (m_settings.showWaypoints) {
        renderRadarWaypoints(painter);
    }
    
    if (m_settings.showSelf) {
        renderRadarSelf(painter);
    }
    
    if (m_settings.showCenter) {
        renderRadarCenter(painter);
    }
    
    if (m_settings.showBorder) {
        renderRadarBorder(painter);
    }
    
    painter.end();
    
    // Update performance metrics
    m_renderingTime = startTime.msecsTo(QDateTime::currentDateTime());
    updatePerformanceMetrics();
    
    m_radarImage = radarPixmap;
    emit radarImageUpdated(m_radarImage);
    
    return radarPixmap;
}

QPixmap Radar::renderCompass()
{
    if (!m_enabled || !m_settings.showCompass || m_settings.compassMode == CompassMode::None) {
        return QPixmap();
    }
    
    QPixmap compassPixmap(m_settings.compassSize.x(), m_settings.compassSize.y());
    compassPixmap.fill(Qt::transparent);
    
    QPainter painter(&compassPixmap);
    painter.setRenderHint(QPainter::Antialiasing, true);
    
    renderCompassBackground(painter);
    renderCompassMarks(painter);
    
    if (m_settings.showCompassCardinals) {
        renderCompassCardinals(painter);
    }
    
    if (m_settings.showCompassDegrees) {
        renderCompassDegrees(painter);
    }
    
    renderCompassNeedle(painter);
    
    painter.end();
    
    m_compassImage = compassPixmap;
    emit compassImageUpdated(m_compassImage);
    
    return compassPixmap;
}

void Radar::updateRadarImage()
{
    renderRadar();
}

void Radar::updateCompassImage()
{
    renderCompass();
}

void Radar::updateEntities()
{
    if (!m_enabled || !m_gameInterface || !m_memoryManager) {
        return;
    }
    
    QMutexLocker locker(&m_entityMutex);
    
    // Scan for new entities
    QList<RadarEntity> newEntities = scanForEntities();
    
    // Update existing entities and add new ones
    for (const RadarEntity &newEntity : newEntities) {
        bool found = false;
        for (RadarEntity &existingEntity : m_entities) {
            if (existingEntity.entityId == newEntity.entityId) {
                updateEntityData(existingEntity);
                found = true;
                break;
            }
        }
        
        if (!found) {
            m_entities.append(newEntity);
            emit entityAdded(newEntity);
        }
    }
    
    // Remove entities that are no longer valid
    for (int i = m_entities.size() - 1; i >= 0; --i) {
        if (!isValidEntity(m_entities[i])) {
            quint32 entityId = m_entities[i].entityId;
            m_entities.removeAt(i);
            emit entityRemoved(entityId);
        }
    }
    
    // Update visible entities list
    m_visibleEntities.clear();
    for (const RadarEntity &entity : m_entities) {
        if (shouldDisplayEntity(entity)) {
            m_visibleEntities.append(entity);
        }
    }
    
    // Apply performance optimizations
    if (m_settings.adaptiveQuality) {
        optimizeEntityProcessing();
    }
    
    m_entityCount = m_entities.size();
    m_visibleEntityCount = m_visibleEntities.size();
}

void Radar::addEntity(const RadarEntity &entity)
{
    QMutexLocker locker(&m_entityMutex);
    m_entities.append(entity);
    emit entityAdded(entity);
}

void Radar::removeEntity(quint32 entityId)
{
    QMutexLocker locker(&m_entityMutex);
    for (int i = 0; i < m_entities.size(); ++i) {
        if (m_entities[i].entityId == entityId) {
            m_entities.removeAt(i);
            emit entityRemoved(entityId);
            break;
        }
    }
}

void Radar::clearEntities()
{
    QMutexLocker locker(&m_entityMutex);
    m_entities.clear();
    m_visibleEntities.clear();
}

QList<RadarEntity> Radar::getVisibleEntities() const
{
    QMutexLocker locker(&m_entityMutex);
    return m_visibleEntities;
}

void Radar::updateZoneInfo()
{
    if (!m_enabled || !m_gameInterface || !m_memoryManager) {
        return;
    }
    
    updateSafeZoneInfo();
    updatePlayZoneInfo();
    updateRedZoneInfo();
}

RadarZoneInfo Radar::getSafeZone() const
{
    return m_safeZone;
}

RadarZoneInfo Radar::getPlayZone() const
{
    return m_playZone;
}

RadarZoneInfo Radar::getRedZone() const
{
    return m_redZone;
}

void Radar::addWaypoint(const RadarWaypoint &waypoint)
{
    RadarWaypoint newWaypoint = waypoint;
    if (newWaypoint.id == 0) {
        newWaypoint.id = m_nextWaypointId++;
    }
    newWaypoint.created = QDateTime::currentDateTime();
    
    m_waypoints.append(newWaypoint);
    emit waypointAdded(newWaypoint);
    
    if (m_logger) {
        m_logger->log(Logger::Info, QString("Waypoint added: %1").arg(newWaypoint.name));
    }
}

void Radar::removeWaypoint(quint32 waypointId)
{
    for (int i = 0; i < m_waypoints.size(); ++i) {
        if (m_waypoints[i].id == waypointId) {
            m_waypoints.removeAt(i);
            emit waypointRemoved(waypointId);
            break;
        }
    }
}

void Radar::clearWaypoints()
{
    m_waypoints.clear();
    emit waypointsCleared();
}

QList<RadarWaypoint> Radar::getWaypoints() const
{
    return m_waypoints;
}

QVector2D Radar::worldToRadar(const QVector3D &worldPos)
{
    return calculateRadarPosition(worldPos);
}

QVector3D Radar::radarToWorld(const QVector2D &radarPos)
{
    return calculateWorldPosition(radarPos);
}

float Radar::calculateDistance(const QVector3D &pos1, const QVector3D &pos2)
{
    QVector3D diff = pos1 - pos2;
    return std::sqrt(diff.x() * diff.x() + diff.y() * diff.y() + diff.z() * diff.z());
}

float Radar::calculateDirection(const QVector3D &from, const QVector3D &to)
{
    QVector3D diff = to - from;
    return std::atan2(diff.y(), diff.x()) * 180.0f / M_PI;
}

void Radar::setZoom(float range)
{
    m_currentZoom = qBound(m_settings.minRange, range, m_settings.maxRange);
    emit zoomChanged(m_currentZoom);
}

float Radar::getZoom() const
{
    return m_currentZoom;
}

void Radar::zoomIn()
{
    setZoom(m_currentZoom * 0.8f);
}

void Radar::zoomOut()
{
    setZoom(m_currentZoom * 1.25f);
}

void Radar::resetZoom()
{
    setZoom(DEFAULT_RANGE);
}

void Radar::centerOnPlayer()
{
    if (readPlayerPosition(m_playerPosition)) {
        m_radarCenter = QVector2D(m_playerPosition.x(), m_playerPosition.y());
    }
}

void Radar::centerOnPosition(const QVector3D &position)
{
    m_radarCenter = QVector2D(position.x(), position.y());
}

// Timer slots
void Radar::updateTimer()
{
    update();
}

void Radar::renderTimer()
{
    if (m_settings.mode == RadarMode::Overlay || m_settings.mode == RadarMode::Fullscreen) {
        updateRadarImage();
    }
    
    if (m_settings.showCompass) {
        updateCompassImage();
    }
}

void Radar::entityScanTimer()
{
    updateEntities();
}

void Radar::zoneUpdateTimer()
{
    updateZoneInfo();
}

void Radar::animationTimer()
{
    if (m_settings.enableAnimations) {
        updateAnimations();
    }
}

void Radar::safetyCheckTimer()
{
    if (m_settings.safeMode) {
        performSafetyChecks();
    }
}

// Main update method
void Radar::update()
{
    if (!m_enabled) {
        return;
    }
    
    // Update player position and direction
    readPlayerPosition(m_playerPosition);
    readPlayerDirection(m_playerDirection);
    
    // Center radar on player if needed
    if (m_settings.mode != RadarMode::Picture) {
        centerOnPlayer();
    }
    
    // Update auto-zoom
    if (m_settings.autoZoom) {
        // TODO: Implement auto-zoom logic based on nearby entities
    }
    
    m_lastUpdateTime = QDateTime::currentDateTime();
    
    emit onGameUpdate();
}

// Placeholder implementations for complex methods
void Radar::renderRadarBackground(QPainter &painter)
{
    if (!m_settings.showBackground) return;
    
    painter.fillRect(0, 0, m_settings.size.x(), m_settings.size.y(), m_settings.backgroundColor);
}

void Radar::renderRadarGrid(QPainter &painter)
{
    // TODO: Implement grid rendering
}

void Radar::renderRadarBorder(QPainter &painter)
{
    if (!m_settings.showBorder) return;
    
    QPen pen(m_settings.borderColor, m_settings.borderWidth);
    painter.setPen(pen);
    
    if (m_settings.shape == RadarShape::Circle) {
        painter.drawEllipse(0, 0, m_settings.size.x(), m_settings.size.y());
    } else {
        painter.drawRect(0, 0, m_settings.size.x(), m_settings.size.y());
    }
}

void Radar::renderRadarCenter(QPainter &painter)
{
    if (!m_settings.showCenter) return;
    
    QVector2D center(m_settings.size.x() / 2, m_settings.size.y() / 2);
    painter.setPen(QPen(m_settings.centerColor, 2));
    painter.drawPoint(center.x(), center.y());
}

void Radar::renderRadarEntities(QPainter &painter)
{
    for (const RadarEntity &entity : m_visibleEntities) {
        renderEntity(painter, entity);
    }
}

void Radar::renderRadarZones(QPainter &painter)
{
    if (m_settings.showSafeZone) {
        renderSafeZone(painter);
    }
    
    if (m_settings.showPlayZone) {
        renderPlayZone(painter);
    }
    
    if (m_settings.showRedZone) {
        renderRedZone(painter);
    }
}

void Radar::renderRadarWaypoints(QPainter &painter)
{
    for (const RadarWaypoint &waypoint : m_waypoints) {
        if (waypoint.visible) {
            renderWaypoint(painter, waypoint);
        }
    }
}

void Radar::renderRadarSelf(QPainter &painter)
{
    // TODO: Implement self rendering
}

void Radar::renderRadarMap(QPainter &painter)
{
    // TODO: Implement custom map rendering
}

// Placeholder implementations for other complex methods
QList<RadarEntity> Radar::scanForEntities()
{
    QList<RadarEntity> entities;
    // TODO: Implement entity scanning
    return entities;
}

void Radar::updateEntityData(RadarEntity &entity)
{
    // TODO: Implement entity data updates
}

bool Radar::isValidEntity(const RadarEntity &entity)
{
    // TODO: Implement entity validation
    return true;
}

bool Radar::shouldDisplayEntity(const RadarEntity &entity)
{
    // TODO: Implement display filtering
    return true;
}

void Radar::renderEntity(QPainter &painter, const RadarEntity &entity)
{
    // TODO: Implement entity rendering
}

void Radar::updateSafeZoneInfo()
{
    // TODO: Implement safe zone updates
}

void Radar::updatePlayZoneInfo()
{
    // TODO: Implement play zone updates
}

void Radar::updateRedZoneInfo()
{
    // TODO: Implement red zone updates
}

void Radar::renderSafeZone(QPainter &painter)
{
    // TODO: Implement safe zone rendering
}

void Radar::renderPlayZone(QPainter &painter)
{
    // TODO: Implement play zone rendering
}

void Radar::renderRedZone(QPainter &painter)
{
    // TODO: Implement red zone rendering
}

void Radar::renderWaypoint(QPainter &painter, const RadarWaypoint &waypoint)
{
    // TODO: Implement waypoint rendering
}

QVector2D Radar::calculateRadarPosition(const QVector3D &worldPos)
{
    // TODO: Implement coordinate conversion
    return QVector2D(0, 0);
}

QVector3D Radar::calculateWorldPosition(const QVector2D &radarPos)
{
    // TODO: Implement coordinate conversion
    return QVector3D(0, 0, 0);
}

void Radar::updateAnimations()
{
    m_currentAnimationTime = m_animationStartTime.msecsTo(QDateTime::currentDateTime()) / 1000.0f;
}

void Radar::optimizeEntityProcessing()
{
    if (m_visibleEntities.size() > m_settings.maxDisplayedEntities) {
        limitDisplayedEntities();
    }
}

void Radar::limitDisplayedEntities()
{
    // Sort by distance and keep only the closest entities
    std::sort(m_visibleEntities.begin(), m_visibleEntities.end(), 
              [](const RadarEntity &a, const RadarEntity &b) {
                  return a.distance < b.distance;
              });
    
    if (m_visibleEntities.size() > m_settings.maxDisplayedEntities) {
        m_visibleEntities.resize(m_settings.maxDisplayedEntities);
    }
}

void Radar::performSafetyChecks()
{
    checkDetectionRisk();
    
    if (m_settings.hideFromScreenshots && isScreenshotActive()) {
        m_screenshotDetected = true;
        // Temporarily disable rendering
    }
    
    if (m_settings.hideFromRecording && isRecordingActive()) {
        m_recordingDetected = true;
        // Temporarily disable rendering
    }
    
    if (m_settings.disableOnAltTab && !isGameFocused()) {
        m_altTabDetected = true;
        // Temporarily disable
    }
}

void Radar::checkDetectionRisk()
{
    // TODO: Implement detection risk assessment
}

bool Radar::isScreenshotActive()
{
    // TODO: Implement screenshot detection
    return false;
}

bool Radar::isRecordingActive()
{
    // TODO: Implement recording detection
    return false;
}

bool Radar::isGameFocused()
{
    // TODO: Implement game focus detection
    return true;
}

void Radar::updatePerformanceMetrics()
{
    m_frameCount++;
    QDateTime currentTime = QDateTime::currentDateTime();
    qint64 timeDiff = m_lastFrameTime.msecsTo(currentTime);
    
    if (timeDiff > 1000) { // Update every second
        m_averageFPS = m_frameCount * 1000.0f / timeDiff;
        m_frameCount = 0;
        m_lastFrameTime = currentTime;
    }
}

// Memory reading placeholder implementations
bool Radar::readPlayerPosition(QVector3D &position)
{
    // TODO: Implement memory reading
    return false;
}

bool Radar::readPlayerDirection(float &direction)
{
    // TODO: Implement memory reading
    return false;
}

// Compass rendering placeholder implementations
void Radar::renderCompassBackground(QPainter &painter)
{
    painter.fillRect(0, 0, m_settings.compassSize.x(), m_settings.compassSize.y(), m_settings.compassColor);
}

void Radar::renderCompassMarks(QPainter &painter)
{
    // TODO: Implement compass marks
}

void Radar::renderCompassCardinals(QPainter &painter)
{
    // TODO: Implement cardinal directions
}

void Radar::renderCompassDegrees(QPainter &painter)
{
    // TODO: Implement degree markings
}

void Radar::renderCompassNeedle(QPainter &painter)
{
    // TODO: Implement compass needle
}

// Settings management
void Radar::loadSettings()
{
    // TODO: Implement settings loading from QSettings
    if (m_logger) {
        m_logger->log(Logger::Info, "Radar settings loaded");
    }
}

void Radar::saveSettings()
{
    // TODO: Implement settings saving to QSettings
    if (m_logger) {
        m_logger->log(Logger::Info, "Radar settings saved");
    }
}

void Radar::resetSettings()
{
    m_settings = RadarSettings();
    emit settingsChanged(m_settings);
    
    if (m_logger) {
        m_logger->log(Logger::Info, "Radar settings reset to defaults");
    }
}

// Slot implementations (basic stubs)
void Radar::onGameUpdate() { /* TODO */ }
void Radar::onPlayerUpdate() { /* TODO */ }
void Radar::onEntityUpdate() { /* TODO */ }
void Radar::onZoneUpdate() { /* TODO */ }
void Radar::onSettingsChanged(const RadarSettings &settings) { setSettings(settings); }
void Radar::onModeChanged(int mode) { m_settings.mode = static_cast<RadarMode>(mode); }
void Radar::onStyleChanged(int style) { m_settings.style = static_cast<RadarStyle>(style); }
void Radar::onShapeChanged(int shape) { m_settings.shape = static_cast<RadarShape>(shape); }
void Radar::onZoomLevelChanged(int level) { m_settings.zoomLevel = static_cast<RadarZoom>(level); }
void Radar::onCompassModeChanged(int mode) { m_settings.compassMode = static_cast<CompassMode>(mode); }
void Radar::onPositionChanged(const QVector2D &position) { m_settings.position = position; }
void Radar::onSizeChanged(const QVector2D &size) { m_settings.size = size; }
void Radar::onScaleChanged(float scale) { m_settings.scale = scale; }
void Radar::onOpacityChanged(float opacity) { m_settings.opacity = opacity; }
void Radar::onBackgroundColorChanged(const QColor &color) { m_settings.backgroundColor = color; }
void Radar::onBorderColorChanged(const QColor &color) { m_settings.borderColor = color; }
void Radar::onGridColorChanged(const QColor &color) { m_settings.gridColor = color; }
void Radar::onShowEnemiesToggled(bool enabled) { m_settings.showEnemies = enabled; }
void Radar::onShowTeammatesToggled(bool enabled) { m_settings.showTeammates = enabled; }
void Radar::onShowBotsToggled(bool enabled) { m_settings.showBots = enabled; }
void Radar::onShowKnockedToggled(bool enabled) { m_settings.showKnocked = enabled; }
void Radar::onShowVehiclesToggled(bool enabled) { m_settings.showVehicles = enabled; }
void Radar::onShowItemsToggled(bool enabled) { m_settings.showItems = enabled; }
void Radar::onShowAirdropsToggled(bool enabled) { m_settings.showAirdrops = enabled; }
void Radar::onShowDeathBoxesToggled(bool enabled) { m_settings.showDeathBoxes = enabled; }
void Radar::onShowZoneToggled(bool enabled) { m_settings.showZone = enabled; }
void Radar::onShowCompassToggled(bool enabled) { m_settings.showCompass = enabled; }
void Radar::onShowWaypointsToggled(bool enabled) { m_settings.showWaypoints = enabled; }
void Radar::onEnemyColorChanged(const QColor &color) { m_settings.enemyColor = color; }
void Radar::onTeammateColorChanged(const QColor &color) { m_settings.teammateColor = color; }
void Radar::onBotColorChanged(const QColor &color) { m_settings.botColor = color; }
void Radar::onKnockedColorChanged(const QColor &color) { m_settings.knockedColor = color; }
void Radar::onVehicleColorChanged(const QColor &color) { m_settings.vehicleColor = color; }
void Radar::onWeaponColorChanged(const QColor &color) { m_settings.weaponColor = color; }
void Radar::onArmorColorChanged(const QColor &color) { m_settings.armorColor = color; }
void Radar::onMedicalColorChanged(const QColor &color) { m_settings.medicalColor = color; }
void Radar::onAirdropColorChanged(const QColor &color) { m_settings.airdropColor = color; }
void Radar::onDeathBoxColorChanged(const QColor &color) { m_settings.deathBoxColor = color; }
void Radar::onSafeZoneColorChanged(const QColor &color) { m_settings.safeZoneColor = color; }
void Radar::onPlayZoneColorChanged(const QColor &color) { m_settings.playZoneColor = color; }
void Radar::onRedZoneColorChanged(const QColor &color) { m_settings.redZoneColor = color; }
void Radar::onEnemySizeChanged(float size) { m_settings.enemySize = size; }
void Radar::onTeammateSizeChanged(float size) { m_settings.teammateSize = size; }
void Radar::onBotSizeChanged(float size) { m_settings.botSize = size; }
void Radar::onKnockedSizeChanged(float size) { m_settings.knockedSize = size; }
void Radar::onVehicleSizeChanged(float size) { m_settings.vehicleSize = size; }
void Radar::onItemSizeChanged(float size) { m_settings.itemSize = size; }
void Radar::onAirdropSizeChanged(float size) { m_settings.airdropSize = size; }
void Radar::onDeathBoxSizeChanged(float size) { m_settings.deathBoxSize = size; }
void Radar::onCustomRangeChanged(float range) { m_settings.customRange = range; }
void Radar::onMinRangeChanged(float range) { m_settings.minRange = range; }
void Radar::onMaxRangeChanged(float range) { m_settings.maxRange = range; }
void Radar::onAutoZoomSpeedChanged(float speed) { m_settings.autoZoomSpeed = speed; }
void Radar::onItemRangeChanged(float range) { m_settings.itemRange = range; }
void Radar::onMaxDistanceDisplayChanged(float distance) { m_settings.maxDistanceDisplay = distance; }
void Radar::onRadarClicked(const QVector2D &position) { /* TODO: Handle radar click */ }
void Radar::onRadarDoubleClicked(const QVector2D &position) { /* TODO: Handle radar double click */ }
void Radar::onRadarRightClicked(const QVector2D &position) { /* TODO: Handle radar right click */ }
void Radar::onRadarScrolled(float delta) { /* TODO: Handle radar scroll */ }
void Radar::onRadarDragged(const QVector2D &delta) { /* TODO: Handle radar drag */ }
void Radar::onRadarResized(const QVector2D &newSize) { m_settings.size = newSize; }
void Radar::onWaypointAdded(const RadarWaypoint &waypoint) { addWaypoint(waypoint); }
void Radar::onWaypointRemoved(quint32 waypointId) { removeWaypoint(waypointId); }
void Radar::onWaypointUpdated(const RadarWaypoint &waypoint) { /* TODO: Update waypoint */ }
void Radar::onWaypointsCleared() { clearWaypoints(); }
void Radar::onEmergencyDisable() { emergencyShutdown(); }
void Radar::onSafeModeToggled(bool enabled) { m_settings.safeMode = enabled; }
void Radar::onHideFromScreenshotsToggled(bool enabled) { m_settings.hideFromScreenshots = enabled; }
void Radar::onHideFromRecordingToggled(bool enabled) { m_settings.hideFromRecording = enabled; }

// Additional toggle slots (stubs)
void Radar::onShowGridToggled(bool enabled) { m_settings.showGrid = enabled; }
void Radar::onShowBorderToggled(bool enabled) { m_settings.showBorder = enabled; }
void Radar::onShowCenterToggled(bool enabled) { m_settings.showCenter = enabled; }
void Radar::onShowBackgroundToggled(bool enabled) { m_settings.showBackground = enabled; }
void Radar::onShowSelfToggled(bool enabled) { m_settings.showSelf = enabled; }
void Radar::onSelfArrowToggled(bool enabled) { m_settings.selfArrow = enabled; }
void Radar::onShowSelfDirectionToggled(bool enabled) { m_settings.showSelfDirection = enabled; }
void Radar::onShowSelfFOVToggled(bool enabled) { m_settings.showSelfFOV = enabled; }
void Radar::onEnemyArrowsToggled(bool enabled) { m_settings.enemyArrows = enabled; }
void Radar::onShowEnemyDirectionToggled(bool enabled) { m_settings.showEnemyDirection = enabled; }
void Radar::onShowEnemyDistanceToggled(bool enabled) { m_settings.showEnemyDistance = enabled; }
void Radar::onShowEnemyHealthToggled(bool enabled) { m_settings.showEnemyHealth = enabled; }
void Radar::onShowEnemyWeaponToggled(bool enabled) { m_settings.showEnemyWeapon = enabled; }
void Radar::onShowEnemyNameToggled(bool enabled) { m_settings.showEnemyName = enabled; }
void Radar::onTeammateArrowsToggled(bool enabled) { m_settings.teammateArrows = enabled; }
void Radar::onShowTeammateDirectionToggled(bool enabled) { m_settings.showTeammateDirection = enabled; }
void Radar::onShowTeammateDistanceToggled(bool enabled) { m_settings.showTeammateDistance = enabled; }
void Radar::onShowTeammateHealthToggled(bool enabled) { m_settings.showTeammateHealth = enabled; }
void Radar::onShowTeammateWeaponToggled(bool enabled) { m_settings.showTeammateWeapon = enabled; }
void Radar::onShowTeammateNameToggled(bool enabled) { m_settings.showTeammateName = enabled; }
void Radar::onVehicleArrowsToggled(bool enabled) { m_settings.vehicleArrows = enabled; }
void Radar::onShowVehicleDirectionToggled(bool enabled) { m_settings.showVehicleDirection = enabled; }
void Radar::onShowVehicleTypeToggled(bool enabled) { m_settings.showVehicleType = enabled; }
void Radar::onShowVehicleHealthToggled(bool enabled) { m_settings.showVehicleHealth = enabled; }
void Radar::onShowEmptyVehiclesToggled(bool enabled) { m_settings.showEmptyVehicles = enabled; }
void Radar::onShowDistancesToggled(bool enabled) { m_settings.showDistances = enabled; }
void Radar::onDistanceColorCodingToggled(bool enabled) { m_settings.distanceColorCoding = enabled; }
void Radar::onEnableAnimationsToggled(bool enabled) { m_settings.enableAnimations = enabled; }
void Radar::onSmoothMovementToggled(bool enabled) { m_settings.smoothMovement = enabled; }
void Radar::onFadeInOutToggled(bool enabled) { m_settings.fadeInOut = enabled; }
void Radar::onPulseEffectsToggled(bool enabled) { m_settings.pulseEffects = enabled; }
void Radar::onRotationAnimationToggled(bool enabled) { m_settings.rotationAnimation = enabled; }
void Radar::onAutoZoomToggled(bool enabled) { m_settings.autoZoom = enabled; }
void Radar::onPredictiveTrackingToggled(bool enabled) { m_settings.predictiveTracking = enabled; }
void Radar::onShowTrailsToggled(bool enabled) { m_settings.showTrails = enabled; }
void Radar::onHeatmapToggled(bool enabled) { m_settings.heatmap = enabled; }
void Radar::onUseGameMapToggled(bool enabled) { m_settings.useGameMap = enabled; }
void Radar::onMapRotationToggled(bool enabled) { m_settings.mapRotation = enabled; }
void Radar::onMapZoomToggled(bool enabled) { m_settings.mapZoom = enabled; }

void Radar::emergencyShutdown()
{
    disable();
    emit emergencyTriggered();
    
    if (m_logger) {
        m_logger->log(Logger::Warning, "Radar emergency shutdown triggered");
    }
}

#include "radar.moc"