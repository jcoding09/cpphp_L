#include "data_manager.h"
#include <QDir>
#include <QFile>
#include <QTextStream>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QTimer>
#include <QMutexLocker>
#include <QDebug>
#include <QCryptographicHash>
#include <QDateTime>
#include <QStandardPaths>

DataManager::DataManager(QObject *parent)
    : QObject(parent)
    , m_cachePolicy(CachePolicy::Memory)
    , m_autoUpdate(false)
    , m_compressionEnabled(false)
    , m_encryptionEnabled(false)
    , m_maxCacheSize(100 * 1024 * 1024) // 100MB
    , m_maxMemoryEntries(10000)
    , m_updateInterval(300000) // 5 minutes
    , m_networkTimeout(30000) // 30 seconds
    , m_retryCount(3)
    , m_retryDelay(5000) // 5 seconds
    , m_isLoading(false)
    , m_isSaving(false)
    , m_networkManager(new QNetworkAccessManager(this))
    , m_fileWatcher(new QFileSystemWatcher(this))
    , m_updateTimer(new QTimer(this))
    , m_cleanupTimer(new QTimer(this))
{
    // Initialize data directory
    m_dataDir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/data";
    QDir().mkpath(m_dataDir);
    
    // Setup timers
    m_updateTimer->setInterval(m_updateInterval);
    connect(m_updateTimer, &QTimer::timeout, this, &DataManager::performAutoUpdate);
    
    m_cleanupTimer->setInterval(60000); // 1 minute
    connect(m_cleanupTimer, &QTimer::timeout, this, &DataManager::performCleanup);
    m_cleanupTimer->start();
    
    // Setup file watcher
    connect(m_fileWatcher, &QFileSystemWatcher::fileChanged,
            this, &DataManager::onFileChanged);
    connect(m_fileWatcher, &QFileSystemWatcher::directoryChanged,
            this, &DataManager::onDirectoryChanged);
    
    // Setup network manager
    m_networkManager->setTransferTimeout(m_networkTimeout);
    
    // Initialize statistics
    m_statistics.totalEntries = 0;
    m_statistics.memoryEntries = 0;
    m_statistics.diskEntries = 0;
    m_statistics.cacheHits = 0;
    m_statistics.cacheMisses = 0;
    m_statistics.networkRequests = 0;
    m_statistics.loadOperations = 0;
    m_statistics.saveOperations = 0;
    m_statistics.lastUpdate = QDateTime::currentDateTime();
    
    emit initialized();
}

DataManager::~DataManager()
{
    // Save any pending data
    if (m_autoUpdate) {
        saveAllCollections();
    }
    
    // Clear cache
    clearCache();
}

bool DataManager::addEntry(const QString& collectionName, const DataEntry& entry)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_collections.contains(collectionName)) {
        DataCollection collection;
        collection.name = collectionName;
        collection.created = QDateTime::currentDateTime();
        collection.modified = collection.created;
        m_collections[collectionName] = collection;
    }
    
    DataCollection& collection = m_collections[collectionName];
    collection.entries[entry.id] = entry;
    collection.modified = QDateTime::currentDateTime();
    collection.entryCount = collection.entries.size();
    
    // Update cache
    updateCache(collectionName, entry.id, entry);
    
    // Update statistics
    m_statistics.totalEntries++;
    m_statistics.memoryEntries++;
    
    emit entryAdded(collectionName, entry.id);
    emit collectionChanged(collectionName);
    
    return true;
}

bool DataManager::updateEntry(const QString& collectionName, const QString& entryId, const DataEntry& entry)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_collections.contains(collectionName)) {
        return false;
    }
    
    DataCollection& collection = m_collections[collectionName];
    if (!collection.entries.contains(entryId)) {
        return false;
    }
    
    collection.entries[entryId] = entry;
    collection.modified = QDateTime::currentDateTime();
    
    // Update cache
    updateCache(collectionName, entryId, entry);
    
    emit entryUpdated(collectionName, entryId);
    emit collectionChanged(collectionName);
    
    return true;
}

bool DataManager::removeEntry(const QString& collectionName, const QString& entryId)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_collections.contains(collectionName)) {
        return false;
    }
    
    DataCollection& collection = m_collections[collectionName];
    if (!collection.entries.contains(entryId)) {
        return false;
    }
    
    collection.entries.remove(entryId);
    collection.modified = QDateTime::currentDateTime();
    collection.entryCount = collection.entries.size();
    
    // Remove from cache
    removeFromCache(collectionName, entryId);
    
    // Update statistics
    m_statistics.totalEntries--;
    m_statistics.memoryEntries--;
    
    emit entryRemoved(collectionName, entryId);
    emit collectionChanged(collectionName);
    
    return true;
}

DataEntry DataManager::getEntry(const QString& collectionName, const QString& entryId) const
{
    QMutexLocker locker(&m_mutex);
    
    // Check cache first
    QString cacheKey = QString("%1:%2").arg(collectionName, entryId);
    if (m_cache.contains(cacheKey)) {
        m_statistics.cacheHits++;
        return m_cache[cacheKey];
    }
    
    m_statistics.cacheMisses++;
    
    if (!m_collections.contains(collectionName)) {
        return DataEntry();
    }
    
    const DataCollection& collection = m_collections[collectionName];
    if (!collection.entries.contains(entryId)) {
        return DataEntry();
    }
    
    DataEntry entry = collection.entries[entryId];
    
    // Update cache
    const_cast<DataManager*>(this)->updateCache(collectionName, entryId, entry);
    
    return entry;
}

QList<DataEntry> DataManager::getEntries(const QString& collectionName) const
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_collections.contains(collectionName)) {
        return QList<DataEntry>();
    }
    
    const DataCollection& collection = m_collections[collectionName];
    return collection.entries.values();
}

bool DataManager::loadFromFile(const QString& filePath, DataFormat format)
{
    QMutexLocker locker(&m_mutex);
    
    m_isLoading = true;
    
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) {
        m_isLoading = false;
        emit errorOccurred(QString("Failed to open file: %1").arg(filePath));
        return false;
    }
    
    QByteArray data = file.readAll();
    file.close();
    
    bool success = false;
    
    switch (format) {
        case DataFormat::JSON:
            success = loadFromJson(data);
            break;
        case DataFormat::XML:
            success = loadFromXml(data);
            break;
        case DataFormat::Binary:
            success = loadFromBinary(data);
            break;
        case DataFormat::CSV:
            success = loadFromCsv(data);
            break;
    }
    
    if (success) {
        // Add file to watcher
        if (!m_fileWatcher->files().contains(filePath)) {
            m_fileWatcher->addPath(filePath);
        }
        
        m_statistics.loadOperations++;
        emit dataLoaded(filePath);
    } else {
        emit errorOccurred(QString("Failed to load data from: %1").arg(filePath));
    }
    
    m_isLoading = false;
    return success;
}

bool DataManager::saveToFile(const QString& filePath, DataFormat format) const
{
    QMutexLocker locker(&m_mutex);
    
    const_cast<DataManager*>(this)->m_isSaving = true;
    
    QByteArray data;
    
    switch (format) {
        case DataFormat::JSON:
            data = saveToJson();
            break;
        case DataFormat::XML:
            data = saveToXml();
            break;
        case DataFormat::Binary:
            data = saveToBinary();
            break;
        case DataFormat::CSV:
            data = saveToCsv();
            break;
    }
    
    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly)) {
        const_cast<DataManager*>(this)->m_isSaving = false;
        const_cast<DataManager*>(this)->emit errorOccurred(QString("Failed to open file for writing: %1").arg(filePath));
        return false;
    }
    
    qint64 written = file.write(data);
    file.close();
    
    bool success = (written == data.size());
    
    if (success) {
        const_cast<DataManager*>(this)->m_statistics.saveOperations++;
        const_cast<DataManager*>(this)->emit dataSaved(filePath);
    } else {
        const_cast<DataManager*>(this)->emit errorOccurred(QString("Failed to save data to: %1").arg(filePath));
    }
    
    const_cast<DataManager*>(this)->m_isSaving = false;
    return success;
}

bool DataManager::loadFromJson(const QByteArray& data)
{
    QJsonParseError error;
    QJsonDocument doc = QJsonDocument::fromJson(data, &error);
    
    if (error.error != QJsonParseError::NoError) {
        emit errorOccurred(QString("JSON parse error: %1").arg(error.errorString()));
        return false;
    }
    
    QJsonObject root = doc.object();
    
    // Load collections
    QJsonObject collectionsObj = root["collections"].toObject();
    for (auto it = collectionsObj.begin(); it != collectionsObj.end(); ++it) {
        QString collectionName = it.key();
        QJsonObject collectionObj = it.value().toObject();
        
        DataCollection collection;
        collection.name = collectionName;
        collection.created = QDateTime::fromString(collectionObj["created"].toString(), Qt::ISODate);
        collection.modified = QDateTime::fromString(collectionObj["modified"].toString(), Qt::ISODate);
        collection.version = collectionObj["version"].toString();
        collection.description = collectionObj["description"].toString();
        
        // Load entries
        QJsonObject entriesObj = collectionObj["entries"].toObject();
        for (auto entryIt = entriesObj.begin(); entryIt != entriesObj.end(); ++entryIt) {
            QString entryId = entryIt.key();
            QJsonObject entryObj = entryIt.value().toObject();
            
            DataEntry entry;
            entry.id = entryId;
            entry.type = static_cast<DataType>(entryObj["type"].toInt());
            entry.source = static_cast<DataSource>(entryObj["source"].toInt());
            entry.status = static_cast<DataStatus>(entryObj["status"].toInt());
            entry.data = entryObj["data"].toVariant();
            entry.metadata = entryObj["metadata"].toVariant().toMap();
            entry.created = QDateTime::fromString(entryObj["created"].toString(), Qt::ISODate);
            entry.modified = QDateTime::fromString(entryObj["modified"].toString(), Qt::ISODate);
            entry.accessed = QDateTime::fromString(entryObj["accessed"].toString(), Qt::ISODate);
            entry.size = entryObj["size"].toInt();
            entry.checksum = entryObj["checksum"].toString();
            
            collection.entries[entryId] = entry;
        }
        
        collection.entryCount = collection.entries.size();
        m_collections[collectionName] = collection;
    }
    
    return true;
}

QByteArray DataManager::saveToJson() const
{
    QJsonObject root;
    QJsonObject collectionsObj;
    
    for (auto it = m_collections.begin(); it != m_collections.end(); ++it) {
        const QString& collectionName = it.key();
        const DataCollection& collection = it.value();
        
        QJsonObject collectionObj;
        collectionObj["created"] = collection.created.toString(Qt::ISODate);
        collectionObj["modified"] = collection.modified.toString(Qt::ISODate);
        collectionObj["version"] = collection.version;
        collectionObj["description"] = collection.description;
        
        QJsonObject entriesObj;
        for (auto entryIt = collection.entries.begin(); entryIt != collection.entries.end(); ++entryIt) {
            const QString& entryId = entryIt.key();
            const DataEntry& entry = entryIt.value();
            
            QJsonObject entryObj;
            entryObj["type"] = static_cast<int>(entry.type);
            entryObj["source"] = static_cast<int>(entry.source);
            entryObj["status"] = static_cast<int>(entry.status);
            entryObj["data"] = QJsonValue::fromVariant(entry.data);
            entryObj["metadata"] = QJsonObject::fromVariantMap(entry.metadata);
            entryObj["created"] = entry.created.toString(Qt::ISODate);
            entryObj["modified"] = entry.modified.toString(Qt::ISODate);
            entryObj["accessed"] = entry.accessed.toString(Qt::ISODate);
            entryObj["size"] = entry.size;
            entryObj["checksum"] = entry.checksum;
            
            entriesObj[entryId] = entryObj;
        }
        
        collectionObj["entries"] = entriesObj;
        collectionsObj[collectionName] = collectionObj;
    }
    
    root["collections"] = collectionsObj;
    
    QJsonDocument doc(root);
    return doc.toJson();
}

bool DataManager::loadFromXml(const QByteArray& data)
{
    // Placeholder implementation
    Q_UNUSED(data)
    return false;
}

QByteArray DataManager::saveToXml() const
{
    // Placeholder implementation
    return QByteArray();
}

bool DataManager::loadFromBinary(const QByteArray& data)
{
    // Placeholder implementation
    Q_UNUSED(data)
    return false;
}

QByteArray DataManager::saveToBinary() const
{
    // Placeholder implementation
    return QByteArray();
}

bool DataManager::loadFromCsv(const QByteArray& data)
{
    // Placeholder implementation
    Q_UNUSED(data)
    return false;
}

QByteArray DataManager::saveToCsv() const
{
    // Placeholder implementation
    return QByteArray();
}

void DataManager::updateCache(const QString& collectionName, const QString& entryId, const DataEntry& entry)
{
    QString cacheKey = QString("%1:%2").arg(collectionName, entryId);
    
    // Check cache size limit
    if (m_cache.size() >= m_maxMemoryEntries) {
        // Remove oldest entry (simple LRU)
        auto oldestIt = m_cache.begin();
        m_cache.erase(oldestIt);
    }
    
    m_cache[cacheKey] = entry;
}

void DataManager::removeFromCache(const QString& collectionName, const QString& entryId)
{
    QString cacheKey = QString("%1:%2").arg(collectionName, entryId);
    m_cache.remove(cacheKey);
}

void DataManager::clearCache()
{
    QMutexLocker locker(&m_mutex);
    m_cache.clear();
    m_statistics.memoryEntries = 0;
}

void DataManager::saveAllCollections()
{
    for (auto it = m_collections.begin(); it != m_collections.end(); ++it) {
        QString filePath = QDir(m_dataDir).filePath(it.key() + ".json");
        saveToFile(filePath, DataFormat::JSON);
    }
}

void DataManager::performAutoUpdate()
{
    if (m_autoUpdate) {
        saveAllCollections();
        emit autoUpdatePerformed();
    }
}

void DataManager::performCleanup()
{
    // Clean up expired cache entries
    QDateTime now = QDateTime::currentDateTime();
    
    for (auto it = m_cache.begin(); it != m_cache.end();) {
        const DataEntry& entry = it.value();
        if (entry.accessed.secsTo(now) > 3600) { // 1 hour
            it = m_cache.erase(it);
        } else {
            ++it;
        }
    }
}

void DataManager::onFileChanged(const QString& path)
{
    if (m_isLoading || m_isSaving) {
        return;
    }
    
    // Reload file if auto-reload is enabled
    emit fileChanged(path);
}

void DataManager::onDirectoryChanged(const QString& path)
{
    emit directoryChanged(path);
}