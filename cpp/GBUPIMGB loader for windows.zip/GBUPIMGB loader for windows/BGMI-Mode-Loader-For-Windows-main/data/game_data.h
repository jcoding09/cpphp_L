#ifndef GAME_DATA_H
#define GAME_DATA_H

#include <QtCore/QObject>
#include <QtCore/QString>
#include <QtCore/QStringList>
#include <QtCore/QVector>
#include <QtCore/QMap>
#include <QtCore/QSet>
#include <QtCore/QDateTime>
#include <QtCore/QTimer>
#include <QtCore/QMutex>
#include <QtCore/QJsonObject>
#include <QtCore/QJsonArray>
#include <QtGui/QVector2D>
#include <QtGui/QVector3D>
#include <QtGui/QColor>
#include <QtGui/QPixmap>
#include <memory>

// Forward declarations
class Logger;
class DataManager;
class EntityManager;

enum class GameMode {
    Unknown = 0,
    Classic = 1,
    Arcade = 2,
    Arena = 3,
    Training = 4,
    Custom = 5,
    Ranked = 6,
    Unranked = 7,
    Solo = 8,
    Duo = 9,
    Squad = 10,
    TeamDeathmatch = 11,
    Domination = 12,
    Payload = 13,
    Infection = 14,
    War = 15,
    Survive = 16,
    Escape = 17,
    Zombie = 18,
    Event = 19,
    Tournament = 20
};

enum class MapType {
    Unknown = 0,
    Erangel = 1,
    Miramar = 2,
    Sanhok = 3,
    Vikendi = 4,
    Karakin = 5,
    Haven = 6,
    Paramo = 7,
    Taego = 8,
    Deston = 9,
    Nusa = 10,
    Rondo = 11,
    Livik = 12,
    Varenga = 13,
    Training_Ground = 14,
    Spawn_Island = 15,
    Lobby = 16,
    Custom_Map = 17
};

enum class WeatherType {
    Unknown = 0,
    Clear = 1,
    Cloudy = 2,
    Overcast = 3,
    Foggy = 4,
    Rainy = 5,
    Stormy = 6,
    Snowy = 7,
    Sandstorm = 8,
    Night = 9,
    Dawn = 10,
    Dusk = 11,
    Dynamic = 12
};

enum class GamePhase {
    Unknown = 0,
    Lobby = 1,
    Waiting = 2,
    Starting = 3,
    Plane = 4,
    Parachute = 5,
    Playing = 6,
    Ending = 7,
    Finished = 8,
    Spectating = 9,
    Results = 10,
    Loading = 11,
    Reconnecting = 12,
    Disconnected = 13
};

enum class ZonePhase {
    Unknown = 0,
    Waiting = 1,
    Shrinking = 2,
    Static = 3,
    Final = 4,
    Finished = 5
};

enum class ItemCategory {
    Unknown = 0,
    Weapon = 1,
    Ammunition = 2,
    Attachment = 3,
    Equipment = 4,
    Consumable = 5,
    Throwable = 6,
    Armor = 7,
    Helmet = 8,
    Backpack = 9,
    Vest = 10,
    Shoes = 11,
    Gloves = 12,
    Mask = 13,
    Skin = 14,
    Vehicle = 15,
    Fuel = 16,
    Material = 17,
    Tool = 18,
    Key = 19,
    Currency = 20
};

enum class ItemRarity {
    Unknown = 0,
    Common = 1,
    Uncommon = 2,
    Rare = 3,
    Epic = 4,
    Legendary = 5,
    Mythic = 6,
    Special = 7,
    Event = 8,
    Limited = 9
};

enum class WeaponType {
    Unknown = 0,
    AssaultRifle = 1,
    SniperRifle = 2,
    SubmachineGun = 3,
    LightMachineGun = 4,
    DesignatedMarksmanRifle = 5,
    Shotgun = 6,
    Pistol = 7,
    Crossbow = 8,
    Melee = 9,
    Throwable = 10,
    Special = 11
};

enum class VehicleType {
    Unknown = 0,
    Car = 1,
    Motorcycle = 2,
    Boat = 3,
    Plane = 4,
    Helicopter = 5,
    Tank = 6,
    Truck = 7,
    Bus = 8,
    Bicycle = 9,
    Glider = 10,
    Parachute = 11,
    Jet = 12,
    Submarine = 13,
    Hovercraft = 14,
    ATV = 15
};

struct GameInfo {
    QString version;
    QString buildNumber;
    QString region;
    QString server;
    QString sessionId;
    QString matchId;
    
    GameMode mode = GameMode::Unknown;
    MapType map = MapType::Unknown;
    WeatherType weather = WeatherType::Unknown;
    GamePhase phase = GamePhase::Unknown;
    
    int maxPlayers = 100;
    int currentPlayers = 0;
    int aliveePlayers = 0;
    int teamCount = 0;
    int spectators = 0;
    
    QDateTime startTime;
    QDateTime currentTime;
    int elapsedTime = 0; // seconds
    int remainingTime = 0; // seconds
    
    bool isRanked = false;
    bool isCustom = false;
    bool isEvent = false;
    bool isTournament = false;
    
    QMap<QString, QVariant> settings;
    QMap<QString, QVariant> rules;
    QMap<QString, QVariant> metadata;
};

struct MapInfo {
    QString id;
    QString name;
    QString displayName;
    QString description;
    
    MapType type = MapType::Unknown;
    QVector2D size;
    QVector3D bounds_min;
    QVector3D bounds_max;
    QVector3D center;
    
    float scale = 1.0f;
    QString heightmapPath;
    QString minimapPath;
    QString thumbnailPath;
    
    QVector<QVector3D> spawnPoints;
    QVector<QVector3D> lootSpawns;
    QVector<QVector3D> vehicleSpawns;
    QVector<QVector3D> safeZones;
    
    QStringList landmarks;
    QStringList cities;
    QStringList regions;
    
    QMap<QString, QVariant> properties;
    QDateTime lastUpdate;
};

struct ZoneInfo {
    int phase = 0;
    ZonePhase state = ZonePhase::Unknown;
    
    QVector3D currentCenter;
    float currentRadius = 0.0f;
    QVector3D nextCenter;
    float nextRadius = 0.0f;
    
    float shrinkDuration = 0.0f;
    float waitDuration = 0.0f;
    float remainingTime = 0.0f;
    
    float damagePerSecond = 0.0f;
    float damageMultiplier = 1.0f;
    
    bool isActive = false;
    bool isShrinking = false;
    bool isInZone = false;
    
    QDateTime phaseStartTime;
    QDateTime nextPhaseTime;
    
    QVector<QVector3D> safeZoneHistory;
    QVector<float> radiusHistory;
};

struct WeatherInfo {
    WeatherType type = WeatherType::Unknown;
    QString name;
    QString description;
    
    float visibility = 1.0f;
    float fogDensity = 0.0f;
    float rainIntensity = 0.0f;
    float windSpeed = 0.0f;
    QVector3D windDirection;
    
    float temperature = 20.0f;
    float humidity = 50.0f;
    float pressure = 1013.25f;
    
    QColor skyColor;
    QColor fogColor;
    QColor sunColor;
    QVector3D sunDirection;
    
    bool isDynamic = false;
    float changeRate = 0.0f;
    QDateTime lastChange;
    
    QMap<QString, QVariant> effects;
};

struct ItemInfo {
    QString id;
    QString name;
    QString displayName;
    QString description;
    
    ItemCategory category = ItemCategory::Unknown;
    ItemRarity rarity = ItemRarity::Unknown;
    
    QString iconPath;
    QString modelPath;
    QString texturePath;
    QPixmap icon;
    
    int stackSize = 1;
    float weight = 0.0f;
    int value = 0;
    
    bool isDroppable = true;
    bool isTradeable = false;
    bool isConsumable = false;
    bool isEquippable = false;
    bool isAttachment = false;
    
    QStringList compatibleWeapons;
    QStringList requiredItems;
    QStringList effects;
    
    QMap<QString, float> stats;
    QMap<QString, QVariant> properties;
    QDateTime lastUpdate;
};

struct WeaponInfo {
    QString id;
    QString name;
    QString displayName;
    QString description;
    
    WeaponType type = WeaponType::Unknown;
    ItemRarity rarity = ItemRarity::Unknown;
    
    QString iconPath;
    QString modelPath;
    QString soundPath;
    QPixmap icon;
    
    // Damage stats
    float baseDamage = 0.0f;
    float headDamage = 0.0f;
    float chestDamage = 0.0f;
    float limbDamage = 0.0f;
    
    // Range and accuracy
    float range = 0.0f;
    float effectiveRange = 0.0f;
    float accuracy = 0.0f;
    float stability = 0.0f;
    
    // Fire rate and reload
    float fireRate = 0.0f;
    float reloadTime = 0.0f;
    float aimTime = 0.0f;
    
    // Ammunition
    QString ammoType;
    int magazineSize = 0;
    int maxAmmo = 0;
    
    // Recoil
    QVector2D recoilPattern;
    float recoilRecovery = 0.0f;
    float recoilControl = 0.0f;
    
    // Attachments
    QStringList supportedAttachments;
    QStringList defaultAttachments;
    QMap<QString, QString> attachmentSlots;
    
    // Special properties
    bool isAutomatic = false;
    bool isSingleShot = false;
    bool isBurstFire = false;
    bool hasScope = false;
    bool isSilenced = false;
    
    QMap<QString, float> stats;
    QMap<QString, QVariant> properties;
    QDateTime lastUpdate;
};

struct VehicleInfo {
    QString id;
    QString name;
    QString displayName;
    QString description;
    
    VehicleType type = VehicleType::Unknown;
    
    QString iconPath;
    QString modelPath;
    QString soundPath;
    QPixmap icon;
    
    // Performance stats
    float maxSpeed = 0.0f;
    float acceleration = 0.0f;
    float braking = 0.0f;
    float handling = 0.0f;
    
    // Durability
    float maxHealth = 100.0f;
    float armor = 0.0f;
    float fuelCapacity = 0.0f;
    float fuelConsumption = 0.0f;
    
    // Capacity
    int maxPassengers = 1;
    int maxCargo = 0;
    float cargoWeight = 0.0f;
    
    // Special features
    bool hasWeapons = false;
    bool isAmphibious = false;
    bool canFly = false;
    bool hasBoost = false;
    bool hasShield = false;
    
    QStringList weaponSlots;
    QStringList specialAbilities;
    
    QMap<QString, float> stats;
    QMap<QString, QVariant> properties;
    QDateTime lastUpdate;
};

struct PlayerRank {
    QString tier;
    QString division;
    int points = 0;
    int maxPoints = 0;
    float percentage = 0.0f;
    
    int wins = 0;
    int losses = 0;
    int draws = 0;
    int totalMatches = 0;
    
    float winRate = 0.0f;
    float kda = 0.0f;
    float averageDamage = 0.0f;
    float averageSurvivalTime = 0.0f;
    
    QString season;
    QDateTime lastUpdate;
    QDateTime seasonEnd;
    
    QMap<QString, int> achievements;
    QMap<QString, QVariant> statistics;
};

struct PlayerStats {
    // Match statistics
    int totalMatches = 0;
    int wins = 0;
    int top10 = 0;
    int top5 = 0;
    int chickenDinners = 0;
    
    // Combat statistics
    int kills = 0;
    int deaths = 0;
    int assists = 0;
    int headshots = 0;
    int knockouts = 0;
    int revives = 0;
    
    // Damage statistics
    float totalDamage = 0.0f;
    float averageDamage = 0.0f;
    float maxDamage = 0.0f;
    int damageDealt = 0;
    int damageTaken = 0;
    
    // Survival statistics
    float totalSurvivalTime = 0.0f;
    float averageSurvivalTime = 0.0f;
    float maxSurvivalTime = 0.0f;
    float longestKill = 0.0f;
    
    // Movement statistics
    float totalDistance = 0.0f;
    float walkDistance = 0.0f;
    float rideDistance = 0.0f;
    float swimDistance = 0.0f;
    
    // Weapon statistics
    QMap<QString, int> weaponKills;
    QMap<QString, float> weaponDamage;
    QMap<QString, int> weaponUses;
    QString favoriteWeapon;
    
    // Vehicle statistics
    QMap<QString, float> vehicleDistance;
    QMap<QString, int> vehicleKills;
    int vehiclesDestroyed = 0;
    
    // Calculated ratios
    float kda = 0.0f;
    float kdr = 0.0f;
    float winRate = 0.0f;
    float top10Rate = 0.0f;
    float headshotRate = 0.0f;
    
    QDateTime lastUpdate;
    QString season;
    
    QMap<QString, QVariant> customStats;
};

struct TeamInfo {
    QString id;
    QString name;
    QString tag;
    QColor color;
    
    QStringList memberIds;
    QString leaderId;
    int maxMembers = 4;
    
    int teamRank = 0;
    int teamKills = 0;
    float teamDamage = 0.0f;
    bool isAlive = true;
    
    QVector3D averagePosition;
    float teamSpread = 0.0f;
    
    QDateTime formationTime;
    QMap<QString, QVariant> properties;
};

struct MatchResult {
    QString matchId;
    QString mode;
    QString map;
    QDateTime startTime;
    QDateTime endTime;
    int duration = 0; // seconds
    
    int placement = 0;
    int totalPlayers = 0;
    int totalTeams = 0;
    
    // Player performance
    int kills = 0;
    int deaths = 0;
    int assists = 0;
    int headshots = 0;
    int knockouts = 0;
    int revives = 0;
    
    float damageDealt = 0.0f;
    float damageTaken = 0.0f;
    float healingDone = 0.0f;
    
    float survivalTime = 0.0f;
    float longestKill = 0.0f;
    float totalDistance = 0.0f;
    
    // Rewards
    int experienceGained = 0;
    int rankPointsGained = 0;
    int currencyEarned = 0;
    QStringList itemsEarned;
    QStringList achievementsUnlocked;
    
    // Team performance
    TeamInfo team;
    QMap<QString, PlayerStats> teammates;
    
    QMap<QString, QVariant> metadata;
};

struct GameStatistics {
    // Session statistics
    int sessionsPlayed = 0;
    int totalPlayTime = 0; // seconds
    int averageSessionTime = 0;
    QDateTime firstSession;
    QDateTime lastSession;
    
    // Performance statistics
    MatchResult bestMatch;
    MatchResult worstMatch;
    MatchResult lastMatch;
    
    float averageKDA = 0.0f;
    float averageDamage = 0.0f;
    float averageSurvival = 0.0f;
    float averagePlacement = 0.0f;
    
    // Progression
    PlayerRank currentRank;
    PlayerRank highestRank;
    PlayerStats overallStats;
    
    // Preferences
    QMap<QString, int> modePreferences;
    QMap<QString, int> mapPreferences;
    QMap<QString, int> weaponPreferences;
    QMap<QString, int> vehiclePreferences;
    
    // Recent activity
    QVector<MatchResult> recentMatches;
    QStringList recentAchievements;
    QStringList recentItems;
    
    QDateTime lastUpdate;
    QMap<QString, QVariant> customData;
};

class GameData : public QObject
{
    Q_OBJECT

public:
    explicit GameData(QObject *parent = nullptr);
    ~GameData();
    
    // Component integration
    void setLogger(Logger *logger);
    void setDataManager(DataManager *dataManager);
    void setEntityManager(EntityManager *entityManager);
    
    // Initialization
    bool initialize();
    void cleanup();
    bool isInitialized() const;
    
    // Game information
    GameInfo getGameInfo() const;
    void setGameInfo(const GameInfo &info);
    void updateGameInfo();
    
    // Map information
    MapInfo getMapInfo() const;
    MapInfo getMapInfo(MapType type) const;
    void setMapInfo(const MapInfo &info);
    void addMapInfo(const MapInfo &info);
    QList<MapInfo> getAllMaps() const;
    QStringList getMapNames() const;
    bool hasMap(MapType type) const;
    
    // Zone information
    ZoneInfo getZoneInfo() const;
    void setZoneInfo(const ZoneInfo &info);
    void updateZoneInfo();
    bool isInSafeZone(const QVector3D &position) const;
    float getDistanceToZone(const QVector3D &position) const;
    QVector3D getNearestSafePoint(const QVector3D &position) const;
    
    // Weather information
    WeatherInfo getWeatherInfo() const;
    void setWeatherInfo(const WeatherInfo &info);
    void updateWeatherInfo();
    
    // Item information
    ItemInfo getItemInfo(const QString &id) const;
    void addItemInfo(const ItemInfo &info);
    void updateItemInfo(const ItemInfo &info);
    QList<ItemInfo> getAllItems() const;
    QList<ItemInfo> getItemsByCategory(ItemCategory category) const;
    QList<ItemInfo> getItemsByRarity(ItemRarity rarity) const;
    QStringList getItemNames() const;
    bool hasItem(const QString &id) const;
    
    // Weapon information
    WeaponInfo getWeaponInfo(const QString &id) const;
    void addWeaponInfo(const WeaponInfo &info);
    void updateWeaponInfo(const WeaponInfo &info);
    QList<WeaponInfo> getAllWeapons() const;
    QList<WeaponInfo> getWeaponsByType(WeaponType type) const;
    QList<WeaponInfo> getWeaponsByRarity(ItemRarity rarity) const;
    QStringList getWeaponNames() const;
    bool hasWeapon(const QString &id) const;
    
    // Vehicle information
    VehicleInfo getVehicleInfo(const QString &id) const;
    void addVehicleInfo(const VehicleInfo &info);
    void updateVehicleInfo(const VehicleInfo &info);
    QList<VehicleInfo> getAllVehicles() const;
    QList<VehicleInfo> getVehiclesByType(VehicleType type) const;
    QStringList getVehicleNames() const;
    bool hasVehicle(const QString &id) const;
    
    // Player statistics
    PlayerStats getPlayerStats() const;
    PlayerStats getPlayerStats(const QString &playerId) const;
    void setPlayerStats(const PlayerStats &stats);
    void updatePlayerStats(const PlayerStats &stats);
    void addPlayerStats(const QString &playerId, const PlayerStats &stats);
    
    // Player ranking
    PlayerRank getPlayerRank() const;
    PlayerRank getPlayerRank(const QString &playerId) const;
    void setPlayerRank(const PlayerRank &rank);
    void updatePlayerRank(const PlayerRank &rank);
    void addPlayerRank(const QString &playerId, const PlayerRank &rank);
    
    // Team information
    TeamInfo getTeamInfo() const;
    TeamInfo getTeamInfo(const QString &teamId) const;
    void setTeamInfo(const TeamInfo &info);
    void addTeamInfo(const TeamInfo &info);
    QList<TeamInfo> getAllTeams() const;
    bool hasTeam(const QString &teamId) const;
    
    // Match results
    MatchResult getLastMatch() const;
    MatchResult getMatch(const QString &matchId) const;
    void addMatchResult(const MatchResult &result);
    QList<MatchResult> getRecentMatches(int count = 10) const;
    QList<MatchResult> getMatchesByMode(GameMode mode) const;
    QList<MatchResult> getMatchesByMap(MapType map) const;
    
    // Game statistics
    GameStatistics getGameStatistics() const;
    void updateGameStatistics();
    void resetGameStatistics();
    
    // Data queries
    QStringList searchItems(const QString &query) const;
    QStringList searchWeapons(const QString &query) const;
    QStringList searchVehicles(const QString &query) const;
    QList<ItemInfo> getCompatibleAttachments(const QString &weaponId) const;
    QList<WeaponInfo> getWeaponsForAmmo(const QString &ammoType) const;
    
    // Data validation
    bool validateGameInfo(const GameInfo &info) const;
    bool validateMapInfo(const MapInfo &info) const;
    bool validateItemInfo(const ItemInfo &info) const;
    bool validateWeaponInfo(const WeaponInfo &info) const;
    bool validateVehicleInfo(const VehicleInfo &info) const;
    
    // File operations
    bool loadFromFile(const QString &filename);
    bool saveToFile(const QString &filename) const;
    bool importData(const QString &filename);
    bool exportData(const QString &filename) const;
    bool loadGameData(const QString &directory);
    bool saveGameData(const QString &directory) const;
    
    // Configuration
    void setAutoUpdate(bool enabled);
    bool isAutoUpdateEnabled() const;
    void setUpdateInterval(int interval);
    int getUpdateInterval() const;
    void setCacheEnabled(bool enabled);
    bool isCacheEnabled() const;
    
    // Utility functions
    static QString gameModeToString(GameMode mode);
    static GameMode stringToGameMode(const QString &str);
    static QString mapTypeToString(MapType type);
    static MapType stringToMapType(const QString &str);
    static QString weatherTypeToString(WeatherType type);
    static WeatherType stringToWeatherType(const QString &str);
    static QString gamePhaseToString(GamePhase phase);
    static GamePhase stringToGamePhase(const QString &str);
    static QString itemCategoryToString(ItemCategory category);
    static ItemCategory stringToItemCategory(const QString &str);
    static QString itemRarityToString(ItemRarity rarity);
    static ItemRarity stringToItemRarity(const QString &str);
    static QString weaponTypeToString(WeaponType type);
    static WeaponType stringToWeaponType(const QString &str);
    static QString vehicleTypeToString(VehicleType type);
    static VehicleType stringToVehicleType(const QString &str);
    
public slots:
    // Game information slots
    void onGameInfoUpdateRequested();
    void onGameModeChanged(int mode);
    void onMapChanged(int map);
    void onWeatherChanged(int weather);
    void onPhaseChanged(int phase);
    
    // Zone slots
    void onZoneUpdateRequested();
    void onZonePhaseChanged(int phase);
    void onZoneShrinkStarted();
    void onZoneShrinkFinished();
    
    // Data management slots
    void onItemDataRequested(const QString &id);
    void onWeaponDataRequested(const QString &id);
    void onVehicleDataRequested(const QString &id);
    void onDataUpdateRequested();
    void onDataReloadRequested();
    
    // Statistics slots
    void onStatsUpdateRequested();
    void onStatsResetRequested();
    void onMatchResultAdded(const MatchResult &result);
    void onPlayerStatsChanged(const PlayerStats &stats);
    void onPlayerRankChanged(const PlayerRank &rank);
    
    // File operation slots
    void onLoadFromFileRequested(const QString &filename);
    void onSaveToFileRequested(const QString &filename);
    void onImportDataRequested(const QString &filename);
    void onExportDataRequested(const QString &filename);
    
    // Configuration slots
    void onAutoUpdateToggled(bool enabled);
    void onUpdateIntervalChanged(int interval);
    void onCacheToggled(bool enabled);
    
private slots:
    void onUpdateTimer();
    void onDataChanged();
    
signals:
    void gameInfoUpdated(const GameInfo &info);
    void gameModeChanged(GameMode oldMode, GameMode newMode);
    void mapChanged(MapType oldMap, MapType newMap);
    void weatherChanged(WeatherType oldWeather, WeatherType newWeather);
    void phaseChanged(GamePhase oldPhase, GamePhase newPhase);
    
    void mapInfoUpdated(const MapInfo &info);
    void mapAdded(const MapInfo &info);
    
    void zoneInfoUpdated(const ZoneInfo &info);
    void zonePhaseChanged(ZonePhase oldPhase, ZonePhase newPhase);
    void zoneShrinkStarted(int phase);
    void zoneShrinkFinished(int phase);
    
    void weatherInfoUpdated(const WeatherInfo &info);
    
    void itemInfoUpdated(const ItemInfo &info);
    void itemAdded(const ItemInfo &info);
    void weaponInfoUpdated(const WeaponInfo &info);
    void weaponAdded(const WeaponInfo &info);
    void vehicleInfoUpdated(const VehicleInfo &info);
    void vehicleAdded(const VehicleInfo &info);
    
    void playerStatsUpdated(const PlayerStats &stats);
    void playerRankUpdated(const PlayerRank &rank);
    void teamInfoUpdated(const TeamInfo &info);
    void matchResultAdded(const MatchResult &result);
    void gameStatisticsUpdated(const GameStatistics &stats);
    
    void dataLoaded(const QString &filename, bool success);
    void dataSaved(const QString &filename, bool success);
    void dataImported(const QString &filename, bool success, int itemCount);
    void dataExported(const QString &filename, bool success, int itemCount);
    
    void autoUpdateToggled(bool enabled);
    void updateIntervalChanged(int interval);
    void cacheToggled(bool enabled);
    
    void error(const QString &message);
    void warning(const QString &message);
    void info(const QString &message);
    
private:
    // Data conversion
    QJsonObject gameInfoToJson(const GameInfo &info) const;
    GameInfo gameInfoFromJson(const QJsonObject &json) const;
    QJsonObject mapInfoToJson(const MapInfo &info) const;
    MapInfo mapInfoFromJson(const QJsonObject &json) const;
    QJsonObject zoneInfoToJson(const ZoneInfo &info) const;
    ZoneInfo zoneInfoFromJson(const QJsonObject &json) const;
    QJsonObject weatherInfoToJson(const WeatherInfo &info) const;
    WeatherInfo weatherInfoFromJson(const QJsonObject &json) const;
    QJsonObject itemInfoToJson(const ItemInfo &info) const;
    ItemInfo itemInfoFromJson(const QJsonObject &json) const;
    QJsonObject weaponInfoToJson(const WeaponInfo &info) const;
    WeaponInfo weaponInfoFromJson(const QJsonObject &json) const;
    QJsonObject vehicleInfoToJson(const VehicleInfo &info) const;
    VehicleInfo vehicleInfoFromJson(const QJsonObject &json) const;
    QJsonObject playerStatsToJson(const PlayerStats &stats) const;
    PlayerStats playerStatsFromJson(const QJsonObject &json) const;
    QJsonObject playerRankToJson(const PlayerRank &rank) const;
    PlayerRank playerRankFromJson(const QJsonObject &json) const;
    QJsonObject teamInfoToJson(const TeamInfo &info) const;
    TeamInfo teamInfoFromJson(const QJsonObject &json) const;
    QJsonObject matchResultToJson(const MatchResult &result) const;
    MatchResult matchResultFromJson(const QJsonObject &json) const;
    
    // Data validation
    QStringList validateGameInfoInternal(const GameInfo &info) const;
    QStringList validateMapInfoInternal(const MapInfo &info) const;
    QStringList validateItemInfoInternal(const ItemInfo &info) const;
    QStringList validateWeaponInfoInternal(const WeaponInfo &info) const;
    QStringList validateVehicleInfoInternal(const VehicleInfo &info) const;
    
    // Data processing
    void updateGameStatisticsInternal();
    void calculatePlayerRatios(PlayerStats &stats) const;
    void updateTeamStatistics(TeamInfo &team) const;
    void processMatchResult(const MatchResult &result);
    
    // Cache management
    void updateCache();
    void clearCache();
    bool loadFromCache(const QString &key, QJsonObject &data) const;
    void saveToCache(const QString &key, const QJsonObject &data);
    
    // Error handling
    void handleError(const QString &operation, const QString &error);
    void handleWarning(const QString &operation, const QString &warning);
    void logOperation(const QString &operation, bool success);
    
    // Core components
    Logger *m_logger;
    DataManager *m_dataManager;
    EntityManager *m_entityManager;
    
    // Game data
    GameInfo m_gameInfo;
    QMap<MapType, MapInfo> m_maps;
    ZoneInfo m_zoneInfo;
    WeatherInfo m_weatherInfo;
    
    // Item data
    QMap<QString, ItemInfo> m_items;
    QMap<QString, WeaponInfo> m_weapons;
    QMap<QString, VehicleInfo> m_vehicles;
    
    // Player data
    QMap<QString, PlayerStats> m_playerStats;
    QMap<QString, PlayerRank> m_playerRanks;
    QMap<QString, TeamInfo> m_teams;
    
    // Match data
    QVector<MatchResult> m_matchHistory;
    GameStatistics m_gameStatistics;
    
    // Cache
    QMap<QString, QJsonObject> m_cache;
    
    // Timers
    QTimer *m_updateTimer;
    
    // Settings
    bool m_autoUpdateEnabled;
    int m_updateInterval;
    bool m_cacheEnabled;
    
    // State
    bool m_initialized;
    QMutex m_mutex;
    
    // Constants
    static const int DEFAULT_UPDATE_INTERVAL = 5000; // 5 seconds
    static const int MAX_MATCH_HISTORY = 100;
    static const int MAX_CACHE_SIZE = 1000;
};

#endif // GAME_DATA_H