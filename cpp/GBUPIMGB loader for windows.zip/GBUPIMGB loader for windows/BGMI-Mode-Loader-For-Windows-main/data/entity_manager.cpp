#include "entity_manager.h"
#include <QTimer>
#include <QMutexLocker>
#include <QDebug>
#include <QDateTime>
#include <QtMath>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>
#include <QDir>
#include <QStandardPaths>

EntityManager::EntityManager(QObject *parent)
    : QObject(parent)
    , m_maxEntities(10000)
    , m_trackingEnabled(true)
    , m_autoCleanup(true)
    , m_cleanupInterval(60000) // 1 minute
    , m_maxDistance(1000.0f)
    , m_updateInterval(100) // 100ms
    , m_memoryOptimization(true)
    , m_persistenceEnabled(false)
    , m_validationEnabled(true)
    , m_nextEntityId(1)
    , m_updateTimer(new QTimer(this))
    , m_cleanupTimer(new QTimer(this))
{
    // Initialize data directory
    m_dataDir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/entities";
    QDir().mkpath(m_dataDir);
    
    // Setup timers
    m_updateTimer->setInterval(m_updateInterval);
    connect(m_updateTimer, &QTimer::timeout, this, &EntityManager::performUpdate);
    
    m_cleanupTimer->setInterval(m_cleanupInterval);
    connect(m_cleanupTimer, &QTimer::timeout, this, &EntityManager::performCleanup);
    
    if (m_autoCleanup) {
        m_cleanupTimer->start();
    }
    
    // Initialize statistics
    m_statistics.totalEntities = 0;
    m_statistics.activeEntities = 0;
    m_statistics.trackedEntities = 0;
    m_statistics.memoryUsage = 0;
    m_statistics.updateCount = 0;
    m_statistics.lastUpdate = QDateTime::currentDateTime();
    m_statistics.averageUpdateTime = 0.0;
    m_statistics.peakEntities = 0;
    
    emit initialized();
}

EntityManager::~EntityManager()
{
    if (m_persistenceEnabled) {
        saveEntities();
    }
    
    clearAllEntities();
}

quint32 EntityManager::addEntity(const EntityData& entity)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_entities.size() >= m_maxEntities) {
        emit errorOccurred("Maximum entity limit reached");
        return 0;
    }
    
    quint32 entityId = m_nextEntityId++;
    EntityData newEntity = entity;
    newEntity.id = entityId;
    newEntity.created = QDateTime::currentDateTime();
    newEntity.lastUpdate = newEntity.created;
    
    if (m_validationEnabled && !validateEntity(newEntity)) {
        emit errorOccurred(QString("Entity validation failed for ID: %1").arg(entityId));
        return 0;
    }
    
    m_entities[entityId] = newEntity;
    
    // Add to type index
    m_typeIndex[newEntity.type].insert(entityId);
    
    // Add to team index
    m_teamIndex[newEntity.team].insert(entityId);
    
    // Update statistics
    m_statistics.totalEntities++;
    m_statistics.activeEntities++;
    if (m_statistics.activeEntities > m_statistics.peakEntities) {
        m_statistics.peakEntities = m_statistics.activeEntities;
    }
    
    emit entityAdded(entityId);
    emit statisticsChanged();
    
    return entityId;
}

bool EntityManager::updateEntity(quint32 entityId, const EntityData& entity)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_entities.contains(entityId)) {
        return false;
    }
    
    EntityData& existingEntity = m_entities[entityId];
    
    // Remove from old indices
    m_typeIndex[existingEntity.type].remove(entityId);
    m_teamIndex[existingEntity.team].remove(entityId);
    
    // Update entity
    EntityData updatedEntity = entity;
    updatedEntity.id = entityId;
    updatedEntity.created = existingEntity.created;
    updatedEntity.lastUpdate = QDateTime::currentDateTime();
    
    if (m_validationEnabled && !validateEntity(updatedEntity)) {
        // Restore indices
        m_typeIndex[existingEntity.type].insert(entityId);
        m_teamIndex[existingEntity.team].insert(entityId);
        emit errorOccurred(QString("Entity validation failed for ID: %1").arg(entityId));
        return false;
    }
    
    m_entities[entityId] = updatedEntity;
    
    // Add to new indices
    m_typeIndex[updatedEntity.type].insert(entityId);
    m_teamIndex[updatedEntity.team].insert(entityId);
    
    emit entityUpdated(entityId);
    
    return true;
}

bool EntityManager::removeEntity(quint32 entityId)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_entities.contains(entityId)) {
        return false;
    }
    
    const EntityData& entity = m_entities[entityId];
    
    // Remove from indices
    m_typeIndex[entity.type].remove(entityId);
    m_teamIndex[entity.team].remove(entityId);
    
    // Remove from groups
    for (auto& group : m_groups) {
        group.entities.remove(entityId);
    }
    
    // Remove relationships
    m_relationships.remove(entityId);
    for (auto it = m_relationships.begin(); it != m_relationships.end(); ++it) {
        it.value().remove(entityId);
    }
    
    // Remove from tracking
    m_trackedEntities.remove(entityId);
    
    // Remove entity
    m_entities.remove(entityId);
    
    // Update statistics
    m_statistics.activeEntities--;
    
    emit entityRemoved(entityId);
    emit statisticsChanged();
    
    return true;
}

EntityData EntityManager::getEntity(quint32 entityId) const
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_entities.contains(entityId)) {
        return EntityData();
    }
    
    EntityData entity = m_entities[entityId];
    
    // Update access time
    const_cast<EntityManager*>(this)->m_entities[entityId].lastAccess = QDateTime::currentDateTime();
    
    return entity;
}

QList<EntityData> EntityManager::getAllEntities() const
{
    QMutexLocker locker(&m_mutex);
    return m_entities.values();
}

QList<EntityData> EntityManager::getEntitiesByType(EntityType type) const
{
    QMutexLocker locker(&m_mutex);
    
    QList<EntityData> result;
    
    if (m_typeIndex.contains(type)) {
        const QSet<quint32>& entityIds = m_typeIndex[type];
        for (quint32 id : entityIds) {
            if (m_entities.contains(id)) {
                result.append(m_entities[id]);
            }
        }
    }
    
    return result;
}

QList<EntityData> EntityManager::getEntitiesByTeam(EntityTeam team) const
{
    QMutexLocker locker(&m_mutex);
    
    QList<EntityData> result;
    
    if (m_teamIndex.contains(team)) {
        const QSet<quint32>& entityIds = m_teamIndex[team];
        for (quint32 id : entityIds) {
            if (m_entities.contains(id)) {
                result.append(m_entities[id]);
            }
        }
    }
    
    return result;
}

QList<EntityData> EntityManager::getEntitiesInRange(const QVector3D& position, float range) const
{
    QMutexLocker locker(&m_mutex);
    
    QList<EntityData> result;
    
    for (const EntityData& entity : m_entities) {
        float distance = position.distanceToPoint(entity.transform.position);
        if (distance <= range) {
            result.append(entity);
        }
    }
    
    return result;
}

QList<EntityData> EntityManager::queryEntities(const EntityFilter& filter) const
{
    QMutexLocker locker(&m_mutex);
    
    QList<EntityData> result;
    
    for (const EntityData& entity : m_entities) {
        if (matchesFilter(entity, filter)) {
            result.append(entity);
        }
    }
    
    return result;
}

bool EntityManager::matchesFilter(const EntityData& entity, const EntityFilter& filter) const
{
    // Check type filter
    if (!filter.types.isEmpty() && !filter.types.contains(entity.type)) {
        return false;
    }
    
    // Check team filter
    if (!filter.teams.isEmpty() && !filter.teams.contains(entity.team)) {
        return false;
    }
    
    // Check state filter
    if (!filter.states.isEmpty() && !filter.states.contains(entity.state)) {
        return false;
    }
    
    // Check visibility filter
    if (!filter.visibilities.isEmpty() && !filter.visibilities.contains(entity.visibility)) {
        return false;
    }
    
    // Check position filter
    if (filter.usePositionFilter) {
        float distance = filter.centerPosition.distanceToPoint(entity.transform.position);
        if (distance < filter.minDistance || distance > filter.maxDistance) {
            return false;
        }
    }
    
    // Check health filter
    if (filter.useHealthFilter) {
        if (entity.health.current < filter.minHealth || entity.health.current > filter.maxHealth) {
            return false;
        }
    }
    
    return true;
}

quint32 EntityManager::createGroup(const QString& name, const QList<quint32>& entityIds)
{
    QMutexLocker locker(&m_mutex);
    
    quint32 groupId = m_nextGroupId++;
    
    EntityGroup group;
    group.id = groupId;
    group.name = name;
    group.created = QDateTime::currentDateTime();
    group.entities = QSet<quint32>(entityIds.begin(), entityIds.end());
    
    m_groups[groupId] = group;
    
    emit groupCreated(groupId);
    
    return groupId;
}

bool EntityManager::addToGroup(quint32 groupId, quint32 entityId)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_groups.contains(groupId) || !m_entities.contains(entityId)) {
        return false;
    }
    
    m_groups[groupId].entities.insert(entityId);
    
    emit entityAddedToGroup(groupId, entityId);
    
    return true;
}

bool EntityManager::removeFromGroup(quint32 groupId, quint32 entityId)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_groups.contains(groupId)) {
        return false;
    }
    
    bool removed = m_groups[groupId].entities.remove(entityId);
    
    if (removed) {
        emit entityRemovedFromGroup(groupId, entityId);
    }
    
    return removed;
}

bool EntityManager::addRelationship(quint32 entityId1, quint32 entityId2, EntityRelation relation)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_entities.contains(entityId1) || !m_entities.contains(entityId2)) {
        return false;
    }
    
    EntityRelationship relationship;
    relationship.entityId = entityId2;
    relationship.relation = relation;
    relationship.strength = 1.0f;
    relationship.created = QDateTime::currentDateTime();
    
    m_relationships[entityId1][entityId2] = relationship;
    
    emit relationshipAdded(entityId1, entityId2, relation);
    
    return true;
}

bool EntityManager::removeRelationship(quint32 entityId1, quint32 entityId2)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_relationships.contains(entityId1)) {
        return false;
    }
    
    bool removed = m_relationships[entityId1].remove(entityId2);
    
    if (removed) {
        emit relationshipRemoved(entityId1, entityId2);
    }
    
    return removed;
}

QList<EntityRelationship> EntityManager::getRelationships(quint32 entityId) const
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_relationships.contains(entityId)) {
        return QList<EntityRelationship>();
    }
    
    return m_relationships[entityId].values();
}

void EntityManager::startTracking(quint32 entityId)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_entities.contains(entityId)) {
        m_trackedEntities.insert(entityId);
        m_statistics.trackedEntities = m_trackedEntities.size();
        emit trackingStarted(entityId);
    }
}

void EntityManager::stopTracking(quint32 entityId)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_trackedEntities.remove(entityId)) {
        m_statistics.trackedEntities = m_trackedEntities.size();
        emit trackingStopped(entityId);
    }
}

bool EntityManager::isTracked(quint32 entityId) const
{
    QMutexLocker locker(&m_mutex);
    return m_trackedEntities.contains(entityId);
}

float EntityManager::getDistance(quint32 entityId1, quint32 entityId2) const
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_entities.contains(entityId1) || !m_entities.contains(entityId2)) {
        return -1.0f;
    }
    
    const QVector3D& pos1 = m_entities[entityId1].transform.position;
    const QVector3D& pos2 = m_entities[entityId2].transform.position;
    
    return pos1.distanceToPoint(pos2);
}

float EntityManager::getDistance2D(quint32 entityId1, quint32 entityId2) const
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_entities.contains(entityId1) || !m_entities.contains(entityId2)) {
        return -1.0f;
    }
    
    const QVector3D& pos1 = m_entities[entityId1].transform.position;
    const QVector3D& pos2 = m_entities[entityId2].transform.position;
    
    QVector2D pos1_2d(pos1.x(), pos1.z());
    QVector2D pos2_2d(pos2.x(), pos2.z());
    
    return pos1_2d.distanceToPoint(pos2_2d);
}

QVector3D EntityManager::getDirection(quint32 fromEntityId, quint32 toEntityId) const
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_entities.contains(fromEntityId) || !m_entities.contains(toEntityId)) {
        return QVector3D();
    }
    
    const QVector3D& fromPos = m_entities[fromEntityId].transform.position;
    const QVector3D& toPos = m_entities[toEntityId].transform.position;
    
    return (toPos - fromPos).normalized();
}

bool EntityManager::hasLineOfSight(quint32 entityId1, quint32 entityId2) const
{
    // Placeholder implementation - would need actual collision detection
    Q_UNUSED(entityId1)
    Q_UNUSED(entityId2)
    return true;
}

bool EntityManager::isVisible(quint32 entityId, const QVector3D& viewerPosition, const QVector3D& viewerDirection, float fov) const
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_entities.contains(entityId)) {
        return false;
    }
    
    const QVector3D& entityPos = m_entities[entityId].transform.position;
    QVector3D dirToEntity = (entityPos - viewerPosition).normalized();
    
    float angle = qAcos(QVector3D::dotProduct(viewerDirection, dirToEntity));
    float halfFov = qDegreesToRadians(fov / 2.0f);
    
    return angle <= halfFov;
}

bool EntityManager::validateEntity(const EntityData& entity) const
{
    // Basic validation
    if (entity.type == EntityType::Unknown) {
        return false;
    }
    
    if (entity.health.current < 0 || entity.health.current > entity.health.maximum) {
        return false;
    }
    
    // Add more validation rules as needed
    return true;
}

bool EntityManager::saveEntities() const
{
    QMutexLocker locker(&m_mutex);
    
    QString filePath = QDir(m_dataDir).filePath("entities.json");
    
    QJsonObject root;
    QJsonArray entitiesArray;
    
    for (const EntityData& entity : m_entities) {
        QJsonObject entityObj;
        entityObj["id"] = static_cast<int>(entity.id);
        entityObj["type"] = static_cast<int>(entity.type);
        entityObj["state"] = static_cast<int>(entity.state);
        entityObj["team"] = static_cast<int>(entity.team);
        entityObj["visibility"] = static_cast<int>(entity.visibility);
        entityObj["priority"] = static_cast<int>(entity.priority);
        
        // Transform
        QJsonObject transformObj;
        QJsonArray posArray = {entity.transform.position.x(), entity.transform.position.y(), entity.transform.position.z()};
        QJsonArray rotArray = {entity.transform.rotation.x(), entity.transform.rotation.y(), entity.transform.rotation.z()};
        QJsonArray scaleArray = {entity.transform.scale.x(), entity.transform.scale.y(), entity.transform.scale.z()};
        transformObj["position"] = posArray;
        transformObj["rotation"] = rotArray;
        transformObj["scale"] = scaleArray;
        entityObj["transform"] = transformObj;
        
        // Health
        QJsonObject healthObj;
        healthObj["current"] = entity.health.current;
        healthObj["maximum"] = entity.health.maximum;
        healthObj["shield"] = entity.health.shield;
        healthObj["maxShield"] = entity.health.maxShield;
        entityObj["health"] = healthObj;
        
        entityObj["created"] = entity.created.toString(Qt::ISODate);
        entityObj["lastUpdate"] = entity.lastUpdate.toString(Qt::ISODate);
        
        entitiesArray.append(entityObj);
    }
    
    root["entities"] = entitiesArray;
    
    QJsonDocument doc(root);
    
    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly)) {
        return false;
    }
    
    file.write(doc.toJson());
    file.close();
    
    return true;
}

bool EntityManager::loadEntities()
{
    QMutexLocker locker(&m_mutex);
    
    QString filePath = QDir(m_dataDir).filePath("entities.json");
    
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) {
        return false;
    }
    
    QByteArray data = file.readAll();
    file.close();
    
    QJsonParseError error;
    QJsonDocument doc = QJsonDocument::fromJson(data, &error);
    
    if (error.error != QJsonParseError::NoError) {
        return false;
    }
    
    QJsonObject root = doc.object();
    QJsonArray entitiesArray = root["entities"].toArray();
    
    for (const QJsonValue& value : entitiesArray) {
        QJsonObject entityObj = value.toObject();
        
        EntityData entity;
        entity.id = entityObj["id"].toInt();
        entity.type = static_cast<EntityType>(entityObj["type"].toInt());
        entity.state = static_cast<EntityState>(entityObj["state"].toInt());
        entity.team = static_cast<EntityTeam>(entityObj["team"].toInt());
        entity.visibility = static_cast<EntityVisibility>(entityObj["visibility"].toInt());
        entity.priority = static_cast<EntityPriority>(entityObj["priority"].toInt());
        
        // Transform
        QJsonObject transformObj = entityObj["transform"].toObject();
        QJsonArray posArray = transformObj["position"].toArray();
        QJsonArray rotArray = transformObj["rotation"].toArray();
        QJsonArray scaleArray = transformObj["scale"].toArray();
        
        entity.transform.position = QVector3D(posArray[0].toDouble(), posArray[1].toDouble(), posArray[2].toDouble());
        entity.transform.rotation = QVector3D(rotArray[0].toDouble(), rotArray[1].toDouble(), rotArray[2].toDouble());
        entity.transform.scale = QVector3D(scaleArray[0].toDouble(), scaleArray[1].toDouble(), scaleArray[2].toDouble());
        
        // Health
        QJsonObject healthObj = entityObj["health"].toObject();
        entity.health.current = healthObj["current"].toInt();
        entity.health.maximum = healthObj["maximum"].toInt();
        entity.health.shield = healthObj["shield"].toInt();
        entity.health.maxShield = healthObj["maxShield"].toInt();
        
        entity.created = QDateTime::fromString(entityObj["created"].toString(), Qt::ISODate);
        entity.lastUpdate = QDateTime::fromString(entityObj["lastUpdate"].toString(), Qt::ISODate);
        
        m_entities[entity.id] = entity;
        
        // Update indices
        m_typeIndex[entity.type].insert(entity.id);
        m_teamIndex[entity.team].insert(entity.id);
        
        // Update next ID
        if (entity.id >= m_nextEntityId) {
            m_nextEntityId = entity.id + 1;
        }
    }
    
    // Update statistics
    m_statistics.totalEntities = m_entities.size();
    m_statistics.activeEntities = m_entities.size();
    
    return true;
}

void EntityManager::clearAllEntities()
{
    QMutexLocker locker(&m_mutex);
    
    m_entities.clear();
    m_typeIndex.clear();
    m_teamIndex.clear();
    m_groups.clear();
    m_relationships.clear();
    m_trackedEntities.clear();
    
    // Reset statistics
    m_statistics.totalEntities = 0;
    m_statistics.activeEntities = 0;
    m_statistics.trackedEntities = 0;
    m_statistics.memoryUsage = 0;
    
    emit allEntitiesCleared();
    emit statisticsChanged();
}

void EntityManager::performUpdate()
{
    if (!m_trackingEnabled) {
        return;
    }
    
    QDateTime startTime = QDateTime::currentDateTime();
    
    QMutexLocker locker(&m_mutex);
    
    // Update tracked entities
    for (quint32 entityId : m_trackedEntities) {
        if (m_entities.contains(entityId)) {
            // Perform entity-specific updates here
            // This could include AI updates, movement prediction, etc.
        }
    }
    
    // Update statistics
    m_statistics.updateCount++;
    m_statistics.lastUpdate = QDateTime::currentDateTime();
    
    qint64 updateTime = startTime.msecsTo(m_statistics.lastUpdate);
    m_statistics.averageUpdateTime = (m_statistics.averageUpdateTime + updateTime) / 2.0;
    
    emit entitiesUpdated();
}

void EntityManager::performCleanup()
{
    QMutexLocker locker(&m_mutex);
    
    QDateTime now = QDateTime::currentDateTime();
    QList<quint32> toRemove;
    
    // Find entities that haven't been updated recently
    for (auto it = m_entities.begin(); it != m_entities.end(); ++it) {
        const EntityData& entity = it.value();
        if (entity.lastUpdate.secsTo(now) > 300) { // 5 minutes
            toRemove.append(it.key());
        }
    }
    
    // Remove stale entities
    for (quint32 entityId : toRemove) {
        removeEntity(entityId);
    }
    
    if (!toRemove.isEmpty()) {
        emit cleanupPerformed(toRemove.size());
    }
}