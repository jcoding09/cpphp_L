#include "game_data.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>
#include <QDir>
#include <QStandardPaths>
#include <QMutexLocker>
#include <QTimer>
#include <QDebug>

GameData::GameData(QObject *parent)
    : QObject(parent)
    , m_initialized(false)
    , m_autoUpdate(true)
    , m_updateInterval(1000)
    , m_cacheEnabled(true)
    , m_maxCacheSize(1000)
    , m_compressionEnabled(false)
    , m_encryptionEnabled(false)
    , m_backupEnabled(true)
    , m_maxBackups(5)
    , m_autoSave(true)
    , m_autoLoad(true)
    , m_validationEnabled(true)
    , m_networkEnabled(false)
    , m_debugMode(false)
    , m_readOnly(false)
{
    // Initialize timers
    m_updateTimer = new QTimer(this);
    m_saveTimer = new QTimer(this);
    m_cleanupTimer = new QTimer(this);
    
    // Connect timer signals
    connect(m_updateTimer, &QTimer::timeout, this, &GameData::onUpdateTimer);
    connect(m_saveTimer, &QTimer::timeout, this, &GameData::onSaveTimer);
    connect(m_cleanupTimer, &QTimer::timeout, this, &GameData::onCleanupTimer);
    
    // Initialize default data
    initializeDefaults();
}

GameData::~GameData()
{
    if (m_autoSave && m_initialized) {
        saveData();
    }
    cleanup();
}

bool GameData::initialize()
{
    QMutexLocker locker(&m_mutex);
    
    if (m_initialized) {
        return true;
    }
    
    try {
        // Create data directory
        QString dataDir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/data";
        QDir().mkpath(dataDir);
        
        // Load existing data if auto-load is enabled
        if (m_autoLoad) {
            loadData();
        }
        
        // Start timers
        if (m_autoUpdate) {
            m_updateTimer->start(m_updateInterval);
        }
        
        if (m_autoSave) {
            m_saveTimer->start(30000); // Save every 30 seconds
        }
        
        m_cleanupTimer->start(300000); // Cleanup every 5 minutes
        
        m_initialized = true;
        emit statusChanged("Game data initialized successfully");
        return true;
    }
    catch (const std::exception& e) {
        emit errorOccurred(QString("Failed to initialize game data: %1").arg(e.what()));
        return false;
    }
}

void GameData::cleanup()
{
    QMutexLocker locker(&m_mutex);
    
    // Stop timers
    if (m_updateTimer) {
        m_updateTimer->stop();
    }
    if (m_saveTimer) {
        m_saveTimer->stop();
    }
    if (m_cleanupTimer) {
        m_cleanupTimer->stop();
    }
    
    // Clear data
    m_gameInfo = GameInfo();
    m_mapInfo = MapInfo();
    m_zoneInfo = ZoneInfo();
    m_weatherInfo = WeatherInfo();
    m_itemCache.clear();
    m_weaponCache.clear();
    m_vehicleCache.clear();
    m_playerStats.clear();
    m_teamInfo.clear();
    m_matchResults.clear();
    
    m_initialized = false;
}

void GameData::initializeDefaults()
{
    // Initialize default game info
    m_gameInfo.mode = GameMode::Classic;
    m_gameInfo.phase = GamePhase::Lobby;
    m_gameInfo.playersAlive = 0;
    m_gameInfo.totalPlayers = 100;
    m_gameInfo.elapsedTime = 0;
    m_gameInfo.remainingTime = 0;
    m_gameInfo.serverRegion = "Unknown";
    m_gameInfo.gameVersion = "1.0.0";
    m_gameInfo.tickRate = 60;
    m_gameInfo.ping = 0;
    m_gameInfo.fps = 0;
    
    // Initialize default map info
    m_mapInfo.type = MapType::Erangel;
    m_mapInfo.name = "Erangel";
    m_mapInfo.size = QSizeF(8000, 8000);
    m_mapInfo.scale = 1.0f;
    m_mapInfo.bounds = QRectF(0, 0, 8000, 8000);
    m_mapInfo.spawnPoints.clear();
    m_mapInfo.landmarks.clear();
    m_mapInfo.safeZones.clear();
    m_mapInfo.redZones.clear();
    
    // Initialize default zone info
    m_zoneInfo.phase = ZonePhase::Safe;
    m_zoneInfo.currentZone = QRectF();
    m_zoneInfo.nextZone = QRectF();
    m_zoneInfo.shrinkTime = 0;
    m_zoneInfo.waitTime = 0;
    m_zoneInfo.damage = 0.0f;
    m_zoneInfo.speed = 0.0f;
    
    // Initialize default weather info
    m_weatherInfo.type = WeatherType::Clear;
    m_weatherInfo.visibility = 1.0f;
    m_weatherInfo.windSpeed = 0.0f;
    m_weatherInfo.windDirection = 0.0f;
    m_weatherInfo.temperature = 20.0f;
    m_weatherInfo.humidity = 50.0f;
    m_weatherInfo.pressure = 1013.25f;
}

// Game Info Management
void GameData::updateGameInfo(const GameInfo& info)
{
    QMutexLocker locker(&m_mutex);
    m_gameInfo = info;
    emit gameInfoUpdated(info);
}

GameInfo GameData::getGameInfo() const
{
    QMutexLocker locker(&m_mutex);
    return m_gameInfo;
}

void GameData::setGameMode(GameMode mode)
{
    QMutexLocker locker(&m_mutex);
    if (m_gameInfo.mode != mode) {
        m_gameInfo.mode = mode;
        emit gameModeChanged(mode);
    }
}

GameMode GameData::getGameMode() const
{
    QMutexLocker locker(&m_mutex);
    return m_gameInfo.mode;
}

void GameData::setGamePhase(GamePhase phase)
{
    QMutexLocker locker(&m_mutex);
    if (m_gameInfo.phase != phase) {
        m_gameInfo.phase = phase;
        emit gamePhaseChanged(phase);
    }
}

GamePhase GameData::getGamePhase() const
{
    QMutexLocker locker(&m_mutex);
    return m_gameInfo.phase;
}

// Map Info Management
void GameData::updateMapInfo(const MapInfo& info)
{
    QMutexLocker locker(&m_mutex);
    m_mapInfo = info;
    emit mapInfoUpdated(info);
}

MapInfo GameData::getMapInfo() const
{
    QMutexLocker locker(&m_mutex);
    return m_mapInfo;
}

void GameData::setMapType(MapType type)
{
    QMutexLocker locker(&m_mutex);
    if (m_mapInfo.type != type) {
        m_mapInfo.type = type;
        emit mapTypeChanged(type);
    }
}

MapType GameData::getMapType() const
{
    QMutexLocker locker(&m_mutex);
    return m_mapInfo.type;
}

// Zone Info Management
void GameData::updateZoneInfo(const ZoneInfo& info)
{
    QMutexLocker locker(&m_mutex);
    m_zoneInfo = info;
    emit zoneInfoUpdated(info);
}

ZoneInfo GameData::getZoneInfo() const
{
    QMutexLocker locker(&m_mutex);
    return m_zoneInfo;
}

void GameData::setZonePhase(ZonePhase phase)
{
    QMutexLocker locker(&m_mutex);
    if (m_zoneInfo.phase != phase) {
        m_zoneInfo.phase = phase;
        emit zonePhaseChanged(phase);
    }
}

ZonePhase GameData::getZonePhase() const
{
    QMutexLocker locker(&m_mutex);
    return m_zoneInfo.phase;
}

// Weather Info Management
void GameData::updateWeatherInfo(const WeatherInfo& info)
{
    QMutexLocker locker(&m_mutex);
    m_weatherInfo = info;
    emit weatherInfoUpdated(info);
}

WeatherInfo GameData::getWeatherInfo() const
{
    QMutexLocker locker(&m_mutex);
    return m_weatherInfo;
}

void GameData::setWeatherType(WeatherType type)
{
    QMutexLocker locker(&m_mutex);
    if (m_weatherInfo.type != type) {
        m_weatherInfo.type = type;
        emit weatherTypeChanged(type);
    }
}

WeatherType GameData::getWeatherType() const
{
    QMutexLocker locker(&m_mutex);
    return m_weatherInfo.type;
}

// Item Management
void GameData::addItem(const ItemInfo& item)
{
    QMutexLocker locker(&m_mutex);
    m_itemCache[item.id] = item;
    emit itemAdded(item);
}

void GameData::updateItem(const ItemInfo& item)
{
    QMutexLocker locker(&m_mutex);
    if (m_itemCache.contains(item.id)) {
        m_itemCache[item.id] = item;
        emit itemUpdated(item);
    }
}

void GameData::removeItem(int itemId)
{
    QMutexLocker locker(&m_mutex);
    if (m_itemCache.remove(itemId)) {
        emit itemRemoved(itemId);
    }
}

ItemInfo GameData::getItem(int itemId) const
{
    QMutexLocker locker(&m_mutex);
    return m_itemCache.value(itemId, ItemInfo());
}

QList<ItemInfo> GameData::getItems() const
{
    QMutexLocker locker(&m_mutex);
    return m_itemCache.values();
}

QList<ItemInfo> GameData::getItemsByCategory(ItemCategory category) const
{
    QMutexLocker locker(&m_mutex);
    QList<ItemInfo> result;
    for (const auto& item : m_itemCache) {
        if (item.category == category) {
            result.append(item);
        }
    }
    return result;
}

// Data Persistence
bool GameData::saveData(const QString& filename)
{
    QMutexLocker locker(&m_mutex);
    
    try {
        QString filePath = filename.isEmpty() ? getDefaultDataPath() : filename;
        
        QJsonObject root;
        
        // Save game info
        QJsonObject gameObj;
        gameObj["mode"] = static_cast<int>(m_gameInfo.mode);
        gameObj["phase"] = static_cast<int>(m_gameInfo.phase);
        gameObj["playersAlive"] = m_gameInfo.playersAlive;
        gameObj["totalPlayers"] = m_gameInfo.totalPlayers;
        gameObj["elapsedTime"] = static_cast<qint64>(m_gameInfo.elapsedTime);
        gameObj["remainingTime"] = static_cast<qint64>(m_gameInfo.remainingTime);
        gameObj["serverRegion"] = m_gameInfo.serverRegion;
        gameObj["gameVersion"] = m_gameInfo.gameVersion;
        gameObj["tickRate"] = m_gameInfo.tickRate;
        gameObj["ping"] = m_gameInfo.ping;
        gameObj["fps"] = m_gameInfo.fps;
        root["gameInfo"] = gameObj;
        
        // Save map info
        QJsonObject mapObj;
        mapObj["type"] = static_cast<int>(m_mapInfo.type);
        mapObj["name"] = m_mapInfo.name;
        mapObj["width"] = m_mapInfo.size.width();
        mapObj["height"] = m_mapInfo.size.height();
        mapObj["scale"] = m_mapInfo.scale;
        root["mapInfo"] = mapObj;
        
        // Save zone info
        QJsonObject zoneObj;
        zoneObj["phase"] = static_cast<int>(m_zoneInfo.phase);
        zoneObj["shrinkTime"] = static_cast<qint64>(m_zoneInfo.shrinkTime);
        zoneObj["waitTime"] = static_cast<qint64>(m_zoneInfo.waitTime);
        zoneObj["damage"] = m_zoneInfo.damage;
        zoneObj["speed"] = m_zoneInfo.speed;
        root["zoneInfo"] = zoneObj;
        
        // Save weather info
        QJsonObject weatherObj;
        weatherObj["type"] = static_cast<int>(m_weatherInfo.type);
        weatherObj["visibility"] = m_weatherInfo.visibility;
        weatherObj["windSpeed"] = m_weatherInfo.windSpeed;
        weatherObj["windDirection"] = m_weatherInfo.windDirection;
        weatherObj["temperature"] = m_weatherInfo.temperature;
        weatherObj["humidity"] = m_weatherInfo.humidity;
        weatherObj["pressure"] = m_weatherInfo.pressure;
        root["weatherInfo"] = weatherObj;
        
        // Save items
        QJsonArray itemsArray;
        for (const auto& item : m_itemCache) {
            QJsonObject itemObj;
            itemObj["id"] = item.id;
            itemObj["name"] = item.name;
            itemObj["category"] = static_cast<int>(item.category);
            itemObj["rarity"] = static_cast<int>(item.rarity);
            itemObj["damage"] = item.damage;
            itemObj["range"] = item.range;
            itemObj["weight"] = item.weight;
            itemObj["stackSize"] = item.stackSize;
            itemsArray.append(itemObj);
        }
        root["items"] = itemsArray;
        
        // Write to file
        QJsonDocument doc(root);
        QFile file(filePath);
        if (!file.open(QIODevice::WriteOnly)) {
            emit errorOccurred(QString("Failed to open file for writing: %1").arg(filePath));
            return false;
        }
        
        file.write(doc.toJson());
        file.close();
        
        emit dataSaved(filePath);
        return true;
    }
    catch (const std::exception& e) {
        emit errorOccurred(QString("Failed to save data: %1").arg(e.what()));
        return false;
    }
}

bool GameData::loadData(const QString& filename)
{
    QMutexLocker locker(&m_mutex);
    
    try {
        QString filePath = filename.isEmpty() ? getDefaultDataPath() : filename;
        
        QFile file(filePath);
        if (!file.exists()) {
            return true; // Not an error if file doesn't exist
        }
        
        if (!file.open(QIODevice::ReadOnly)) {
            emit errorOccurred(QString("Failed to open file for reading: %1").arg(filePath));
            return false;
        }
        
        QByteArray data = file.readAll();
        file.close();
        
        QJsonParseError error;
        QJsonDocument doc = QJsonDocument::fromJson(data, &error);
        if (error.error != QJsonParseError::NoError) {
            emit errorOccurred(QString("JSON parse error: %1").arg(error.errorString()));
            return false;
        }
        
        QJsonObject root = doc.object();
        
        // Load game info
        if (root.contains("gameInfo")) {
            QJsonObject gameObj = root["gameInfo"].toObject();
            m_gameInfo.mode = static_cast<GameMode>(gameObj["mode"].toInt());
            m_gameInfo.phase = static_cast<GamePhase>(gameObj["phase"].toInt());
            m_gameInfo.playersAlive = gameObj["playersAlive"].toInt();
            m_gameInfo.totalPlayers = gameObj["totalPlayers"].toInt();
            m_gameInfo.elapsedTime = gameObj["elapsedTime"].toVariant().toULongLong();
            m_gameInfo.remainingTime = gameObj["remainingTime"].toVariant().toULongLong();
            m_gameInfo.serverRegion = gameObj["serverRegion"].toString();
            m_gameInfo.gameVersion = gameObj["gameVersion"].toString();
            m_gameInfo.tickRate = gameObj["tickRate"].toInt();
            m_gameInfo.ping = gameObj["ping"].toInt();
            m_gameInfo.fps = gameObj["fps"].toInt();
        }
        
        // Load items
        if (root.contains("items")) {
            QJsonArray itemsArray = root["items"].toArray();
            m_itemCache.clear();
            for (const auto& value : itemsArray) {
                QJsonObject itemObj = value.toObject();
                ItemInfo item;
                item.id = itemObj["id"].toInt();
                item.name = itemObj["name"].toString();
                item.category = static_cast<ItemCategory>(itemObj["category"].toInt());
                item.rarity = static_cast<ItemRarity>(itemObj["rarity"].toInt());
                item.damage = itemObj["damage"].toDouble();
                item.range = itemObj["range"].toDouble();
                item.weight = itemObj["weight"].toDouble();
                item.stackSize = itemObj["stackSize"].toInt();
                m_itemCache[item.id] = item;
            }
        }
        
        emit dataLoaded(filePath);
        return true;
    }
    catch (const std::exception& e) {
        emit errorOccurred(QString("Failed to load data: %1").arg(e.what()));
        return false;
    }
}

QString GameData::getDefaultDataPath() const
{
    QString dataDir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/data";
    return dataDir + "/game_data.json";
}

// Utility Functions
QString GameData::gameModeToString(GameMode mode)
{
    switch (mode) {
        case GameMode::Classic: return "Classic";
        case GameMode::Arcade: return "Arcade";
        case GameMode::Arena: return "Arena";
        case GameMode::Training: return "Training";
        case GameMode::Custom: return "Custom";
        default: return "Unknown";
    }
}

QString GameData::mapTypeToString(MapType type)
{
    switch (type) {
        case MapType::Erangel: return "Erangel";
        case MapType::Miramar: return "Miramar";
        case MapType::Sanhok: return "Sanhok";
        case MapType::Vikendi: return "Vikendi";
        case MapType::Karakin: return "Karakin";
        case MapType::Paramo: return "Paramo";
        case MapType::Haven: return "Haven";
        case MapType::Taego: return "Taego";
        case MapType::Deston: return "Deston";
        default: return "Unknown";
    }
}

QString GameData::weatherTypeToString(WeatherType type)
{
    switch (type) {
        case WeatherType::Clear: return "Clear";
        case WeatherType::Cloudy: return "Cloudy";
        case WeatherType::Rainy: return "Rainy";
        case WeatherType::Foggy: return "Foggy";
        case WeatherType::Stormy: return "Stormy";
        case WeatherType::Snowy: return "Snowy";
        default: return "Unknown";
    }
}

// Slot implementations
void GameData::onUpdateTimer()
{
    // Placeholder for periodic updates
    emit statusChanged("Game data updated");
}

void GameData::onSaveTimer()
{
    if (m_autoSave) {
        saveData();
    }
}

void GameData::onCleanupTimer()
{
    // Cleanup old cache entries if needed
    if (m_cacheEnabled && m_itemCache.size() > m_maxCacheSize) {
        // Remove oldest entries (simplified implementation)
        while (m_itemCache.size() > m_maxCacheSize * 0.8) {
            auto it = m_itemCache.begin();
            m_itemCache.erase(it);
        }
    }
}

void GameData::onSettingsChanged()
{
    // Reload settings if needed
    emit statusChanged("Settings updated");
}

void GameData::onNetworkReply()
{
    // Handle network responses
    emit statusChanged("Network data received");
}

void GameData::onFileChanged(const QString& path)
{
    // Handle file system changes
    if (m_autoLoad) {
        loadData(path);
    }
}

void GameData::onCacheCleared()
{
    QMutexLocker locker(&m_mutex);
    m_itemCache.clear();
    m_weaponCache.clear();
    m_vehicleCache.clear();
    emit statusChanged("Cache cleared");
}

void GameData::onDataValidated()
{
    emit statusChanged("Data validation completed");
}

void GameData::onBackupCreated()
{
    emit statusChanged("Backup created");
}

void GameData::onCompressionToggled(bool enabled)
{
    m_compressionEnabled = enabled;
    emit statusChanged(enabled ? "Compression enabled" : "Compression disabled");
}

void GameData::onEncryptionToggled(bool enabled)
{
    m_encryptionEnabled = enabled;
    emit statusChanged(enabled ? "Encryption enabled" : "Encryption disabled");
}

void GameData::onDebugModeToggled(bool enabled)
{
    m_debugMode = enabled;
    emit statusChanged(enabled ? "Debug mode enabled" : "Debug mode disabled");
}

void GameData::onReadOnlyModeToggled(bool enabled)
{
    m_readOnly = enabled;
    emit statusChanged(enabled ? "Read-only mode enabled" : "Read-only mode disabled");
}