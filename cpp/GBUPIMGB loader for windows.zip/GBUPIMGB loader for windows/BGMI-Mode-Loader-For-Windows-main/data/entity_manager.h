#ifndef ENTITY_MANAGER_H
#define ENTITY_MANAGER_H

#include <QtCore/QObject>
#include <QtCore/QString>
#include <QtCore/QStringList>
#include <QtCore/QVector>
#include <QtCore/QMap>
#include <QtCore/QSet>
#include <QtCore/QDateTime>
#include <QtCore/QTimer>
#include <QtCore/QMutex>
#include <QtCore/QThread>
#include <QtGui/QVector2D>
#include <QtGui/QVector3D>
#include <QtGui/QQuaternion>
#include <QtGui/QMatrix4x4>
#include <memory>

// Forward declarations
class Logger;
class MemoryManager;
class GameInterface;
class DataManager;

enum class EntityType {
    Unknown = 0,
    Player = 1,
    Bot = 2,
    Vehicle = 3,
    Weapon = 4,
    Item = 5,
    Loot = 6,
    Building = 7,
    Obstacle = 8,
    Zone = 9,
    Projectile = 10,
    Effect = 11,
    Pickup = 12,
    Container = 13,
    Door = 14,
    Window = 15,
    Trap = 16,
    Grenade = 17,
    Smoke = 18,
    Marker = 19,
    Waypoint = 20
};

enum class EntityState {
    Unknown = 0,
    Active = 1,
    Inactive = 2,
    Destroyed = 3,
    Hidden = 4,
    Moving = 5,
    Stationary = 6,
    Attacking = 7,
    Defending = 8,
    Looting = 9,
    Healing = 10,
    Reloading = 11,
    Aiming = 12,
    Crouching = 13,
    Prone = 14,
    Jumping = 15,
    Swimming = 16,
    Parachuting = 17,
    Driving = 18,
    Dead = 19
};

enum class EntityTeam {
    Unknown = 0,
    Self = 1,
    Teammate = 2,
    Enemy = 3,
    Neutral = 4,
    Spectator = 5
};

enum class EntityVisibility {
    Unknown = 0,
    Visible = 1,
    Hidden = 2,
    Occluded = 3,
    OutOfRange = 4,
    BehindWall = 5,
    InSmoke = 6,
    Underground = 7,
    InVehicle = 8
};

enum class EntityPriority {
    VeryLow = 0,
    Low = 1,
    Normal = 2,
    High = 3,
    VeryHigh = 4,
    Critical = 5
};

enum class EntityRelation {
    None = 0,
    Parent = 1,
    Child = 2,
    Sibling = 3,
    Owner = 4,
    Owned = 5,
    Attached = 6,
    Container = 7,
    Contained = 8,
    Target = 9,
    Targeting = 10
};

struct EntityTransform {
    QVector3D position;
    QVector3D rotation;
    QVector3D scale = QVector3D(1.0f, 1.0f, 1.0f);
    QQuaternion orientation;
    QMatrix4x4 matrix;
    
    QVector3D velocity;
    QVector3D acceleration;
    QVector3D angularVelocity;
    
    QVector3D localPosition;
    QVector3D localRotation;
    QVector3D localScale = QVector3D(1.0f, 1.0f, 1.0f);
    
    bool isDirty = true;
    QDateTime lastUpdate;
};

struct EntityBounds {
    QVector3D min;
    QVector3D max;
    QVector3D center;
    QVector3D size;
    float radius = 0.0f;
    
    QVector3D localMin;
    QVector3D localMax;
    QVector3D localCenter;
    QVector3D localSize;
    float localRadius = 0.0f;
    
    bool isValid = false;
    QDateTime lastUpdate;
};

struct EntityHealth {
    float current = 100.0f;
    float maximum = 100.0f;
    float percentage = 100.0f;
    
    float armor = 0.0f;
    float maxArmor = 0.0f;
    float armorPercentage = 0.0f;
    
    float shield = 0.0f;
    float maxShield = 0.0f;
    float shieldPercentage = 0.0f;
    
    bool isAlive = true;
    bool isInvulnerable = false;
    bool isRegenerating = false;
    
    float regenRate = 0.0f;
    QDateTime lastDamage;
    QDateTime lastHeal;
};

struct EntityWeapon {
    QString id;
    QString name;
    QString type;
    QString category;
    
    int currentAmmo = 0;
    int maxAmmo = 0;
    int totalAmmo = 0;
    QString ammoType;
    
    float damage = 0.0f;
    float range = 0.0f;
    float accuracy = 0.0f;
    float fireRate = 0.0f;
    float reloadTime = 0.0f;
    
    bool isReloading = false;
    bool isFiring = false;
    bool isAiming = false;
    bool hasAmmo = false;
    
    QStringList attachments;
    QDateTime lastFired;
    QDateTime lastReload;
};

struct EntityInventory {
    QMap<QString, int> items;
    QStringList weapons;
    QStringList equipment;
    QStringList consumables;
    
    int capacity = 0;
    int usedSlots = 0;
    float weight = 0.0f;
    float maxWeight = 0.0f;
    
    QString activeWeapon;
    QString secondaryWeapon;
    QString meleeWeapon;
    QString throwable;
    
    QDateTime lastUpdate;
};

struct EntityMovement {
    QVector3D velocity;
    QVector3D acceleration;
    QVector3D direction;
    
    float speed = 0.0f;
    float maxSpeed = 0.0f;
    float walkSpeed = 0.0f;
    float runSpeed = 0.0f;
    float crouchSpeed = 0.0f;
    float proneSpeed = 0.0f;
    
    bool isMoving = false;
    bool isRunning = false;
    bool isWalking = false;
    bool isCrouching = false;
    bool isProne = false;
    bool isJumping = false;
    bool isFalling = false;
    bool isSwimming = false;
    
    QDateTime lastMovement;
};

struct EntityVision {
    float viewDistance = 0.0f;
    float fieldOfView = 0.0f;
    QVector3D viewDirection;
    QVector3D lookAt;
    
    bool canSee = false;
    bool isLookingAt = false;
    bool hasLineOfSight = false;
    
    QSet<QString> visibleEntities;
    QSet<QString> occludedEntities;
    
    QDateTime lastUpdate;
};

struct EntityAI {
    QString behavior;
    QString state;
    QString target;
    
    float aggroRange = 0.0f;
    float alertLevel = 0.0f;
    float suspicion = 0.0f;
    
    bool isAggressive = false;
    bool isAlert = false;
    bool isPatrolling = false;
    bool isSearching = false;
    bool isChasing = false;
    bool isAttacking = false;
    
    QVector<QVector3D> patrolPoints;
    QVector3D lastKnownPosition;
    QDateTime lastSeen;
};

struct EntityRelationship {
    QString entityId;
    EntityRelation relation = EntityRelation::None;
    float strength = 0.0f;
    bool isActive = true;
    QDateTime created;
    QDateTime lastUpdate;
    QMap<QString, QVariant> properties;
};

struct EntityData {
    QString id;
    QString name;
    QString displayName;
    QString description;
    
    EntityType type = EntityType::Unknown;
    EntityState state = EntityState::Unknown;
    EntityTeam team = EntityTeam::Unknown;
    EntityVisibility visibility = EntityVisibility::Unknown;
    EntityPriority priority = EntityPriority::Normal;
    
    EntityTransform transform;
    EntityBounds bounds;
    EntityHealth health;
    EntityWeapon weapon;
    EntityInventory inventory;
    EntityMovement movement;
    EntityVision vision;
    EntityAI ai;
    
    QVector<EntityRelationship> relationships;
    
    uintptr_t memoryAddress = 0;
    QMap<QString, uintptr_t> offsets;
    QMap<QString, QVariant> properties;
    QMap<QString, QVariant> metadata;
    
    bool isValid = false;
    bool isTracked = false;
    bool isPersistent = false;
    bool isImportant = false;
    
    float distance = 0.0f;
    float angle = 0.0f;
    QVector2D screenPosition;
    
    QDateTime created;
    QDateTime lastSeen;
    QDateTime lastUpdate;
    
    int updateCount = 0;
    qint64 totalUpdateTime = 0;
    qint64 averageUpdateTime = 0;
};

struct EntityFilter {
    QString name;
    QString description;
    
    QSet<EntityType> types;
    QSet<EntityState> states;
    QSet<EntityTeam> teams;
    QSet<EntityVisibility> visibilities;
    QSet<EntityPriority> priorities;
    
    float minDistance = 0.0f;
    float maxDistance = 0.0f;
    float minHealth = 0.0f;
    float maxHealth = 100.0f;
    
    bool includeAlive = true;
    bool includeDead = false;
    bool includeVisible = true;
    bool includeHidden = false;
    bool includeMoving = true;
    bool includeStationary = true;
    
    QStringList requiredProperties;
    QStringList excludedProperties;
    QMap<QString, QVariant> propertyFilters;
    
    QString customFilter;
    bool isActive = true;
    QDateTime created;
};

struct EntityGroup {
    QString id;
    QString name;
    QString description;
    
    QSet<QString> entityIds;
    EntityFilter filter;
    
    bool autoUpdate = true;
    int updateInterval = 1000; // ms
    
    QDateTime created;
    QDateTime lastUpdate;
    
    QMap<QString, QVariant> properties;
};

struct EntityStatistics {
    int totalEntities = 0;
    int activeEntities = 0;
    int trackedEntities = 0;
    int visibleEntities = 0;
    
    QMap<EntityType, int> typeCount;
    QMap<EntityState, int> stateCount;
    QMap<EntityTeam, int> teamCount;
    QMap<EntityVisibility, int> visibilityCount;
    
    int updateOperations = 0;
    int addOperations = 0;
    int removeOperations = 0;
    int queryOperations = 0;
    
    qint64 totalUpdateTime = 0;
    qint64 averageUpdateTime = 0;
    qint64 maxUpdateTime = 0;
    qint64 minUpdateTime = 0;
    
    float averageDistance = 0.0f;
    float maxDistance = 0.0f;
    float minDistance = 0.0f;
    
    QDateTime lastReset;
    QDateTime lastUpdate;
    
    QStringList mostActiveEntities;
    QStringList recentlyAdded;
    QStringList recentlyRemoved;
};

class EntityManager : public QObject
{
    Q_OBJECT

public:
    explicit EntityManager(QObject *parent = nullptr);
    ~EntityManager();
    
    // Component integration
    void setLogger(Logger *logger);
    void setMemoryManager(MemoryManager *memoryManager);
    void setGameInterface(GameInterface *gameInterface);
    void setDataManager(DataManager *dataManager);
    
    // Initialization
    bool initialize();
    void cleanup();
    bool isInitialized() const;
    
    // Entity management
    bool addEntity(const EntityData &entity);
    bool updateEntity(const QString &id, const EntityData &entity);
    bool removeEntity(const QString &id);
    EntityData getEntity(const QString &id) const;
    bool hasEntity(const QString &id) const;
    QStringList getEntityIds() const;
    QStringList getEntityIds(EntityType type) const;
    QStringList getEntityIds(EntityTeam team) const;
    QStringList getEntityIds(EntityState state) const;
    
    // Entity queries
    QList<EntityData> getAllEntities() const;
    QList<EntityData> getEntitiesByType(EntityType type) const;
    QList<EntityData> getEntitiesByTeam(EntityTeam team) const;
    QList<EntityData> getEntitiesByState(EntityState state) const;
    QList<EntityData> getEntitiesByVisibility(EntityVisibility visibility) const;
    QList<EntityData> getEntitiesByPriority(EntityPriority priority) const;
    QList<EntityData> getEntitiesInRange(const QVector3D &position, float range) const;
    QList<EntityData> getEntitiesInRadius(const QVector3D &center, float radius) const;
    QList<EntityData> getEntitiesInBounds(const QVector3D &min, const QVector3D &max) const;
    QList<EntityData> getVisibleEntities() const;
    QList<EntityData> getAliveEntities() const;
    QList<EntityData> getMovingEntities() const;
    
    // Entity filtering
    QList<EntityData> filterEntities(const EntityFilter &filter) const;
    bool addFilter(const EntityFilter &filter);
    bool removeFilter(const QString &name);
    EntityFilter getFilter(const QString &name) const;
    QStringList getFilterNames() const;
    void setActiveFilter(const QString &name);
    QString getActiveFilter() const;
    
    // Entity grouping
    bool createGroup(const QString &id, const QString &name);
    bool deleteGroup(const QString &id);
    bool addToGroup(const QString &groupId, const QString &entityId);
    bool removeFromGroup(const QString &groupId, const QString &entityId);
    EntityGroup getGroup(const QString &id) const;
    QStringList getGroupIds() const;
    QList<EntityData> getGroupEntities(const QString &groupId) const;
    void setGroupFilter(const QString &groupId, const EntityFilter &filter);
    void updateGroups();
    
    // Entity relationships
    bool addRelationship(const QString &entityId, const EntityRelationship &relationship);
    bool removeRelationship(const QString &entityId, const QString &relatedEntityId);
    QList<EntityRelationship> getRelationships(const QString &entityId) const;
    QList<EntityRelationship> getRelationships(const QString &entityId, EntityRelation relation) const;
    QStringList getRelatedEntities(const QString &entityId) const;
    QStringList getRelatedEntities(const QString &entityId, EntityRelation relation) const;
    bool hasRelationship(const QString &entityId, const QString &relatedEntityId) const;
    
    // Entity tracking
    void startTracking(const QString &id);
    void stopTracking(const QString &id);
    bool isTracking(const QString &id) const;
    QStringList getTrackedEntities() const;
    void setTrackingEnabled(bool enabled);
    bool isTrackingEnabled() const;
    
    // Entity updates
    void updateAllEntities();
    void updateEntity(const QString &id);
    void updateEntitiesByType(EntityType type);
    void updateEntitiesInRange(const QVector3D &position, float range);
    void setAutoUpdate(bool enabled);
    bool isAutoUpdateEnabled() const;
    void setUpdateInterval(int interval);
    int getUpdateInterval() const;
    
    // Memory operations
    bool loadEntityFromMemory(const QString &id, uintptr_t address);
    bool saveEntityToMemory(const QString &id) const;
    bool scanForEntities(EntityType type);
    bool scanForEntitiesInRange(const QVector3D &position, float range);
    void setMemoryOffsets(EntityType type, const QMap<QString, uintptr_t> &offsets);
    QMap<QString, uintptr_t> getMemoryOffsets(EntityType type) const;
    
    // Distance and positioning
    float getDistance(const QString &id1, const QString &id2) const;
    float getDistance(const QString &id, const QVector3D &position) const;
    QVector3D getDirection(const QString &id1, const QString &id2) const;
    QVector3D getDirection(const QString &id, const QVector3D &position) const;
    float getAngle(const QString &id1, const QString &id2) const;
    float getAngle(const QString &id, const QVector3D &position) const;
    QVector2D getScreenPosition(const QString &id) const;
    bool isInFieldOfView(const QString &id, const QVector3D &position, float fov) const;
    
    // Visibility and line of sight
    bool isVisible(const QString &id) const;
    bool hasLineOfSight(const QString &id1, const QString &id2) const;
    bool hasLineOfSight(const QString &id, const QVector3D &position) const;
    EntityVisibility getVisibility(const QString &id) const;
    void updateVisibility(const QString &id);
    void updateAllVisibility();
    
    // Entity validation
    bool validateEntity(const EntityData &entity) const;
    QStringList getValidationErrors(const QString &id) const;
    void setValidationEnabled(bool enabled);
    bool isValidationEnabled() const;
    
    // Entity persistence
    bool saveToFile(const QString &filename) const;
    bool loadFromFile(const QString &filename);
    bool exportEntities(const QString &filename, const QStringList &ids) const;
    bool importEntities(const QString &filename);
    void setPersistenceEnabled(bool enabled);
    bool isPersistenceEnabled() const;
    
    // Statistics and monitoring
    EntityStatistics getStatistics() const;
    void resetStatistics();
    QString getUsageReport() const;
    QString getPerformanceReport() const;
    int getEntityCount() const;
    int getEntityCount(EntityType type) const;
    int getEntityCount(EntityTeam team) const;
    int getEntityCount(EntityState state) const;
    
    // Configuration
    void setMaxEntities(int count);
    int getMaxEntities() const;
    void setMaxDistance(float distance);
    float getMaxDistance() const;
    void setUpdateThreshold(float threshold);
    float getUpdateThreshold() const;
    void setCleanupInterval(int interval);
    int getCleanupInterval() const;
    
    // Utility functions
    static QString typeToString(EntityType type);
    static EntityType stringToType(const QString &str);
    static QString stateToString(EntityState state);
    static EntityState stringToState(const QString &str);
    static QString teamToString(EntityTeam team);
    static EntityTeam stringToTeam(const QString &str);
    static QString visibilityToString(EntityVisibility visibility);
    static EntityVisibility stringToVisibility(const QString &str);
    static QString priorityToString(EntityPriority priority);
    static EntityPriority stringToPriority(const QString &str);
    static QString relationToString(EntityRelation relation);
    static EntityRelation stringToRelation(const QString &str);
    
public slots:
    // Entity management slots
    void onEntityAddRequested(const EntityData &entity);
    void onEntityUpdateRequested(const QString &id, const EntityData &entity);
    void onEntityRemoveRequested(const QString &id);
    void onEntityQueryRequested(int type);
    
    // Tracking slots
    void onTrackingStartRequested(const QString &id);
    void onTrackingStopRequested(const QString &id);
    void onTrackingToggled(bool enabled);
    
    // Update slots
    void onUpdateAllRequested();
    void onUpdateEntityRequested(const QString &id);
    void onUpdateTypeRequested(int type);
    void onAutoUpdateToggled(bool enabled);
    void onUpdateIntervalChanged(int interval);
    
    // Filter slots
    void onFilterAddRequested(const EntityFilter &filter);
    void onFilterRemoveRequested(const QString &name);
    void onFilterActivated(const QString &name);
    
    // Group slots
    void onGroupCreateRequested(const QString &id, const QString &name);
    void onGroupDeleteRequested(const QString &id);
    void onGroupAddEntityRequested(const QString &groupId, const QString &entityId);
    void onGroupRemoveEntityRequested(const QString &groupId, const QString &entityId);
    void onGroupUpdateRequested();
    
    // Relationship slots
    void onRelationshipAddRequested(const QString &entityId, const EntityRelationship &relationship);
    void onRelationshipRemoveRequested(const QString &entityId, const QString &relatedEntityId);
    
    // Memory slots
    void onMemoryLoadRequested(const QString &id, quint64 address);
    void onMemorySaveRequested(const QString &id);
    void onMemoryScanRequested(int type);
    void onMemoryOffsetsChanged(int type, const QMap<QString, quint64> &offsets);
    
    // Visibility slots
    void onVisibilityUpdateRequested(const QString &id);
    void onVisibilityUpdateAllRequested();
    
    // Validation slots
    void onValidationRequested(const QString &id);
    void onValidationToggled(bool enabled);
    
    // Persistence slots
    void onSaveToFileRequested(const QString &filename);
    void onLoadFromFileRequested(const QString &filename);
    void onExportRequested(const QString &filename, const QStringList &ids);
    void onImportRequested(const QString &filename);
    void onPersistenceToggled(bool enabled);
    
    // Statistics slots
    void onStatisticsRequested();
    void onStatisticsReset();
    void onUsageReportRequested();
    void onPerformanceReportRequested();
    
    // Configuration slots
    void onMaxEntitiesChanged(int count);
    void onMaxDistanceChanged(float distance);
    void onUpdateThresholdChanged(float threshold);
    void onCleanupIntervalChanged(int interval);
    
private slots:
    void onUpdateTimer();
    void onCleanupTimer();
    void onStatisticsTimer();
    void onMemoryChanged(quint64 address, const QByteArray &data);
    void onGameStateChanged(int state);
    
signals:
    void entityAdded(const QString &id, const EntityData &entity);
    void entityUpdated(const QString &id, const EntityData &entity);
    void entityRemoved(const QString &id);
    void entityStateChanged(const QString &id, EntityState oldState, EntityState newState);
    void entityTeamChanged(const QString &id, EntityTeam oldTeam, EntityTeam newTeam);
    void entityVisibilityChanged(const QString &id, EntityVisibility oldVisibility, EntityVisibility newVisibility);
    
    void entitiesQueried(EntityType type, const QList<EntityData> &entities);
    void entitiesFiltered(const QString &filterName, const QList<EntityData> &entities);
    
    void trackingStarted(const QString &id);
    void trackingStopped(const QString &id);
    void trackingToggled(bool enabled);
    
    void updateCompleted(int updatedCount);
    void updateEntityCompleted(const QString &id, bool success);
    void autoUpdateToggled(bool enabled);
    void updateIntervalChanged(int interval);
    
    void filterAdded(const QString &name);
    void filterRemoved(const QString &name);
    void filterActivated(const QString &name);
    
    void groupCreated(const QString &id, const QString &name);
    void groupDeleted(const QString &id);
    void groupEntityAdded(const QString &groupId, const QString &entityId);
    void groupEntityRemoved(const QString &groupId, const QString &entityId);
    void groupsUpdated();
    
    void relationshipAdded(const QString &entityId, const QString &relatedEntityId, EntityRelation relation);
    void relationshipRemoved(const QString &entityId, const QString &relatedEntityId);
    
    void memoryLoaded(const QString &id, bool success);
    void memorySaved(const QString &id, bool success);
    void memoryScanCompleted(EntityType type, int foundCount);
    void memoryOffsetsChanged(EntityType type);
    
    void visibilityUpdated(const QString &id, EntityVisibility visibility);
    void visibilityUpdateCompleted(int updatedCount);
    
    void validationCompleted(const QString &id, bool success, const QStringList &errors);
    void validationToggled(bool enabled);
    
    void savedToFile(const QString &filename, bool success);
    void loadedFromFile(const QString &filename, bool success, int loadedCount);
    void exported(const QString &filename, bool success, int exportedCount);
    void imported(const QString &filename, bool success, int importedCount);
    void persistenceToggled(bool enabled);
    
    void statisticsUpdated(const EntityStatistics &stats);
    void usageReportGenerated(const QString &report);
    void performanceReportGenerated(const QString &report);
    
    void maxEntitiesChanged(int count);
    void maxDistanceChanged(float distance);
    void updateThresholdChanged(float threshold);
    void cleanupIntervalChanged(int interval);
    
    void error(const QString &message);
    void warning(const QString &message);
    void info(const QString &message);
    
private:
    // Core functionality
    void updateEntityInternal(const QString &id);
    void updateEntityFromMemory(const QString &id);
    void validateEntityInternal(const EntityData &entity);
    void updateStatistics(const QString &operation, qint64 duration = 0);
    
    // Memory operations
    bool readEntityData(uintptr_t address, EntityType type, EntityData &entity) const;
    bool writeEntityData(const EntityData &entity) const;
    QList<uintptr_t> scanForEntityAddresses(EntityType type) const;
    
    // Visibility calculations
    EntityVisibility calculateVisibility(const EntityData &entity) const;
    bool checkLineOfSight(const QVector3D &from, const QVector3D &to) const;
    bool isInFieldOfView(const QVector3D &viewerPos, const QVector3D &viewerDir, const QVector3D &targetPos, float fov) const;
    
    // Distance calculations
    float calculateDistance(const QVector3D &pos1, const QVector3D &pos2) const;
    QVector3D calculateDirection(const QVector3D &from, const QVector3D &to) const;
    float calculateAngle(const QVector3D &from, const QVector3D &to) const;
    QVector2D calculateScreenPosition(const QVector3D &worldPos) const;
    
    // Filtering and grouping
    bool matchesFilter(const EntityData &entity, const EntityFilter &filter) const;
    void updateGroupsInternal();
    void applyFilterToGroup(const QString &groupId);
    
    // Cleanup and maintenance
    void cleanupInvalidEntities();
    void cleanupOldEntities();
    void cleanupDistantEntities();
    void optimizeMemoryUsage();
    
    // File operations
    QJsonObject entityToJson(const EntityData &entity) const;
    EntityData entityFromJson(const QJsonObject &json) const;
    QJsonObject filterToJson(const EntityFilter &filter) const;
    EntityFilter filterFromJson(const QJsonObject &json) const;
    QJsonObject groupToJson(const EntityGroup &group) const;
    EntityGroup groupFromJson(const QJsonObject &json) const;
    
    // Utility functions
    QString generateEntityId() const;
    bool isValidEntityId(const QString &id) const;
    EntityPriority calculatePriority(const EntityData &entity) const;
    void updateEntityBounds(EntityData &entity) const;
    void updateEntityTransform(EntityData &entity) const;
    
    // Error handling
    void handleError(const QString &operation, const QString &error);
    void handleWarning(const QString &operation, const QString &warning);
    void logOperation(const QString &operation, bool success, qint64 duration = 0);
    
    // Core components
    Logger *m_logger;
    MemoryManager *m_memoryManager;
    GameInterface *m_gameInterface;
    DataManager *m_dataManager;
    
    // Entity storage
    QMap<QString, EntityData> m_entities;
    QMap<QString, EntityFilter> m_filters;
    QMap<QString, EntityGroup> m_groups;
    QMap<EntityType, QMap<QString, uintptr_t>> m_memoryOffsets;
    
    // Tracking
    QSet<QString> m_trackedEntities;
    QString m_activeFilter;
    
    // Timers
    QTimer *m_updateTimer;
    QTimer *m_cleanupTimer;
    QTimer *m_statisticsTimer;
    
    // Settings
    int m_maxEntities;
    float m_maxDistance;
    float m_updateThreshold;
    int m_updateInterval;
    int m_cleanupInterval;
    bool m_autoUpdateEnabled;
    bool m_trackingEnabled;
    bool m_validationEnabled;
    bool m_persistenceEnabled;
    
    // Statistics
    EntityStatistics m_statistics;
    
    // State
    bool m_initialized;
    QMutex m_mutex;
    QMutex m_updateMutex;
    
    // Constants
    static const int DEFAULT_MAX_ENTITIES = 1000;
    static const float DEFAULT_MAX_DISTANCE;
    static const float DEFAULT_UPDATE_THRESHOLD;
    static const int DEFAULT_UPDATE_INTERVAL = 100; // ms
    static const int DEFAULT_CLEANUP_INTERVAL = 30000; // 30 seconds
    static const int DEFAULT_STATISTICS_INTERVAL = 5000; // 5 seconds
};

#endif // ENTITY_MANAGER_H