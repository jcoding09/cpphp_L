#ifndef DATA_MANAGER_H
#define DATA_MANAGER_H

#include <QtCore/QObject>
#include <QtCore/QJsonObject>
#include <QtCore/QJsonDocument>
#include <QtCore/QJsonArray>
#include <QtCore/QString>
#include <QtCore/QStringList>
#include <QtCore/QVariant>
#include <QtCore/QMap>
#include <QtCore/QVector>
#include <QtCore/QDateTime>
#include <QtCore/QTimer>
#include <QtCore/QMutex>
#include <QtCore/QThread>
#include <QtCore/QFileSystemWatcher>
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkReply>
#include <memory>

// Forward declarations
class Logger;
class MemoryManager;
class GameInterface;

enum class DataType {
    GameData = 0,
    PlayerData = 1,
    WeaponData = 2,
    VehicleData = 3,
    ItemData = 4,
    MapData = 5,
    OffsetData = 6,
    PatternData = 7,
    ConfigData = 8,
    StatisticsData = 9,
    CacheData = 10,
    UserData = 11
};

enum class DataSource {
    Local = 0,
    Remote = 1,
    Memory = 2,
    File = 3,
    Database = 4,
    Network = 5,
    Cache = 6,
    User = 7
};

enum class DataFormat {
    JSON = 0,
    XML = 1,
    Binary = 2,
    CSV = 3,
    INI = 4,
    Custom = 5
};

enum class DataStatus {
    Unknown = 0,
    Loading = 1,
    Loaded = 2,
    Error = 3,
    Outdated = 4,
    Updating = 5,
    Cached = 6,
    Synchronized = 7
};

enum class CachePolicy {
    NoCache = 0,
    MemoryOnly = 1,
    DiskOnly = 2,
    MemoryAndDisk = 3,
    Temporary = 4,
    Persistent = 5
};

struct DataEntry {
    QString id;
    QString name;
    QString description;
    QString category;
    
    DataType type = DataType::GameData;
    DataSource source = DataSource::Local;
    DataFormat format = DataFormat::JSON;
    DataStatus status = DataStatus::Unknown;
    
    QVariant data;
    QJsonObject metadata;
    QString checksum;
    qint64 size = 0;
    
    QDateTime created;
    QDateTime lastModified;
    QDateTime lastAccessed;
    QDateTime expires;
    
    QString version;
    QString author;
    QStringList tags;
    
    bool isEncrypted = false;
    bool isCompressed = false;
    bool isReadOnly = false;
    bool isCached = false;
    
    QString filePath;
    QString url;
    int priority = 0;
    
    QMap<QString, QVariant> properties;
};

struct DataCollection {
    QString id;
    QString name;
    QString description;
    DataType type = DataType::GameData;
    
    QMap<QString, DataEntry> entries;
    QStringList entryOrder;
    
    QDateTime created;
    QDateTime lastModified;
    QString version;
    
    bool isReadOnly = false;
    bool isEncrypted = false;
    bool autoUpdate = false;
    int updateInterval = 0; // seconds
    
    QString filePath;
    QString remoteUrl;
    CachePolicy cachePolicy = CachePolicy::MemoryAndDisk;
    
    QMap<QString, QVariant> metadata;
};

struct DataQuery {
    QString id;
    QString name;
    DataType type = DataType::GameData;
    
    QString filter;
    QStringList fields;
    QString sortBy;
    bool ascending = true;
    
    int limit = -1;
    int offset = 0;
    
    QMap<QString, QVariant> parameters;
    QDateTime created;
    
    bool useCache = true;
    int cacheTimeout = 300; // seconds
};

struct DataStatistics {
    int totalEntries = 0;
    int totalCollections = 0;
    qint64 totalSize = 0;
    qint64 memoryUsage = 0;
    qint64 diskUsage = 0;
    
    int loadedEntries = 0;
    int cachedEntries = 0;
    int errorEntries = 0;
    int outdatedEntries = 0;
    
    int loadOperations = 0;
    int saveOperations = 0;
    int queryOperations = 0;
    int cacheHits = 0;
    int cacheMisses = 0;
    
    qint64 totalLoadTime = 0;
    qint64 totalSaveTime = 0;
    qint64 totalQueryTime = 0;
    qint64 averageLoadTime = 0;
    qint64 averageSaveTime = 0;
    qint64 averageQueryTime = 0;
    
    QDateTime lastReset;
    QDateTime lastUpdate;
    
    QMap<DataType, int> typeUsage;
    QMap<DataSource, int> sourceUsage;
    QMap<DataFormat, int> formatUsage;
    
    QStringList mostAccessedEntries;
    QStringList recentlyModified;
    QStringList errorMessages;
};

struct GameEntityData {
    QString id;
    QString name;
    QString type;
    
    QVector3D position;
    QVector3D rotation;
    QVector3D velocity;
    
    float health = 100.0f;
    float maxHealth = 100.0f;
    float armor = 0.0f;
    float maxArmor = 0.0f;
    
    bool isValid = false;
    bool isVisible = false;
    bool isAlive = true;
    bool isEnemy = false;
    bool isTeammate = false;
    
    float distance = 0.0f;
    QDateTime lastSeen;
    
    QMap<QString, QVariant> properties;
};

struct WeaponData {
    QString id;
    QString name;
    QString category;
    QString type;
    
    int damage = 0;
    float range = 0.0f;
    float accuracy = 0.0f;
    float stability = 0.0f;
    float fireRate = 0.0f;
    float reloadTime = 0.0f;
    
    int magazineSize = 0;
    int currentAmmo = 0;
    int totalAmmo = 0;
    
    QString ammoType;
    QStringList attachments;
    QStringList compatibleAttachments;
    
    bool isAutomatic = false;
    bool isSilenced = false;
    bool hasScope = false;
    
    QMap<QString, float> recoilPattern;
    QMap<QString, QVariant> properties;
};

struct VehicleData {
    QString id;
    QString name;
    QString type;
    QString category;
    
    float health = 100.0f;
    float maxHealth = 100.0f;
    float fuel = 100.0f;
    float maxFuel = 100.0f;
    
    float speed = 0.0f;
    float maxSpeed = 0.0f;
    int seats = 1;
    int occupiedSeats = 0;
    
    bool isDestroyed = false;
    bool isMoving = false;
    bool isOccupied = false;
    
    QStringList passengers;
    QMap<QString, QVariant> properties;
};

struct ItemData {
    QString id;
    QString name;
    QString category;
    QString type;
    
    int quantity = 1;
    int maxStack = 1;
    float weight = 0.0f;
    int rarity = 0;
    
    bool isUsable = false;
    bool isEquippable = false;
    bool isStackable = false;
    bool isDroppable = true;
    
    QString description;
    QStringList effects;
    QMap<QString, QVariant> properties;
};

struct MapData {
    QString id;
    QString name;
    QString description;
    
    float width = 0.0f;
    float height = 0.0f;
    QVector2D center;
    
    QVector<QVector2D> safeZones;
    QVector<QVector2D> redZones;
    QVector<QVector2D> landmarks;
    QVector<QVector2D> lootSpawns;
    QVector<QVector2D> vehicleSpawns;
    
    QString imagePath;
    QString heightmapPath;
    
    QMap<QString, QVariant> properties;
};

class DataManager : public QObject
{
    Q_OBJECT

public:
    explicit DataManager(QObject *parent = nullptr);
    ~DataManager();
    
    // Component integration
    void setLogger(Logger *logger);
    void setMemoryManager(MemoryManager *memoryManager);
    void setGameInterface(GameInterface *gameInterface);
    
    // Initialization
    bool initialize();
    void cleanup();
    bool isInitialized() const;
    
    // Data entry management
    bool addEntry(const DataEntry &entry);
    bool updateEntry(const QString &id, const DataEntry &entry);
    bool removeEntry(const QString &id);
    DataEntry getEntry(const QString &id) const;
    bool hasEntry(const QString &id) const;
    QStringList getEntryIds() const;
    QStringList getEntryIds(DataType type) const;
    QStringList getEntryIds(const QString &category) const;
    
    // Collection management
    bool createCollection(const QString &id, const QString &name, DataType type);
    bool deleteCollection(const QString &id);
    bool addToCollection(const QString &collectionId, const DataEntry &entry);
    bool removeFromCollection(const QString &collectionId, const QString &entryId);
    DataCollection getCollection(const QString &id) const;
    QStringList getCollectionIds() const;
    QStringList getCollectionIds(DataType type) const;
    
    // Data loading and saving
    bool loadFromFile(const QString &filename, DataFormat format = DataFormat::JSON);
    bool saveToFile(const QString &filename, DataFormat format = DataFormat::JSON) const;
    bool loadCollection(const QString &id);
    bool saveCollection(const QString &id) const;
    bool loadEntry(const QString &id);
    bool saveEntry(const QString &id) const;
    
    // Remote data operations
    void loadFromUrl(const QString &url, const QString &id = "");
    void uploadToUrl(const QString &url, const QString &id);
    void synchronizeWithRemote(const QString &url);
    bool isRemoteAvailable(const QString &url) const;
    
    // Memory data operations
    bool loadFromMemory(const QString &id, uintptr_t address, size_t size);
    bool saveToMemory(const QString &id, uintptr_t address) const;
    bool scanMemoryForData(const QString &pattern, DataType type);
    bool updateFromMemory(const QString &id);
    
    // Query operations
    QList<DataEntry> query(const DataQuery &query) const;
    QList<DataEntry> findByType(DataType type) const;
    QList<DataEntry> findByCategory(const QString &category) const;
    QList<DataEntry> findByTag(const QString &tag) const;
    QList<DataEntry> findByName(const QString &name, bool exactMatch = false) const;
    QList<DataEntry> findByProperty(const QString &key, const QVariant &value) const;
    
    // Cache management
    void setCachePolicy(const QString &id, CachePolicy policy);
    CachePolicy getCachePolicy(const QString &id) const;
    void clearCache();
    void clearCache(DataType type);
    void clearCache(const QString &id);
    bool isCached(const QString &id) const;
    void preloadToCache(const QStringList &ids);
    
    // Game data specific methods
    QList<GameEntityData> getPlayers() const;
    QList<GameEntityData> getEnemies() const;
    QList<GameEntityData> getTeammates() const;
    QList<WeaponData> getWeapons() const;
    QList<VehicleData> getVehicles() const;
    QList<ItemData> getItems() const;
    QList<ItemData> getLoot() const;
    MapData getCurrentMap() const;
    
    // Game data updates
    void updatePlayerData(const QList<GameEntityData> &players);
    void updateWeaponData(const QList<WeaponData> &weapons);
    void updateVehicleData(const QList<VehicleData> &vehicles);
    void updateItemData(const QList<ItemData> &items);
    void updateMapData(const MapData &mapData);
    
    // Data validation
    bool validateEntry(const DataEntry &entry) const;
    bool validateCollection(const DataCollection &collection) const;
    QStringList getValidationErrors(const QString &id) const;
    void setValidationEnabled(bool enabled);
    bool isValidationEnabled() const;
    
    // Data transformation
    QJsonObject entryToJson(const DataEntry &entry) const;
    DataEntry entryFromJson(const QJsonObject &json) const;
    QByteArray entryToBinary(const DataEntry &entry) const;
    DataEntry entryFromBinary(const QByteArray &data) const;
    QString entryToXml(const DataEntry &entry) const;
    DataEntry entryFromXml(const QString &xml) const;
    
    // Data compression and encryption
    QByteArray compressData(const QByteArray &data) const;
    QByteArray decompressData(const QByteArray &data) const;
    QByteArray encryptData(const QByteArray &data, const QString &password) const;
    QByteArray decryptData(const QByteArray &data, const QString &password) const;
    QString calculateChecksum(const QByteArray &data) const;
    bool verifyChecksum(const QByteArray &data, const QString &checksum) const;
    
    // Auto-update management
    void setAutoUpdate(const QString &id, bool enabled, int interval = 300);
    bool isAutoUpdateEnabled(const QString &id) const;
    void checkForUpdates();
    void checkForUpdates(const QString &id);
    void setUpdateUrl(const QString &id, const QString &url);
    QString getUpdateUrl(const QString &id) const;
    
    // Statistics and monitoring
    DataStatistics getStatistics() const;
    void resetStatistics();
    QString getUsageReport() const;
    QString getPerformanceReport() const;
    qint64 getMemoryUsage() const;
    qint64 getDiskUsage() const;
    
    // Configuration
    void setDataDirectory(const QString &path);
    QString getDataDirectory() const;
    void setCacheDirectory(const QString &path);
    QString getCacheDirectory() const;
    void setMaxCacheSize(qint64 size);
    qint64 getMaxCacheSize() const;
    void setMaxMemoryUsage(qint64 size);
    qint64 getMaxMemoryUsage() const;
    
    // Utility functions
    static QString typeToString(DataType type);
    static DataType stringToType(const QString &str);
    static QString sourceToString(DataSource source);
    static DataSource stringToSource(const QString &str);
    static QString formatToString(DataFormat format);
    static DataFormat stringToFormat(const QString &str);
    static QString statusToString(DataStatus status);
    static DataStatus stringToStatus(const QString &str);
    static QString cachePolicyToString(CachePolicy policy);
    static CachePolicy stringToCachePolicy(const QString &str);
    
public slots:
    // Entry management slots
    void onEntryAddRequested(const DataEntry &entry);
    void onEntryUpdateRequested(const QString &id, const DataEntry &entry);
    void onEntryRemoveRequested(const QString &id);
    void onEntryLoadRequested(const QString &id);
    void onEntrySaveRequested(const QString &id);
    
    // Collection management slots
    void onCollectionCreateRequested(const QString &id, const QString &name, int type);
    void onCollectionDeleteRequested(const QString &id);
    void onCollectionLoadRequested(const QString &id);
    void onCollectionSaveRequested(const QString &id);
    
    // File operation slots
    void onLoadFromFileRequested(const QString &filename, int format);
    void onSaveToFileRequested(const QString &filename, int format);
    
    // Remote operation slots
    void onLoadFromUrlRequested(const QString &url, const QString &id);
    void onUploadToUrlRequested(const QString &url, const QString &id);
    void onSynchronizeRequested(const QString &url);
    
    // Memory operation slots
    void onLoadFromMemoryRequested(const QString &id, quint64 address, quint64 size);
    void onSaveToMemoryRequested(const QString &id, quint64 address);
    void onMemoryScanRequested(const QString &pattern, int type);
    void onMemoryUpdateRequested(const QString &id);
    
    // Cache management slots
    void onCacheClearRequested();
    void onCacheClearTypeRequested(int type);
    void onCacheClearIdRequested(const QString &id);
    void onCachePreloadRequested(const QStringList &ids);
    void onCachePolicyChanged(const QString &id, int policy);
    
    // Game data slots
    void onGameDataUpdateRequested();
    void onPlayerDataReceived(const QList<GameEntityData> &players);
    void onWeaponDataReceived(const QList<WeaponData> &weapons);
    void onVehicleDataReceived(const QList<VehicleData> &vehicles);
    void onItemDataReceived(const QList<ItemData> &items);
    void onMapDataReceived(const MapData &mapData);
    
    // Auto-update slots
    void onAutoUpdateToggled(const QString &id, bool enabled, int interval);
    void onUpdateCheckRequested();
    void onUpdateCheckRequested(const QString &id);
    void onUpdateUrlChanged(const QString &id, const QString &url);
    
    // Validation slots
    void onValidationRequested(const QString &id);
    void onValidationToggled(bool enabled);
    
    // Statistics slots
    void onStatisticsRequested();
    void onStatisticsReset();
    void onUsageReportRequested();
    void onPerformanceReportRequested();
    
    // Configuration slots
    void onDataDirectoryChanged(const QString &path);
    void onCacheDirectoryChanged(const QString &path);
    void onMaxCacheSizeChanged(qint64 size);
    void onMaxMemoryUsageChanged(qint64 size);
    
private slots:
    void onNetworkReplyFinished();
    void onFileSystemChanged(const QString &path);
    void onAutoUpdateTimer();
    void onCacheCleanupTimer();
    void onStatisticsUpdateTimer();
    void onMemoryDataChanged(quint64 address, const QByteArray &data);
    void onGameStateChanged(int state);
    
signals:
    void entryAdded(const QString &id, const DataEntry &entry);
    void entryUpdated(const QString &id, const DataEntry &entry);
    void entryRemoved(const QString &id);
    void entryLoaded(const QString &id, bool success);
    void entrySaved(const QString &id, bool success);
    
    void collectionCreated(const QString &id, const QString &name);
    void collectionDeleted(const QString &id);
    void collectionLoaded(const QString &id, bool success);
    void collectionSaved(const QString &id, bool success);
    
    void fileLoaded(const QString &filename, bool success);
    void fileSaved(const QString &filename, bool success);
    
    void urlLoaded(const QString &url, const QString &id, bool success);
    void urlUploaded(const QString &url, const QString &id, bool success);
    void synchronizationCompleted(const QString &url, bool success);
    
    void memoryLoaded(const QString &id, bool success);
    void memorySaved(const QString &id, bool success);
    void memoryScanCompleted(const QString &pattern, int resultsCount);
    void memoryUpdated(const QString &id, bool success);
    
    void cacheCleared();
    void cacheCleared(DataType type);
    void cacheCleared(const QString &id);
    void cachePreloaded(const QStringList &ids, int successCount);
    void cachePolicyChanged(const QString &id, CachePolicy policy);
    
    void gameDataUpdated();
    void playerDataUpdated(int count);
    void weaponDataUpdated(int count);
    void vehicleDataUpdated(int count);
    void itemDataUpdated(int count);
    void mapDataUpdated();
    
    void autoUpdateToggled(const QString &id, bool enabled);
    void updateCheckCompleted(const QString &id, bool hasUpdate);
    void updateUrlChanged(const QString &id, const QString &url);
    
    void validationCompleted(const QString &id, bool success, const QStringList &errors);
    void validationToggled(bool enabled);
    
    void statisticsUpdated(const DataStatistics &stats);
    void usageReportGenerated(const QString &report);
    void performanceReportGenerated(const QString &report);
    
    void dataDirectoryChanged(const QString &path);
    void cacheDirectoryChanged(const QString &path);
    void maxCacheSizeChanged(qint64 size);
    void maxMemoryUsageChanged(qint64 size);
    
    void error(const QString &message);
    void warning(const QString &message);
    void info(const QString &message);
    
private:
    // Core functionality
    bool loadEntryInternal(const QString &id);
    bool saveEntryInternal(const QString &id) const;
    bool loadCollectionInternal(const QString &id);
    bool saveCollectionInternal(const QString &id) const;
    void updateStatistics(const QString &operation, qint64 duration = 0);
    
    // File operations
    QJsonObject entryToJsonInternal(const DataEntry &entry) const;
    DataEntry entryFromJsonInternal(const QJsonObject &json) const;
    QJsonObject collectionToJson(const DataCollection &collection) const;
    DataCollection collectionFromJson(const QJsonObject &json) const;
    
    // Network operations
    void processNetworkReply(QNetworkReply *reply, const QString &id);
    void handleNetworkError(QNetworkReply::NetworkError error, const QString &operation);
    
    // Memory operations
    bool readMemoryData(uintptr_t address, size_t size, QByteArray &data) const;
    bool writeMemoryData(uintptr_t address, const QByteArray &data) const;
    QList<uintptr_t> scanMemoryPattern(const QString &pattern) const;
    
    // Cache operations
    void addToCache(const QString &id, const DataEntry &entry);
    void removeFromCache(const QString &id);
    bool isInCache(const QString &id) const;
    DataEntry getFromCache(const QString &id) const;
    void cleanupCache();
    
    // Validation implementation
    bool validateEntryInternal(const DataEntry &entry) const;
    bool validateCollectionInternal(const DataCollection &collection) const;
    QStringList getValidationErrorsInternal(const DataEntry &entry) const;
    
    // Auto-update implementation
    void performAutoUpdate(const QString &id);
    void checkRemoteVersion(const QString &id, const QString &url);
    void downloadUpdate(const QString &id, const QString &url);
    
    // Game data processing
    void processGameData(const QByteArray &data, DataType type);
    GameEntityData parsePlayerData(const QByteArray &data) const;
    WeaponData parseWeaponData(const QByteArray &data) const;
    VehicleData parseVehicleData(const QByteArray &data) const;
    ItemData parseItemData(const QByteArray &data) const;
    MapData parseMapData(const QByteArray &data) const;
    
    // Utility functions
    QString getEntryFilePath(const QString &id) const;
    QString getCollectionFilePath(const QString &id) const;
    QString getCacheFilePath(const QString &id) const;
    QString generateUniqueId() const;
    bool createDirectoryIfNotExists(const QString &path) const;
    
    // Error handling
    void handleError(const QString &operation, const QString &error);
    void handleWarning(const QString &operation, const QString &warning);
    void logOperation(const QString &operation, bool success, qint64 duration = 0);
    
    // Core components
    Logger *m_logger;
    MemoryManager *m_memoryManager;
    GameInterface *m_gameInterface;
    
    // Data storage
    QMap<QString, DataEntry> m_entries;
    QMap<QString, DataCollection> m_collections;
    QMap<QString, DataEntry> m_cache;
    
    // Network
    QNetworkAccessManager *m_networkManager;
    QMap<QNetworkReply*, QString> m_pendingRequests;
    
    // File watching
    QFileSystemWatcher *m_fileWatcher;
    
    // Timers
    QTimer *m_autoUpdateTimer;
    QTimer *m_cacheCleanupTimer;
    QTimer *m_statisticsTimer;
    
    // Settings
    QString m_dataDirectory;
    QString m_cacheDirectory;
    qint64 m_maxCacheSize;
    qint64 m_maxMemoryUsage;
    bool m_validationEnabled;
    
    // Auto-update settings
    QMap<QString, bool> m_autoUpdateEnabled;
    QMap<QString, int> m_autoUpdateIntervals;
    QMap<QString, QString> m_updateUrls;
    QMap<QString, QDateTime> m_lastUpdateChecks;
    
    // Cache settings
    QMap<QString, CachePolicy> m_cachePolicies;
    qint64 m_currentCacheSize;
    
    // Statistics
    DataStatistics m_statistics;
    
    // State
    bool m_initialized;
    QMutex m_mutex;
    QMutex m_cacheMutex;
    QMutex m_networkMutex;
    
    // Constants
    static const QString DATA_FILE_EXTENSION;
    static const QString COLLECTION_FILE_EXTENSION;
    static const QString CACHE_FILE_EXTENSION;
    static const int DEFAULT_AUTO_UPDATE_INTERVAL = 300; // 5 minutes
    static const int DEFAULT_CACHE_CLEANUP_INTERVAL = 600000; // 10 minutes
    static const int DEFAULT_STATISTICS_UPDATE_INTERVAL = 60000; // 1 minute
    static const qint64 DEFAULT_MAX_CACHE_SIZE = 100 * 1024 * 1024; // 100 MB
    static const qint64 DEFAULT_MAX_MEMORY_USAGE = 500 * 1024 * 1024; // 500 MB
};

#endif // DATA_MANAGER_H