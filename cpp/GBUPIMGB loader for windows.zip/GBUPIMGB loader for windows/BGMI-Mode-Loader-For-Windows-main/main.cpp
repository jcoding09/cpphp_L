#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QStatusBar>
#include <QtCore/QTimer>
#include <QtCore/QThread>
#include <QtCore/QMutex>
#include <QtCore/QDateTime>
#include <QtGui/QFont>
#include <QtGui/QPalette>
#include <memory>
#include <vector>
#include <string>
#include <map>

// Core includes
#include "core/injection_manager.h"
#include "core/memory_manager.h"
#include "core/game_interface.h"
#include "core/logger.h"
#include "core/status_monitor.h"

// Module includes
#include "modules/aimbot.h"
#include "modules/esp.h"
#include "modules/wallhack.h"
#include "modules/radar.h"
#include "modules/misc.h"

// Config includes
#include "config/config_manager.h"

// Data includes
#include "data/data_manager.h"
#include "data/entity_manager.h"
#include "data/game_data.h"

// Tools includes
#include "tools/memory_scanner.h"
#include "tools/offset_manager.h"
#include "tools/pattern_scanner.h"
#include "tools/security_manager.h"

class GhostPulseMainWindow : public QMainWindow {
    Q_OBJECT

public:
    GhostPulseMainWindow(QWidget *parent = nullptr);
    ~GhostPulseMainWindow();

private slots:
    void onInjectClicked();
    void onStopClicked();
    void onSettingsChanged();
    void updateStatus();
    void onLogMessage(const QString& level, const QString& message);
    void onProgressUpdate(int percentage, const QString& status);

private:
    void setupUI();
    void setupMenuBar();
    void setupStatusBar();
    void setupConnections();
    void applyDarkTheme();
    
    // UI Components
    QWidget* m_centralWidget;
    QTabWidget* m_tabWidget;
    QSplitter* m_mainSplitter;
    
    // Control Panel
    QWidget* m_controlPanel;
    QPushButton* m_injectButton;
    QPushButton* m_stopButton;
    QProgressBar* m_progressBar;
    QLabel* m_statusLabel;
    
    // Settings Panel
    QWidget* m_settingsPanel;
    QCheckBox* m_aimbotEnabled;
    QCheckBox* m_espEnabled;
    QCheckBox* m_wallhackEnabled;
    QSlider* m_aimbotSensitivity;
    QComboBox* m_injectionMethod;
    
    // Log Panel
    QWidget* m_logPanel;
    QTextEdit* m_logDisplay;
    QListWidget* m_errorList;
    QPushButton* m_clearLogsButton;
    QPushButton* m_exportLogsButton;
    
    // Status Monitor
    QWidget* m_statusPanel;
    QLabel* m_gameStatusLabel;
    QLabel* m_injectionStatusLabel;
    QLabel* m_memoryUsageLabel;
    QLabel* m_cpuUsageLabel;
    
    // Core Components
    std::unique_ptr<InjectionManager> m_injectionManager;
    std::unique_ptr<MemoryManager> m_memoryManager;
    std::unique_ptr<GameInterface> m_gameInterface;
    std::unique_ptr<Logger> m_logger;
    std::unique_ptr<StatusMonitor> m_statusMonitor;
    
    // Timers
    QTimer* m_statusTimer;
    QTimer* m_gameCheckTimer;
    
    // State
    bool m_isInjected;
    QString m_currentGameVersion;
};

GhostPulseMainWindow::GhostPulseMainWindow(QWidget *parent)
    : QMainWindow(parent)
    , m_isInjected(false)
{
    setWindowTitle("GhostPulse BGMI Mod Loader v3.9");
    setMinimumSize(1200, 800);
    resize(1400, 900);
    
    // Initialize core components
    m_injectionManager = std::make_unique<InjectionManager>();
    m_memoryManager = std::make_unique<MemoryManager>();
    m_gameInterface = std::make_unique<GameInterface>();
    m_logger = std::make_unique<Logger>();
    m_statusMonitor = std::make_unique<StatusMonitor>();
    
    setupUI();
    setupMenuBar();
    setupStatusBar();
    setupConnections();
    applyDarkTheme();
    
    // Initialize timers
    m_statusTimer = new QTimer(this);
    m_gameCheckTimer = new QTimer(this);
    
    connect(m_statusTimer, &QTimer::timeout, this, &GhostPulseMainWindow::updateStatus);
    connect(m_gameCheckTimer, &QTimer::timeout, [this]() {
        m_gameInterface->checkGameStatus();
    });
    
    m_statusTimer->start(1000); // Update every second
    m_gameCheckTimer->start(5000); // Check game every 5 seconds
    
    // Log startup
    m_logger->log(Logger::Info, "GhostPulse BGMI Mod Loader v3.9 initialized successfully");
}

GhostPulseMainWindow::~GhostPulseMainWindow() {
    if (m_isInjected) {
        m_injectionManager->uninject();
    }
}

void GhostPulseMainWindow::setupUI() {
    m_centralWidget = new QWidget;
    setCentralWidget(m_centralWidget);
    
    // Main layout
    auto mainLayout = new QHBoxLayout(m_centralWidget);
    m_mainSplitter = new QSplitter(Qt::Horizontal);
    mainLayout->addWidget(m_mainSplitter);
    
    // Left panel - Controls and Settings
    auto leftPanel = new QWidget;
    leftPanel->setMaximumWidth(400);
    leftPanel->setMinimumWidth(350);
    
    auto leftLayout = new QVBoxLayout(leftPanel);
    
    // Control Panel
    auto controlGroup = new QGroupBox("Control Panel");
    auto controlLayout = new QVBoxLayout(controlGroup);
    
    m_injectButton = new QPushButton("Inject into BGMI");
    m_injectButton->setMinimumHeight(40);
    m_injectButton->setStyleSheet("QPushButton { background-color: #4CAF50; color: white; font-weight: bold; }");
    
    m_stopButton = new QPushButton("Stop Injection");
    m_stopButton->setMinimumHeight(40);
    m_stopButton->setEnabled(false);
    m_stopButton->setStyleSheet("QPushButton { background-color: #f44336; color: white; font-weight: bold; }");
    
    m_progressBar = new QProgressBar;
    m_progressBar->setVisible(false);
    
    m_statusLabel = new QLabel("Ready to inject");
    m_statusLabel->setAlignment(Qt::AlignCenter);
    
    controlLayout->addWidget(m_injectButton);
    controlLayout->addWidget(m_stopButton);
    controlLayout->addWidget(m_progressBar);
    controlLayout->addWidget(m_statusLabel);
    
    // Settings Panel
    auto settingsGroup = new QGroupBox("Mod Settings");
    auto settingsLayout = new QGridLayout(settingsGroup);
    
    m_aimbotEnabled = new QCheckBox("Enable Aimbot");
    m_espEnabled = new QCheckBox("Enable ESP");
    m_wallhackEnabled = new QCheckBox("Enable Wallhack");
    
    settingsLayout->addWidget(m_aimbotEnabled, 0, 0);
    settingsLayout->addWidget(m_espEnabled, 1, 0);
    settingsLayout->addWidget(m_wallhackEnabled, 2, 0);
    
    settingsLayout->addWidget(new QLabel("Aimbot Sensitivity:"), 3, 0);
    m_aimbotSensitivity = new QSlider(Qt::Horizontal);
    m_aimbotSensitivity->setRange(1, 100);
    m_aimbotSensitivity->setValue(50);
    settingsLayout->addWidget(m_aimbotSensitivity, 3, 1);
    
    settingsLayout->addWidget(new QLabel("Injection Method:"), 4, 0);
    m_injectionMethod = new QComboBox;
    m_injectionMethod->addItems({"Manual Map", "Reflective DLL", "Process Hollowing"});
    settingsLayout->addWidget(m_injectionMethod, 4, 1);
    
    // Status Monitor Panel
    auto statusGroup = new QGroupBox("System Status");
    auto statusLayout = new QGridLayout(statusGroup);
    
    m_gameStatusLabel = new QLabel("Game: Not Detected");
    m_injectionStatusLabel = new QLabel("Injection: Inactive");
    m_memoryUsageLabel = new QLabel("Memory: 0 MB");
    m_cpuUsageLabel = new QLabel("CPU: 0%");
    
    statusLayout->addWidget(m_gameStatusLabel, 0, 0);
    statusLayout->addWidget(m_injectionStatusLabel, 1, 0);
    statusLayout->addWidget(m_memoryUsageLabel, 2, 0);
    statusLayout->addWidget(m_cpuUsageLabel, 3, 0);
    
    leftLayout->addWidget(controlGroup);
    leftLayout->addWidget(settingsGroup);
    leftLayout->addWidget(statusGroup);
    leftLayout->addStretch();
    
    // Right panel - Logs and Monitoring
    m_tabWidget = new QTabWidget;
    
    // Log Tab
    m_logPanel = new QWidget;
    auto logLayout = new QVBoxLayout(m_logPanel);
    
    auto logButtonLayout = new QHBoxLayout;
    m_clearLogsButton = new QPushButton("Clear Logs");
    m_exportLogsButton = new QPushButton("Export Logs");
    logButtonLayout->addWidget(m_clearLogsButton);
    logButtonLayout->addWidget(m_exportLogsButton);
    logButtonLayout->addStretch();
    
    m_logDisplay = new QTextEdit;
    m_logDisplay->setReadOnly(true);
    m_logDisplay->setFont(QFont("Consolas", 9));
    
    logLayout->addLayout(logButtonLayout);
    logLayout->addWidget(m_logDisplay);
    
    // Error Tab
    auto errorPanel = new QWidget;
    auto errorLayout = new QVBoxLayout(errorPanel);
    
    m_errorList = new QListWidget;
    errorLayout->addWidget(new QLabel("Critical Errors:"));
    errorLayout->addWidget(m_errorList);
    
    m_tabWidget->addTab(m_logPanel, "Logs");
    m_tabWidget->addTab(errorPanel, "Errors");
    
    m_mainSplitter->addWidget(leftPanel);
    m_mainSplitter->addWidget(m_tabWidget);
    m_mainSplitter->setStretchFactor(0, 0);
    m_mainSplitter->setStretchFactor(1, 1);
}

void GhostPulseMainWindow::setupConnections() {
    connect(m_injectButton, &QPushButton::clicked, this, &GhostPulseMainWindow::onInjectClicked);
    connect(m_stopButton, &QPushButton::clicked, this, &GhostPulseMainWindow::onStopClicked);
    
    connect(m_aimbotEnabled, &QCheckBox::toggled, this, &GhostPulseMainWindow::onSettingsChanged);
    connect(m_espEnabled, &QCheckBox::toggled, this, &GhostPulseMainWindow::onSettingsChanged);
    connect(m_wallhackEnabled, &QCheckBox::toggled, this, &GhostPulseMainWindow::onSettingsChanged);
    
    connect(m_clearLogsButton, &QPushButton::clicked, [this]() {
        m_logDisplay->clear();
        m_logger->log(Logger::Info, "Logs cleared by user");
    });
    
    connect(m_exportLogsButton, &QPushButton::clicked, [this]() {
        m_logger->exportLogs("logs_" + QDateTime::currentDateTime().toString("yyyyMMdd_hhmmss") + ".txt");
    });
    
    // Connect logger signals
    connect(m_logger.get(), &Logger::logMessage, this, &GhostPulseMainWindow::onLogMessage);
    connect(m_injectionManager.get(), &InjectionManager::progressUpdate, this, &GhostPulseMainWindow::onProgressUpdate);
}

void GhostPulseMainWindow::applyDarkTheme() {
    setStyleSheet(
        "QMainWindow { background-color: #2b2b2b; color: #ffffff; }"
        "QGroupBox { font-weight: bold; border: 2px solid #555555; border-radius: 5px; margin-top: 1ex; padding-top: 10px; }"
        "QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px 0 5px; }"
        "QTabWidget::pane { border: 1px solid #555555; }"
        "QTabBar::tab { background-color: #3c3c3c; padding: 8px 16px; margin-right: 2px; }"
        "QTabBar::tab:selected { background-color: #4CAF50; }"
        "QTextEdit { background-color: #1e1e1e; border: 1px solid #555555; }"
        "QListWidget { background-color: #1e1e1e; border: 1px solid #555555; }"
        "QPushButton { padding: 8px; border: 1px solid #555555; border-radius: 4px; }"
        "QPushButton:hover { background-color: #3c3c3c; }"
        "QCheckBox::indicator { width: 18px; height: 18px; }"
        "QCheckBox::indicator:checked { background-color: #4CAF50; }"
    );
}

void GhostPulseMainWindow::onInjectClicked() {
    m_logger->log(Logger::Info, "Starting injection process...");
    
    if (!m_gameInterface->isGameRunning()) {
        m_logger->log(Logger::Error, "BGMI game not detected. Please start the game first.");
        m_errorList->addItem("Game not detected - " + QDateTime::currentDateTime().toString());
        return;
    }
    
    m_injectButton->setEnabled(false);
    m_progressBar->setVisible(true);
    m_progressBar->setValue(0);
    m_statusLabel->setText("Injecting...");
    
    // Start injection in separate thread
    QThread::create([this]() {
        try {
            m_injectionManager->setInjectionMethod(m_injectionMethod->currentText());
            
            if (m_injectionManager->inject()) {
                m_isInjected = true;
                QMetaObject::invokeMethod(this, [this]() {
                    m_stopButton->setEnabled(true);
                    m_progressBar->setVisible(false);
                    m_statusLabel->setText("Injection successful!");
                    m_injectionStatusLabel->setText("Injection: Active");
                    m_logger->log(Logger::Success, "Successfully injected into BGMI process");
                });
            } else {
                QMetaObject::invokeMethod(this, [this]() {
                    m_injectButton->setEnabled(true);
                    m_progressBar->setVisible(false);
                    m_statusLabel->setText("Injection failed!");
                    m_logger->log(Logger::Error, "Failed to inject into BGMI process");
                    m_errorList->addItem("Injection failed - " + QDateTime::currentDateTime().toString());
                });
            }
        } catch (const std::exception& e) {
            QMetaObject::invokeMethod(this, [this, e]() {
                m_injectButton->setEnabled(true);
                m_progressBar->setVisible(false);
                m_statusLabel->setText("Injection error!");
                m_logger->log(Logger::Error, QString("Injection error: %1").arg(e.what()));
                m_errorList->addItem(QString("Exception: %1 - %2").arg(e.what(), QDateTime::currentDateTime().toString()));
            });
        }
    })->start();
}

void GhostPulseMainWindow::onStopClicked() {
    m_logger->log(Logger::Info, "Stopping injection...");
    
    if (m_injectionManager->uninject()) {
        m_isInjected = false;
        m_injectButton->setEnabled(true);
        m_stopButton->setEnabled(false);
        m_statusLabel->setText("Injection stopped");
        m_injectionStatusLabel->setText("Injection: Inactive");
        m_logger->log(Logger::Success, "Successfully stopped injection");
    } else {
        m_logger->log(Logger::Error, "Failed to stop injection cleanly");
        m_errorList->addItem("Failed to stop injection - " + QDateTime::currentDateTime().toString());
    }
}

void GhostPulseMainWindow::onSettingsChanged() {
    if (m_isInjected) {
        // Apply settings to injected modules
        m_gameInterface->setAimbotEnabled(m_aimbotEnabled->isChecked());
        m_gameInterface->setESPEnabled(m_espEnabled->isChecked());
        m_gameInterface->setWallhackEnabled(m_wallhackEnabled->isChecked());
        m_gameInterface->setAimbotSensitivity(m_aimbotSensitivity->value());
        
        m_logger->log(Logger::Info, "Settings updated and applied to game");
    }
}

void GhostPulseMainWindow::updateStatus() {
    // Update game status
    if (m_gameInterface->isGameRunning()) {
        m_currentGameVersion = m_gameInterface->getGameVersion();
        m_gameStatusLabel->setText(QString("Game: BGMI %1 Detected").arg(m_currentGameVersion));
    } else {
        m_gameStatusLabel->setText("Game: Not Detected");
    }
    
    // Update system resources
    auto memUsage = m_statusMonitor->getMemoryUsage();
    auto cpuUsage = m_statusMonitor->getCPUUsage();
    
    m_memoryUsageLabel->setText(QString("Memory: %1 MB").arg(memUsage));
    m_cpuUsageLabel->setText(QString("CPU: %1%").arg(cpuUsage, 0, 'f', 1));
}

void GhostPulseMainWindow::onLogMessage(const QString& level, const QString& message) {
    QString timestamp = QDateTime::currentDateTime().toString("hh:mm:ss");
    QString coloredMessage;
    
    if (level == "ERROR") {
        coloredMessage = QString("<span style='color: #ff6b6b;'>[%1] %2: %3</span>").arg(timestamp, level, message);
    } else if (level == "SUCCESS") {
        coloredMessage = QString("<span style='color: #51cf66;'>[%1] %2: %3</span>").arg(timestamp, level, message);
    } else if (level == "WARNING") {
        coloredMessage = QString("<span style='color: #ffd43b;'>[%1] %2: %3</span>").arg(timestamp, level, message);
    } else {
        coloredMessage = QString("<span style='color: #74c0fc;'>[%1] %2: %3</span>").arg(timestamp, level, message);
    }
    
    m_logDisplay->append(coloredMessage);
    
    // Auto-scroll to bottom
    auto cursor = m_logDisplay->textCursor();
    cursor.movePosition(QTextCursor::End);
    m_logDisplay->setTextCursor(cursor);
}

void GhostPulseMainWindow::onProgressUpdate(int percentage, const QString& status) {
    m_progressBar->setValue(percentage);
    m_statusLabel->setText(status);
}

void GhostPulseMainWindow::setupMenuBar() {
    auto fileMenu = menuBar()->addMenu("&File");
    fileMenu->addAction("&Settings", [this]() {
        // Open settings dialog
    });
    fileMenu->addSeparator();
    fileMenu->addAction("E&xit", this, &QWidget::close);
    
    auto helpMenu = menuBar()->addMenu("&Help");
    helpMenu->addAction("&About", [this]() {
        // Show about dialog
    });
}

void GhostPulseMainWindow::setupStatusBar() {
    statusBar()->showMessage("Ready");
}

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    
    app.setApplicationName("GhostPulse BGMI Mod Loader");
    app.setApplicationVersion("3.9");
    app.setOrganizationName("GhostPulse Team");
    
    GhostPulseMainWindow window;
    window.show();
    
    return app.exec();
}

#include "main.moc"